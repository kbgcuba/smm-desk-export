import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import path from "node:path";

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), "..");
const file = path.join(root, "src/lib/smm/add-match.test.ts");
const result = spawnSync(process.execPath, ["--experimental-strip-types", "--test", file], { stdio: "inherit" });
process.exit(result.status ?? 1);
