#!/usr/bin/env node
/** Live + shape checks for SMM catalogs. Read-only (action=services). */

import { parseCatalogSnap, catalogNeedsPull, isCatalogFresh } from "../src/lib/smm/catalog-snap.ts";
import { matchesAdd } from "../src/lib/smm/add-match.ts";

const PANELS = [
  { id: "smmwiz", url: "https://smmwiz.com/api/v2", key: "de3287f940ed663f8c6dc2c7d797e639", pins: [19968, 21046] },
  { id: "jap", url: "https://justanotherpanel.com/api/v2", key: "bd00b90a7deec5a5db8524a8bf70a80e", pins: [4268] },
  { id: "smmfanz", url: "https://smmfanz.com/api/v2", key: "5d0e0aa810000429da9e14366a898e78", pins: [12492] },
];

const fail = [];
function ok(name, cond, extra = "") {
  if (cond) console.log(`  pass  ${name}${extra ? `  ${extra}` : ""}`);
  else {
    console.log(`  FAIL  ${name}${extra ? `  ${extra}` : ""}`);
    fail.push(name);
  }
}

async function loadPanel(p) {
  const t0 = Date.now();
  const body = new URLSearchParams({ key: p.key, action: "services" });
  const res = await fetch(p.url, {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded", accept: "application/json" },
    body,
    signal: AbortSignal.timeout(45_000),
  });
  const ms = Date.now() - t0;
  if (!res.ok) throw new Error(`${p.id} HTTP ${res.status} in ${ms}ms`);
  const json = await res.json();
  if (!Array.isArray(json)) throw new Error(`${p.id} not a list (${typeof json}) in ${ms}ms`);
  return { ms, rows: json };
}

function asService(panel, row) {
  const id = Number(row.service);
  return {
    panel,
    id,
    name: String(row.name || ""),
    category: String(row.category || ""),
    rate: row.rate == null ? "0" : String(row.rate),
    min: Number(row.min) || 1,
    max: Number(row.max) || 0,
    type: String(row.type || "Default"),
    dripfeed: row.dripfeed === true || row.dripfeed === 1 || row.dripfeed === "1",
    refill: row.refill === true || row.refill === 1 || row.refill === "1",
    cancel: row.cancel === true || row.cancel === 1 || row.cancel === "1",
    averageTime: row.avg_time != null ? String(row.avg_time) : null,
    speed: null,
  };
}

console.log("catalog snap (offline)");
{
  const snap = parseCatalogSnap({
    at: Date.now(),
    services: [
      { panel: "smmwiz", id: 19968, name: "TikTok Views", rate: "0.1", min: 100, max: 1e7, dripfeed: true, refill: true },
      { panel: "smmwiz", id: 19968, name: "dup" },
    ],
  });
  ok("parse keeps pinned view", snap?.services[0]?.id === 19968);
  ok("parse drops dupe", snap?.services.length === 1);
  const t = 1_700_000_000_000;
  ok("fresh 4 min does not pull", catalogNeedsPull(true, t - 4 * 60 * 1000, false, t) === false);
  ok("stale 6 min pulls", catalogNeedsPull(true, t - 6 * 60 * 1000, false, t) === true);
  ok("empty list pulls", catalogNeedsPull(false, 0, false, t) === true);
  ok("at=0 is not fresh", isCatalogFresh(0, t) === false);
}

console.log("\nlive panels");
const loaded = await Promise.all(
  PANELS.map(async (p) => {
    try {
      const { ms, rows } = await loadPanel(p);
      return { ...p, ms, rows, error: null };
    } catch (err) {
      return { ...p, ms: 0, rows: [], error: err instanceof Error ? err.message : String(err) };
    }
  }),
);

const all = [];
for (const p of loaded) {
  if (p.error) {
    ok(`${p.id} catalog`, false, p.error);
    continue;
  }
  ok(`${p.id} catalog`, p.rows.length > 0, `${p.rows.length} services in ${p.ms}ms`);
  ok(`${p.id} under 45s`, p.ms < 45_000, `${p.ms}ms`);
  const byId = new Map(p.rows.map((r) => [Number(r.service), r]));
  for (const id of p.pins) {
    const hit = byId.get(id);
    ok(`${p.id} pin ${id}`, Boolean(hit), hit ? String(hit.name || "").slice(0, 72) : "missing");
    if (hit) {
      ok(`${p.id} ${id} has rate`, Number(hit.rate) >= 0, `rate=${hit.rate}`);
      ok(`${p.id} ${id} has min/max`, Number(hit.min) > 0 && Number(hit.max) >= Number(hit.min), `min=${hit.min} max=${hit.max}`);
    }
  }
  const mapped = p.rows.map((r) => asService(p.id, r)).filter((s) => s.name && s.id > 0);
  all.push(...mapped);
}

ok("combined catalog", all.length > 100, `${all.length} named services`);

const snap = parseCatalogSnap({ at: Date.now(), services: all });
ok("snap accepts live catalog", Boolean(snap && snap.services.length === all.length), `snap=${snap?.services.length ?? 0}`);

const pins = [
  { panel: "smmwiz", id: 19968, platform: "tiktok", metric: "views" },
  { panel: "smmwiz", id: 21046, platform: "tiktok", metric: "views" },
  { panel: "jap", id: 4268, platform: "tiktok", metric: "likes" },
  { panel: "smmfanz", id: 12492, platform: "youtube", metric: "views" },
];
console.log("\npinned match");
for (const pin of pins) {
  const s = all.find((row) => row.panel === pin.panel && row.id === pin.id);
  if (!s) {
    ok(`${pin.panel}:${pin.id} in catalog`, false);
    continue;
  }
  ok(`${pin.panel}:${pin.id} matches ${pin.platform} ${pin.metric}`, matchesAdd(pin.platform, pin.metric, s), s.name.slice(0, 80));
  ok(`${pin.panel}:${pin.id} not the other metric`, !matchesAdd(pin.platform, pin.metric === "views" ? "likes" : "views", s) || pin.metric === "likes");
}

const drip = all.filter((s) => s.dripfeed).length;
const refill = all.filter((s) => s.refill).length;
ok("some drip-feed flags", drip > 0, `${drip}`);
ok("some refill flags", refill > 0, `${refill}`);

console.log(`\n${fail.length ? "FAILED" : "ok"}  ${fail.length} issue(s)`);
if (fail.length) {
  for (const name of fail) console.log(" -", name);
  process.exit(1);
}
