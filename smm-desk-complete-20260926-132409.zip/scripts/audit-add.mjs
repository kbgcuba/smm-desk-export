import { writeFileSync } from "node:fs";

const PLATFORM_RE = {
  tiktok: /tiktok|\btik\s*tok\b|\btt\b/i,
  youtube: /youtube|youtu\.be|\byt\b/i,
  instagram: /instagram|\binsta\b|\big\b/i,
  facebook: /facebook|\bfb\b/i,
  twitter: /twitter|\btweets?\b|\bx\.com\b/i,
  telegram: /telegram|\btg\b/i,
  spotify: /spotify/i,
};
const METRIC_RE = {
  page: /page\s*likes?/i,
  comments: /\bcomments?\b/i,
  shares: /\bshares?\b|\breposts?\b|\bforwards?\b/i,
  saves: /\bsaves?\b|\bsaved\b|\bbookmarks?\b|\bfavorites?\b/i,
  likes: /\blikes?\b/i,
  reactions: /\breactions?\b|\blove\b|\bhaha\b|\bangry\b|\bcare\b|\bwow\b/i,
  followers: /\bfollow(?:ers?|s)?\b/i,
  subs: /\bsubscribers?\b|\bsubs?\b/i,
  watch: /watch\s*hours?|watch\s*time|\bretention\b/i,
  reach: /\breach\b|\bimpressions?\b/i,
  views: /\bviews?\b|\bplays?\b/i,
};
const PRODUCT_IDS = ["page", "comments", "shares", "saves", "reactions", "likes", "followers", "subs", "watch", "reach", "views"];
const PILLS = {
  tiktok: ["views", "likes", "comments", "shares", "saves"],
  youtube: ["views", "likes", "comments"],
  instagram: ["views", "likes", "comments", "shares", "saves"],
  facebook: ["views", "reactions", "comments", "shares"],
};
const EXTRA = {
  tiktok: /tiktok|\btik\s*tok\b|\btt\b/i,
  youtube: /youtube|\byt\b/i,
  instagram: /instagram|\binsta\b|\big\b/i,
  facebook: /facebook|\bfb\b/i,
};

function decodeHay(v) {
  return String(v || "").replace(/&(amp|AMP);/g, "&").replace(/\[[^\]]*\]/g, " ").replace(/\s+/g, " ").trim();
}
function metricOf(hay) {
  if (!hay) return null;
  if (/comment\s*likes?/i.test(hay)) return "likes";
  if (/page\s*likes?/i.test(hay) && !/post\s*likes?/i.test(hay)) return "page";
  let best = null;
  for (const id of PRODUCT_IDS) {
    const m = METRIC_RE[id]?.exec(hay);
    if (!m || m.index == null) continue;
    if (!best || m.index < best.at) best = { id, at: m.index };
  }
  return best?.id ?? null;
}
function metricsEqual(platform, a, b) {
  if (a === b) return true;
  if (platform === "facebook" && (b === "reactions" || b === "likes")) return a === "likes" || a === "reactions";
  if (platform === "youtube" && (b === "subs" || b === "followers")) return a === "subs" || a === "followers";
  return false;
}
function headHay(hay) {
  return (hay.split(/[|–—]/)[0] ?? hay).slice(0, 80);
}
function primaryPlatform(hay) {
  const text = String(hay || "").replace(/\bfrom\s+(?:tiktok|youtube|instagram|facebook|twitter|x)\b/gi, " ");
  let best = null;
  for (const [id, re] of Object.entries(PLATFORM_RE)) {
    const m = re.exec(text);
    if (!m || m.index == null) continue;
    if (!best || m.index < best.at) best = { id, at: m.index };
  }
  return best?.id ?? null;
}
function belongsTo(platform, hay, extra) {
  const target = hay.replace(/\bfrom\s+(?:tiktok|youtube|instagram|facebook|twitter|x)\b/gi, " ");
  const head = (target.split(/[|–—]/)[0] ?? target).slice(0, 72);
  const primary = primaryPlatform(head);
  if (primary) return primary === platform;
  if (extra?.test(head)) return true;
  return false;
}
function nameHasMetric(platform, metric, name) {
  if (METRIC_RE[metric]?.test(name)) return true;
  if (platform === "facebook" && (metric === "reactions" || metric === "likes")) {
    return Boolean(METRIC_RE.likes.test(name) || METRIC_RE.reactions.test(name));
  }
  return false;
}
function matchesAdd(platform, metric, s) {
  const name = decodeHay(s.name || "");
  const all = `${decodeHay(s.category || "")} ${name}`;
  const hay = name || all;
  const primary = primaryPlatform(hay);
  if (primary && primary !== platform) return false;
  if (!belongsTo(platform, hay, EXTRA[platform])) return false;
  if (/\blive\b/i.test(s.name || "") && metric !== "comments") return false;
  const product = metricOf(headHay(name)) ?? metricOf(name);
  if (product) return metricsEqual(platform, product, metric);
  return nameHasMetric(platform, metric, name);
}

const OFF_TYPE = /\b(community\s*post|page\s*(?:like|follow|review|fan)|group\s*(?:member|join)|profile\s*visit|pk\s*battle|watch\s*hour|subscriber|website|web\s*traffic|seo\s*traffic)\b/i;

const PANELS = [
  { id: "smmwiz", url: "https://smmwiz.com/api/v2", key: "de3287f940ed663f8c6dc2c7d797e639" },
  { id: "jap", url: "https://justanotherpanel.com/api/v2", key: "bd00b90a7deec5a5db8524a8bf70a80e" },
  { id: "smmfanz", url: "https://smmfanz.com/api/v2", key: "5d0e0aa810000429da9e14366a898e78" },
];

async function loadPanel(p) {
  const body = new URLSearchParams({ key: p.key, action: "services" });
  const res = await fetch(p.url, { method: "POST", headers: { "content-type": "application/x-www-form-urlencoded" }, body });
  const json = await res.json();
  if (!Array.isArray(json)) throw new Error(`${p.id} not a list`);
  return json.map((s) => ({ panel: p.id, id: s.service, name: String(s.name || ""), category: String(s.category || "") }));
}

const services = (await Promise.all(PANELS.map((p) => loadPanel(p).catch((e) => { console.error(p.id, e.message); return []; })))).flat();
console.log("catalog", services.length);

const otherPlat = (name, platform) =>
  Object.keys(PLATFORM_RE).filter((id) => id !== platform && PLATFORM_RE[id].test(name));

const report = [];
let hard = 0;
let warn = 0;
for (const [platform, metrics] of Object.entries(PILLS)) {
  for (const metric of metrics) {
    const hits = services.filter((s) => matchesAdd(platform, metric, s));
    const bad = [];
    const odd = [];
    for (const s of hits) {
      const name = decodeHay(s.name);
      const product = metricOf(headHay(name)) ?? metricOf(name);
      const primary = primaryPlatform(s.name);
      const others = otherPlat(headHay(s.name), platform);
      const okProduct = product ? metricsEqual(platform, product, metric) : nameHasMetric(platform, metric, name);
      if ((primary && primary !== platform) || !okProduct) {
        bad.push(s.name.slice(0, 100));
        hard += 1;
      } else if (others.length || OFF_TYPE.test(s.name)) {
        odd.push({ why: others.length ? `also:${others.join(",")}` : "type", name: s.name.slice(0, 100) });
        warn += 1;
      }
    }
    report.push({
      platform,
      metric,
      count: hits.length,
      first: hits.slice(0, 4).map((s) => s.name.replace(/\s+/g, " ").slice(0, 70)),
      hard: bad.slice(0, 8),
      warn: odd.slice(0, 8),
    });
  }
}

console.log(JSON.stringify({ hard, warn, report }, null, 2));
writeFileSync("/tmp/add-audit.json", JSON.stringify({ total: services.length, hard, warn, report }, null, 2));
if (hard) process.exit(1);
