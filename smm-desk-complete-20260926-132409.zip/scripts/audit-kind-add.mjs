import { writeFileSync } from "node:fs";

const PLATFORM_RE = {
  tiktok: /tiktok|\btik\s*tok\b|\btt\b/i,
  youtube: /youtube|youtu\.be|\byt\b/i,
  instagram: /instagram|\binsta\b|\big\b/i,
  facebook: /facebook|\bfb\b/i,
  twitter: /twitter|\btweets?\b|\bx\.com\b/i,
  telegram: /telegram|\btg\b/i,
  spotify: /spotify/i,
};
const METRIC_RE = {
  page: /page\s*likes?/i,
  comments: /\bcomments?\b/i,
  shares: /\bshares?\b|\breposts?\b|\bforwards?\b/i,
  saves: /\bsaves?\b|\bsaved\b|\bbookmarks?\b|\bfavorites?\b/i,
  likes: /\blikes?\b/i,
  reactions: /\breactions?\b|\blove\b|\bhaha\b|\bangry\b|\bcare\b|\bwow\b/i,
  followers: /\bfollow(?:ers?|s)?\b/i,
  subs: /\bsubscribers?\b|\bsubs?\b/i,
  watch: /watch\s*hours?|watch\s*time|\bretention\b/i,
  reach: /\breach\b|\bimpressions?\b/i,
  views: /\bviews?\b|\bplays?\b/i,
};
const PRODUCT_IDS = ["page", "comments", "shares", "saves", "reactions", "likes", "followers", "subs", "watch", "reach", "views"];
const EXTRA = {
  tiktok: /tiktok|\btik\s*tok\b|\btt\b/i,
  youtube: /youtube|\byt\b/i,
  instagram: /instagram|\binsta\b|\big\b/i,
  facebook: /facebook|\bfb\b/i,
};
const PILLS = {
  tiktok: { kinds: ["video"], metrics: ["views", "likes", "comments", "shares", "saves"] },
  youtube: { kinds: ["short", "video"], metrics: ["views", "likes", "comments"] },
  instagram: { kinds: ["reel", "post"], metrics: ["views", "likes", "comments", "shares", "saves"] },
  facebook: { kinds: ["reel", "post"], metrics: ["views", "reactions", "comments", "shares"] },
};

function decodeHay(v) {
  return String(v || "").replace(/&(amp|AMP);/g, "&").replace(/\[[^\]]*\]/g, " ").replace(/\s+/g, " ").trim();
}
function metricOf(hay) {
  if (!hay) return null;
  if (/comments?\s+likes?/i.test(hay) || /comment\s*likes?/i.test(hay)) return "likes";
  if (/page\s*likes?/i.test(hay) && !/post\s*likes?/i.test(hay)) return "page";
  let best = null;
  for (const id of PRODUCT_IDS) {
    const m = METRIC_RE[id]?.exec(hay);
    if (!m || m.index == null) continue;
    if (!best || m.index < best.at) best = { id, at: m.index };
  }
  return best?.id ?? null;
}
function metricsEqual(platform, a, b) {
  if (a === b) return true;
  if (platform === "facebook" && (b === "reactions" || b === "likes")) return a === "likes" || a === "reactions";
  return false;
}
function headHay(hay) {
  return (hay.split(/[|–—]/)[0] ?? hay).slice(0, 80);
}
function primaryPlatform(hay) {
  const text = String(hay || "").replace(/\bfrom\s+(?:tiktok|youtube|instagram|facebook|twitter|x)\b/gi, " ");
  let best = null;
  for (const [id, re] of Object.entries(PLATFORM_RE)) {
    const m = re.exec(text);
    if (!m || m.index == null) continue;
    if (!best || m.index < best.at) best = { id, at: m.index };
  }
  return best?.id ?? null;
}
function belongsTo(platform, hay, extra) {
  const target = hay.replace(/\bfrom\s+(?:tiktok|youtube|instagram|facebook|twitter|x)\b/gi, " ");
  const head = (target.split(/[|–—]/)[0] ?? target).slice(0, 72);
  const primary = primaryPlatform(head);
  if (primary) return primary === platform;
  if (extra?.test(head)) return true;
  return false;
}
function contentOf(hay) {
  const text = decodeHay(hay);
  if (/\bshorts?\b/i.test(text)) return "short";
  if (/\breels?\b/i.test(text)) return "reel";
  if (/\bigtv\b/i.test(text)) return "reel";
  if (/\bstor(?:y|ies)\b/i.test(text)) return "story";
  if (/\blive\s*(streams?|chats?|videos?|broadcasts?|rooms?)\b/i.test(text)) return "live";
  if (/\bposts?\b/i.test(text) && !/\breposts?\b/i.test(text)) return "post";
  if (/\b(videos?|watch)\b/i.test(text)) return "video";
  return "any";
}
function kindFits(itemKind, serviceKind) {
  if (!itemKind || serviceKind === "any") return true;
  if (serviceKind === "story" || serviceKind === "live") return itemKind === serviceKind;
  if (itemKind === "short") return serviceKind === "short";
  if (itemKind === "reel") return serviceKind === "reel" || serviceKind === "video";
  if (itemKind === "post") return serviceKind === "post";
  if (itemKind === "video") return serviceKind === "video";
  return serviceKind === itemKind;
}
function kindRank(itemKind, serviceKind) {
  if (!itemKind || serviceKind === itemKind) return 0;
  if (itemKind === "reel" && serviceKind === "video") return 1;
  if (serviceKind === "any") return 2;
  return 9;
}
function nameHasMetric(platform, metric, name) {
  if (METRIC_RE[metric]?.test(name)) return true;
  if (platform === "facebook" && (metric === "reactions" || metric === "likes")) {
    return Boolean(METRIC_RE.likes.test(name) || METRIC_RE.reactions.test(name));
  }
  return false;
}
function matchesAdd(platform, metric, s, kind) {
  const name = decodeHay(s.name || "");
  const all = `${decodeHay(s.category || "")} ${name}`;
  const hay = name || all;
  const primary = primaryPlatform(hay);
  if (primary && primary !== platform) return false;
  if (!belongsTo(platform, hay, EXTRA[platform])) return false;
  if (/community\s*posts?/i.test(s.name || "")) return false;
  if (/\blive\s*(streams?|chats?|videos?|broadcasts?|rooms?)\b/i.test(s.name || "")) return false;
  if (/\blive\b/i.test(s.name || "") && metric !== "comments") return false;
  if (kind && !kindFits(kind, contentOf(name))) return false;
  const product = metricOf(headHay(name)) ?? metricOf(name);
  if (product) return metricsEqual(platform, product, metric);
  return nameHasMetric(platform, metric, name);
}

const WRONG = {
  short: /\b(long\s*form|community\s*post)\b/i,
  video: /\bshorts?\b/i,
  reel: /\b(stor(?:y|ies)|igtv\b|post\s*likes?)\b/i,
  post: /\b(reels?|shorts?|stor(?:y|ies)|igtv)\b/i,
};

const PANELS = [
  { id: "smmwiz", url: "https://smmwiz.com/api/v2", key: "de3287f940ed663f8c6dc2c7d797e639" },
  { id: "jap", url: "https://justanotherpanel.com/api/v2", key: "bd00b90a7deec5a5db8524a8bf70a80e" },
  { id: "smmfanz", url: "https://smmfanz.com/api/v2", key: "5d0e0aa810000429da9e14366a898e78" },
];

async function loadPanel(p) {
  const res = await fetch(p.url, {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ key: p.key, action: "services" }),
  });
  const json = await res.json();
  if (!Array.isArray(json)) throw new Error(p.id);
  return json.map((s) => ({ panel: p.id, id: s.service, name: String(s.name || ""), category: String(s.category || "") }));
}

const services = (await Promise.all(PANELS.map((p) => loadPanel(p).catch((e) => { console.error(p.id, e.message); return []; })))).flat();
console.log("catalog", services.length);

const report = [];
let leaks = 0;
let empty = 0;
for (const [platform, { kinds, metrics }] of Object.entries(PILLS)) {
  for (const kind of kinds) {
    for (const metric of metrics) {
      const hits = services
        .filter((s) => matchesAdd(platform, metric, s, kind))
        .sort((a, b) => kindRank(kind, contentOf(a.name)) - kindRank(kind, contentOf(b.name)));
      const bad = [];
      for (const s of hits) {
        const c = contentOf(s.name);
        const primary = primaryPlatform(s.name);
        const product = metricOf(headHay(decodeHay(s.name))) ?? metricOf(decodeHay(s.name));
        const okProduct = product ? metricsEqual(platform, product, metric) : nameHasMetric(platform, metric, decodeHay(s.name));
        const wrongKind = !kindFits(kind, c);
        const wrongPlat = primary && primary !== platform;
        const nameLeak = WRONG[kind]?.test(s.name) && c !== "any" && c !== kind && !(kind === "reel" && c === "video");
        if (wrongKind || wrongPlat || !okProduct || nameLeak) {
          bad.push({ why: wrongPlat ? "plat" : wrongKind ? "kind" : !okProduct ? "product" : "name", c, name: s.name.slice(0, 96) });
          leaks += 1;
        }
      }
      const mix = { any: 0, exact: 0, other: 0 };
      for (const s of hits) {
        const c = contentOf(s.name);
        if (c === "any") mix.any += 1;
        else if (c === kind || (kind === "reel" && c === "video")) mix.exact += 1;
        else mix.other += 1;
      }
      if (!hits.length) empty += 1;
      report.push({
        platform,
        kind,
        metric,
        count: hits.length,
        mix,
        first: hits.slice(0, 3).map((s) => `${contentOf(s.name)} · ${s.name.replace(/\s+/g, " ").slice(0, 68)}`),
        leaks: bad.slice(0, 6),
      });
    }
  }
}

console.log(JSON.stringify({ catalog: services.length, leaks, empty, report }, null, 2));
writeFileSync("/tmp/kind-audit.json", JSON.stringify({ catalog: services.length, leaks, empty, report }, null, 2));
if (leaks) process.exit(1);
