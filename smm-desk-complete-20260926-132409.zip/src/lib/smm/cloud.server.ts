import { createHash, randomBytes } from "node:crypto";
import { readFile } from "node:fs/promises";
import path from "node:path";
import type { PanelId } from "@/lib/smm/types";
import type { DeskDef } from "@/lib/smm/desks";
import { getSql, type Sql } from "@/lib/db";
import type { TrackedProfile } from "@/lib/smm/profile-types";
import { mergeDesks, mergeFavorites, mergePanels, mergePrefs, mergeProfiles, unionOrders, unionRefills, type PanelSnap, type PrefsDump } from "@/lib/smm/merge";
import { emptyWpList, mergeSavedBadges, parseStyle, parseWpList, sanitizeBadges, sanitizeWpItems, WP_REST_HOOK, type WpList } from "@/lib/smm/wp-list.ts";
import { claudiaIvoryLinks } from "@/lib/smm/ci-links.ts";

export type CloudOrder = {
  panel: PanelId;
  order: string;
  service: number;
  name: string;
  link: string;
  quantity: number;
  refill: boolean;
  at: number;
  desk?: string;
  thumb?: string | null;
  mediaTitle?: string | null;
  refilledAt?: number;
  actual?: number | null;
  actualAt?: number;
  metric?: "views" | "likes" | "comments";
  start?: number;
  remains?: number;
  panelStatus?: string;
  panelRefill?: boolean;
  source?: "post" | "panel" | null;
  startOnPost?: number | null;
  doneOnPost?: number | null;
  viewsAt?: number;
  viewsClosedAt?: number;
  runs?: number;
  panelRuns?: number;
};

export type CloudDump = {
  orders: CloudOrder[];
  refills: { panel: PanelId; order: string; at: number }[];
  desks: DeskDef[];
  desksAt: number;
  gone: Record<string, number>;
  prefs: PrefsDump;
  panels: PanelSnap[];
  profiles: TrackedProfile[];
  profilesAt: number;
  savedAt: number;
  social?: { id: string; token: string; extra: string }[];
  accessPassword?: string;
  accessDevices?: AccessDevice[];
  wp?: WpList;
};

export type AccessDevice = { id: string; name: string; at: number; stamp: string };

const DESK_ID = "desk";
const bus = new EventTarget();
const emptyPrefs: PrefsDump = {
  lastService: {},
  lastQty: {},
  recentLinks: [],
  autoRefill: true,
  lastAccount: "",
  lastAccountAt: 0,
};

function emptyDump(): CloudDump {
  return {
    orders: [],
    refills: [],
    desks: [],
    desksAt: 0,
    gone: {},
    prefs: { ...emptyPrefs, lastService: {}, lastQty: {}, recentLinks: [] },
    panels: [],
    profiles: [],
    profilesAt: 0,
    savedAt: 0,
    social: [],
    accessPassword: "",
    accessDevices: [],
    wp: emptyWpList(),
  };
}

export function onCloudWrite(fn: () => void): () => void {
  const handler = () => fn();
  bus.addEventListener("change", handler);
  return () => bus.removeEventListener("change", handler);
}

function asDump(raw: unknown): CloudDump | null {
  if (typeof raw === "string") {
    try {
      raw = JSON.parse(raw) as unknown;
    } catch {
      return null;
    }
  }
  if (!raw || typeof raw !== "object") return null;
  const d = raw as CloudDump;
  if (!Array.isArray(d.orders)) return null;
  return {
    orders: d.orders,
    refills: Array.isArray(d.refills) ? d.refills : [],
    desks: Array.isArray(d.desks) ? d.desks : [],
    desksAt: typeof d.desksAt === "number" ? d.desksAt : 0,
    gone: d.gone && typeof d.gone === "object" ? d.gone : {},
    prefs: {
      lastService: d.prefs?.lastService ?? {},
      lastQty: d.prefs?.lastQty ?? {},
      recentLinks: Array.isArray(d.prefs?.recentLinks) ? d.prefs.recentLinks : [],
      autoRefill: d.prefs?.autoRefill !== false,
      lastAccount: typeof d.prefs?.lastAccount === "string" ? d.prefs.lastAccount : "",
      lastAccountAt: typeof d.prefs?.lastAccountAt === "number" ? d.prefs.lastAccountAt : 0,
    },
    panels: Array.isArray(d.panels) ? d.panels : [],
    profiles: Array.isArray((d as CloudDump).profiles) ? (d as CloudDump).profiles : [],
    profilesAt: typeof (d as CloudDump).profilesAt === "number" ? (d as CloudDump).profilesAt : 0,
    savedAt: typeof d.savedAt === "number" ? d.savedAt : 0,
    social: Array.isArray((d as CloudDump).social)
      ? (d as CloudDump).social!.filter((row) => row && typeof row.id === "string" && typeof row.token === "string")
      : [],
    accessPassword: typeof (d as CloudDump).accessPassword === "string" ? (d as CloudDump).accessPassword : "",
    accessDevices: Array.isArray((d as CloudDump).accessDevices)
      ? (d as CloudDump).accessDevices!.filter((row) => row && typeof row.id === "string").map((row) => ({
          id: String(row.id),
          name: String(row.name || "Device"),
          at: Number(row.at) || 0,
          stamp: String(row.stamp || ""),
        }))
      : [],
    wp: parseWpList((d as CloudDump).wp),
  };
}

async function seedFromFiles(): Promise<CloudDump> {
  const next = emptyDump();
  try {
    const raw = await readFile(path.join(process.cwd(), "data", "smm-cloud.json"), "utf8");
    const dump = asDump(JSON.parse(raw));
    if (dump) Object.assign(next, dump);
  } catch {
    /* no file */
  }
  try {
    const raw = await readFile(path.join(process.cwd(), "data", "smm-settings.json"), "utf8");
    const json = JSON.parse(raw) as { desks?: DeskDef[]; prefs?: PrefsDump; panels?: PanelSnap[]; savedAt?: number };
    next.desks = mergeDesks(next.desks, json.desks ?? []);
    if (json.prefs) next.prefs = mergePrefs(next.prefs, json.prefs, next.savedAt, json.savedAt ?? 0);
    next.panels = mergePanels(next.panels, json.panels ?? []);
    next.savedAt = Math.max(next.savedAt, json.savedAt ?? 0);
  } catch {
    /* no file */
  }
  return next;
}

async function ensureRow(sql: Sql): Promise<void> {
  const hit = await sql.query<{ id: string }>("select id from smm_cloud where id = $1", [DESK_ID]);
  if (hit.length) return;
  const seed = await seedFromFiles();
  await sql.query("insert into smm_cloud (id, dump, version) values ($1, $2, $3) on conflict (id) do nothing", [
    DESK_ID,
    JSON.stringify(seed),
    0,
  ]);
}

type OrderRow = {
  panel: string;
  order_id: string;
  placed_at: number | string;
  desk: string;
  service: number;
  name: string;
  link: string;
  quantity: number;
  refill: boolean;
  body: unknown;
};

function orderToBody(row: CloudOrder): Record<string, unknown> {
  return {
    thumb: row.thumb ?? null,
    mediaTitle: row.mediaTitle ?? null,
    refilledAt: row.refilledAt,
    actual: row.actual ?? null,
    actualAt: row.actualAt,
    metric: row.metric,
    start: row.start,
    remains: row.remains,
    panelStatus: row.panelStatus,
    panelRefill: row.panelRefill,
    source: row.source ?? null,
    startOnPost: row.startOnPost ?? null,
    doneOnPost: row.doneOnPost ?? null,
    viewsAt: row.viewsAt,
    viewsClosedAt: row.viewsClosedAt,
  };
}

function rowToOrder(row: OrderRow): CloudOrder {
  const body =
    row.body && typeof row.body === "object" && !Array.isArray(row.body)
      ? (row.body as Record<string, unknown>)
      : typeof row.body === "string"
        ? (JSON.parse(row.body) as Record<string, unknown>)
        : {};
  const placed = Number(row.placed_at);
  return {
    panel: row.panel as PanelId,
    order: row.order_id,
    service: Number(row.service) || 0,
    name: row.name ?? "",
    link: row.link ?? "",
    quantity: Number(row.quantity) || 0,
    refill: Boolean(row.refill),
    at: Number.isFinite(placed) ? placed : 0,
    desk: row.desk || undefined,
    thumb: (body.thumb as string | null | undefined) ?? null,
    mediaTitle: (body.mediaTitle as string | null | undefined) ?? null,
    refilledAt: typeof body.refilledAt === "number" ? body.refilledAt : undefined,
    actual: typeof body.actual === "number" ? body.actual : body.actual === null ? null : undefined,
    actualAt: typeof body.actualAt === "number" ? body.actualAt : undefined,
    metric: body.metric === "likes" || body.metric === "comments" || body.metric === "views" ? body.metric : undefined,
    start: typeof body.start === "number" ? body.start : undefined,
    remains: typeof body.remains === "number" ? body.remains : undefined,
    panelStatus: typeof body.panelStatus === "string" ? body.panelStatus : undefined,
    panelRefill: typeof body.panelRefill === "boolean" ? body.panelRefill : undefined,
    source: body.source === "post" || body.source === "panel" ? body.source : body.source === null ? null : undefined,
    startOnPost: typeof body.startOnPost === "number" ? body.startOnPost : body.startOnPost === null ? null : undefined,
    doneOnPost: typeof body.doneOnPost === "number" ? body.doneOnPost : body.doneOnPost === null ? null : undefined,
    viewsAt: typeof body.viewsAt === "number" ? body.viewsAt : undefined,
    viewsClosedAt: typeof body.viewsClosedAt === "number" ? body.viewsClosedAt : undefined,
  };
}

async function upsertOrders(sql: Sql, orders: CloudOrder[]): Promise<void> {
  if (orders.length === 0) return;
  try {
    for (let i = 0; i < orders.length; i += 40) {
      const chunk = orders.slice(i, i + 40);
      const values: unknown[] = [];
      const slots = chunk.map((row, n) => {
        const o = n * 10;
        values.push(
          row.panel,
          row.order,
          row.at,
          row.desk ?? "",
          row.service,
          row.name ?? "",
          row.link ?? "",
          row.quantity,
          row.refill,
          JSON.stringify(orderToBody(row)),
        );
        return `($${o + 1}, $${o + 2}, $${o + 3}, $${o + 4}, $${o + 5}, $${o + 6}, $${o + 7}, $${o + 8}, $${o + 9}, $${o + 10}::jsonb)`;
      });
      await sql.query(
        `insert into smm_orders (panel, order_id, placed_at, desk, service, name, link, quantity, refill, body)
         values ${slots.join(",")}
         on conflict (panel, order_id) do update set
           placed_at = excluded.placed_at,
           desk = excluded.desk,
           service = excluded.service,
           name = excluded.name,
           link = excluded.link,
           quantity = excluded.quantity,
           refill = excluded.refill,
           body = excluded.body`,
        values,
      );
    }
  } catch {
    /* table not ready yet — dump still holds orders */
  }
}

async function listOrderRows(sql: Sql): Promise<CloudOrder[]> {
  try {
    const rows = await sql.query<OrderRow>(
      "select panel, order_id, placed_at, desk, service, name, link, quantity, refill, body from smm_orders order by placed_at desc",
    );
    return rows.map(rowToOrder);
  } catch {
    return [];
  }
}

async function seedOrdersIfEmpty(sql: Sql, dump: CloudDump): Promise<void> {
  try {
    const any = await sql.query<{ "?column?": number }>("select 1 from smm_orders limit 1");
    if (!any.length && dump.orders.length) await upsertOrders(sql, dump.orders);
  } catch {
    /* table not ready */
  }
}

async function ensureOrders(sql: Sql, dump: CloudDump): Promise<CloudOrder[]> {
  await seedOrdersIfEmpty(sql, dump);
  try {
    const rows = await listOrderRows(sql);
    return rows.length ? unionOrders(rows, dump.orders) : dump.orders;
  } catch {
    return dump.orders;
  }
}

async function readRow(sql: Sql): Promise<{ dump: CloudDump; version: number }> {
  await ensureRow(sql);
  const rows = await sql.query<{ dump: string; version: number }>("select dump, version from smm_cloud where id = $1", [
    DESK_ID,
  ]);
  return { dump: asDump(rows[0]?.dump) ?? emptyDump(), version: rows[0]?.version ?? 0 };
}

async function casWrite(sql: Sql, next: CloudDump, version: number): Promise<boolean> {
  const rows = await sql.query<{ version: number }>(
    "update smm_cloud set dump = $1, version = version + 1 where id = $2 and version = $3 returning version",
    [JSON.stringify(next), DESK_ID, version],
  );
  if (rows.length) {
    bus.dispatchEvent(new Event("change"));
    return true;
  }
  return false;
}

function mergeDump(prev: CloudDump, incoming: Partial<CloudDump>): CloudDump {
  const incomingDesks = Array.isArray(incoming.desks) ? incoming.desks : [];
  const inNewer = incomingDesks.length > 0 && (incoming.desksAt ?? 0) >= (prev.desksAt ?? 0);
  const fav = mergeFavorites(
    inNewer ? { desks: incomingDesks, gone: incoming.gone } : { desks: prev.desks, gone: prev.gone },
    inNewer ? { desks: prev.desks, gone: prev.gone } : { desks: incomingDesks, gone: incoming.gone },
  );
  return {
    orders: unionOrders(prev.orders, incoming.orders ?? []),
    refills: unionRefills(prev.refills, incoming.refills ?? []),
    desks: fav.desks.length ? fav.desks : prev.desks,
    desksAt: Math.max(incoming.desksAt ?? 0, prev.desksAt ?? 0),
    gone: fav.gone,
    prefs: mergePrefs(prev.prefs, incoming.prefs ?? prev.prefs, prev.savedAt, incoming.savedAt ?? Date.now()),
    panels: mergePanels(prev.panels, incoming.panels ?? []),
    profiles:
      Array.isArray(incoming.profiles) && (incoming.profilesAt ?? 0) >= (prev.profilesAt ?? 0)
        ? incoming.profiles
        : mergeProfiles(prev.profiles, incoming.profiles ?? []),
    profilesAt: Math.max(incoming.profilesAt ?? 0, prev.profilesAt ?? 0),
    savedAt: Date.now(),
    social: Array.isArray(prev.social) && prev.social.length ? prev.social : incoming.social,
    accessPassword: prev.accessPassword || "",
    accessDevices: Array.isArray(prev.accessDevices) ? prev.accessDevices : [],
    wp: incoming.wp ? mergeWp(prev.wp, incoming.wp) : (prev.wp ?? emptyWpList()),
  };
}

function mergeWp(prev: WpList | undefined, incoming: WpList): WpList {
  const base = prev ?? emptyWpList();
  const badges = Array.isArray(incoming.badges)
    ? mergeSavedBadges(base.badges ?? [], sanitizeBadges(incoming.badges))
    : (base.badges ?? []);
  const extra = new Set(badges.map((row) => row.id));
  return {
    items: sanitizeWpItems(incoming.items, extra),
    hookUrl: incoming.hookUrl?.trim() || base.hookUrl,
    secret: incoming.secret?.trim() || base.secret,
    updatedAt: Math.max(Number(incoming.updatedAt) || 0, base.updatedAt || 0),
    style: parseStyle(incoming.style ?? base.style),
    badges,
  };
}

export async function pullCloud(): Promise<CloudDump | null> {
  const sql = await getSql();
  const { dump } = await readRow(sql);
  const orders = await ensureOrders(sql, dump);
  const wp = dump.wp ?? emptyWpList();
  return { ...dump, orders, social: [], accessPassword: "", accessDevices: [], wp: { ...wp, secret: "" } };
}

export async function pushCloud(incoming: CloudDump): Promise<CloudDump> {
  const sql = await getSql();
  await ensureRow(sql);
  let next = emptyDump();
  for (let i = 0; i < 12; i++) {
    const { dump, version } = await readRow(sql);
    const table = await ensureOrders(sql, dump);
    next = mergeDump({ ...dump, orders: table }, incoming);
    await upsertOrders(sql, next.orders);
    if (await casWrite(sql, next, version)) return next;
  }
  const { dump } = await readRow(sql);
  const table = await ensureOrders(sql, dump);
  next = mergeDump({ ...dump, orders: table }, incoming);
  await upsertOrders(sql, next.orders);
  return next;
}

export type OrderIndexHit = { at: number; desk: string; panel: string; order: string };

export async function loadOrderIndex(start: number, end: number, desk?: string): Promise<OrderIndexHit[]> {
  try {
    const sql = await getSql();
    await ensureRow(sql);
    const { dump } = await readRow(sql);
    await seedOrdersIfEmpty(sql, dump);
    const deskKey = desk?.trim() ?? "";
    const rows = deskKey
      ? await sql.query<{ placed_at: number | string; desk: string; panel: string; order_id: string }>(
          "select placed_at, desk, panel, order_id from smm_orders where desk = $3 and placed_at >= $1 and placed_at < $2 order by placed_at desc",
          [start, end, deskKey],
        )
      : await sql.query<{ placed_at: number | string; desk: string; panel: string; order_id: string }>(
          "select placed_at, desk, panel, order_id from smm_orders where placed_at >= $1 and placed_at < $2 order by placed_at desc",
          [start, end],
        );
    return rows.map((row) => ({
      at: Number(row.placed_at) || 0,
      desk: row.desk ?? "",
      panel: row.panel,
      order: row.order_id,
    }));
  } catch {
    return [];
  }
}

export async function loadOrdersRange(start: number, end: number, desk?: string): Promise<CloudOrder[]> {
  try {
    const sql = await getSql();
    await ensureRow(sql);
    const { dump } = await readRow(sql);
    await seedOrdersIfEmpty(sql, dump);
    const deskKey = desk?.trim() ?? "";
    const rows = deskKey
      ? await sql.query<OrderRow>(
          "select panel, order_id, placed_at, desk, service, name, link, quantity, refill, body from smm_orders where desk = $3 and placed_at >= $1 and placed_at < $2 order by placed_at desc",
          [start, end, deskKey],
        )
      : await sql.query<OrderRow>(
          "select panel, order_id, placed_at, desk, service, name, link, quantity, refill, body from smm_orders where placed_at >= $1 and placed_at < $2 order by placed_at desc",
          [start, end],
        );
    return rows.map(rowToOrder);
  } catch {
    return [];
  }
}

let lastPanels = "";

export async function stampPanels(panels: PanelSnap[]): Promise<void> {
  const key = JSON.stringify(panels);
  if (key === lastPanels) return;
  lastPanels = key;
  const sql = await getSql();
  for (let i = 0; i < 6; i++) {
    const { dump, version } = await readRow(sql);
    const next: CloudDump = {
      ...dump,
      panels: mergePanels(dump.panels, panels),
      savedAt: Date.now(),
    };
    if (await casWrite(sql, next, version)) return;
  }
}

export async function readWpListStored(): Promise<WpList> {
  const sql = await getSql();
  await ensureRow(sql);
  const { dump } = await readRow(sql);
  return dump.wp ?? emptyWpList();
}

export async function readWpList(): Promise<WpList> {
  const sql = await getSql();
  await ensureRow(sql);
  const { dump, version } = await readRow(sql);
  let current = dump.wp ?? emptyWpList();
  let changed = false;
  if (!current.secret) {
    current = { ...current, secret: randomBytes(18).toString("hex") };
    changed = true;
  }
  if (!current.hookUrl.trim()) {
    current = { ...current, hookUrl: WP_REST_HOOK };
    changed = true;
  }
  if (!current.items.length) {
    current = { ...current, items: claudiaIvoryLinks(), updatedAt: Date.now() };
    changed = true;
  }
  if (!changed) return current;
  const row: CloudDump = { ...dump, wp: current };
  if (await casWrite(sql, row, version)) return current;
  return current;
}

export async function saveWpList(input: WpList): Promise<{ list: WpList; hook: { ok: boolean; status: number; error: string } }> {
  const sql = await getSql();
  await ensureRow(sql);
  let stored = emptyWpList();
  for (let i = 0; i < 8; i++) {
    const { dump, version } = await readRow(sql);
    const prev = dump.wp ?? emptyWpList();
    const badges = Array.isArray(input.badges)
      ? mergeSavedBadges(prev.badges ?? [], sanitizeBadges(input.badges))
      : (prev.badges ?? []);
    const extra = new Set(badges.map((row) => row.id));
    stored = {
      items: sanitizeWpItems(input.items, extra),
      hookUrl: input.hookUrl.trim() || prev.hookUrl,
      secret: input.secret.trim() || prev.secret,
      updatedAt: Date.now(),
      style: parseStyle(input.style),
      badges,
    };
    const row: CloudDump = { ...dump, wp: stored, savedAt: Date.now() };
    if (await casWrite(sql, row, version)) break;
  }
  const { pushWpHook } = await import("./wp-hook.server.ts");
  const hook = await pushWpHook(stored);
  return { list: stored, hook };
}

export async function readSocialKeys(): Promise<{ id: string; token: string; extra: string }[]> {
  try {
    const sql = await getSql();
    const { dump } = await readRow(sql);
    return Array.isArray(dump.social) ? dump.social : [];
  } catch {
    return [];
  }
}

export async function writeSocialKeys(keys: { id: string; token: string; extra: string }[]): Promise<void> {
  try {
    const sql = await getSql();
    for (let i = 0; i < 8; i++) {
      const { dump, version } = await readRow(sql);
      const next: CloudDump = { ...dump, social: keys, savedAt: Date.now() };
      if (await casWrite(sql, next, version)) return;
    }
  } catch {
    /* file store is enough when the cloud db is down */
  }
}

export async function loadSettings() {
  const dump = (await pullCloud()) ?? emptyDump();
  return { desks: dump.desks, prefs: dump.prefs, panels: dump.panels, savedAt: dump.savedAt };
}

export async function saveSettings(incoming: {
  desks?: DeskDef[];
  prefs?: PrefsDump;
  panels?: PanelSnap[];
  savedAt?: number;
}) {
  const sql = await getSql();
  let next = emptyDump();
  for (let i = 0; i < 8; i++) {
    const { dump, version } = await readRow(sql);
    next = mergeDump(dump, {
      orders: dump.orders,
      refills: dump.refills,
      desks: incoming.desks ?? dump.desks,
      prefs: incoming.prefs ?? dump.prefs,
      panels: incoming.panels ?? dump.panels,
      savedAt: incoming.savedAt ?? Date.now(),
    });
    if (await casWrite(sql, next, version)) return next;
  }
  return next;
}

function gateStamp(secret: string): string {
  return createHash("sha256").update(`smm-gate:v1:${secret}`).digest("hex").slice(0, 32);
}

export async function readAccessPassword(): Promise<string> {
  try {
    const sql = await getSql();
    const { dump } = await readRow(sql);
    return (dump.accessPassword ?? "").trim();
  } catch {
    return "";
  }
}

export async function writeAccessPassword(next: string): Promise<void> {
  const sql = await getSql();
  for (let i = 0; i < 8; i++) {
    const { dump, version } = await readRow(sql);
    const row: CloudDump = { ...dump, accessPassword: next.trim(), accessDevices: next.trim() ? dump.accessDevices : [], savedAt: Date.now() };
    if (await casWrite(sql, row, version)) return;
  }
}

export async function accessGateStatus(deviceId = ""): Promise<{
  locked: boolean;
  stamp: string;
  allowed: boolean;
  token: string;
  devices: { id: string; name: string; at: number }[];
}> {
  const custom = await readAccessPassword();
  if (!custom) return { locked: false, stamp: "", allowed: true, token: "", devices: [] };
  const stamp = gateStamp(custom);
  const sql = await getSql();
  const { dump } = await readRow(sql);
  const devices = (dump.accessDevices ?? []).filter((d) => d.stamp === stamp);
  const { readAccessDevice, signAccess, stampAccessCookie } = await import("./gate.server.ts");
  const id = (await readAccessDevice(custom)) || deviceId.trim();
  const allowed = Boolean(id && devices.some((d) => d.id === id));
  const token = allowed && id ? signAccess(id, custom) : "";
  if (token && id) {
    try {
      await stampAccessCookie(id, custom);
    } catch {
      /* cookie optional — client also stores the token */
    }
  }
  return {
    locked: true,
    stamp,
    allowed,
    token,
    devices: devices.map(({ id, name, at }) => ({ id, name, at })),
  };
}

export async function unlockAccessGate(
  password: string,
  device: { id: string; name: string },
): Promise<{ stamp: string; allowed: boolean; token: string }> {
  const { passwordOk } = await import("./admin.server.ts");
  const custom = await readAccessPassword();
  if (!custom) return { stamp: "", allowed: true, token: "" };
  if (!passwordOk(password, custom)) throw new Error("Wrong password");
  const stamp = gateStamp(custom);
  const id = device.id.trim().slice(0, 64);
  const name = (device.name || "Device").trim().slice(0, 48) || "Device";
  if (!id) throw new Error("Unknown device");
  const sql = await getSql();
  for (let i = 0; i < 8; i++) {
    const { dump, version } = await readRow(sql);
    const rest = (dump.accessDevices ?? []).filter((row) => row.id !== id && row.stamp === stamp);
    const next: CloudDump = {
      ...dump,
      accessDevices: [...rest, { id, name, at: Date.now(), stamp }].slice(-20),
      savedAt: Date.now(),
    };
    if (await casWrite(sql, next, version)) {
      const { stampAccessCookie, signAccess } = await import("./gate.server.ts");
      await stampAccessCookie(id, custom);
      return { stamp, allowed: true, token: signAccess(id, custom) };
    }
  }
  const { stampAccessCookie, signAccess } = await import("./gate.server.ts");
  await stampAccessCookie(id, custom);
  return { stamp, allowed: true, token: signAccess(id, custom) };
}

export async function saveAccessGate(
  adminPassword: string,
  next: string,
  keepDevice?: { id: string; name: string },
): Promise<{ locked: boolean; stamp: string; allowed: boolean; devices: { id: string; name: string; at: number }[] }> {
  const { unlockAdmin } = await import("./admin.server.ts");
  if (!unlockAdmin(adminPassword)) throw new Error("Wrong admin password");
  const value = next.trim();
  const sql = await getSql();
  for (let i = 0; i < 8; i++) {
    const { dump, version } = await readRow(sql);
    const stamp = value ? gateStamp(value) : "";
    const devices =
      value && keepDevice?.id
        ? [{ id: keepDevice.id.trim().slice(0, 64), name: (keepDevice.name || "This device").slice(0, 48), at: Date.now(), stamp }]
        : [];
    const row: CloudDump = { ...dump, accessPassword: value, accessDevices: devices, savedAt: Date.now() };
    if (await casWrite(sql, row, version)) break;
  }
  if (value && keepDevice?.id) {
    const { stampAccessCookie } = await import("./gate.server.ts");
    await stampAccessCookie(keepDevice.id.trim().slice(0, 64), value);
  } else {
    const { clearAccessCookie } = await import("./gate.server.ts");
    await clearAccessCookie();
  }
  return accessGateStatus(keepDevice?.id ?? "");
}

export async function revokeAccessDevice(adminPassword: string, deviceId: string): Promise<{ devices: { id: string; name: string; at: number }[] }> {
  const { unlockAdmin } = await import("./admin.server.ts");
  if (!unlockAdmin(adminPassword)) throw new Error("Wrong admin password");
  const sql = await getSql();
  for (let i = 0; i < 8; i++) {
    const { dump, version } = await readRow(sql);
    const row: CloudDump = {
      ...dump,
      accessDevices: (dump.accessDevices ?? []).filter((d) => d.id !== deviceId),
      savedAt: Date.now(),
    };
    if (await casWrite(sql, row, version)) break;
  }
  const status = await accessGateStatus();
  return { devices: status.devices };
}
