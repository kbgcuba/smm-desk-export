import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { linkReady, pageBrand, publicHttpUrl, resolveBrand } from "./brand-badge.ts";
import { sanitizeBadges, sanitizeWpItems } from "./wp-list.ts";

const NIKE_ON_AMAZON = `<!doctype html><html><head>
<meta property="og:site_name" content="Amazon.com">
<meta name="theme-color" content="#111111">
<script type="application/ld+json">{"@type":"Product","name":"Air","brand":{"@type":"Brand","name":"Nike"}}</script>
</head></html>`;

describe("brand from a link", () => {
  it("rejects local and carrier-grade targets", () => {
    assert.equal(publicHttpUrl("https://example.com/p"), "https://example.com/p");
    assert.equal(publicHttpUrl("https://127.0.0.1/x"), null);
    assert.equal(publicHttpUrl("https://100.64.0.5/x"), null);
    assert.equal(publicHttpUrl("http://metadata.google.internal/"), null);
    assert.equal(linkReady("example.com/p"), "https://example.com/p");
  });

  it("reads the product brand, not the store name", () => {
    const page = pageBrand(NIKE_ON_AMAZON, "https://www.amazon.com/dp/1");
    assert.deepEqual(page.brands, ["Nike"]);
    assert.equal(page.site, "Amazon.com");
  });

  it("reuses the Nike badge when Amazon sells Nike", async () => {
    const hit = await resolveBrand({ pageUrl: "https://www.amazon.com/dp/1", html: NIKE_ON_AMAZON });
    assert.equal(hit?.id, "nike");
    assert.equal(hit?.existing, true);
  });

  it("builds a new circle badge when the brand is not in the list", async () => {
    const html = `<script type="application/ld+json">{"brand":{"name":"Acme Goods"}}</script>`;
    const hit = await resolveBrand({ pageUrl: "https://www.amazon.com/dp/9", html });
    assert.equal(hit?.existing, false);
    assert.equal(hit?.id, "c-acmegoods");
    assert.match(hit?.img ?? "", /^data:image\/svg\+xml;base64,/);
  });

  it("keeps a saved custom badge and drops an unknown one", () => {
    const extra = new Set(["c-acme"]);
    const items = sanitizeWpItems(
      [
        { id: "a", title: "A", url: "https://example.com", badge: "c-acme" },
        { id: "b", title: "B", url: "https://example.com", badge: "c-nope" },
        { id: "c", title: "C", url: "https://example.com", badge: "coach" },
      ],
      extra,
    );
    assert.equal(items[0]?.badge, "c-acme");
    assert.equal(items[1]?.badge, "");
    assert.equal(items[2]?.badge, "coach");
    const badges = sanitizeBadges([
      { id: "c-acme", label: "Acme", bg: "#112233", fg: "#ffffff", img: "", path: "M2 2h4v4H2z", listed: false },
      { id: "nope", label: "Nope", bg: "#111111", fg: "#ffffff", path: "M2 2h4" },
    ]);
    assert.equal(badges.length, 1);
    assert.equal(badges[0]?.listed, false);
    assert.equal(badges[0]?.id, "c-acme");
  });
});
