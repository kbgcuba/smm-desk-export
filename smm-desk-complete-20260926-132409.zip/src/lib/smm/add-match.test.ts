import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { attributeName, matchesAdd } from "./add-match.ts";

const cases: [string, string, string, boolean][] = [
  ["facebook", "comments", "Facebook Followers | Page & Profile | Max 5M | HQ Profiles | Low Drop", false],
  ["facebook", "comments", "Facebook Followers | Page & Profile | Max 5M | HQ Profiles | Low Drop | Instant | Comments", false],
  ["facebook", "comments", "Facebook Comments | HQ Accounts | Drop 0% | Instant Start | No Refill", true],
  ["facebook", "comments", "Facebook Live Comments | Real users", true],
  ["facebook", "comments", "Facebook Post Comments Custom", true],
  ["facebook", "comments", "Facebook Comment Likes | HQ", false],
  ["tiktok", "likes", "TikTok Comment Likes (6068)", false],
  ["tiktok", "comments", "TikTok Comment Likes (6068)", false],
  ["tiktok", "likes", "TikTok Likes (4268)", true],
  ["tiktok", "likes", "TikTok Dislikes", false],
  ["youtube", "views", "YouTube Preview", false],
  ["instagram", "followers", "Instagram Unfollow", false],
  ["instagram", "views", "Instagram Reel Likes", false],
  ["instagram", "likes", "Instagram Reel Likes", true],
  ["instagram", "views", "Instagram Reels Views", true],
  ["facebook", "reactions", "Facebook Followers | Page & Profile", false],
  ["facebook", "reactions", "Facebook Post Likes | HQ", true],
  ["facebook", "reactions", "Facebook Page Likes | Profile", false],
  ["facebook", "reactions", "Facebook Reactions | Love Care", true],
  ["facebook", "followers", "Facebook Followers | Page & Profile", true],
  ["facebook", "followers", "Facebook Comments | HQ", false],
  ["tiktok", "comments", "TikTok Views | No Drop", false],
  ["tiktok", "views", "TikTok Views | No Drop", true],
  ["tiktok", "comments", "TikTok Comments Custom", true],
  ["youtube", "views", "YouTube Views Fast", true],
  ["youtube", "likes", "YouTube Views Fast", false],
  ["youtube", "comments", "YouTube Comments | HQ", true],
  ["instagram", "comments", "Instagram Followers", false],
  ["instagram", "followers", "Instagram Followers", true],
  ["instagram", "likes", "Instagram Likes | Real", true],
  ["facebook", "shares", "Youtube Facebook Shares (10340)", false],
  ["facebook", "shares", "Facebook Post Shares - 0-1 HRS (8248)", true],
  ["facebook", "shares", "Facebook Post Shares (1638)", true],
  ["facebook", "shares", "YouTube Social Shares from Facebook", false],
  ["youtube", "views", "Youtube Facebook Shares", false],
  ["facebook", "views", "YouTube Facebook Video Views", false],
  ["instagram", "likes", "TikTok Instagram Likes", false],
  ["youtube", "likes", "Youtube Community Post Likes [World Wide]", false],
  ["youtube", "likes", "Youtube Likes [No Refill]", true],
  ["youtube", "comments", "Youtube Live Chat Custom Comments", false],
  ["youtube", "comments", "Youtube Costum Comments [World Wide]", true],
  ["tiktok", "comments", "TikTok Live Stream Custom Comments", false],
  ["tiktok", "comments", "Tiktok Custom Comments - [ Max - 100k ]", true],
  ["youtube", "comments", "Youtube Community Post Comments Likes", false],
];

const kinds: [string, string, string, string, boolean][] = [
  ["youtube", "views", "YouTube Views Fast", "short", false],
  ["youtube", "views", "Youtube Short Views [No Drop]", "short", true],
  ["youtube", "views", "Youtube Short Views [No Drop]", "video", false],
  ["youtube", "views", "YouTube Views Fast", "video", true],
  ["facebook", "views", "Facebook views - [ 200k/day ] INSTANT", "post", false],
  ["facebook", "views", "Facebook views - [ 200k/day ] INSTANT", "reel", true],
  ["instagram", "views", "Instagram Views SUPER INSTANT", "post", false],
  ["instagram", "views", "Instagram Views SUPER INSTANT", "reel", true],
  ["instagram", "likes", "Instagram Likes | Real", "reel", true],
  ["instagram", "likes", "Instagram Post Likes [HQ]", "reel", false],
  ["instagram", "likes", "Instagram Post Likes [HQ]", "post", true],
  ["instagram", "views", "Instagram Reels Views", "post", false],
  ["instagram", "views", "Instagram Reels Views", "reel", true],
  ["facebook", "views", "Facebook Video / Reels Views [3 Sec]", "post", false],
  ["facebook", "views", "Facebook Video / Reels Views [3 Sec]", "reel", true],
  ["facebook", "reactions", "Facebook Post Likes | HQ", "reel", false],
  ["facebook", "reactions", "Facebook Post Likes | HQ", "post", true],
  ["facebook", "reactions", "Facebook Reactions | Love Care", "reel", true],
  ["tiktok", "views", "TikTok Views | Non Drop", "video", true],
];

const attrs: [string, string, string, string][] = [
  ["Youtube Facebook Shares (10340)", "youtube", "facebook", "shares"],
  ["TikTok Instagram Likes", "tiktok", "instagram", "likes"],
  ["YouTube Social Shares from Facebook", "youtube", "facebook", "shares"],
  ["Facebook Post Likes | HQ", "facebook", "", "likes"],
  ["YouTube Views Fast", "youtube", "", "views"],
];

describe("matchesAdd (real module)", () => {
  for (const [platform, metric, name, want] of cases) {
    it(`${platform} ${metric} :: ${name.slice(0, 48)} → ${want}`, () => {
      assert.equal(matchesAdd(platform, metric, { name }), want);
    });
  }
});

describe("matchesAdd kind (real module)", () => {
  for (const [platform, metric, name, kind, want] of kinds) {
    it(`${platform} ${metric} ${kind} :: ${name.slice(0, 40)} → ${want}`, () => {
      assert.equal(matchesAdd(platform, metric, { name }, undefined, undefined, kind), want);
    });
  }
});

describe("attributeName (real module)", () => {
  for (const [name, platform, via, metric] of attrs) {
    it(name, () => {
      const got = attributeName(name);
      assert.equal(got.platform, platform);
      if (via) assert.equal(got.via.includes(via), true);
      else assert.equal(got.via.length, 0);
      assert.equal(got.metric, metric);
    });
  }
});
