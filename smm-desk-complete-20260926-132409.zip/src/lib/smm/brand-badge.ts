import { WP_BADGE_DEFS, wpBadge, type WpBadgeDef } from "@/lib/smm/wp-badges.ts";

export type BrandHit = {
  id: string;
  label: string;
  existing: boolean;
  bg: string;
  fg: string;
  img: string;
  path: string;
};

const HOST_BADGE: Record<string, string> = {
  "amazon.com": "amazon",
  "amzn.to": "amazon",
  "a.co": "amazon",
  "ebay.com": "ebay",
  "walmart.com": "walmart",
  "target.com": "target",
  "etsy.com": "etsy",
  "shein.com": "shein",
  "temu.com": "temu",
  "aliexpress.com": "aliexpress",
  "shopify.com": "shopify",
  "nike.com": "nike",
  "adidas.com": "adidas",
  "sephora.com": "sephora",
  "ulta.com": "ulta",
  "nordstrom.com": "nordstrom",
  "macys.com": "macys",
  "ikea.com": "ikea",
  "hm.com": "hm",
  "zara.com": "zara",
  "gap.com": "gap",
  "bestbuy.com": "bestbuy",
  "costco.com": "costco",
  "homedepot.com": "homedepot",
  "lowes.com": "lowes",
  "wayfair.com": "wayfair",
  "chewy.com": "chewy",
  "depop.com": "depop",
  "poshmark.com": "poshmark",
  "mercari.com": "mercari",
  "stockx.com": "stockx",
  "google.com": "google",
  "apple.com": "apple",
  "youtube.com": "youtube",
  "youtu.be": "youtube",
  "instagram.com": "instagram",
  "facebook.com": "facebook",
  "pinterest.com": "pinterest",
  "netflix.com": "netflix",
  "spotify.com": "spotify",
  "paypal.com": "paypal",
  "discord.com": "discord",
  "reddit.com": "reddit",
  "twitch.tv": "twitch",
  "linkedin.com": "linkedin",
  "whatsapp.com": "whatsapp",
  "snapchat.com": "snapchat",
  "airbnb.com": "airbnb",
  "uber.com": "uber",
  "doordash.com": "doordash",
  "starbucks.com": "starbucks",
  "yelp.com": "yelp",
  "booking.com": "booking",
  "coach.com": "coach",
  "guess.com": "guess",
  "gucci.com": "gucci",
  "chanel.com": "chanel",
  "prada.com": "prada",
  "louisvuitton.com": "louisvuitton",
  "burberry.com": "burberry",
  "calvinklein.com": "calvinklein",
  "levi.com": "levis",
  "converse.com": "converse",
  "ysl.com": "saintlaurent",
  "fendi.com": "fendi",
  "dior.com": "dior",
  "hugoboss.com": "boss",
  "katespade.com": "katespade",
  "ae.com": "americaneagle",
  "abercrombie.com": "abercrombie",
  "vans.com": "vans",
  "newbalance.com": "newbalance",
  "skechers.com": "skechers",
  "uniqlo.com": "uniqlo",
  "thenorthface.com": "thenorthface",
  "asos.com": "asos",
  "puma.com": "puma",
  "underarmour.com": "underarmour",
  "fila.com": "fila",
  "reebok.com": "reebok",
  "tiktok.com": "tiktokshop",
};

export function normBrand(value: string): string {
  return value.toLowerCase().replace(/&/g, "and").replace(/[^a-z0-9]+/g, "");
}

export function publicHttpUrl(raw: string): string | null {
  let url: URL;
  try {
    url = new URL(raw.trim());
  } catch {
    return null;
  }
  if (url.protocol !== "https:" && url.protocol !== "http:") return null;
  if (url.username || url.password) return null;
  const host = url.hostname.toLowerCase().replace(/\.$/, "");
  if (!host || host === "localhost" || host.endsWith(".local") || host.endsWith(".internal")) return null;
  if (host === "0.0.0.0" || host === "::1" || host === "::" || host === "metadata.google.internal") return null;
  const v4 = host.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
  if (v4) {
    const n = v4.slice(1).map(Number);
    if (n.some((part) => part > 255)) return null;
    const [a, b] = n;
    if (a === 10 || a === 127 || a === 0 || (a === 169 && b === 254) || (a === 192 && b === 168)) return null;
    if (a === 172 && b >= 16 && b <= 31) return null;
    if (a === 100 && b >= 64 && b <= 127) return null;
  }
  return url.toString();
}

export function hex6(raw: string): string {
  const match = raw.trim().match(/^#([0-9a-f]{3}|[0-9a-f]{6})$/i);
  if (!match) return "";
  const body = match[1];
  const full = body.length === 3 ? body.split("").map((ch) => ch + ch).join("") : body;
  return `#${full.toLowerCase()}`;
}

export function inkFor(bg: string): string {
  const hex = hex6(bg).slice(1);
  if (hex.length !== 6) return "#111111";
  const r = Number.parseInt(hex.slice(0, 2), 16);
  const g = Number.parseInt(hex.slice(2, 4), 16);
  const b = Number.parseInt(hex.slice(4, 6), 16);
  return (r * 299 + g * 587 + b * 114) / 1000 > 150 ? "#111111" : "#ffffff";
}

function hostKeys(host: string): string[] {
  const clean = host.toLowerCase().replace(/^www\./, "");
  const parts = clean.split(".").filter(Boolean);
  const keys = [clean];
  if (parts.length >= 2) keys.push(parts.slice(-2).join("."));
  if (parts.length >= 3) keys.push(parts.slice(-3).join("."));
  return keys;
}

export function builtInFromHost(host: string): WpBadgeDef | null {
  for (const key of hostKeys(host)) {
    const id = HOST_BADGE[key];
    if (id) return wpBadge(id);
  }
  const stem = hostKeys(host)[0]?.split(".")[0] ?? "";
  return builtInFromName(stem);
}

function brandKeys(name: string): string[] {
  const key = normBrand(name);
  if (key.length < 2) return [];
  const trimmed = key.replace(/(corporation|incorporated|company|llc|ltd|inc)$/g, "");
  return trimmed.length >= 2 && trimmed !== key ? [key, trimmed] : [key];
}

export function builtInFromName(name: string): WpBadgeDef | null {
  const keys = brandKeys(name);
  if (!keys.length) return null;
  return WP_BADGE_DEFS.find((row) => keys.includes(row.id) || keys.includes(normBrand(row.label))) ?? null;
}

export function customBadgeId(name: string): string {
  const key = normBrand(name).slice(0, 24);
  return key.length >= 2 ? `c-${key}` : "";
}

export function titleCaseBrand(name: string): string {
  const clean = name.replace(/\s+/g, " ").trim().slice(0, 32);
  if (!clean) return "";
  return clean
    .split(" ")
    .map((word) => (word.length <= 3 && word === word.toUpperCase() ? word : word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()))
    .join(" ");
}

function meta(html: string, key: string): string {
  const patterns = [
    new RegExp(`<meta[^>]+(?:property|name)=["']${key}["'][^>]+content=["']([^"']+)["']`, "i"),
    new RegExp(`<meta[^>]+content=["']([^"']+)["'][^>]+(?:property|name)=["']${key}["']`, "i"),
  ];
  for (const pattern of patterns) {
    const found = html.match(pattern);
    if (found?.[1]) return decode(found[1]).trim();
  }
  return "";
}

function decode(value: string): string {
  return value
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">");
}

function walkBrand(node: unknown, into: string[], depth: number) {
  if (!node || depth > 6) return;
  if (Array.isArray(node)) {
    for (const row of node.slice(0, 12)) walkBrand(row, into, depth + 1);
    return;
  }
  if (typeof node !== "object") return;
  const row = node as Record<string, unknown>;
  const brand = row.brand;
  if (typeof brand === "string") into.push(brand);
  else if (brand && typeof brand === "object") {
    const name = (brand as { name?: unknown }).name;
    if (typeof name === "string") into.push(name);
  }
  if (typeof row.name === "string" && /brand/i.test(String(row["@type"] ?? ""))) into.push(row.name);
  for (const key of ["mainEntity", "itemListElement", "hasVariant"]) {
    if (row[key]) walkBrand(row[key], into, depth + 1);
  }
  if (row["@graph"]) walkBrand(row["@graph"], into, depth + 1);
}

export type PageBrand = { brands: string[]; site: string; theme: string; icons: string[] };

export function pageBrand(html: string, pageUrl: string): PageBrand {
  const brands: string[] = [];
  const blocks = html.match(/<script[^>]*type=["']application\/ld\+json["'][^>]*>[\s\S]*?<\/script>/gi) ?? [];
  for (const block of blocks.slice(0, 6)) {
    const raw = block.replace(/^<script[^>]*>/i, "").replace(/<\/script>$/i, "").trim();
    try {
      walkBrand(JSON.parse(raw), brands, 0);
    } catch {
      /* ignore broken product data */
    }
  }
  const site = meta(html, "og:site_name") || meta(html, "application-name");
  const theme = hex6(meta(html, "theme-color"));
  const icons: string[] = [];
  const links = html.match(/<link\b[^>]*>/gi) ?? [];
  for (const tag of links) {
    if (!/rel=["'][^"']*icon/i.test(tag)) continue;
    const href = tag.match(/href=["']([^"']+)["']/i)?.[1];
    if (!href) continue;
    try {
      const abs = new URL(decode(href), pageUrl).toString();
      if (publicHttpUrl(abs)) icons.push(abs);
    } catch {
      /* skip bad icon href */
    }
  }
  return {
    brands: brands.map((name) => name.trim()).filter(Boolean).slice(0, 8),
    site: site.trim().slice(0, 80),
    theme,
    icons: icons.slice(0, 6),
  };
}

export function hostLabel(host: string): string {
  const stem = host.replace(/^www\./, "").split(".")[0] ?? "";
  return titleCaseBrand(stem.replace(/[-_]+/g, " "));
}

export function safePath(raw: string): string {
  const path = raw.trim();
  if (path.length < 2 || path.length > 5000) return "";
  return /^[MmLlHhVvCcSsQqTtAaZz0-9eE.,\-\s]+$/.test(path) ? path : "";
}

export function safeSvgMarkup(raw: string): string {
  const text = raw.replace(/^\uFEFF/, "").trim();
  if (text.length < 20 || text.length > 60_000) return "";
  if (!/<svg[\s>]/i.test(text)) return "";
  if (/<script|foreignobject|onload|onerror|javascript:|<iframe|<embed|<object|@import/i.test(text)) return "";
  return text;
}

export function svgDataUri(markup: string): string {
  const clean = safeSvgMarkup(markup);
  if (!clean) return "";
  const bytes = new TextEncoder().encode(clean);
  let bin = "";
  for (const byte of bytes) bin += String.fromCharCode(byte);
  return `data:image/svg+xml;base64,${btoa(bin)}`;
}

export function monogramUri(label: string, bg: string): string {
  const letter = (label.match(/[A-Za-z0-9]/)?.[0] ?? "B").toUpperCase();
  const fg = inkFor(bg);
  return svgDataUri(
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><text x="32" y="43" text-anchor="middle" font-family="Georgia,serif" font-size="34" font-weight="700" fill="${fg}">${letter}</text></svg>`,
  );
}

export function linkReady(raw: string): string | null {
  let url = raw.trim();
  if (!url) return null;
  if (!/^https?:\/\//i.test(url)) url = `https://${url.replace(/^\/+/, "")}`;
  return publicHttpUrl(url);
}

const SKIP_ICON = new Set(["hermes"]);

function isStoreName(name: string, host: string, site: string): boolean {
  const keys = brandKeys(name);
  const store = new Set([
    ...brandKeys(site),
    ...brandKeys(hostLabel(host)),
    ...brandKeys(host.replace(/^www\./, "").split(".")[0] || ""),
  ]);
  return keys.some((key) => store.has(key));
}

function hitFromDef(def: WpBadgeDef): BrandHit {
  return {
    id: def.id,
    label: def.label,
    existing: true,
    bg: def.bg,
    fg: def.fg,
    img: def.img ?? "",
    path: def.path ?? "",
  };
}

function hitCustom(label: string, bg: string, fg: string, img: string, path: string): BrandHit | null {
  const nice = titleCaseBrand(label);
  const id = customBadgeId(nice || label);
  if (!id || (!img && !path)) return null;
  const paint = hex6(bg) || "#111111";
  return {
    id,
    label: nice || label,
    existing: false,
    bg: paint,
    fg: hex6(fg) || inkFor(paint),
    img,
    path: safePath(path),
  };
}

export async function resolveBrand(args: {
  pageUrl: string;
  html: string;
  lookupIcon?: (name: string) => Promise<{ path: string; hex: string } | null>;
  lookupImage?: (icons: string[], host: string) => Promise<string>;
}): Promise<BrandHit | null> {
  let host = "";
  try {
    host = new URL(args.pageUrl).hostname;
  } catch {
    return null;
  }
  const page = pageBrand(args.html, args.pageUrl);
  const distinct = page.brands.filter((name) => !isStoreName(name, host, page.site));
  const named = distinct.length ? distinct : page.brands;
  for (const name of named) {
    const hit = builtInFromName(name);
    if (hit) return hitFromDef(hit);
  }
  if (!distinct.length) {
    const hostHit = builtInFromHost(host);
    if (hostHit) return hitFromDef(hostHit);
    const siteHit = page.site ? builtInFromName(page.site) : null;
    if (siteHit) return hitFromDef(siteHit);
  }
  const label = titleCaseBrand(named[0] || page.site || hostLabel(host));
  if (!label) return null;
  const search = named[0] || page.site || hostLabel(host);
  if (args.lookupIcon && !SKIP_ICON.has(normBrand(search))) {
    const icon = await args.lookupIcon(search);
    const path = safePath(icon?.path ?? "");
    if (path) {
      const paint = page.theme || hex6(icon?.hex ? `#${icon.hex.replace(/^#/, "")}` : "") || "#111111";
      const made = hitCustom(label, paint, inkFor(paint), "", path);
      if (made) return made;
    }
  }
  const sameStore = distinct.length === 0;
  if (sameStore && args.lookupImage) {
    const img = await args.lookupImage(page.icons, host);
    if (img) {
      const paint = page.theme || "#ffffff";
      const made = hitCustom(label, paint, inkFor(paint), img, "");
      if (made) return made;
    }
  }
  const paint = page.theme || "#1c1917";
  const mark = monogramUri(label, paint);
  return mark ? hitCustom(label, paint, inkFor(paint), mark, "") : null;
}
