import type { PanelId, SmmDesk, SmmService } from "@/lib/smm/types";
import { serviceKey, orderNeeds, parseMemo, asUsername } from "@/lib/smm/types";
import { getAccount, listAccounts, type PanelAccount } from "@/lib/smm/accounts.server.ts";
import { parsePanelAction } from "@/lib/smm/panel-result.ts";
import { decodeEntities } from "@/lib/smm/text.ts";
import { createPanelQueue } from "@/lib/smm/panel-queue.ts";
import { extraCounts } from "@/lib/smm/order-status.ts";

export type { PanelId, SmmService };

type RawService = {
  service: number | string;
  name: string;
  type?: string;
  rate: string | number;
  min: number | string;
  max: number | string;
  category: string;
  dripfeed?: boolean | string | number;
  drip_feed?: boolean | string | number;
  drip?: boolean | string | number;
  refill?: boolean | string | number;
  cancel?: boolean | string | number;
  avg_time?: number | string;
  average_time?: number | string;
  time?: number | string;
  average?: number | string;
};

const DESKS: Record<string, readonly PanelId[]> = {
  tiktok: ["smmwiz", "jap"],
  youtube: ["smmfanz"],
};

const ALLOWED: Partial<Record<PanelId, readonly number[]>> = {
  smmwiz: [19968, 21046],
  jap: [4268],
  smmfanz: [12492],
};

const TTL_MS = 5 * 60 * 1000;
const cache = new Map<string, { at: number; services: SmmService[] }>();
const inflightCatalog = new Map<string, Promise<SmmService[]>>();
const inflightBalance = new Map<string, Promise<{ balance: string; currency: string }>>();
const mutate = createPanelQueue();

function clean(s: string): string {
  return decodeEntities(s)
    .replace(/\p{Extended_Pictographic}/gu, "")
    .replace(/\p{Emoji_Presentation}/gu, "")
    .replace(/[\u2600-\u27BF\u2B00-\u2BFF\uFE0F\u200D]/g, "")
    .replace(/\[\s*\]/g, "")
    .replace(/\(\s*\)/g, "")
    .replace(/\s+/g, " ")
    .replace(/^[\s|_\-–—]+|[\s|_\-–—]+$/g, "")
    .trim();
}

function num(v: number | string): number {
  const n = typeof v === "number" ? v : Number(v);
  return Number.isFinite(n) ? n : 0;
}

function flag(v: unknown): boolean {
  if (v === true || v === 1 || v === "1") return true;
  if (typeof v === "string") {
    const t = v.trim().toLowerCase();
    return t === "true" || t === "yes" || t === "available" || t === "y";
  }
  return false;
}

function bracket(name: string, label: string): string | null {
  const re = new RegExp(`${label}\\s*:\\s*([^\\]\\[]+)`, "i");
  const m = name.match(re);
  return m ? m[1].trim() : null;
}

function listedFlag(name: string, label: string): boolean | null {
  const raw = bracket(name, label);
  if (!raw) return null;
  const t = raw.toLowerCase().replace(/[.]/g, "").trim();
  if (/^(no|none|false|0|n|off|disabled|unavailable|-)$/.test(t)) return false;
  if (/^(yes|true|1|y|on|available|lifetime|life time)$/.test(t)) return true;
  if (/\d/.test(t) || /day|hour|month|week|year|life/.test(t)) return true;
  return /yes|true|available/.test(t);
}

function serviceFlag(name: string, label: string, api: unknown): boolean {
  const listed = listedFlag(name, label);
  if (listed != null) return listed;
  return flag(api);
}

function parseSpeed(name: string): string | null {
  const labeled = bracket(name, "Speed");
  if (labeled) return labeled;
  const m = name.match(/(\d+(?:\.\d+)?\s*[kKmM])\s*(?:per|\/)\s*day/i);
  return m ? `${m[1].replace(/\s+/g, "")}/Day` : null;
}

function unitLabel(unit: string): string {
  const u = unit.toLowerCase();
  if (/^(d|days?)$/.test(u)) return "d";
  if (/^(h|hours?|hrs?)$/.test(u)) return "hr";
  if (/^(m|min|minutes?|mins?)$/.test(u)) return "min";
  return "s";
}

function trimNum(v: string): string {
  const n = Number(v);
  if (!Number.isFinite(n)) return v;
  return Number.isInteger(n) ? String(n) : String(Number(n.toFixed(1)));
}

function formatSeconds(seconds: number): string {
  if (seconds < 60) return `${Math.round(seconds)}s`;
  if (seconds < 3600) return `${Math.round(seconds / 60)} min`;
  const hours = seconds / 3600;
  if (hours < 24) return Number.isInteger(hours) ? `${hours} hr` : `${hours.toFixed(1)} hr`;
  const days = hours / 24;
  return Number.isInteger(days) ? `${days} d` : `${days.toFixed(1)} d`;
}

function parseHumanDuration(raw: string): string | null {
  const t = raw.replace(/[_]+/g, " ").replace(/\s+/g, " ").trim();
  if (!t || /^(n\/?a|none|null|unknown|-|—|–)$/i.test(t)) return null;
  if (/instant|immediate/i.test(t)) return "Instant";
  const range = t.match(
    /(\d+(?:\.\d+)?)\s*(?:[-–—]|to)\s*(\d+(?:\.\d+)?)\s*(seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d)\b/i,
  );
  if (range) return `${trimNum(range[1]!)}–${trimNum(range[2]!)} ${unitLabel(range[3]!)}`;
  const one = t.match(/(\d+(?:\.\d+)?)\s*(seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d)\b/i);
  if (one) return `${trimNum(one[1]!)} ${unitLabel(one[2]!)}`;
  return null;
}

function parseAverageTime(name: string, raw: RawService): string | null {
  const api = raw.avg_time ?? raw.average_time ?? raw.time ?? raw.average;
  if (typeof api === "number" && Number.isFinite(api) && api > 0) return formatSeconds(api);
  if (typeof api === "string" && api.trim()) {
    const asNum = Number(api.trim());
    if (Number.isFinite(asNum) && asNum > 0) return formatSeconds(asNum);
    const human = parseHumanDuration(api);
    if (human) return human;
  }
  if (/\[?\s*instant(?:\s+start)?\s*\]?/i.test(name)) return "Instant";
  const labeled =
    bracket(name, "Average Time") ??
    bracket(name, "Avg Time") ??
    bracket(name, "Avg\\. Time") ??
    bracket(name, "Start Time") ??
    bracket(name, "Time") ??
    bracket(name, "Start");
  if (labeled) {
    const human = parseHumanDuration(labeled);
    if (human) return human;
    if (labeled.length < 28) return labeled.trim();
  }
  const complete = name.match(/(\d+)\s*Hours?\s*Complete/i);
  if (complete) return `${complete[1]} hr`;
  const fromName =
    name.match(/(\d+(?:\.\d+)?)\s*(?:[-–—]|to)\s*(\d+(?:\.\d+)?)\s*(hours?|hrs?|h|minutes?|mins?|m)\b/i) ??
    name.match(/(?:in|within)\s+(\d+(?:\.\d+)?)\s*(hours?|hrs?|h|minutes?|mins?|m)\b/i);
  if (fromName) return parseHumanDuration(fromName[0]);
  return null;
}

function formatBalance(raw: unknown): { balance: string; currency: string } {
  if (raw && typeof raw === "object" && "balance" in raw) {
    const b = raw as { balance: string; currency?: string };
    const n = Number(b.balance);
    return {
      balance: Number.isFinite(n) ? n.toFixed(2) : "0.00",
      currency: b.currency ?? "USD",
    };
  }
  if (raw && typeof raw === "object" && "error" in raw) {
    throw new Error(String((raw as { error: unknown }).error));
  }
  return { balance: "—", currency: "USD" };
}

async function panelOf(id: PanelId): Promise<PanelAccount> {
  const hit = await getAccount(id);
  if (!hit) throw new Error("Unknown panel");
  return hit;
}

async function accountList(): Promise<PanelId[]> {
  return (await listAccounts()).map((row) => row.id);
}

async function panelPost(id: PanelId, action: string, extra?: Record<string, string>): Promise<unknown> {
  const panel = await panelOf(id);
  const body = new URLSearchParams({ key: panel.key, action, ...extra });
  const res = await fetch(panel.url, {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      Accept: "application/json",
    },
    body,
    signal: AbortSignal.timeout(action === "services" ? 45_000 : action === "add" ? 25_000 : 8_000),
  });
  if (!res.ok) throw new Error(`${panel.label} returned ${res.status}`);
  return res.json();
}

function normalize(raw: RawService, panel: PanelId): SmmService {
  const name = clean(String(raw.name ?? ""));
  return {
    panel,
    id: num(raw.service),
    name,
    category: clean(String(raw.category ?? "Other")) || "Other",
    rate: String(raw.rate ?? "0"),
    min: num(raw.min),
    max: num(raw.max),
    type: clean(String(raw.type ?? "Default")) || "Default",
    dripfeed: serviceFlag(`${raw.name ?? ""} ${raw.category ?? ""}`, "Drip(?:-?feed)?", raw.dripfeed ?? raw.drip_feed ?? raw.drip),
    refill: serviceFlag(`${raw.name ?? ""} ${raw.category ?? ""}`, "Refill", raw.refill),
    cancel: flag(raw.cancel),
    averageTime: parseAverageTime(`${raw.name ?? ""} ${raw.category ?? ""}`, raw),
    speed: parseSpeed(String(raw.name ?? "")),
  };
}

function isYoutubeService(s: SmmService): boolean {
  return `${s.category} ${s.name}`.toLowerCase().includes("youtube");
}

function youtubeRank(s: SmmService): number {
  const c = s.category.toLowerCase();
  if (c === "youtube views") return 0;
  if (c === "youtube likes") return 1;
  if (c === "youtube subscribers") return 2;
  if (c === "youtube comments") return 3;
  if (c.includes("view")) return 10;
  if (c.includes("like")) return 11;
  if (c.includes("subscriber")) return 12;
  return 50;
}

function pickWanted(services: SmmService[], ids: number[]): SmmService[] {
  if (ids.length === 0) return [];
  const map = new Map(services.map((s) => [s.id, s]));
  const out: SmmService[] = [];
  for (const id of ids) {
    const hit = map.get(id);
    if (hit) out.push(hit);
  }
  return out;
}

async function catalogAll(id: PanelId): Promise<SmmService[]> {
  const key = `${id}:all:v1`;
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < TTL_MS) return hit.services;
  const pending = inflightCatalog.get(key);
  if (pending) return pending;
  const run = (async () => {
    const json = await panelPost(id, "services");
    if (!Array.isArray(json)) {
      const err =
        json && typeof json === "object" && "error" in json
          ? String((json as { error: unknown }).error)
          : "Could not load services";
      throw new Error(err);
    }
    const services = (json as RawService[]).map((row) => normalize(row, id)).filter((s) => s.name);
    cache.set(key, { at: Date.now(), services });
    return services;
  })();
  inflightCatalog.set(key, run);
  try {
    return await run;
  } finally {
    inflightCatalog.delete(key);
  }
}

async function catalog(id: PanelId): Promise<SmmService[]> {
  const all = await catalogAll(id);
  const rank = ALLOWED[id];
  if (rank && rank.length) return pickWanted(all, [...rank]);
  if (id === "smmfanz") {
    return all
      .filter(isYoutubeService)
      .sort((a, b) => youtubeRank(a) - youtubeRank(b) || a.category.localeCompare(b.category) || a.id - b.id);
  }
  return all;
}

export type PanelBalance = {
  id: PanelId;
  label: string;
  balance: string;
  currency: string;
};

export async function fetchBalances(ids: readonly PanelId[]): Promise<PanelBalance[]> {
  const all = await listAccounts();
  const map = new Map(all.map((row) => [row.id, row]));
  const balances = await Promise.all(
    ids.map(async (id) => {
      const pending = inflightBalance.get(id);
      if (pending) return pending;
      const run = (async () => {
        for (let i = 0; i < 2; i++) {
          try {
            return formatBalance(await panelPost(id, "balance"));
          } catch {
            /* retry once */
          }
        }
        return { balance: "—", currency: "USD" };
      })();
      inflightBalance.set(id, run);
      try {
        return await run;
      } finally {
        inflightBalance.delete(id);
      }
    }),
  );

  return ids.map((id, i) => ({
    id,
    label: map.get(id)?.label ?? id,
    balance: balances[i]!.balance,
    currency: balances[i]!.currency,
  }));
}

function deskOf(panel: PanelId): SmmDesk {
  return panel === "smmfanz" ? "youtube" : "tiktok";
}

export async function loadPicks(picks: { panel: PanelId; id: number }[]): Promise<{
  panels: PanelBalance[];
  services: SmmService[];
}> {
  const ids = [...new Set(picks.map((row) => row.panel))];
  const grouped = new Map<PanelId, number[]>();
  for (const id of ids) grouped.set(id, []);
  for (const row of picks) grouped.get(row.panel)!.push(row.id);

  const catalogs = await Promise.all(
    ids.map(async (id) => {
      try {
        const all = await catalogAll(id);
        return { id, services: pickWanted(all, grouped.get(id) ?? []), error: null as string | null };
      } catch (err) {
        return { id, services: [] as SmmService[], error: err instanceof Error ? err.message : "Could not load" };
      }
    }),
  );

  const services = catalogs.flatMap((row) => row.services);
  if (picks.length > 0 && services.length === 0) {
    const msg = catalogs.map((row) => row.error).filter(Boolean).join(" · ");
    throw new Error(msg || "Could not load services");
  }
  return { panels: [], services };
}

export async function loadAllCatalogs(): Promise<{ panels: PanelBalance[]; services: SmmService[] }> {
  const ids = await accountList();
  const catalogs = await Promise.all(
    ids.map(async (id) => {
      try {
        return { id, services: await catalogAll(id), error: null as string | null };
      } catch (err) {
        return {
          id,
          services: [] as SmmService[],
          error: err instanceof Error ? err.message : "Could not load",
        };
      }
    }),
  );
  const services = catalogs.flatMap((row) => row.services);
  if (services.length === 0) {
    const msg = catalogs.map((row) => row.error).filter(Boolean).join(" · ");
    throw new Error(msg || "Could not load services");
  }
  return { panels: [], services };
}

export async function lookupService(panel: PanelId, id: number): Promise<SmmService> {
  const all = await catalogAll(panel);
  const hit = all.find((s) => s.id === id);
  if (!hit) throw new Error(`Service ${id} is not on ${(await panelOf(panel)).label}`);
  return hit;
}

export async function loadDesk(desk: SmmDesk): Promise<{ panels: PanelBalance[]; services: SmmService[] }> {
  const ids = DESKS[desk] ?? DESKS.tiktok;
  const catalogs = await Promise.all(
    ids.map(async (id) => {
      try {
        return { id, services: await catalog(id), error: null as string | null };
      } catch (err) {
        return {
          id,
          services: [] as SmmService[],
          error: err instanceof Error ? err.message : "Could not load",
        };
      }
    }),
  );

  const panels = await fetchBalances(ids);
  const services = catalogs.flatMap((row) => row.services);

  if (services.length === 0) {
    const msg = catalogs.map((row) => row.error).filter(Boolean).join(" · ");
    throw new Error(msg || "Could not load services");
  }

  return { panels, services };
}

export async function loadBalances(desk: SmmDesk): Promise<PanelBalance[]> {
  return fetchBalances(DESKS[desk] ?? DESKS.tiktok);
}

let inflightAllBalances: Promise<PanelBalance[]> | null = null;

export async function loadAllBalances(): Promise<PanelBalance[]> {
  if (inflightAllBalances) return inflightAllBalances;
  inflightAllBalances = (async () => {
    const rows = await fetchBalances(await accountList());
    void import("./cloud.server.ts")
      .then(({ stampPanels }) => stampPanels(rows))
      .catch(() => undefined);
    return rows;
  })().finally(() => {
    inflightAllBalances = null;
  });
  return inflightAllBalances;
}

async function isAllowed(panel: PanelId, id: number): Promise<boolean> {
  const all = await catalogAll(panel);
  return all.some((s) => s.id === id);
}

export async function addOrder(input: {
  panel: PanelId;
  service: number;
  link: string;
  quantity: number;
  runs?: number;
  interval?: number;
  extras?: Record<string, string>;
}): Promise<{ order: string; panels: PanelBalance[]; startOnPost: number | null; metric: "views" | "likes" | "comments" }> {
  const all = await catalogAll(input.panel);
  const svc = all.find((s) => s.id === input.service);
  if (!svc) throw new Error("Unknown service");
  const needs = orderNeeds(svc);
  const extrasIn = input.extras ?? {};
  const extra: Record<string, string> = { service: String(input.service) };

  if (needs.target === "username" || needs.subscription) {
    const user = asUsername(extrasIn.username || input.link);
    if (!user) throw new Error("Enter a username");
    extra.username = user;
  } else {
    const link = input.link.trim();
    if (!/^https?:\/\//i.test(link)) throw new Error("Link must start with http:// or https://");
    extra.link = link;
  }

  if (needs.quantity === "hidden" && !needs.subscription) {
    extra.quantity = "1";
  } else if (needs.quantity !== "hidden") {
    extra.quantity = String(Math.min(svc.max, Math.max(svc.min, Math.floor(Number(input.quantity) || svc.min))));
  }

  if (input.runs && input.runs > 1 && needs.drip) {
    extra.runs = String(Math.floor(input.runs));
    extra.interval = String(Math.max(1, Math.floor(input.interval ?? 1)));
  }

  if (needs.lines) {
    const lines = parseMemo(extrasIn[needs.lines.param] ?? extrasIn.comments ?? "", svc.max);
    if (needs.quantity === "from-lines" && lines.length < svc.min) {
      throw new Error(`Add at least ${svc.min} ${needs.lines.label.toLowerCase()}`);
    }
    if (lines.length) extra[needs.lines.param] = lines.join("\n");
    if (needs.quantity === "from-lines") extra.quantity = String(lines.length);
  }
  if (extrasIn.comments && !extra.comments) {
    const lines = parseMemo(extrasIn.comments, svc.max);
    if (lines.length) {
      extra.comments = lines.join("\n");
      extra.quantity = String(lines.length);
    }
  }
  if (needs.username) {
    const user = asUsername(extrasIn.username || "");
    if (!user) throw new Error(`Enter ${needs.username.label.toLowerCase()}`);
    extra.username = user;
  }
  if (needs.hashtag) {
    const tag = (extrasIn.hashtag ?? "").replace(/^#/, "").trim();
    if (!tag) throw new Error("Enter a hashtag");
    extra.hashtag = tag;
  }
  if (needs.media) {
    const media = (extrasIn.media ?? "").trim();
    if (!/^https?:\/\//i.test(media)) throw new Error("Enter the media link");
    extra.media = media;
  }
  if (needs.answer) {
    const n = Math.max(1, Math.floor(Number(extrasIn.answer_number) || 1));
    extra.answer_number = String(n);
  }
  if (needs.subscription) {
    extra.min = String(Math.max(1, Math.floor(Number(extrasIn.min) || svc.min)));
    extra.max = String(Math.max(Number(extra.min), Math.floor(Number(extrasIn.max) || svc.max)));
    extra.posts = String(Math.max(0, Math.floor(Number(extrasIn.posts) || 0)));
    extra.delay = String(Math.max(0, Math.floor(Number(extrasIn.delay) || 0)));
    if (extrasIn.expiry?.trim()) extra.expiry = extrasIn.expiry.trim();
  }

  const href = extra.link || input.link.trim();
  const { countOnPost, metricOf, skipsPostCount } = await import("./stats.server.ts");
  const metric = metricOf(svc.name);
  const startP =
    metric === "comments" || skipsPostCount(svc.name) || !href.startsWith("http")
      ? Promise.resolve(null)
      : countOnPost(href, metric).catch(() => null);

  return mutate.enqueue(input.panel, async () => {
    const json = await panelPost(input.panel, "add", extra);
    if (json && typeof json === "object" && "error" in json) {
      throw new Error(String((json as { error: unknown }).error));
    }
    if (json && typeof json === "object" && "order" in json) {
      const startOnPost = await startP.catch(() => null);
      const panels = await fetchBalances(await accountList());
      return {
        order: String((json as { order: unknown }).order),
        panels,
        startOnPost: startOnPost ?? null,
        metric,
      };
    }
    throw new Error("Could not place order");
  });
}

export { serviceKey };

export type RefillQuery = {
  panel: PanelId;
  order: string;
  refill: boolean;
  service: number;
  name: string;
  link: string;
};

export type RefillItem = {
  panel: PanelId;
  label: string;
  order: string;
  service: number;
  name: string;
  link: string;
  status: string;
  ready: boolean;
};

export type RefillAccount = {
  id: PanelId;
  label: string;
  ready: number;
};

export type OrderProgress = {
  status: string;
  error?: string;
  start?: number;
  remains?: number;
  refill?: boolean;
  runs?: number;
};

function refillAvailable(hit?: OrderProgress): boolean {
  if (!hit || hit.error) return false;
  return hit.refill === true;
}

function parseStatusMap(json: unknown, ids: string[]): Map<string, OrderProgress> {
  const map = new Map<string, OrderProgress>();
  if (!json) return map;
  if (Array.isArray(json)) {
    for (const row of json) {
      if (!row || typeof row !== "object") continue;
      const item = row as { order?: unknown; status?: unknown; error?: unknown; start_count?: unknown; start?: unknown; remains?: unknown; refill?: unknown; runs?: unknown };
      const id = item.order != null ? String(item.order) : "";
      if (!id) continue;
      map.set(id, {
        status: item.status != null ? String(item.status) : "",
        error: item.error != null ? String(item.error) : undefined,
        ...extraCounts(item),
      });
    }
    return map;
  }
  if (typeof json !== "object") return map;
  const rec = json as Record<string, unknown>;
  if (ids.length === 1 && ("status" in rec || "error" in rec) && !ids.some((id) => id in rec)) {
    const err = rec.error != null ? String(rec.error) : undefined;
    map.set(ids[0], {
      status: rec.status != null ? String(rec.status) : "",
      error: err,
      ...extraCounts(rec),
    });
    return map;
  }
  for (const id of ids) {
    const row = rec[id];
    if (!row || typeof row !== "object") continue;
    const item = row as { status?: unknown; error?: unknown; start_count?: unknown; start?: unknown; remains?: unknown; refill?: unknown; runs?: unknown };
    map.set(id, {
      status: item.status != null ? String(item.status) : "",
      error: item.error != null ? String(item.error) : undefined,
      ...extraCounts(item),
    });
  }
  return map;
}

const inflightStatus = new Map<string, Promise<Map<string, OrderProgress>>>();

export async function statusMany(id: PanelId, orderIds: string[]): Promise<Map<string, OrderProgress>> {
  const unique = [...new Set(orderIds.filter(Boolean))];
  if (!unique.length) return new Map();
  const key = `${id}:${unique.join(",")}`;
  const pending = inflightStatus.get(key);
  if (pending) return pending;
  const run = (async () => {
    const map = new Map<string, OrderProgress>();
    for (let i = 0; i < unique.length; i += 100) {
      const chunk = unique.slice(i, i + 100);
      try {
        const json = await panelPost(id, "status", { orders: chunk.join(",") });
        for (const [k, value] of parseStatusMap(json, chunk)) map.set(k, value);
      } catch {
        for (const order of chunk) map.set(order, { status: "", error: "Could not check" });
      }
    }
    return map;
  })();
  inflightStatus.set(key, run);
  try {
    return await run;
  } finally {
    inflightStatus.delete(key);
  }
}

export async function loadRefills(queries: RefillQuery[]): Promise<{ accounts: RefillAccount[]; items: RefillItem[] }> {
  const ids = await accountList();
  const groups = new Map<PanelId, RefillQuery[]>();
  for (const id of ids) groups.set(id, []);
  for (const q of queries) {
    if (!groups.has(q.panel)) continue;
    groups.get(q.panel)!.push(q);
  }

  const all = await listAccounts();
  const labels = new Map(all.map((row) => [row.id, row.label]));
  const grouped = await Promise.all(
    ids.map(async (id) => {
      const rows = groups.get(id) ?? [];
      const unique = [...new Map(rows.map((row) => [row.order, row])).values()];
      const statuses = unique.length ? await statusMany(id, unique.map((row) => row.order)) : new Map();
      return unique.map((row) => {
        const hit = statuses.get(row.order);
        const status = hit?.error ? hit.error : (hit?.status ?? "Unknown");
        const ready = refillAvailable(hit);
        return {
          panel: id,
          label: labels.get(id) ?? id,
          order: row.order,
          service: row.service,
          name: row.name,
          link: row.link,
          status,
          ready,
        } satisfies RefillItem;
      });
    }),
  );
  const items = grouped.flat();

  const accounts: RefillAccount[] = ids.map((id) => ({
    id,
    label: labels.get(id) ?? id,
    ready: items.filter((row) => row.panel === id && row.ready).length,
  }));

  return { accounts, items };
}

function parseRefillResult(json: unknown, ids: string[]): { order: string; ok: boolean; error?: string }[] {
  return parsePanelAction(json, ids, "refill");
}

function parseCancelResult(json: unknown, ids: string[]): { order: string; ok: boolean; error?: string }[] {
  return parsePanelAction(json, ids, "cancel");
}

export async function runRefills(
  queries: { panel: PanelId; order: string }[],
): Promise<{ ok: number; fail: { order: string; error: string }[] }> {
  const groups = new Map<PanelId, string[]>();
  for (const q of queries) {
    const list = groups.get(q.panel) ?? [];
    if (!list.includes(q.order)) list.push(q.order);
    groups.set(q.panel, list);
  }

  const results = await Promise.all(
    [...groups.entries()].map(async ([id, orderIds]) => {
      let ok = 0;
      const fail: { order: string; error: string }[] = [];
      for (let i = 0; i < orderIds.length; i += 100) {
        const chunk = orderIds.slice(i, i + 100);
        const statuses = await statusMany(id, chunk);
        const allowed: string[] = [];
        for (const order of chunk) {
          if (refillAvailable(statuses.get(order))) allowed.push(order);
          else fail.push({ order, error: "Refill isn’t available on the panel" });
        }
        if (allowed.length === 0) continue;
        const rows = await mutate.enqueue(id, async () => {
          const json = await panelPost(id, "refill", { orders: allowed.join(",") });
          return parseRefillResult(json, allowed);
        });
        for (const row of rows) {
          if (row.ok) ok += 1;
          else fail.push({ order: row.order, error: row.error ?? "Could not refill" });
        }
      }
      return { ok, fail };
    }),
  );

  return {
    ok: results.reduce((n, row) => n + row.ok, 0),
    fail: results.flatMap((row) => row.fail),
  };
}

export async function cancelOrders(
  queries: { panel: PanelId; order: string }[],
): Promise<{ ok: number; fail: { order: string; error: string }[] }> {
  const groups = new Map<PanelId, string[]>();
  for (const q of queries) {
    const list = groups.get(q.panel) ?? [];
    if (!list.includes(q.order)) list.push(q.order);
    groups.set(q.panel, list);
  }

  const results = await Promise.all(
    [...groups.entries()].map(async ([id, orderIds]) => {
      let ok = 0;
      const fail: { order: string; error: string }[] = [];
      for (let i = 0; i < orderIds.length; i += 100) {
        const chunk = orderIds.slice(i, i + 100);
        const rows = await mutate.enqueue(id, async () => {
          const json = await panelPost(id, "cancel", { orders: chunk.join(",") });
          return parseCancelResult(json, chunk);
        });
        for (const row of rows) {
          if (row.ok) ok += 1;
          else fail.push({ order: row.order, error: row.error ?? "Could not cancel" });
        }
      }
      return { ok, fail };
    }),
  );

  return {
    ok: results.reduce((n, row) => n + row.ok, 0),
    fail: results.flatMap((row) => row.fail),
  };
}
