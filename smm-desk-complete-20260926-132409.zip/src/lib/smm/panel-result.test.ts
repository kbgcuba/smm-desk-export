import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { parsePanelAction } from "./panel-result.ts";

describe("cancel parser", () => {
  it("accepts { cancel: 1 }", () => {
    const rows = parsePanelAction({ cancel: 1 }, ["100"], "cancel");
    assert.deepEqual(rows, [{ order: "100", ok: true }]);
  });

  it("accepts PerfectPanel array with cancel status", () => {
    const rows = parsePanelAction(
      [
        { order: 87654, cancel: { status: "Pending" } },
        { order: 87655, cancel: { error: "Incorrect order ID" } },
      ],
      ["87654", "87655"],
      "cancel",
    );
    assert.equal(rows[0]?.ok, true);
    assert.equal(rows[1]?.ok, false);
    assert.equal(rows[1]?.error, "Incorrect order ID");
  });

  it("accepts per-id map { id: { cancel: 1 } }", () => {
    const rows = parsePanelAction({ "100": { cancel: 1 }, "101": { cancel: { error: "Too late" } } }, ["100", "101"], "cancel");
    assert.deepEqual(rows, [
      { order: "100", ok: true },
      { order: "101", ok: false, error: "Too late" },
    ]);
  });

  it("does not treat cancel success as refill failure", () => {
    const oldFail = parsePanelAction({ cancel: 1 }, ["100"], "refill");
    assert.equal(oldFail[0]?.ok, false);
    assert.equal(oldFail[0]?.error, "Could not refill");
    const next = parsePanelAction({ cancel: 1 }, ["100"], "cancel");
    assert.equal(next[0]?.ok, true);
  });

  it("surfaces top-level panel error", () => {
    const rows = parsePanelAction({ error: "Not allowed" }, ["100"], "cancel");
    assert.deepEqual(rows, [{ order: "100", ok: false, error: "Not allowed" }]);
  });
});

describe("refill parser", () => {
  it("still accepts { refill: 1 }", () => {
    const rows = parsePanelAction({ refill: 1 }, ["9"], "refill");
    assert.deepEqual(rows, [{ order: "9", ok: true }]);
  });

  it("still accepts nested refill error", () => {
    const rows = parsePanelAction([{ order: "9", refill: { error: "Already refilled" } }], ["9"], "refill");
    assert.equal(rows[0]?.ok, false);
    assert.equal(rows[0]?.error, "Already refilled");
  });
});
