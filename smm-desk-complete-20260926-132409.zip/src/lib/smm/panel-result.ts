export type PanelActionHit = { order: string; ok: boolean; error?: string };

function nestedError(node: unknown): string | null {
  if (node && typeof node === "object" && "error" in node) {
    const err = (node as { error: unknown }).error;
    if (err != null && String(err).trim()) return String(err);
  }
  return null;
}

export function parsePanelAction(
  json: unknown,
  ids: string[],
  key: "refill" | "cancel",
): PanelActionHit[] {
  const fail = key === "cancel" ? "Could not cancel" : "Could not refill";

  if (Array.isArray(json)) {
    return json.map((row, i) => {
      const rec = row && typeof row === "object" ? (row as Record<string, unknown>) : {};
      const order = rec.order != null ? String(rec.order) : ids[i] ?? "";
      if (rec.error != null) return { order, ok: false, error: String(rec.error) };
      const inner = nestedError(rec[key]);
      if (inner) return { order, ok: false, error: inner };
      return { order, ok: true };
    });
  }

  if (json && typeof json === "object") {
    const rec = json as Record<string, unknown>;
    if (rec.error != null) return ids.map((order) => ({ order, ok: false, error: String(rec.error) }));

    if (key in rec) {
      const inner = nestedError(rec[key]);
      if (inner) return ids.map((order) => ({ order, ok: false, error: inner }));
      return ids.map((order) => ({ order, ok: true }));
    }

    const hits: PanelActionHit[] = [];
    const seen = new Set<string>();
    for (const order of ids) {
      if (!(order in rec)) continue;
      const node = rec[order];
      seen.add(order);
      if (node && typeof node === "object") {
        const obj = node as Record<string, unknown>;
        if (obj.error != null) {
          hits.push({ order, ok: false, error: String(obj.error) });
          continue;
        }
        const inner = nestedError(obj[key]);
        if (inner) {
          hits.push({ order, ok: false, error: inner });
          continue;
        }
        hits.push({ order, ok: true });
        continue;
      }
      hits.push({ order, ok: Boolean(node) });
    }
    if (hits.length) {
      for (const order of ids) {
        if (!seen.has(order)) hits.push({ order, ok: false, error: fail });
      }
      return hits;
    }
  }

  return ids.map((order) => ({ order, ok: false, error: fail }));
}
