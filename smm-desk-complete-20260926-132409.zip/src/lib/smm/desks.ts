import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { PanelId } from "@/lib/smm/types";
import { CORE_DESKS, ensureCoreDesks, isCoreDesk, type DeskDef, type DeskService } from "@/lib/smm/desk-core";

export type { DeskDef, DeskService };
export { CORE_DESKS, ensureCoreDesks, isCoreDesk };

const RESERVED = new Set(["refills", "orders", "settings", "all", "favorites", ""]);

export function slugify(label: string): string {
  return label
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

function uniqueId(label: string, used: Set<string>): string {
  const base = slugify(label);
  if (!base || RESERVED.has(base)) return "";
  if (!used.has(base)) return base;
  for (let n = 2; n < 20; n++) {
    const id = `${base}-${n}`;
    if (!used.has(id)) return id;
  }
  return "";
}

function keyOf(row: DeskService): string {
  return `${row.panel}:${row.id}`;
}

const PINNED = new Set(["smmfanz:12492"]);

export function isPinned(panel: PanelId, id: number): boolean {
  return PINNED.has(`${panel}:${id}`);
}

function peekSaved(): { desks: DeskDef[]; desksAt: number; gone: Record<string, number> } {
  if (typeof window === "undefined") return { desks: CORE_DESKS, desksAt: 0, gone: {} };
  try {
    const raw = localStorage.getItem("smm-desks");
    if (!raw) return { desks: CORE_DESKS, desksAt: 0, gone: {} };
    const state = JSON.parse(raw)?.state as { desks?: DeskDef[]; desksAt?: number; gone?: Record<string, number> } | undefined;
    const desks = Array.isArray(state?.desks) && state.desks.length ? state.desks : CORE_DESKS;
    return {
      desks: ensureCoreDesks(desks.filter((d) => d.services?.length)),
      desksAt: typeof state?.desksAt === "number" ? state.desksAt : 0,
      gone: state?.gone && typeof state.gone === "object" ? state.gone : {},
    };
  } catch {
    return { desks: CORE_DESKS, desksAt: 0, gone: {} };
  }
}

const seeded = peekSaved();

type State = {
  desks: DeskDef[];
  desksAt: number;
  gone: Record<string, number>;
  addService: (deskId: string, service: DeskService) => string | null;
  addDesk: (label: string, service: DeskService) => string | null;
  removeService: (deskId: string, panel: PanelId, id: number) => void;
  removeDesk: (deskId: string) => void;
  renameDesk: (deskId: string, label: string) => string | null;
  renameService: (deskId: string, panel: PanelId, id: number, title: string) => void;
  moveDesk: (deskId: string, dir: -1 | 1) => void;
  reorderDesks: (fromId: string, toIndex: number) => void;
  moveService: (deskId: string, panel: PanelId, id: number, dir: -1 | 1) => void;
  moveServiceTo: (fromId: string, panel: PanelId, id: number, toId: string) => string | null;
  toggleFavorite: (service: DeskService, hint: { id: string; label: string }) => string | null;
  replaceAll: (desks: DeskDef[], at?: number, gone?: Record<string, number>) => void;
  syncServiceNames: (rows: { panel: PanelId; id: number; name: string }[]) => void;
};

export const useSmmDesks = create<State>()(
  persist(
    (set, get) => {
      const write = (desks: DeskDef[], gone?: Record<string, number>) =>
        set({ desks, desksAt: Date.now(), gone: gone ?? get().gone });
      return {
      desks: seeded.desks,
      desksAt: seeded.desksAt,
      gone: seeded.gone,
      addService: (deskId, service) => {
        const desks = get().desks;
        const desk = desks.find((d) => d.id === deskId);
        if (!desk) return "Unknown tab";
        const elsewhere = desks.find((d) => d.services.some((row) => keyOf(row) === keyOf(service)));
        if (elsewhere) return `Already on ${elsewhere.label}`;
        const row = { ...service, at: Date.now() };
        const gone = { ...get().gone };
        delete gone[keyOf(row)];
        write(
          desks.map((d) => (d.id === deskId ? { ...d, services: [...d.services, row] } : d)),
          gone,
        );
        return null;
      },
      addDesk: (label, service) => {
        const name = label.trim();
        if (!name) return "Enter a tab name";
        const desks = get().desks;
        const elsewhere = desks.find((d) => d.services.some((row) => keyOf(row) === keyOf(service)));
        if (elsewhere) return `Already on ${elsewhere.label}`;
        if (desks.length >= 8) return "Too many tabs";
        const id = uniqueId(name, new Set(desks.map((d) => d.id)));
        if (!id) return "Pick a different tab name";
        write([...desks, { id, label: name, locked: false, services: [{ ...service, at: Date.now() }] }]);
        return null;
      },
      removeService: (deskId, panel, id) => {
        if (isPinned(panel, id)) return;
        const desk = get().desks.find((d) => d.id === deskId);
        if (!desk) return;
        if (get().desks.length <= 1 && desk.services.length <= 1) return;
        const gone = { ...get().gone, [`${panel}:${id}`]: Date.now() };
        write(
          ensureCoreDesks(
            get()
              .desks.map((d) => {
                if (d.id !== deskId) return d;
                return { ...d, services: d.services.filter((row) => !(row.panel === panel && row.id === id)) };
              })
              .filter((d) => d.services.length > 0),
          ),
          gone,
        );
      },
      removeDesk: (deskId) => {
        const desk = get().desks.find((d) => d.id === deskId);
        if (!desk) return;
        if (get().desks.length <= 1) return;
        const gone = { ...get().gone };
        for (const row of desk.services) gone[keyOf(row)] = Date.now();
        write(
          ensureCoreDesks(get().desks.filter((d) => d.id !== deskId)),
          gone,
        );
      },
      renameDesk: (deskId, label) => {
        const name = label.trim() || "Tab";
        write(get().desks.map((d) => (d.id === deskId ? { ...d, label: label.length ? label : name } : d)));
        return null;
      },
      renameService: (deskId, panel, id, title) => {
        write(
          get().desks.map((d) =>
            d.id !== deskId
              ? d
              : {
                  ...d,
                  services: d.services.map((row) =>
                    row.panel === panel && row.id === id ? { ...row, title } : row,
                  ),
                },
          ),
        );
      },
      moveDesk: (deskId, dir) => {
        const desks = [...get().desks];
        const i = desks.findIndex((d) => d.id === deskId);
        const j = i + dir;
        if (i < 0 || j < 0 || j >= desks.length) return;
        const swap = desks[i]!;
        desks[i] = desks[j]!;
        desks[j] = swap;
        write(desks);
      },
      reorderDesks: (fromId, toIndex) => {
        const desks = get().desks;
        const item = desks.find((d) => d.id === fromId);
        if (!item) return;
        const rest = desks.filter((d) => d.id !== fromId);
        const i = Math.max(0, Math.min(toIndex, rest.length));
        const next = [...rest.slice(0, i), item, ...rest.slice(i)];
        if (next.every((d, n) => d.id === desks[n]?.id)) return;
        write(next);
      },
      moveService: (deskId, panel, id, dir) => {
        write(
          get().desks.map((d) => {
            if (d.id !== deskId) return d;
            const services = [...d.services];
            const i = services.findIndex((row) => row.panel === panel && row.id === id);
            const j = i + dir;
            if (i < 0 || j < 0 || j >= services.length) return d;
            const swap = services[i]!;
            services[i] = services[j]!;
            services[j] = swap;
            return { ...d, services };
          }),
        );
      },
      moveServiceTo: (fromId, panel, id, toId) => {
        if (fromId === toId) return null;
        const desks = get().desks;
        const from = desks.find((d) => d.id === fromId);
        const to = desks.find((d) => d.id === toId);
        if (!from || !to) return "Unknown tab";
        const service = from.services.find((row) => row.panel === panel && row.id === id);
        if (!service) return "Unknown service";
        if (from.services.length === 1 && get().desks.length <= 1) return "Keep at least one favorite";
        write(
          desks.map((d) => {
            if (d.id === fromId) {
              const next = d.services.filter((row) => !(row.panel === panel && row.id === id));
              return { ...d, services: next };
            }
            if (d.id === toId) return { ...d, services: [...d.services, service] };
            return d;
          }),
        );
        return null;
      },
      toggleFavorite: (service, hint) => {
        const desks = get().desks;
        const have = desks.find((d) => d.services.some((row) => keyOf(row) === keyOf(service)));
        if (have) {
          if (isPinned(service.panel, service.id)) return "pinned";
          get().removeService(have.id, service.panel, service.id);
          return null;
        }
        const want = hint.id.trim().toLowerCase();
        const target =
          desks.find((d) => d.id === want) ??
          desks.find((d) => d.label.toLowerCase() === hint.label.trim().toLowerCase());
        if (target) return get().addService(target.id, service);
        if (desks.length >= 8) return "Too many tabs";
        const used = new Set(desks.map((d) => d.id));
        const id = want && !RESERVED.has(want) && !used.has(want) ? want : uniqueId(hint.label, used);
        if (!id) return "Pick a different tab name";
        const gone = { ...get().gone };
        delete gone[keyOf(service)];
        write(
          [...desks, { id, label: hint.label.trim() || "Favorites", locked: false, services: [{ ...service, at: Date.now() }] }],
          gone,
        );
        return null;
      },
      replaceAll: (desks, at, gone) => {
        if (!Array.isArray(desks) || desks.length === 0) return;
        set({ desks: ensureCoreDesks(desks), desksAt: at ?? Date.now(), gone: gone ?? get().gone });
      },
      syncServiceNames: (rows) => {
        if (!rows.length) return;
        const names = new Map<string, string>();
        for (const row of rows) {
          const n = row.name.trim();
          if (n) names.set(`${row.panel}:${row.id}`, n);
        }
        if (!names.size) return;
        let changed = false;
        const desks = get().desks.map((d) => ({
          ...d,
          services: d.services.map((s) => {
            const title = names.get(keyOf(s));
            if (!title || title === s.title) return s;
            changed = true;
            return { ...s, title };
          }),
        }));
        if (changed) write(desks);
      },
    };
  },
    { name: "smm-desks", skipHydration: true, partialize: (s) => ({ desks: s.desks, desksAt: s.desksAt, gone: s.gone }) },
  ),
);

export function watchedServiceKeys(desks: DeskDef[] = useSmmDesks.getState().desks): Set<string> {
  const set = new Set<string>();
  for (const desk of desks) {
    for (const row of desk.services) set.add(keyOf(row));
  }
  return set;
}

export function isWatchedService(panel: PanelId, id: number): boolean {
  return watchedServiceKeys().has(`${panel}:${id}`);
}

