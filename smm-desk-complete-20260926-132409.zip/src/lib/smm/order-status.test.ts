import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { extraCounts, orderFinished, stillRunning } from "./order-status.ts";

describe("drip parent Active is not done", () => {
  it("treats Active as still running even with remains 0", () => {
    assert.equal(stillRunning("Active"), true);
    assert.equal(stillRunning("In progress"), true);
    assert.equal(orderFinished({ panelStatus: "Active", remains: 0 }), false);
    assert.equal(orderFinished({ panelStatus: "Active" }), false);
    assert.equal(orderFinished({ panelStatus: "Pending", remains: 100 }), false);
  });

  it("still marks a normal completed job done", () => {
    assert.equal(stillRunning("Completed"), false);
    assert.equal(orderFinished({ panelStatus: "Completed", remains: 0 }), true);
    assert.equal(orderFinished({ panelStatus: "Completed" }), true);
    assert.equal(orderFinished({ panelStatus: "Partial", remains: 0 }), true);
  });

  it("matches the live SmmWiz drip parent payloads", () => {
    assert.equal(orderFinished({ panelStatus: "Active", remains: undefined }), false);
    assert.equal(orderFinished({ panelStatus: "Completed", remains: undefined }), true);
    const active = extraCounts({ runs: "1", start_count: undefined, remains: undefined });
    assert.equal(active.runs, 1);
    assert.equal(active.remains, undefined);
    const done = extraCounts({ runs: "2", remains: "0" });
    assert.equal(done.runs, 2);
    assert.equal(orderFinished({ panelStatus: "Completed", remains: done.remains }), true);
  });
});
