import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { nextFeedCursor } from "./profiles.ts";
import type { ProfileItem } from "./profile-types.ts";

function items(ids: string[]): ProfileItem[] {
  return ids.map((id) => ({
    id,
    url: `https://x.test/${id}`,
    title: id,
    thumb: null,
    at: 1,
    kind: "video",
    stats: [],
  }));
}

describe("nextFeedCursor", () => {
  it("keeps the first-page cursor on first load", () => {
    assert.equal(nextFeedCursor(undefined, items(["a", "b", "c"]), "p2"), "p2");
  });

  it("uses the next-page cursor when loading more", () => {
    const prev = { items: items(["a", "b", "c"]), cursor: "p2" };
    assert.equal(nextFeedCursor(prev, items(["d", "e", "f"]), "p3"), "p3");
  });

  it("clears the cursor on the real last page", () => {
    const prev = { items: items(["a", "b", "c"]), cursor: "p2" };
    assert.equal(nextFeedCursor(prev, items(["d", "e"]), null), null);
  });

  it("keeps the further cursor when a first-page refresh is smaller", () => {
    const prev = { items: items(["a", "b", "c", "d", "e", "f"]), cursor: "p4" };
    assert.equal(nextFeedCursor(prev, items(["a", "b", "c"]), "p2"), "p4");
  });

  it("restores a cursor after a saved pack that wiped it", () => {
    const prev = { items: items(["a", "b", "c", "d", "e", "f", "g", "h", "i", "j"]), cursor: null };
    assert.equal(nextFeedCursor(prev, items(["a", "b", "c"]), "p2"), "p2");
  });

  it("lets a drain with no cursor mark the feed complete", () => {
    const prev = { items: items(["a", "b"]), cursor: "p2" };
    const incoming = items(Array.from({ length: 20 }, (_, i) => `n${i}`));
    assert.equal(nextFeedCursor(prev, incoming, null), null);
  });
});
