export type LinkPreview = {
  thumb: string | null;
  title: string | null;
};

const cache = new Map<string, { at: number; data: LinkPreview }>();
const TTL = 6 * 60 * 60 * 1000;

export function youtubeId(url: string): string | null {
  try {
    const u = new URL(url);
    const host = u.hostname.replace(/^www\./, "");
    if (host === "youtu.be") return u.pathname.split("/").filter(Boolean)[0] ?? null;
    if (host === "youtube.com" || host === "m.youtube.com" || host === "music.youtube.com") {
      if (u.searchParams.get("v")) return u.searchParams.get("v");
      const parts = u.pathname.split("/").filter(Boolean);
      if (parts[0] === "shorts" || parts[0] === "embed" || parts[0] === "live") return parts[1] ?? null;
    }
  } catch {
    return null;
  }
  return null;
}

export async function loadLinkPreview(url: string): Promise<LinkPreview> {
  const href = url.trim();
  if (!/^https?:\/\//i.test(href)) return { thumb: null, title: null };
  const hit = cache.get(href);
  if (hit && Date.now() - hit.at < TTL) return hit.data;

  const yt = youtubeId(href);
  if (yt) {
    const data = { thumb: `https://i.ytimg.com/vi/${yt}/hqdefault.jpg`, title: null };
    cache.set(href, { at: Date.now(), data });
    return data;
  }

  const oembed = href.includes("tiktok.com")
    ? `https://www.tiktok.com/oembed?url=${encodeURIComponent(href)}`
    : href.includes("youtube.com") || href.includes("youtu.be")
      ? `https://www.youtube.com/oembed?url=${encodeURIComponent(href)}&format=json`
      : null;

  if (!oembed) {
    const data = { thumb: null, title: null };
    cache.set(href, { at: Date.now(), data });
    return data;
  }

  try {
    const res = await fetch(oembed, {
      headers: {
        accept: "application/json",
        "user-agent": "Mozilla/5.0 (compatible; SocialDesk/1.0)",
      },
      signal: AbortSignal.timeout(5000),
    });
    if (!res.ok) throw new Error("preview");
    const json = (await res.json()) as { thumbnail_url?: unknown; title?: unknown };
    const data: LinkPreview = {
      thumb: typeof json.thumbnail_url === "string" ? json.thumbnail_url : null,
      title: typeof json.title === "string" ? json.title : null,
    };
    cache.set(href, { at: Date.now(), data });
    return data;
  } catch {
    const data = { thumb: null, title: null };
    cache.set(href, { at: Date.now(), data });
    return data;
  }
}
