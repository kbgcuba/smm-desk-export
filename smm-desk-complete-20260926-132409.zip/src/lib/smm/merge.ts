import { ensureCoreDesks, type DeskDef, type DeskService } from "./desk-core.ts";
import type { PanelId } from "@/lib/smm/types";

export type OrderLike = {
  panel: PanelId;
  order: string;
  service: number;
  name: string;
  link: string;
  quantity: number;
  refill: boolean;
  at: number;
  desk?: string;
  thumb?: string | null;
  mediaTitle?: string | null;
  refilledAt?: number;
  actual?: number | null;
  actualAt?: number;
  metric?: "views" | "likes" | "comments";
  start?: number;
  remains?: number;
  panelStatus?: string;
  panelRefill?: boolean;
  source?: "post" | "panel" | null;
  startOnPost?: number | null;
  doneOnPost?: number | null;
  viewsAt?: number;
  viewsClosedAt?: number;
  runs?: number;
  panelRuns?: number;
};

export type RefillLike = { panel: PanelId; order: string; at: number };

export type PrefsDump = {
  lastService: Record<string, string>;
  lastQty: Record<string, number>;
  recentLinks: string[];
  autoRefill: boolean;
  lastAccount?: string;
  lastAccountAt?: number;
};

export type PanelSnap = {
  id: string;
  label: string;
  balance: string;
  currency: string;
};

function earliest(a?: number, b?: number): number | undefined {
  const xs = [a, b].filter((n): n is number => typeof n === "number" && n > 0);
  if (!xs.length) return undefined;
  return Math.min(...xs);
}

function filled(v: unknown): v is string {
  return typeof v === "string" && v.trim().length > 0;
}

function pickName(a?: string | null, b?: string | null): string {
  if (filled(a) && filled(b)) return b.length > a.length ? b : a;
  return (filled(b) ? b : filled(a) ? a : "") as string;
}

function pickThumb(a?: string | null, b?: string | null): string | null | undefined {
  if (typeof a === "string" && a.trim()) return a;
  if (typeof b === "string" && b.trim()) return b;
  if (a === "" || b === "") return "";
  return a ?? b;
}

export function mergeOrder<T extends OrderLike>(a: T, b: T): T {
  const early = (a.at || 0) <= (b.at || 0) ? a : b;
  const late = early === a ? b : a;
  const liveA = a.actualAt ?? 0;
  const liveB = b.actualAt ?? 0;
  const live = liveB > liveA ? b : liveA > liveB ? a : a.actual != null ? a : b;
  const refilledAt = Math.max(a.refilledAt ?? 0, b.refilledAt ?? 0) || undefined;
  const panelRefill =
    live.actualAt != null && live.actualAt > 0 && typeof live.panelRefill === "boolean"
      ? live.panelRefill
      : typeof late.panelRefill === "boolean"
        ? late.panelRefill
        : early.panelRefill;
  return {
    ...early,
    name: pickName(early.name, late.name),
    link: filled(late.link) ? late.link : early.link,
    quantity: early.quantity || late.quantity,
    refill: Boolean(a.refill || b.refill),
    desk: filled(early.desk) ? early.desk : late.desk,
    thumb: pickThumb(late.thumb, early.thumb),
    mediaTitle: pickName(early.mediaTitle, late.mediaTitle) || null,
    refilledAt,
    actual: live.actual ?? late.actual ?? early.actual,
    actualAt: Math.max(liveA, liveB) || undefined,
    metric: live.metric ?? late.metric ?? early.metric,
    start: live.start ?? late.start ?? early.start,
    remains: live.remains ?? late.remains ?? early.remains,
    panelStatus: filled(live.panelStatus) ? live.panelStatus : late.panelStatus || early.panelStatus,
    panelRefill,
    source: live.source === "post" || late.source === "post" || early.source === "post" ? "post" : live.source ?? late.source ?? early.source,
    startOnPost: early.startOnPost ?? late.startOnPost,
    doneOnPost: early.doneOnPost ?? late.doneOnPost,
    viewsAt: earliest(a.viewsAt, b.viewsAt),
    viewsClosedAt: earliest(a.viewsClosedAt, b.viewsClosedAt),
    runs: Math.max(a.runs ?? 0, b.runs ?? 0) || undefined,
    panelRuns: Math.max(a.panelRuns ?? 0, b.panelRuns ?? 0) || undefined,
  };
}

export function unionOrders<T extends OrderLike>(a: T[], b: T[]): T[] {
  const map = new Map<string, T>();
  for (const row of [...a, ...b]) {
    if (!row?.order) continue;
    const k = `${row.panel}:${row.order}`;
    const prev = map.get(k);
    map.set(k, prev ? mergeOrder(prev, row) : row);
  }
  return [...map.values()].sort((x, y) => y.at - x.at).slice(0, 300);
}

export function unionRefills<T extends RefillLike>(a: T[], b: T[]): T[] {
  const have = new Set<string>();
  const out: T[] = [];
  for (const row of [...a, ...b]) {
    if (!row?.order) continue;
    const k = `${row.panel}:${row.order}:${row.at}`;
    if (have.has(k)) continue;
    have.add(k);
    out.push(row);
  }
  return out.sort((x, y) => y.at - x.at).slice(0, 2000);
}

function mergeService(a: DeskService, b: DeskService): DeskService {
  return {
    panel: a.panel,
    id: a.id,
    title: pickName(a.title, b.title) || a.title,
  };
}

function mergeDesk(a: DeskDef, b: DeskDef): DeskDef {
  const map = new Map<string, DeskService>();
  const order: string[] = [];
  for (const row of [...a.services, ...b.services]) {
    const k = `${row.panel}:${row.id}`;
    const prev = map.get(k);
    if (!prev) {
      map.set(k, row);
      order.push(k);
    } else {
      map.set(k, mergeService(prev, row));
    }
  }
  return {
    id: a.id,
    label: pickName(a.label, b.label) || a.label,
    locked: Boolean(a.locked || b.locked),
    services: order.map((k) => map.get(k)!),
  };
}

export function mergeDesks(base: DeskDef[], extra: DeskDef[]): DeskDef[] {
  const map = new Map<string, DeskDef>();
  const ids: string[] = [];
  for (const row of base) {
    if (!row?.id) continue;
    map.set(row.id, row);
    ids.push(row.id);
  }
  for (const row of extra) {
    if (!row?.id) continue;
    const prev = map.get(row.id);
    if (!prev) {
      map.set(row.id, row);
      ids.push(row.id);
    } else {
      map.set(row.id, mergeDesk(prev, row));
    }
  }
  return ids.map((id) => map.get(id)!);
}

export function mergePrefs(prev: PrefsDump, incoming: PrefsDump, prevAt = 0, incomingAt = 0): PrefsDump {
  const links = [...(incoming.recentLinks ?? []), ...(prev.recentLinks ?? [])];
  const seen = new Set<string>();
  const recentLinks: string[] = [];
  for (const href of links) {
    if (!href || seen.has(href)) continue;
    seen.add(href);
    recentLinks.push(href);
    if (recentLinks.length >= 8) break;
  }
  const lastQty = { ...prev.lastQty, ...(incoming.lastQty ?? {}) };
  const prevAcc = prev.lastAccountAt && prev.lastAccountAt > 0 ? prev.lastAccountAt : prevAt;
  const nextAcc = incoming.lastAccountAt && incoming.lastAccountAt > 0 ? incoming.lastAccountAt : incomingAt;
  const takeIncoming = nextAcc >= prevAcc;
  return {
    lastService: { ...prev.lastService, ...incoming.lastService },
    lastQty,
    recentLinks,
    autoRefill: incomingAt >= prevAt ? incoming.autoRefill : prev.autoRefill,
    lastAccount: takeIncoming ? incoming.lastAccount || prev.lastAccount || "" : prev.lastAccount || incoming.lastAccount || "",
    lastAccountAt: takeIncoming ? Math.max(nextAcc, prevAcc) : prevAcc,
  };
}

export function mergePanels(a: PanelSnap[], b: PanelSnap[]): PanelSnap[] {
  const map = new Map<string, PanelSnap>();
  for (const row of [...a, ...b]) {
    if (!row?.id) continue;
    const prev = map.get(row.id);
    const usable = row.balance !== "—" && row.balance !== "…";
    if (!prev || usable) map.set(row.id, row);
  }
  return [...map.values()];
}

export function mergeGone(a: Record<string, number> = {}, b: Record<string, number> = {}): Record<string, number> {
  const out = { ...a };
  for (const [k, t] of Object.entries(b)) {
    if ((out[k] ?? 0) < t) out[k] = t;
  }
  return out;
}

export function applyGone(desks: DeskDef[], gone: Record<string, number>): DeskDef[] {
  return desks
    .map((d) => ({
      ...d,
      services: d.services.filter((s) => (s.at ?? 0) >= (gone[`${s.panel}:${s.id}`] ?? 0)),
    }))
    .filter((d) => d.services.length > 0);
}

export function mergeFavorites(
  newer: { desks: DeskDef[]; gone?: Record<string, number> },
  older: { desks: DeskDef[]; gone?: Record<string, number> },
): { desks: DeskDef[]; gone: Record<string, number> } {
  const gone = mergeGone(newer.gone, older.gone);
  return { desks: ensureCoreDesks(applyGone(mergeDesks(newer.desks, older.desks), gone)), gone };
}

export function desksEqual(a: DeskDef[], b: DeskDef[]): boolean {
  if (a.length !== b.length) return false;
  return a.every((d, i) => {
    const o = b[i];
    if (!o || d.id !== o.id || d.label !== o.label || d.services.length !== o.services.length) return false;
    return d.services.every((s, j) => s.panel === o.services[j]?.panel && s.id === o.services[j]?.id && s.title === o.services[j]?.title);
  });
}

export function mergeProfiles<T extends { id: string; at?: number }>(a: T[], b: T[]): T[] {
  const map = new Map<string, T>();
  const ids: string[] = [];
  for (const row of [...a, ...b]) {
    if (!row?.id) continue;
    const prev = map.get(row.id);
    if (!prev) {
      map.set(row.id, row);
      ids.push(row.id);
    } else {
      const p = prev as T & { stats?: { key: string }[]; avatar?: string | null; title?: string };
      const r = row as T & { stats?: { key: string }[]; avatar?: string | null; title?: string };
      const newer = (row.at ?? 0) >= (prev.at ?? 0) ? { ...prev, ...row } : { ...row, ...prev };
      const n = newer as typeof p;
      map.set(row.id, {
        ...n,
        stats: r.stats?.length ? r.stats : p.stats?.length ? p.stats : n.stats,
        avatar: r.avatar || p.avatar || n.avatar,
        title: (r.title && r.title.trim()) || p.title || n.title,
      } as T);
    }
  }
  return ids.map((id) => map.get(id)!);
}
