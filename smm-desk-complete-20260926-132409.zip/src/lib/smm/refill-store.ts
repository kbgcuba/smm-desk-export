import { create } from "zustand";
import { loadSmmRefills, type RefillAccount, type RefillItem } from "@/lib/smm/fn";
import { canAutoRefill, type SavedOrder } from "@/lib/smm/orders";
import { watchedServiceKeys } from "@/lib/smm/desks";

type State = {
  accounts: RefillAccount[];
  items: RefillItem[];
  readyCount: number;
  loading: boolean;
  error: string | null;
  refresh: (orders: SavedOrder[]) => Promise<void>;
};

let seq = 0;

export const useSmmRefills = create<State>((set) => ({
  accounts: [],
  items: [],
  readyCount: 0,
  loading: true,
  error: null,
  refresh: async (orders) => {
    const n = ++seq;
    set({ loading: true, error: null });
    try {
      const watch = watchedServiceKeys();
      const payload = orders.filter(
        (row) => row.refill || watch.size === 0 || watch.has(`${row.panel}:${row.service}`),
      );
      const next = await loadSmmRefills({
        data: {
          orders: payload.map((row) => ({
            panel: row.panel,
            order: row.order,
            refill: row.refill,
            service: row.service,
            name: row.name,
            link: row.link,
          })),
        },
      });
      if (n !== seq) return;
      const now = Date.now();
      const items = next.items.map((row) => {
        const saved = orders.find((order) => order.panel === row.panel && order.order === row.order);
        const ready = Boolean(row.ready && saved && canAutoRefill(saved, now));
        return { ...row, ready };
      });
      set({
        accounts: next.accounts.map((row) => ({
          ...row,
          ready: items.filter((item) => item.panel === row.id && item.ready).length,
        })),
        items,
        readyCount: items.filter((row) => row.ready).length,
        loading: false,
        error: null,
      });
    } catch (err) {
      if (n !== seq) return;
      set({
        accounts: [],
        items: [],
        readyCount: 0,
        loading: false,
        error: err instanceof Error ? err.message : "Could not load refills",
      });
    }
  },
}));