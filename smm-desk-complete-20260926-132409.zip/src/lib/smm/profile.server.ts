import type { LookedProfile, ProfileFeed, ProfileItem, ProfileStat } from "@/lib/smm/profile-types";
import { feedViaApi, lookupViaApi } from "@/lib/smm/social-api.server.ts";
import { tiktokConsecutive } from "@/lib/smm/tiktok-own";

export type { LookedProfile, ProfileStat };

const PHONE_UA =
  "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1";
const DESK_UA =
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36";
const UA = DESK_UA;

const cache = new Map<string, { at: number; data: LookedProfile }>();
const TTL = 15_000;

function lookupTtl(platform: string): number {
  return platform === "instagram" || platform === "facebook" ? 90_000 : TTL;
}

export function parseProfileUrl(raw: string): { platform: string; handle: string; url: string } | null {
  try {
    const u = new URL(raw.trim());
    const host = u.hostname.replace(/^www\./, "").toLowerCase();
    const parts = u.pathname.split("/").filter(Boolean);
    if (host.includes("tiktok.com")) {
      const handle = (parts[0] || "").replace(/^@/, "");
      if (!handle) return null;
      return { platform: "tiktok", handle, url: `https://www.tiktok.com/@${handle}` };
    }
    if (host.includes("instagram.com")) {
      const handle = (parts[0] || "").replace(/^@/, "");
      if (!handle || ["p", "reel", "reels", "stories", "explore"].includes(handle.toLowerCase())) return null;
      return { platform: "instagram", handle, url: `https://www.instagram.com/${handle}/` };
    }
    if (host.includes("youtube.com") || host === "youtu.be") {
      let handle = "";
      if (parts[0]?.startsWith("@")) handle = parts[0].slice(1);
      else if (parts[0] === "channel" || parts[0] === "c" || parts[0] === "user") handle = parts[1] || "";
      else if (parts[0]) handle = parts[0].replace(/^@/, "");
      if (!handle) return null;
      const url = parts[0] === "channel" ? `https://www.youtube.com/channel/${handle}` : `https://www.youtube.com/@${handle.replace(/^@/, "")}`;
      return { platform: "youtube", handle: handle.replace(/^@/, ""), url };
    }
    if (host.includes("facebook.com") || host === "fb.com" || host === "m.facebook.com") {
      if (parts[0] === "share" && parts[1]) {
        return { platform: "facebook", handle: parts[1], url: `https://www.facebook.com/share/${parts[1]}/` };
      }
      if (parts[0] === "p" && parts[1]) {
        return { platform: "facebook", handle: parts[1], url: `https://www.facebook.com/p/${parts[1]}/` };
      }
      const handle = (parts[0] || "").replace(/^@/, "");
      if (!handle || ["profile.php", "watch", "reel", "login", "groups"].includes(handle.toLowerCase())) return null;
      return { platform: "facebook", handle, url: `https://www.facebook.com/${handle}` };
    }
    if (host === "x.com" || host.includes("twitter.com")) {
      const handle = (parts[0] || "").replace(/^@/, "");
      if (!handle || ["home", "i", "intent", "share"].includes(handle.toLowerCase())) return null;
      return { platform: "twitter", handle, url: `https://x.com/${handle}` };
    }
    if (host === "t.me" || host.includes("telegram.org")) {
      const handle = (parts[0] || "").replace(/^@/, "");
      if (!handle) return null;
      return { platform: "telegram", handle, url: `https://t.me/${handle}` };
    }
    if (host.includes("spotify.com")) {
      const kind = parts[0];
      const handle = parts[1] || parts[0] || "";
      if (!handle) return null;
      return { platform: "spotify", handle, url: `https://open.spotify.com/${kind || "user"}/${handle}` };
    }
  } catch {
    return null;
  }
  return null;
}

async function fetchText(url: string, ua = DESK_UA, extra: Record<string, string> = {}): Promise<string> {
  const res = await fetch(url, {
    headers: {
      "user-agent": ua,
      accept: "text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8",
      "accept-language": "en-US,en;q=0.9",
      ...extra,
    },
    redirect: "follow",
    signal: AbortSignal.timeout(15_000),
  });
  if (!res.ok) throw new Error(`Could not open ${url}`);
  return res.text();
}

function meta(html: string, key: string): string | null {
  const a = html.match(new RegExp(`property=["']${key}["'][^>]*content=["']([\\s\\S]*?)["']`, "i"));
  if (a?.[1]) return decode(a[1]);
  const b = html.match(new RegExp(`content=["']([\\s\\S]*?)["'][^>]*property=["']${key}["']`, "i"));
  return b?.[1] ? decode(b[1]) : null;
}

function decode(s: string): string {
  return s
    .replace(/&(amp|quot|lt);/g, (_, name: string) => ({ amp: "&", quot: '"', lt: "<" }[name] ?? _))
    .replace(/&#39;/g, "'")
    .replace(/\\u002F/g, "/")
    .replace(/\\u0026/g, "&")
    .replace(/\\\//g, "/")
    .replace(/&#x([0-9a-f]+);/gi, (_, h) => String.fromCodePoint(parseInt(h, 16)))
    .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n)));
}

function num(raw: string | number | undefined | null): number | null {
  if (typeof raw === "number" && Number.isFinite(raw)) return raw;
  if (typeof raw !== "string") return null;
  const n = Number(raw.replace(/,/g, ""));
  return Number.isFinite(n) ? n : null;
}

function parseAbbrev(raw: string): number | null {
  const m = raw.replace(/,/g, "").trim().match(/^([\d.]+)\s*([kmb])?/i);
  if (!m) return num(raw.replace(/[^\d.]/g, ""));
  const n = Number(m[1]);
  if (!Number.isFinite(n)) return null;
  const u = (m[2] || "").toLowerCase();
  if (u === "k") return Math.round(n * 1_000);
  if (u === "m") return Math.round(n * 1_000_000);
  if (u === "b") return Math.round(n * 1_000_000_000);
  return Math.round(n);
}

function fromTikTok(html: string, parsed: { handle: string; url: string }): LookedProfile {
  const follower = html.match(/"followerCount":"?(\d+)"?/);
  const following = html.match(/"followingCount":"?(\d+)"?/);
  const hearts = html.match(/"heartCount":"?(\d+)"?/) || html.match(/"heart":(\d+)/);
  const videos = html.match(/"videoCount":"?(\d+)"?/);
  const nick = html.match(new RegExp(`"uniqueId":"${parsed.handle}".{0,500}?"nickname":"([^"]+)"`)) || html.match(/"nickname":"([^"]+)"/);
  const avatar =
    html.match(/"avatarLarger":"([^"]+)"/)?.[1] ||
    html.match(/"avatarMedium":"([^"]+)"/)?.[1] ||
    meta(html, "og:image");
  const stats: ProfileStat[] = [];
  const f = num(follower?.[1]);
  const g = num(following?.[1]);
  const h = num(hearts?.[1]);
  const v = num(videos?.[1]);
  if (f != null) stats.push({ key: "followers", label: "Followers", value: f });
  if (g != null) stats.push({ key: "following", label: "Following", value: g });
  if (v != null) stats.push({ key: "videos", label: "Videos", value: v });
  if (h != null) stats.push({ key: "likes", label: "Likes", value: h });
  return {
    id: `tiktok:${parsed.handle}`,
    url: parsed.url,
    platform: "tiktok",
    handle: parsed.handle,
    title: nick?.[1] || meta(html, "og:title") || parsed.handle,
    avatar: avatar ? decode(avatar) : null,
    stats,
  };
}

function fromYouTube(html: string, parsed: { handle: string; url: string }): LookedProfile {
  const plain = html.replace(/\\x22/gi, '"').replace(/\\"/g, '"');
  const title = (meta(html, "og:title") || "").replace(/\s*-\s*YouTube$/i, "") || parsed.handle;
  const avatar = meta(html, "og:image");
  const stats: ProfileStat[] = [];
  const sub = plain.match(/"content":"([\d.,]+[KMB]?)\s*subscribers"/i) || plain.match(/\b([\d.,]+[KMB]?)\s*subscribers\b/i);
  const vids = plain.match(/"content":"([\d.,]+[KMB]?)\s*videos"/i) || plain.match(/\b([\d.,]+[KMB]?)\s*videos\b/i);
  const s = sub?.[1] ? parseAbbrev(sub[1]) : null;
  const v = vids?.[1] ? parseAbbrev(vids[1]) : null;
  const viewsHit =
    plain.match(/viewCountText":"([\d.,]+[KMB]?)\s*views"/i) ||
    plain.match(/"content":"([\d.,]+[KMB]?)\s*views"/i);
  const views = viewsHit?.[1] ? parseAbbrev(viewsHit[1]) : null;
  if (s != null) stats.push({ key: "subscribers", label: "Subscribers", value: s });
  if (v != null) stats.push({ key: "videos", label: "Videos", value: v });
  if (Number.isFinite(views) && (views as number) > 0) stats.push({ key: "views", label: "Views", value: views as number });
  return {
    id: `youtube:${parsed.handle}`,
    url: parsed.url,
    platform: "youtube",
    handle: parsed.handle,
    title,
    avatar,
    stats,
  };
}

function countIn(text: string, label: string): number | null {
  const m = text.match(new RegExp(`([\\d.,]+[KMB]?)\\s*${label}`, "i"));
  return m?.[1] ? parseAbbrev(m[1]) : null;
}

function fromFacebook(html: string, parsed: { handle: string; url: string }): LookedProfile {
  const title = meta(html, "og:title") || parsed.handle;
  const avatar = meta(html, "og:image");
  const page = meta(html, "og:url") || parsed.url;
  const blob = `${meta(html, "og:description") || ""}\n${html}`;
  let handle = parsed.handle;
  try {
    const u = new URL(page);
    const parts = u.pathname.split("/").filter(Boolean);
    if (parts[0] === "p" && parts[1]) handle = parts[1];
    else if (parts[0] === "profile.php") {
      const id = u.searchParams.get("id");
      if (id) handle = id;
    } else if (parts[0] && parts[0] !== "share") handle = parts[0];
  } catch {
    /* keep share id */
  }
  const stats: ProfileStat[] = [];
  const f = countIn(blob, "followers");
  if (f != null) stats.push({ key: "followers", label: "Followers", value: f });
  return {
    id: `facebook:${handle}`,
    url: page,
    platform: "facebook",
    handle,
    title,
    avatar,
    stats,
  };
}

async function fromInstagram(parsed: { handle: string; url: string }): Promise<LookedProfile> {
  const igHeaders = {
    "x-ig-app-id": "936619743392459",
    referer: `https://www.instagram.com/${parsed.handle}/`,
  };
  let empty: LookedProfile = {
    id: `instagram:${parsed.handle}`,
    url: parsed.url,
    platform: "instagram",
    handle: parsed.handle,
    title: parsed.handle,
    avatar: null,
    stats: [],
  };

  try {
    const raw = await fetchText(
      `https://www.instagram.com/api/v1/users/web_profile_info/?username=${encodeURIComponent(parsed.handle)}`,
      DESK_UA,
      { ...igHeaders, accept: "application/json" },
    );
    const json = JSON.parse(raw) as {
      data?: {
        user?: {
          full_name?: string;
          profile_pic_url_hd?: string;
          profile_pic_url?: string;
          edge_followed_by?: { count?: number };
          edge_follow?: { count?: number };
          edge_owner_to_timeline_media?: { count?: number };
        };
      };
    };
    const user = json.data?.user;
    if (user) {
      const stats: ProfileStat[] = [];
      if (typeof user.edge_followed_by?.count === "number") stats.push({ key: "followers", label: "Followers", value: user.edge_followed_by.count });
      if (typeof user.edge_follow?.count === "number") stats.push({ key: "following", label: "Following", value: user.edge_follow.count });
      if (typeof user.edge_owner_to_timeline_media?.count === "number")
        stats.push({ key: "posts", label: "Posts", value: user.edge_owner_to_timeline_media.count });
      return {
        ...empty,
        title: user.full_name || parsed.handle,
        avatar: user.profile_pic_url_hd || user.profile_pic_url || null,
        stats,
      };
    }
  } catch {
    /* try html */
  }

  try {
    const html = await fetchText(parsed.url, DESK_UA, igHeaders);
    const name = html.match(/"full_name":"([^"]+)"/)?.[1];
    const avatar = html.match(/"profile_pic_url_hd":"([^"]+)"/)?.[1] || html.match(/"profile_pic_url":"([^"]+)"/)?.[1] || meta(html, "og:image");
    const followers = html.match(/"edge_followed_by":\{"count":(\d+)/)?.[1];
    const following = html.match(/"edge_follow":\{"count":(\d+)/)?.[1];
    const posts = html.match(/"edge_owner_to_timeline_media":\{"count":(\d+)/)?.[1];
    const desc = meta(html, "og:description") || "";
    const stats: ProfileStat[] = [];
    const f = followers ? num(followers) : desc.match(/([\d.,]+[KMB]?)\s*Followers/i)?.[1] ? parseAbbrev(desc.match(/([\d.,]+[KMB]?)\s*Followers/i)![1]) : null;
    const g = following ? num(following) : desc.match(/([\d.,]+[KMB]?)\s*Following/i)?.[1] ? parseAbbrev(desc.match(/([\d.,]+[KMB]?)\s*Following/i)![1]) : null;
    const p = posts ? num(posts) : desc.match(/([\d.,]+[KMB]?)\s*Posts/i)?.[1] ? parseAbbrev(desc.match(/([\d.,]+[KMB]?)\s*Posts/i)![1]) : null;
    if (f != null) stats.push({ key: "followers", label: "Followers", value: f });
    if (g != null) stats.push({ key: "following", label: "Following", value: g });
    if (p != null) stats.push({ key: "posts", label: "Posts", value: p });
    if (name || avatar || stats.length) {
      return {
        ...empty,
        title: name || meta(html, "og:title") || parsed.handle,
        avatar: avatar ? decode(avatar) : null,
        stats,
      };
    }
  } catch {
    /* try oembed */
  }

  try {
    const raw = await fetchText(`https://www.instagram.com/oembed/?url=${encodeURIComponent(parsed.url)}`, DESK_UA, {
      accept: "application/json",
    });
    const json = JSON.parse(raw) as { author_name?: string; thumbnail_url?: string; title?: string };
    empty = {
      ...empty,
      title: json.author_name || json.title || parsed.handle,
      avatar: json.thumbnail_url || null,
    };
  } catch {
    /* socialblade */
  }
  const sb = await instagramSocialBlade(parsed);
  if (sb?.stats.length) return { ...sb, title: sb.title || empty.title, avatar: sb.avatar || empty.avatar };
  try {
    const { instagramSocialBladeBrowser } = await import("./profile-browser.server.ts");
    const live = await instagramSocialBladeBrowser(parsed.handle, parsed.url);
    if (live?.stats.length) return { ...live, title: live.title || empty.title, avatar: live.avatar || empty.avatar };
  } catch {
    /* keep empty */
  }
  return empty;
}

async function instagramSocialBlade(parsed: { handle: string; url: string }): Promise<LookedProfile | null> {
  try {
    const html = await fetchText(`https://socialblade.com/instagram/user/${encodeURIComponent(parsed.handle)}`, DESK_UA);
    const chunk = html.match(new RegExp(`"username":"${parsed.handle}"([\\s\\S]{0,5000})`, "i"))?.[1] || "";
    const name = chunk.match(/"displayName":"([^"]*)"/)?.[1];
    const avatar = chunk.match(/"avatar":"(https:[^"]+)"/)?.[1];
    const f = num(chunk.match(/"followers":"?(\d+)"?/)?.[1] || "");
    const g = num(chunk.match(/"following":(\d+)/)?.[1] || "");
    const p = num(chunk.match(/"mediaCount":(\d+)/)?.[1] || "");
    const stats: ProfileStat[] = [];
    if (f != null) stats.push({ key: "followers", label: "Followers", value: f });
    if (g != null) stats.push({ key: "following", label: "Following", value: g });
    if (p != null) stats.push({ key: "posts", label: "Posts", value: p });
    if (!stats.length) return null;
    return {
      id: `instagram:${parsed.handle}`,
      url: parsed.url,
      platform: "instagram",
      handle: parsed.handle,
      title: name || parsed.handle,
      avatar: avatar ? decode(avatar) : null,
      stats,
    };
  } catch {
    return null;
  }
}

async function lookupFacebook(parsed: { handle: string; url: string }): Promise<LookedProfile> {
  const id = parsed.handle.match(/(\d{8,})$/)?.[1] || "";
  const urls = [
    parsed.url,
    id ? `https://www.facebook.com/profile.php?id=${id}` : "",
    parsed.handle.includes("-") ? `https://www.facebook.com/p/${parsed.handle}/` : "",
    id ? `https://www.facebook.com/p/${parsed.handle}/` : "",
  ].filter((u, i, a) => u && a.indexOf(u) === i);

  let best: LookedProfile | null = null;
  for (const href of urls) {
    try {
      const html = await fetchText(href, PHONE_UA);
      const row = fromFacebook(html, parsed);
      if (!best || row.stats.length > best.stats.length) best = row;
      if (row.stats.length) break;
    } catch {
      /* next url */
    }
  }
  if (best?.stats.length) return best;

  const pluginHref = best?.url || urls[0];
  try {
    const html = await fetchText(
      `https://www.facebook.com/plugins/page.php?href=${encodeURIComponent(pluginHref)}&tabs=timeline&width=500&height=800`,
      DESK_UA,
    );
    const title = html.match(/title="([^"]+)"[^>]*href="https:\/\/www\.facebook\.com/i)?.[1] || best?.title || parsed.handle;
    const avatar = html.match(/https:\/\/scontent[^"'\s>]+/)?.[0]?.replace(/&/g, "&") || best?.avatar || null;
    const f = countIn(html, "followers");
    const stats: ProfileStat[] = [];
    if (f != null) stats.push({ key: "followers", label: "Followers", value: f });
    if (stats.length) {
      return {
        id: `facebook:${parsed.handle}`,
        url: pluginHref,
        platform: "facebook",
        handle: parsed.handle,
        title,
        avatar,
        stats,
      };
    }
  } catch {
    /* keep best */
  }
  return (
    best || {
      id: `facebook:${parsed.handle}`,
      url: parsed.url,
      platform: "facebook",
      handle: parsed.handle,
      title: parsed.handle,
      avatar: null,
      stats: [],
    }
  );
}

function fromGeneric(html: string, parsed: { platform: string; handle: string; url: string }): LookedProfile {
  const title = (meta(html, "og:title") || parsed.handle).replace(/\s*[|·•].*$/, "");
  const avatar = meta(html, "og:image");
  const desc = meta(html, "og:description") || "";
  const stats: ProfileStat[] = [];
  const followers = desc.match(/([\d.,]+[KMB]?)\s*Followers/i);
  const following = desc.match(/([\d.,]+[KMB]?)\s*Following/i);
  const posts = desc.match(/([\d.,]+[KMB]?)\s*Posts/i);
  const f = followers?.[1] ? parseAbbrev(followers[1]) : null;
  const g = following?.[1] ? parseAbbrev(following[1]) : null;
  const p = posts?.[1] ? parseAbbrev(posts[1]) : null;
  if (f != null) stats.push({ key: "followers", label: "Followers", value: f });
  if (g != null) stats.push({ key: "following", label: "Following", value: g });
  if (p != null) stats.push({ key: "posts", label: "Posts", value: p });
  return {
    id: `${parsed.platform}:${parsed.handle}`,
    url: parsed.url,
    platform: parsed.platform,
    handle: parsed.handle,
    title,
    avatar,
    stats,
  };
}

export async function lookupProfile(url: string, live = false): Promise<LookedProfile> {
  const parsed = parseProfileUrl(url);
  if (!parsed) throw new Error("Need a profile link (TikTok, YouTube, Instagram, Facebook…)");
  const id = `${parsed.platform}:${parsed.handle}`;
  const hit = cache.get(id);
  const ttl = lookupTtl(parsed.platform);
  if (hit && Date.now() - hit.at < ttl && (!live || hit.data.stats.length)) return hit.data;
  const viaApi = await lookupViaApi(parsed).catch(() => null);
  if (viaApi?.stats.length) {
    cache.set(id, { at: Date.now(), data: viaApi });
    return viaApi;
  }
  let data: LookedProfile;
  try {
    if (parsed.platform === "tiktok") {
      try {
        const html = await fetchText(parsed.url);
        data = fromTikTok(html, parsed);
      } catch {
        const oembed = await fetch(`https://www.tiktok.com/oembed?url=${encodeURIComponent(parsed.url)}`, {
          headers: { accept: "application/json", "user-agent": UA },
          signal: AbortSignal.timeout(8000),
        });
        const json = (await oembed.json()) as { author_name?: string; thumbnail_url?: string; title?: string };
        data = {
          id: `tiktok:${parsed.handle}`,
          url: parsed.url,
          platform: "tiktok",
          handle: parsed.handle,
          title: json.author_name || json.title || parsed.handle,
          avatar: json.thumbnail_url || null,
          stats: [],
        };
      }
    } else if (parsed.platform === "youtube") {
      const about = `${parsed.url.replace(/\/$/, "")}/about`;
      const html = await fetchText(about, DESK_UA).catch(() => fetchText(parsed.url, DESK_UA));
      data = fromYouTube(html, parsed);
    } else if (parsed.platform === "facebook") {
      data = await lookupFacebook(parsed);
    } else if (parsed.platform === "instagram") {
      data = await fromInstagram(parsed);
    } else {
      const html = await fetchText(parsed.url, DESK_UA);
      data = fromGeneric(html, parsed);
    }
  } catch {
    data = {
      id: `${parsed.platform}:${parsed.handle}`,
      url: parsed.url,
      platform: parsed.platform,
      handle: parsed.handle,
      title: parsed.handle,
      avatar: null,
      stats: [],
    };
  }
  if (!data.title) data.title = parsed.handle;
  if (viaApi) {
    data = {
      ...data,
      title: data.title || viaApi.title,
      avatar: data.avatar || viaApi.avatar,
      stats: data.stats.length ? data.stats : viaApi.stats,
    };
  }
  if (hit?.data) {
    data = {
      ...data,
      title: data.title || hit.data.title,
      avatar: data.avatar || hit.data.avatar,
      stats: data.stats.length ? data.stats : hit.data.stats,
    };
  }
  cache.set(id, { at: Date.now(), data });
  return data;
}

const feedCache = new Map<string, { at: number; data: ProfileFeed }>();
const FEED_TTL = 45_000;

function tiktokItemsFromEmbed(html: string, handle: string): ProfileItem[] {
  const items: ProfileItem[] = [];
  const seen = new Set<string>();
  const idx = html.indexOf('"videoList":');
  if (idx >= 0) {
    try {
      const slice = html.slice(idx + '"videoList":'.length).trim();
      const start = slice.indexOf("[");
      let list: Record<string, unknown>[] = [];
      if (start >= 0) {
        let depth = 0;
        for (let i = start; i < slice.length; i++) {
          if (slice[i] === "[") depth += 1;
          else if (slice[i] === "]") {
            depth -= 1;
            if (depth === 0) {
              list = JSON.parse(slice.slice(start, i + 1)) as Record<string, unknown>[];
              break;
            }
          }
        }
      }
      for (const obj of list) {
        const id = String(obj.id || "");
        if (!id || seen.has(id) || id.length < 15) continue;
        seen.add(id);
        const snow = Number(BigInt(id) >> 32n) * 1000;
        items.push({
          id,
          url: `https://www.tiktok.com/@${handle}/video/${id}`,
          title: String(obj.desc || "Video"),
          thumb: String(obj.coverUrl || obj.originCoverUrl || "") || null,
          at: Number.isFinite(snow) ? snow : 0,
          kind: "video",
          stats: typeof obj.playCount === "number" ? [{ key: "views", label: "Views", value: obj.playCount }] : [],
        });
      }
    } catch {
      /* fall through */
    }
  }
  if (items.length) return items;
  let from = 0;
  while (items.length < 24) {
    const i = html.indexOf('"playCount":', from);
    if (i < 0) break;
    const start = html.lastIndexOf('{"id":"', i);
    const end = html.indexOf("}", i);
    from = i + 12;
    if (start < 0 || end < 0) continue;
    try {
      const obj = JSON.parse(html.slice(start, end + 1)) as {
        id?: string;
        desc?: string;
        coverUrl?: string;
        originCoverUrl?: string;
        playCount?: number;
      };
      if (!obj.id || seen.has(obj.id) || typeof obj.playCount !== "number") continue;
      seen.add(obj.id);
      const snow = Number(BigInt(obj.id) >> 32n) * 1000;
      items.push({
        id: obj.id,
        url: `https://www.tiktok.com/@${handle}/video/${obj.id}`,
        title: obj.desc || "Video",
        thumb: obj.coverUrl || obj.originCoverUrl || null,
        at: Number.isFinite(snow) ? snow : Date.now() - items.length * 1000,
        kind: "video",
        stats: [{ key: "views", label: "Views", value: obj.playCount }],
      });
    } catch {
      /* skip a bad slice */
    }
  }
  return items;
}

async function enrichTikTok(handle: string, item: ProfileItem): Promise<ProfileItem> {
  try {
    const html = await fetchText(item.url, DESK_UA);
    const m = html.match(/<script id="__UNIVERSAL_DATA_FOR_REHYDRATION__"[^>]*>(.*?)<\/script>/);
    if (!m?.[1]) return item;
    const scope = JSON.parse(m[1]) as {
      __DEFAULT_SCOPE__?: {
        "webapp.video-detail"?: {
          itemInfo?: {
            itemStruct?: {
              desc?: string;
              createTime?: number;
              stats?: {
                diggCount?: number;
                shareCount?: number;
                commentCount?: number;
                playCount?: number;
                collectCount?: number | string;
              };
              video?: { cover?: string; originCover?: string };
            };
          };
        };
      };
    };
    const it = scope.__DEFAULT_SCOPE__?.["webapp.video-detail"]?.itemInfo?.itemStruct;
    if (!it) return item;
    const st = it.stats || {};
    const stats: ProfileStat[] = [];
    const views = typeof st.playCount === "number" ? st.playCount : item.stats.find((s) => s.key === "views")?.value;
    if (views != null) stats.push({ key: "views", label: "Views", value: views });
    if (typeof st.diggCount === "number") stats.push({ key: "likes", label: "Likes", value: st.diggCount });
    if (typeof st.commentCount === "number") stats.push({ key: "comments", label: "Comments", value: st.commentCount });
    if (typeof st.shareCount === "number") stats.push({ key: "shares", label: "Shares", value: st.shareCount });
    const collect = typeof st.collectCount === "number" ? st.collectCount : Number(st.collectCount);
    if (Number.isFinite(collect) && collect > 0) stats.push({ key: "saves", label: "Saves", value: collect });
    return {
      ...item,
      title: it.desc || item.title,
      thumb: it.video?.cover || it.video?.originCover || item.thumb,
      at: it.createTime ? it.createTime * 1000 : item.at,
      stats: stats.length ? stats : item.stats,
    };
  } catch {
    return item;
  }
}

function parseYouTubeRss(xml: string): ProfileItem[] {
  const parts = xml.split("<entry>").slice(1);
  const items: ProfileItem[] = [];
  for (const raw of parts) {
    const id = raw.match(/<yt:videoId>([^<]+)<\/yt:videoId>/)?.[1];
    if (!id) continue;
    const title = decode(raw.match(/<title>([^<]*)<\/title>/)?.[1] || "Video");
    const published = raw.match(/<published>([^<]+)<\/published>/)?.[1];
    const thumb = raw.match(/<media:thumbnail url="([^"]+)"/)?.[1] || `https://i.ytimg.com/vi/${id}/hqdefault.jpg`;
    const views = num(raw.match(/<media:statistics views="(\d+)"/)?.[1] || "");
    const href = raw.match(/<link rel="alternate" href="([^"]+)"/)?.[1] || `https://www.youtube.com/watch?v=${id}`;
    const short = /\/shorts\//.test(href);
    const stats: ProfileStat[] = [];
    if (views != null) stats.push({ key: "views", label: "Views", value: views });
    items.push({
      id,
      url: href,
      title,
      thumb,
      at: published ? Date.parse(published) : 0,
      kind: short ? "short" : "video",
      stats,
    });
  }
  return items;
}

async function instagramFeed(handle: string): Promise<{ items: ProfileItem[]; cursor: string | null }> {
  try {
    const raw = await fetchText(
      `https://www.instagram.com/api/v1/users/web_profile_info/?username=${encodeURIComponent(handle)}`,
      DESK_UA,
      {
        "x-ig-app-id": "936619743392459",
        referer: `https://www.instagram.com/${handle}/`,
        accept: "application/json",
      },
    );
    const json = JSON.parse(raw) as {
      data?: {
        user?: {
          edge_owner_to_timeline_media?: {
            page_info?: { has_next_page?: boolean; end_cursor?: string };
            edges?: {
              node?: {
                id?: string;
                shortcode?: string;
                taken_at_timestamp?: number;
                display_url?: string;
                thumbnail_src?: string;
                is_video?: boolean;
                video_view_count?: number;
                __typename?: string;
                edge_liked_by?: { count?: number };
                edge_media_to_comment?: { count?: number };
                edge_media_preview_like?: { count?: number };
                accessibility_caption?: string;
              };
            }[];
          };
        };
      };
    };
    const media = json.data?.user?.edge_owner_to_timeline_media;
    const edges = media?.edges || [];
    const items = edges
      .map((e) => e.node)
      .filter((n): n is NonNullable<typeof n> => Boolean(n?.shortcode || n?.id))
      .map((n) => {
        const likes = n.edge_liked_by?.count ?? n.edge_media_preview_like?.count;
        const comments = n.edge_media_to_comment?.count;
        const views = n.video_view_count;
        const stats: ProfileStat[] = [];
        if (typeof views === "number") stats.push({ key: "views", label: "Views", value: views });
        if (typeof likes === "number") stats.push({ key: "likes", label: "Likes", value: likes });
        if (typeof comments === "number") stats.push({ key: "comments", label: "Comments", value: comments });
        const reel = (n.__typename || "").toLowerCase().includes("reel") || Boolean(n.is_video);
        return {
          id: n.shortcode || n.id || "",
          url: `https://www.instagram.com/${n.is_video ? "reel" : "p"}/${n.shortcode || n.id}/`,
          title: n.accessibility_caption || (n.is_video ? "Reel" : "Post"),
          thumb: n.display_url || n.thumbnail_src || null,
          at: n.taken_at_timestamp ? n.taken_at_timestamp * 1000 : 0,
          kind: reel ? "reel" : "post",
          stats,
        };
      });
    const next = media?.page_info?.has_next_page && media.page_info.end_cursor ? `IG|${media.page_info.end_cursor}` : null;
    if (items.length) return { items, cursor: next };
  } catch {
    /* public RSS fallback */
  }
  return instagramRss(handle);
}

async function instagramRss(handle: string): Promise<{ items: ProfileItem[]; cursor: string | null }> {
  try {
    const raw = await fetchText(
      `https://rss-bridge.org/bridge01/?action=display&bridge=InstagramBridge&context=Username&u=${encodeURIComponent(handle)}&format=Json&direct_links=1`,
      DESK_UA,
      { accept: "application/json" },
    );
    const json = JSON.parse(raw) as {
      items?: {
        id?: string;
        title?: string;
        url?: string;
        date_modified?: string;
        content_html?: string;
        attachments?: { url?: string }[];
        _rssbridge?: { thumbnail?: string };
      }[];
    };
    const items: ProfileItem[] = [];
    for (const row of json.items || []) {
      const href = row.url || row.id || "";
      const code = href.match(/instagram\.com\/(p|reel)\/([A-Za-z0-9_-]+)/)?.[2];
      if (!code && !href) continue;
      const poster = row.content_html?.match(/poster="([^"]+)"/)?.[1] || row.content_html?.match(/<img[^>]+src="([^"]+)"/)?.[1];
      const thumb =
        (row._rssbridge?.thumbnail && !/instagram\.com\/.+\/media/i.test(row._rssbridge.thumbnail)
          ? row._rssbridge.thumbnail
          : null) ||
        poster ||
        row.attachments?.[0]?.url ||
        (code ? `https://www.instagram.com/p/${code}/media?size=l` : null);
      const video = /^\s*▶/.test(row.title || "") || /<video/i.test(row.content_html || "");
      items.push({
        id: code || href,
        url: href || `https://www.instagram.com/p/${code}/`,
        title: (row.title || "Post").replace(/^\s*▶\s*/, "").trim(),
        thumb,
        at: row.date_modified ? Date.parse(row.date_modified) : 0,
        kind: video ? "reel" : "post",
        stats: [],
      });
    }
    return { items, cursor: null };
  } catch {
    return { items: [], cursor: null };
  }
}

async function facebookRss(handle: string, pageUrl: string): Promise<{ items: ProfileItem[]; cursor: string | null }> {
  let canonical = pageUrl;
  let vanity = /^[A-Za-z][A-Za-z0-9.]+$/.test(handle) ? handle : "";
  try {
    const html = await fetchText(pageUrl, PHONE_UA);
    const og = meta(html, "og:url");
    if (og) canonical = og;
    vanity =
      html.match(/"userVanity":"([^"]+)"/)?.[1] ||
      (og ? new URL(og).pathname.split("/").filter(Boolean).pop() : "") ||
      vanity;
  } catch {
    /* keep */
  }
  const id = handle.match(/(\d{8,})$/)?.[1] || vanity.match(/(\d{8,})$/)?.[1] || "";
  const names = [...new Set([vanity, handle, id].filter((n) => /^[A-Za-z0-9.]+$/.test(n) && n.length > 2))];
  for (const name of names) {
    try {
      const raw = await fetchText(
        `https://rss-bridge.org/bridge01/?action=display&bridge=FacebookBridge&context=User&u=${encodeURIComponent(name)}&format=Json`,
        DESK_UA,
        { accept: "application/json" },
      );
      const json = JSON.parse(raw) as {
        items?: {
          id?: string;
          title?: string;
          url?: string;
          date_modified?: string;
          content_html?: string;
          attachments?: { url?: string }[];
        }[];
      };
      const items = (json.items || [])
        .map((row) => {
          const img = row.attachments?.[0]?.url || row.content_html?.match(/<img[^>]+src="([^"]+)"/)?.[1] || null;
          return {
            id: row.id || row.url || "",
            url: row.url || pageUrl,
            title: (row.title || "Post").replace(/<[^>]+>/g, "").slice(0, 140),
            thumb: img,
            at: row.date_modified ? Date.parse(row.date_modified) : 0,
            kind: "post",
            stats: [] as ProfileStat[],
          };
        })
        .filter((row) => row.id || row.title);
      if (items.length) return { items, cursor: null };
    } catch {
      /* try plugin */
    }
  }
  try {
    const href = encodeURIComponent(canonical);
    const html = await fetchText(
      `https://www.facebook.com/plugins/page.php?href=${href}&tabs=timeline&width=500&height=2500&small_header=true`,
      DESK_UA,
    );
    const items: ProfileItem[] = [];
    const seen = new Set<string>();
    const re = /href="(https:\/\/www\.facebook\.com\/[^"]+\/(?:posts|videos|reel)\/[^"]+)"/gi;
    let m: RegExpExecArray | null;
    while ((m = re.exec(html))) {
      const url = m[1].replace(/&/g, "&").split("?")[0];
      if (seen.has(url)) continue;
      seen.add(url);
      items.push({
        id: url,
        url,
        title: "Post",
        thumb: null,
        at: 0,
        kind: /reel|video/i.test(url) ? "reel" : "post",
        stats: [],
      });
    }
    const imgs = [...html.matchAll(/https:\/\/scontent[^"'\s>]+/g)].map((x) => x[0].replace(/&/g, "&"));
    for (let i = 1; i < imgs.length && i - 1 < items.length; i += 1) {
      const row = items[i - 1];
      if (row && !row.thumb) row.thumb = imgs[i];
    }
    if (items.length) return { items, cursor: null };
  } catch {
    /* empty */
  }
  return { items: [], cursor: null };
}

function parseViews(raw: string): number | null {
  const m = raw.replace(/,/g, "").match(/([\d.]+)\s*([kmb])?/i);
  if (!m) return null;
  const n = Number(m[1]);
  if (!Number.isFinite(n)) return null;
  const u = (m[2] || "").toLowerCase();
  if (u === "k") return Math.round(n * 1_000);
  if (u === "m") return Math.round(n * 1_000_000);
  if (u === "b") return Math.round(n * 1_000_000_000);
  return Math.round(n);
}

function parseAgo(raw: string): number {
  const now = Date.now();
  const m = raw.trim().match(/(\d+)\s*(second|minute|hour|day|week|month|year)s?\s+ago/i);
  if (!m) return 0;
  const n = Number(m[1]);
  const u = m[2].toLowerCase();
  const ms =
    u === "second" ? 1_000 :
    u === "minute" ? 60_000 :
    u === "hour" ? 3_600_000 :
    u === "day" ? 86_400_000 :
    u === "week" ? 604_800_000 :
    u === "month" ? 2_592_000_000 :
    31_536_000_000;
  return now - n * ms;
}

type YtWalk = { items: ProfileItem[]; token: string | null };

function walkYouTube(node: unknown, out: YtWalk, depth = 0): void {
  if (depth > 18 || node == null) return;
  if (Array.isArray(node)) {
    for (const v of node) walkYouTube(v, out, depth + 1);
    return;
  }
  if (typeof node !== "object") return;
  const o = node as Record<string, unknown>;
  const lock = o.lockupViewModel as {
    contentId?: string;
    contentType?: string;
    metadata?: { lockupMetadataViewModel?: { title?: { content?: string }; metadata?: { contentMetadataViewModel?: { metadataRows?: { metadataParts?: { text?: { content?: string } }[] }[] } } } };
  } | undefined;
  if (lock?.contentId && (!lock.contentType || /VIDEO/i.test(lock.contentType))) {
    const title = lock.metadata?.lockupMetadataViewModel?.title?.content || "Video";
    const parts = lock.metadata?.lockupMetadataViewModel?.metadata?.contentMetadataViewModel?.metadataRows?.[0]?.metadataParts || [];
    const viewsRaw = parts[0]?.text?.content || "";
    const agoRaw = parts[1]?.text?.content || "";
    const views = parseViews(viewsRaw);
    const stats: ProfileStat[] = [];
    if (views != null) stats.push({ key: "views", label: "Views", value: views });
    if (!out.items.some((i) => i.id === lock.contentId)) {
      out.items.push({
        id: lock.contentId,
        url: `https://www.youtube.com/watch?v=${lock.contentId}`,
        title,
        thumb: `https://i.ytimg.com/vi/${lock.contentId}/hqdefault.jpg`,
        at: parseAgo(agoRaw),
        kind: "video",
        stats,
      });
    }
  }
  const cont = o.continuationItemRenderer as { continuationEndpoint?: { continuationCommand?: { token?: string } } } | undefined;
  const token = cont?.continuationEndpoint?.continuationCommand?.token;
  if (token) out.token = token;
  for (const v of Object.values(o)) walkYouTube(v, out, depth + 1);
}

async function youtubeInnertube(channel: string, continuation?: string): Promise<{ items: ProfileItem[]; cursor: string | null }> {
  const payload = continuation
    ? {
        context: { client: { clientName: "WEB", clientVersion: "2.20240918.01.00", hl: "en", gl: "US" } },
        continuation,
      }
    : {
        context: { client: { clientName: "WEB", clientVersion: "2.20240918.01.00", hl: "en", gl: "US" } },
        browseId: channel,
        params: "EgZ2aWRlb3PyBgQKAjoA",
      };
  const res = await fetch("https://www.youtube.com/youtubei/v1/browse?prettyPrint=false", {
    method: "POST",
    headers: { "content-type": "application/json", "user-agent": DESK_UA },
    body: JSON.stringify(payload),
    signal: AbortSignal.timeout(12_000),
  });
  if (!res.ok) return { items: [], cursor: null };
  const json: unknown = await res.json();
  const out: YtWalk = { items: [], token: null };
  walkYouTube(json, out);
  return { items: out.items, cursor: out.token ? `YC|${channel}|${out.token}` : null };
}

function parseAlong(raw: string): number | null {
  const m = raw.match(/along with ([\d,.]+[KMB]?) other/i) || raw.match(/([\d,.]+[KMB]?)\s+likes/i);
  return m?.[1] ? parseAbbrev(m[1]) : null;
}

async function youtubeNextStats(id: string): Promise<ProfileStat[]> {
  try {
    const res = await fetch("https://www.youtube.com/youtubei/v1/next?prettyPrint=false", {
      method: "POST",
      headers: { "content-type": "application/json", "user-agent": DESK_UA },
      body: JSON.stringify({
        context: { client: { clientName: "WEB", clientVersion: "2.20240918.01.00", hl: "en" } },
        videoId: id,
      }),
      signal: AbortSignal.timeout(7000),
    });
    if (!res.ok) return [];
    const text = await res.text();
    const stats: ProfileStat[] = [];
    const likes = parseAlong(text);
    if (likes != null) stats.push({ key: "likes", label: "Likes", value: likes });
    const comments =
      text.match(/"text":"Comments"[\s\S]{0,400}?"contextualInfo":\{"runs":\[\{"text":"([^"]+)"/) ||
      text.match(/"text":"Comments"[\s\S]{0,220}?"contextualInfo"[\s\S]{0,120}?"text":"([^"]+)"/) ||
      text.match(/engagement-panel-comments-section[\s\S]{0,500}?"contextualInfo"[\s\S]{0,120}?"text":"([^"]+)"/) ||
      text.match(/"commentCount"\s*:\s*"(\d+)"/) ||
      text.match(/"text":"([\d,.]+[KMB]?)\s*Comments"/i);
    const c = comments?.[1] ? parseAbbrev(comments[1]) ?? num(comments[1].replace(/,/g, "")) : null;
    if (c != null) stats.push({ key: "comments", label: "Comments", value: c });
    const views =
      text.match(/"viewCount"\s*:\s*\{\s*"simpleText":"([\d,]+)/) ||
      text.match(/"videoViewCountRenderer"[^}]{0,200}"simpleText":"([\d,.]+[KMB]?) views"/i);
    const v = views?.[1] ? parseAbbrev(views[1]) ?? Number(views[1].replace(/,/g, "")) : null;
    if (v != null && Number.isFinite(v)) stats.push({ key: "views", label: "Views", value: v });
    return stats;
  } catch {
    return [];
  }
}

async function attachYouTubeEngagement(items: ProfileItem[]): Promise<ProfileItem[]> {
  if (!items.length) return items;
  const extra = new Map<string, ProfileStat[]>();
  try {
    const { getSocialKey } = await import("@/lib/smm/social.server.ts");
    const key = await getSocialKey("youtube");
    if (key) {
      const ids = items.map((i) => i.id).filter(Boolean);
      for (let i = 0; i < ids.length; i += 50) {
        const chunk = ids.slice(i, i + 50);
        const res = await fetch(
          `https://www.googleapis.com/youtube/v3/videos?part=statistics&id=${chunk.join(",")}&key=${encodeURIComponent(key.token)}`,
          { signal: AbortSignal.timeout(8000) },
        );
        if (!res.ok) continue;
        const json = (await res.json()) as { items?: { id?: string; statistics?: Record<string, string> }[] };
        for (const row of json.items || []) {
          if (!row.id) continue;
          const stats: ProfileStat[] = [];
          const views = Number(row.statistics?.viewCount);
          const likes = Number(row.statistics?.likeCount);
          const comments = Number(row.statistics?.commentCount);
          if (Number.isFinite(views)) stats.push({ key: "views", label: "Views", value: views });
          if (Number.isFinite(likes)) stats.push({ key: "likes", label: "Likes", value: likes });
          if (Number.isFinite(comments)) stats.push({ key: "comments", label: "Comments", value: comments });
          extra.set(row.id, stats);
        }
      }
    }
  } catch {
    /* public fallback */
  }
  const missing = items.filter((i) => !(extra.get(i.id) || []).some((s) => s.key === "comments"));
  const queue = [...missing];
  const workers = Array.from({ length: Math.min(6, queue.length) }, async () => {
    while (queue.length) {
      const row = queue.shift();
      if (!row) break;
      const next = await youtubeNextStats(row.id);
      const prev = extra.get(row.id) || [];
      extra.set(row.id, [...prev.filter((s) => !next.some((n) => n.key === s.key)), ...next]);
    }
  });
  await Promise.all(workers);
  return items.map((item) => {
    const add = extra.get(item.id);
    const by = new Map(item.stats.filter((s) => s.label !== "Ratings").map((s) => [s.key, s]));
    for (const s of add || []) by.set(s.key, s);
    if (!by.has("comments")) by.set("comments", { key: "comments", label: "Comments", value: 0 });
    return { ...item, stats: ["views", "likes", "comments"].flatMap((k) => (by.get(k) ? [by.get(k)!] : [])) };
  });
}

export async function loadProfileFeed(url: string, cursor?: string | null, live = false, drain = false): Promise<ProfileFeed> {
  void live;
  const parsed = parseProfileUrl(url);
  if (!parsed) return { platform: "", handle: "", items: [], cursor: null };
  const cacheKey = `${parsed.platform}:${parsed.handle}:${drain ? "drain" : cursor || ""}`;
  if (!cursor && !drain) {
    const hit = feedCache.get(cacheKey);
    const ttl = parsed.platform === "facebook" || parsed.platform === "instagram" ? 90_000 : FEED_TTL;
    if (hit && Date.now() - hit.at < ttl && hit.data.items.length > 0) {
      return hit.data;
    }
  }
  const viaApi = await feedViaApi(parsed, cursor, drain).catch(() => null);
  if (viaApi && (viaApi.items.length || viaApi.cursor)) {
    const data = { platform: parsed.platform, handle: parsed.handle, items: viaApi.items, cursor: viaApi.cursor };
    if (!cursor) feedCache.set(cacheKey, { at: Date.now(), data });
    return data;
  }
  let items: ProfileItem[] = [];
  let next: string | null = null;
  try {
    if (parsed.platform === "tiktok") {
      const skip = cursor?.startsWith("TP|") ? Number(cursor.slice(3)) || 0 : 0;
      if (!cursor && !drain) {
        const html = await fetchText(`https://www.tiktok.com/embed/@${parsed.handle}`, DESK_UA);
        const seed = tiktokItemsFromEmbed(html, parsed.handle);
        items = await Promise.all(seed.slice(0, 12).map((row) => enrichTikTok(parsed.handle, row)));
        items = tiktokConsecutive(items, parsed.handle);
        next = items.length ? `TP|${items.length}` : null;
      } else {
        const { tiktokBrowserFeed } = await import("./profile-browser.server.ts");
        const extra = await tiktokBrowserFeed(parsed.handle, skip, drain ? 80 : 24);
        items = tiktokConsecutive(extra.items, parsed.handle);
        next = extra.hasMore && items.length ? `TP|${skip + items.length}` : null;
      }
    } else if (parsed.platform === "youtube") {
      let channel = "";
      let cont = "";
      if (cursor?.startsWith("YC|")) {
        const parts = cursor.split("|");
        channel = parts[1] || "";
        cont = parts.slice(2).join("|");
      } else {
        const page = await fetchText(parsed.url, DESK_UA);
        channel = page.match(/"(?:browseId|externalId)":"(UC[^"]+)"/)?.[1] || "";
      }
      if (channel) {
        const page = await youtubeInnertube(channel, cont || undefined);
        items = page.items;
        next = page.cursor;
      }
      if (!items.length && !cursor) {
        const xml = await fetchText(
          `https://www.youtube.com/feeds/videos.xml?channel_id=${channel || ""}`,
          DESK_UA,
        ).catch(() => "");
        if (xml) items = parseYouTubeRss(xml);
      }
      if (items.length) items = await attachYouTubeEngagement(items);
    } else if (parsed.platform === "instagram") {
      if (!cursor) {
        const page = await instagramFeed(parsed.handle);
        items = page.items;
        next = page.cursor;
      } else {
        next = null;
      }
    } else if (parsed.platform === "facebook") {
      /* Graph is the source. Playwright hangs this tab on preview/Vercel. */
    }
  } catch {
    items = [];
  }
  const data = { platform: parsed.platform, handle: parsed.handle, items, cursor: next };
  if (!cursor) feedCache.set(cacheKey, { at: Date.now(), data });
  return data;
}
