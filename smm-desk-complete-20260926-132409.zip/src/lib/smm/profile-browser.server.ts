import type { LookedProfile, ProfileItem, ProfileStat } from "@/lib/smm/profile-types";
import { tiktokOwnVideo } from "@/lib/smm/tiktok-own";

function pageId(handle: string, url: string): string {
  return handle.match(/(\d{8,})$/)?.[1] || url.match(/(?:id=|\/)(\d{10,})/)?.[1] || "";
}

function parseAbbrev(raw: string): number | null {
  const m = raw.replace(/,/g, "").trim().match(/^([\d.]+)\s*([kmb])?/i);
  if (!m) return null;
  const n = Number(m[1]);
  if (!Number.isFinite(n)) return null;
  const u = (m[2] || "").toLowerCase();
  if (u === "k") return Math.round(n * 1_000);
  if (u === "m") return Math.round(n * 1_000_000);
  if (u === "b") return Math.round(n * 1_000_000_000);
  return Math.round(n);
}

function stripGlyphs(s: string): string {
  return s.replace(/\p{Co}/gu, " ").replace(/\s+/g, " ").trim();
}

function ageMs(text: string): number {
  const m = text.match(/\b(\d+)\s*(second|minute|hour|day|week|s|m|h|d)\b/i) || text.match(/(\d+)([smhd])\b/i);
  if (!m) return 0;
  const n = Number(m[1]);
  const u = (m[2] || "").toLowerCase();
  const unit = u.startsWith("second") || u === "s" ? 1_000
    : u.startsWith("minute") || u === "m" ? 60_000
    : u.startsWith("hour") || u === "h" ? 3_600_000
    : u.startsWith("week") ? 7 * 86_400_000
    : 86_400_000;
  return Date.now() - n * unit;
}

let fbBusy: Promise<ProfileItem[]> | null = null;
let igBusy: Promise<LookedProfile | null> | null = null;

export async function facebookBrowserFeed(handle: string, pageUrl: string): Promise<ProfileItem[]> {
  if (fbBusy) return fbBusy;
  fbBusy = scrapeFacebook(handle, pageUrl).finally(() => {
    fbBusy = null;
  });
  return fbBusy;
}

export async function instagramSocialBladeBrowser(handle: string, url: string): Promise<LookedProfile | null> {
  if (igBusy) return igBusy;
  igBusy = scrapeInstagramBlade(handle, url).finally(() => {
    igBusy = null;
  });
  return igBusy;
}

async function scrapeInstagramBlade(handle: string, url: string): Promise<LookedProfile | null> {
  let chromium: typeof import("playwright").chromium;
  let devices: typeof import("playwright").devices;
  try {
    ({ chromium, devices } = await import("playwright"));
  } catch {
    return null;
  }
  const browser = await chromium.launch({
    headless: true,
    args: ["--disable-blink-features=AutomationControlled", "--no-sandbox"],
    executablePath: process.env.PLAYWRIGHT_CHROMIUM_PATH || undefined,
  });
  try {
    const context = await browser.newContext({ ...devices["Desktop Chrome"], locale: "en-US" });
    const page = await context.newPage();
    page.setDefaultTimeout(22_000);
    await page.goto(`https://socialblade.com/instagram/user/${encodeURIComponent(handle)}`, {
      waitUntil: "domcontentloaded",
      timeout: 18_000,
    });
    await page.waitForTimeout(2_500);
    const row = await page.evaluate(() => {
      const text = document.body?.innerText || "";
      const followers = (text.match(/Followers\s+([\d,]+)/i) || [])[1] || "";
      const following = (text.match(/Following\s+([\d,]+)/i) || [])[1] || "";
      const media = (text.match(/Media Count\s+([\d,]+)/i) || [])[1] || "";
      const img = [...document.querySelectorAll("img")].find((i) => /profile picture/i.test(i.alt) || i.width >= 64);
      const title = (document.title || "").replace(/\s+'.*$/, "").replace(/\s+-+\s*Social Blade.*$/i, "").trim();
      return { title, avatar: img?.src || "", followers, following, media };
    });
    const stats: ProfileStat[] = [];
    const f = parseAbbrev(row.followers.replace(/,/g, ""));
    const g = parseAbbrev(row.following.replace(/,/g, ""));
    const p = parseAbbrev(row.media.replace(/,/g, ""));
    if (f != null) stats.push({ key: "followers", label: "Followers", value: f });
    if (g != null) stats.push({ key: "following", label: "Following", value: g });
    if (p != null) stats.push({ key: "posts", label: "Posts", value: p });
    if (!stats.length) return null;
    return {
      id: `instagram:${handle}`,
      url,
      platform: "instagram",
      handle,
      title: (row.title || handle).replace(/'s\s+Instagram Statistics[\s\S]*$/i, "").replace(/\s*-\s*Social Blade.*$/i, "").trim() || handle,
      avatar: row.avatar || null,
      stats,
    };
  } catch {
    return null;
  } finally {
    await browser.close().catch(() => undefined);
  }
}

async function scrapeFacebook(handle: string, pageUrl: string): Promise<ProfileItem[]> {
  let chromium: typeof import("playwright").chromium;
  let devices: typeof import("playwright").devices;
  try {
    ({ chromium, devices } = await import("playwright"));
  } catch {
    return [];
  }
  const id = pageId(handle, pageUrl);
  const target = id ? `https://m.facebook.com/profile.php?id=${id}&v=timeline` : pageUrl;
  const browser = await chromium.launch({
    headless: true,
    args: ["--disable-blink-features=AutomationControlled", "--no-sandbox"],
    executablePath: process.env.PLAYWRIGHT_CHROMIUM_PATH || undefined,
  });
  try {
    const context = await browser.newContext({ ...devices["iPhone 14"], locale: "en-US" });
    const page = await context.newPage();
    page.setDefaultTimeout(22_000);
    await page.goto(target, { waitUntil: "domcontentloaded", timeout: 18_000 });
    await page.waitForTimeout(4_500);
    const rows = await page.evaluate(() => {
      const seen = new Set<string>();
      const out: { file: string; src: string; href: string; video: boolean; text: string }[] = [];
      const imgs = [...document.querySelectorAll("img")].filter((img) => {
        const alt = img.getAttribute("alt") || "";
        const src = img.currentSrc || img.src || "";
        if (alt === "Video player") return true;
        if (!/scontent/.test(src) || /static\.xx\.fbcdn/.test(src)) return false;
        if (/t39\.30808-1/.test(src)) return false;
        const w = img.naturalWidth || img.width;
        return w >= 280 && (/t39\.30808-6/.test(src) || /t51\./.test(src));
      });
      for (const img of imgs) {
        const src = img.currentSrc || img.src;
        const file = (src.match(/\/(\d+_[^/?#]+)/) || [])[1] || src.slice(-48);
        if (!file || seen.has(file)) continue;
        seen.add(file);
        let text = "";
        let href = "";
        let el: HTMLElement | null = img.parentElement;
        for (let i = 0; i < 16 && el; i++) {
          const t = (el.innerText || "").replace(/[\uE000-\uF8FF]/g, " ").replace(/\s+/g, " ").trim();
          const vids = el.querySelectorAll('img[alt="Video player"]').length;
          const ok = img.alt === "Video player" ? vids === 1 : vids <= 1;
          if (ok && t.length > 8 && t.length < 800) text = t;
          const a = el.querySelector('a[href*="/reel/"], a[href*="/posts/"], a[href*="/videos/"], a[href*="/watch/"]') as HTMLAnchorElement | null;
          if (a && a.href) href = a.href.split("?")[0];
          el = el.parentElement;
        }
        out.push({ file, src, href, video: img.alt === "Video player", text });
      }
      return out;
    });
    const items: ProfileItem[] = [];
    for (const row of rows) {
      const text = stripGlyphs(row.text);
      if (!row.video && /Photos See all|Digital creator|Log in to get/i.test(text)) continue;
      const stats: ProfileStat[] = [];
      const others = text.match(/and\s+([\d.,]+[KMB]?)\s+others/i);
      const likes =
        (others?.[1] ? parseAbbrev(others[1]) : null) ??
        (text.match(/([\d.,]+[KMB]?)\s+likes?/i)?.[1] ? parseAbbrev(text.match(/([\d.,]+[KMB]?)\s+likes?/i)![1]) : null);
      const comments = text.match(/([\d.,]+[KMB]?)\s+comments?/i)?.[1];
      const shares = text.match(/([\d.,]+[KMB]?)\s+shares?/i)?.[1];
      if (likes != null) stats.push({ key: "likes", label: "Likes", value: likes });
      if (comments) {
        const n = parseAbbrev(comments);
        if (n != null) stats.push({ key: "comments", label: "Comments", value: n });
      }
      if (shares) {
        const n = parseAbbrev(shares);
        if (n != null) stats.push({ key: "shares", label: "Shares", value: n });
      }
      let title = text
        .replace(/^[^]*?(?=\d+[smhd]\b)/i, "")
        .replace(/^\d+[smhd]\S*\s*/i, "")
        .replace(/See more[\s\S]*$/i, "")
        .replace(/\s+and\s+[\d.,]+[KMB]?\s+others[\s\S]*$/i, "")
        .replace(/\s+[\d.,]+[KMB]?\s+(likes?|comments?|shares?)[\s\S]*$/gi, "")
        .trim();
      title = stripGlyphs(title);
      if (title.length < 3) title = row.video ? "Reel" : "Post";
      items.push({
        id: row.file.replace(/\.[a-z]+$/i, ""),
        url: row.href || pageUrl,
        title: title.slice(0, 140),
        thumb: row.src,
        at: ageMs(text),
        kind: row.video ? "reel" : "post",
        stats,
      });
    }
    return items;
  } catch {
    return [];
  } finally {
    await browser.close().catch(() => undefined);
  }
}

let ttBusy: Promise<{ items: ProfileItem[]; hasMore: boolean }> | null = null;
const ttPack = new Map<string, { items: ProfileItem[]; at: number; done: boolean }>();

function ttOwner(handle: string, row: Record<string, unknown>): boolean {
  const want = handle.replace(/^@/, "").toLowerCase();
  const author = (row.author || {}) as Record<string, unknown>;
  const name = String(author.uniqueId || author.unique_id || row.uniqueId || "").replace(/^@/, "").toLowerCase();
  if (!name) return false;
  return name === want;
}

function ttItem(handle: string, row: Record<string, unknown>): ProfileItem | null {
  if (!ttOwner(handle, row)) return null;
  const id = String(row.id || row.aweme_id || "");
  if (!id) return null;
  const statsBlock = (row.stats || {}) as Record<string, unknown>;
  const video = (row.video || {}) as Record<string, unknown>;
  const coverObj = video.cover as { urlList?: string[] } | string | undefined;
  const origin = video.originCover as { urlList?: string[] } | undefined;
  const thumb =
    (typeof coverObj === "string" ? coverObj : coverObj?.urlList?.[0]) ||
    origin?.urlList?.[0] ||
    (typeof row.cover === "string" ? row.cover : null) ||
    null;
  const stats: ProfileStat[] = [];
  const views = Number(statsBlock.playCount ?? statsBlock.play_count);
  const likes = Number(statsBlock.diggCount ?? statsBlock.digg_count);
  const comments = Number(statsBlock.commentCount ?? statsBlock.comment_count);
  const shares = Number(statsBlock.shareCount ?? statsBlock.share_count);
  const saves = Number(statsBlock.collectCount ?? statsBlock.collect_count);
  if (Number.isFinite(views)) stats.push({ key: "views", label: "Views", value: views });
  if (Number.isFinite(likes)) stats.push({ key: "likes", label: "Likes", value: likes });
  if (Number.isFinite(comments)) stats.push({ key: "comments", label: "Comments", value: comments });
  if (Number.isFinite(shares)) stats.push({ key: "shares", label: "Shares", value: shares });
  if (Number.isFinite(saves)) stats.push({ key: "saves", label: "Saves", value: saves });
  const create = Number(row.createTime ?? row.create_time);
  return {
    id,
    url: `https://www.tiktok.com/@${handle}/video/${id}`,
    title: String(row.desc || "Video").slice(0, 140),
    thumb,
    at: Number.isFinite(create) && create > 1_000_000_000 ? create * (create < 1e12 ? 1000 : 1) : 0,
    kind: "video",
    stats,
  };
}

export async function tiktokBrowserFeed(handle: string, skip = 0, max = 36): Promise<{ items: ProfileItem[]; hasMore: boolean }> {
  const key = handle.replace(/^@/, "").toLowerCase();
  const hit = ttPack.get(key);
  if (hit && Date.now() - hit.at < 8 * 60_000) {
    const slice = hit.items.slice(skip, skip + max);
    return { items: slice, hasMore: skip + slice.length < hit.items.length || !hit.done };
  }
  if (ttBusy) return ttBusy;
  ttBusy = scrapeTikTokGrid(key, 120)
    .then((r) => {
      ttPack.set(key, { items: r.items, at: Date.now(), done: !r.hasMore });
      const slice = r.items.slice(skip, skip + max);
      return { items: slice, hasMore: skip + slice.length < r.items.length || r.hasMore };
    })
    .finally(() => {
      ttBusy = null;
    });
  return ttBusy;
}

function pullTtList(handle: string, bag: Map<string, ProfileItem>, rows: unknown) {
  if (!Array.isArray(rows)) return;
  for (const row of rows) {
    if (!row || typeof row !== "object") continue;
    const item = ttItem(handle, row as Record<string, unknown>);
    if (item) bag.set(item.id, item);
  }
}

function walkTt(handle: string, bag: Map<string, ProfileItem>, node: unknown, depth = 0) {
  if (!node || depth > 12) return;
  if (Array.isArray(node)) {
    if (node[0] && typeof node[0] === "object" && node[0] !== null && ("aweme_id" in node[0] || "desc" in node[0] || "stats" in node[0])) {
      pullTtList(handle, bag, node);
      return;
    }
    for (const row of node) walkTt(handle, bag, row, depth + 1);
    return;
  }
  if (typeof node !== "object") return;
  const rec = node as Record<string, unknown>;
  if (Array.isArray(rec.itemList)) pullTtList(handle, bag, rec.itemList);
  for (const val of Object.values(rec)) walkTt(handle, bag, val, depth + 1);
}

async function scrapeTikTokGrid(handle: string, max: number): Promise<{ items: ProfileItem[]; hasMore: boolean }> {
  let chromium: typeof import("playwright").chromium;
  try {
    ({ chromium } = await import("playwright"));
  } catch {
    return { items: [], hasMore: false };
  }
  const browser = await chromium.launch({
    headless: true,
    args: ["--disable-blink-features=AutomationControlled", "--no-sandbox"],
    executablePath: process.env.PLAYWRIGHT_CHROMIUM_PATH || undefined,
  });
  const found = new Map<string, ProfileItem>();
  try {
    const context = await browser.newContext({
      locale: "en-US",
      viewport: { width: 1280, height: 2200 },
      userAgent:
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36",
    });
    await context.addInitScript("Object.defineProperty(navigator, 'webdriver', { get: () => undefined });");
    const page = await context.newPage();
    page.setDefaultTimeout(20_000);
    page.on("response", async (res) => {
      const url = res.url();
      if (!/item_list/i.test(url) || /related|recommend|foryou|explore/i.test(url)) return;
      try {
        walkTt(handle, found, await res.json());
      } catch {
        /* ignore */
      }
    });
    await page.goto(`https://www.tiktok.com/@${encodeURIComponent(handle)}`, {
      waitUntil: "domcontentloaded",
      timeout: 20_000,
    });
    await page.waitForTimeout(2_500);
    const raw = await page
      .locator("#__UNIVERSAL_DATA_FOR_REHYDRATION__")
      .textContent()
      .catch(() => "");
    if (raw) {
      try {
        walkTt(handle, found, JSON.parse(raw) as unknown);
      } catch {
        /* ignore */
      }
    }
    const needle = `/@${handle}/video/`;
    let stall = 0;
    for (let i = 0; i < 28 && found.size < max && stall < 4; i += 1) {
      const before = found.size;
      const hrefs = await page
        .$$eval(
          "[data-e2e='user-post-item'] a[href*='/video/']",
          (els) => els.map((el) => (el as HTMLAnchorElement).href),
        )
        .catch(() => [] as string[]);
      for (const href of hrefs) {
        if (!href.toLowerCase().includes(needle)) continue;
        const id = href.match(/\/video\/(\d+)/)?.[1];
        if (id && !found.has(id)) {
          found.set(id, {
            id,
            url: `https://www.tiktok.com/@${handle}/video/${id}`,
            title: "Video",
            thumb: null,
            at: 0,
            kind: "video",
            stats: [],
          });
        }
      }
      await page.evaluate(() => {
        const list = document.querySelector("[data-e2e='user-post-item-list']");
        const cards = document.querySelectorAll("[data-e2e='user-post-item']");
        const last = cards[cards.length - 1];
        if (list && last) last.scrollIntoView({ block: "end" });
        else window.scrollBy(0, 1600);
      });
      await page.waitForTimeout(900);
      if (found.size <= before) stall += 1;
      else stall = 0;
    }
    const all = [...found.values()].filter((item) => tiktokOwnVideo(handle, item.url, item.id));
    return { items: all.slice(0, max), hasMore: stall < 4 && all.length >= max };
  } catch {
    return { items: [...found.values()], hasMore: false };
  } finally {
    await browser.close().catch(() => undefined);
  }
}
