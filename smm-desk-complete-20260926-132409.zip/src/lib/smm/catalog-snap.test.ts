import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { catalogNeedsPull, isCatalogFresh, parseCatalogSnap } from "./catalog-snap.ts";

describe("catalog snap", () => {
  it("rejects empty or junk", () => {
    assert.equal(parseCatalogSnap(null), null);
    assert.equal(parseCatalogSnap({}), null);
    assert.equal(parseCatalogSnap({ services: [] }), null);
    assert.equal(parseCatalogSnap({ services: [{ panel: "jap" }] }), null);
  });

  it("keeps valid services and drops dupes", () => {
    const snap = parseCatalogSnap({
      at: 100,
      panels: [{ id: "jap", label: "JustAnotherPanel", balance: "1.00", currency: "USD" }],
      services: [
        { panel: "jap", id: 4268, name: "TikTok Likes", rate: "0.12", min: 10, max: 9e6, dripfeed: false, refill: true },
        { panel: "jap", id: 4268, name: "dup" },
        { panel: "", id: 1, name: "bad" },
      ],
    });
    assert.ok(snap);
    assert.equal(snap.services.length, 1);
    assert.equal(snap.services[0]?.id, 4268);
    assert.equal(snap.services[0]?.refill, true);
    assert.equal(snap.panels[0]?.id, "jap");
    assert.equal(snap.at, 100);
  });

  it("treats 5 minutes as fresh", () => {
    assert.equal(isCatalogFresh(1_000, 1_000 + 4 * 60 * 1000), true);
    assert.equal(isCatalogFresh(1_000, 1_000 + 6 * 60 * 1000), false);
    assert.equal(isCatalogFresh(0, 1_000), false);
  });

  it("only pulls when empty, forced, or older than 5 minutes", () => {
    const t = 1_700_000_000_000;
    assert.equal(catalogNeedsPull(false, 0, false, t), true);
    assert.equal(catalogNeedsPull(true, t - 60_000, false, t), false);
    assert.equal(catalogNeedsPull(true, t - 6 * 60 * 1000, false, t), true);
    assert.equal(catalogNeedsPull(true, t - 60_000, true, t), true);
    assert.equal(catalogNeedsPull(true, 0, false, t), true);
  });
});
