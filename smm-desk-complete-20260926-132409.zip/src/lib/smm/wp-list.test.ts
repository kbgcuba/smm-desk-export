import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { insertLink, moveUnpinned, safeHookUrl, sanitizeWpItems, transferBadges, type WpList } from "./wp-list.ts";

describe("wordpress webhook target", () => {
  it("keeps a public https address", () => {
    assert.equal(safeHookUrl("https://example.com/wp-json/smm-desk/v1/list"), "https://example.com/wp-json/smm-desk/v1/list");
  });
  it("rejects local and private targets", () => {
    assert.equal(safeHookUrl("http://example.com/hook"), "http://example.com/hook");
    assert.equal(safeHookUrl("https://localhost/hook"), null);
    assert.equal(safeHookUrl("https://127.0.0.1/hook"), null);
    assert.equal(safeHookUrl("https://192.168.1.8/hook"), null);
    assert.equal(safeHookUrl("https://10.0.0.4/hook"), null);
  });
  it("keeps a section title and strips a bad link", () => {
    const items = sanitizeWpItems([
      {
        id: "a",
        title: "Home",
        url: "https://example.com",
        published: true,
        children: [{ id: "c", title: "Shop", url: "https://example.com/shop" }, { title: "Bad", url: "javascript:alert(1)" }],
      },
      { id: "b", title: "Nope", url: "javascript:alert(1)" },
    ]);
    assert.equal(items.length, 2);
    assert.equal(items[0]?.children[0]?.url, "https://example.com/shop");
    assert.equal(items[0]?.children[1]?.url, "");
    assert.equal(items[1]?.url, "");
  });
  it("keeps a pin and drops a false one", () => {
    const items = sanitizeWpItems([
      { id: "a", title: "A", url: "https://a.example", pinned: true },
      { id: "b", title: "B", url: "https://b.example", pinned: false },
    ]);
    assert.equal(items[0]?.pinned, true);
    assert.equal(items[1]?.pinned, undefined);
  });
  it("puts a new link in the first open slot", () => {
    const next = insertLink(
      [
        { id: "a", pinned: true },
        { id: "b" },
        { id: "c", pinned: true },
        { id: "d" },
      ],
      { id: "n" },
    );
    assert.deepEqual(next.map((row) => row.id), ["a", "n", "c", "b", "d"]);
  });
  it("drags around a pin and will not drag the pin", () => {
    const items = [
      { id: "a" },
      { id: "b", pinned: true },
      { id: "c" },
    ];
    assert.deepEqual(moveUnpinned(items, 2, 0)?.map((row) => row.id), ["c", "b", "a"]);
    assert.equal(moveUnpinned(items, 1, 0), null);
  });
  it("sends a badge the plugin does not know as a picture", () => {
    const list = {
      items: [{ id: "1", title: "Shop", url: "https://example.com", image: "", badge: "coach", published: true, children: [] }],
      hookUrl: "",
      secret: "",
      updatedAt: 1,
      style: { look: "soft", tone: "blue", size: "md", layout: "stack", thumb: "left", badge: "corner" },
      badges: [],
    } satisfies WpList;
    const art = new Map([["coach", { label: "Coach", bg: "#ffffff", fg: "#111111", img: "data:image/svg+xml;base64,PHN2Zw==", path: "" }]]);
    const sent = transferBadges(list, art);
    assert.equal(sent.items[0]?.badge, "c-coach");
    assert.equal(sent.badges[0]?.id, "c-coach");
    assert.match(sent.badges[0]?.img ?? "", /^data:image\/svg\+xml/);
  });
});
