import type { LookedProfile, ProfileItem, ProfileStat } from "@/lib/smm/profile-types";
import { getSocialKey, type SocialId } from "@/lib/smm/social.server.ts";

const GRAPH = "https://graph.facebook.com/v21.0";
const IG_GRAPH = "https://graph.instagram.com/v21.0";
const YT = "https://www.googleapis.com/youtube/v3";
const TT = "https://open.tiktokapis.com/v2";

type Parsed = { platform: string; handle: string; url: string };
type FeedPage = { items: ProfileItem[]; cursor: string | null };

async function jsonGet(url: string, headers: Record<string, string> = {}): Promise<Record<string, unknown>> {
  const res = await fetch(url, {
    headers: { accept: "application/json", ...headers },
    signal: AbortSignal.timeout(12_000),
  });
  const text = await res.text();
  let data: Record<string, unknown> = {};
  try {
    data = JSON.parse(text) as Record<string, unknown>;
  } catch {
    throw new Error("API did not return JSON");
  }
  if (!res.ok) {
    const err = data.error as { message?: string } | undefined;
    throw new Error(err?.message || `API ${res.status}`);
  }
  return data;
}

function n(v: unknown): number | null {
  const x = Number(v);
  return Number.isFinite(x) ? x : null;
}

const accountTotals = new Map<string, { at: number; stats: ProfileStat[] }>();
const totalsInflight = new Map<string, Promise<ProfileStat[]>>();

function cachedTotals(key: string): ProfileStat[] | null {
  const hit = accountTotals.get(key);
  if (!hit || Date.now() - hit.at > 30 * 60_000) return null;
  return hit.stats;
}

function saveTotals(key: string, stats: ProfileStat[]) {
  accountTotals.set(key, { at: Date.now(), stats });
}

function onceTotals(key: string, load: () => Promise<ProfileStat[]>): Promise<ProfileStat[]> {
  const hit = cachedTotals(key);
  if (hit) return Promise.resolve(hit);
  const pending = totalsInflight.get(key);
  if (pending) return pending;
  const job = load()
    .then((stats) => {
      if (stats.length) saveTotals(key, stats);
      return stats;
    })
    .finally(() => {
      totalsInflight.delete(key);
    });
  totalsInflight.set(key, job);
  return job;
}

export async function lookupViaApi(parsed: Parsed): Promise<LookedProfile | null> {
  try {
    if (parsed.platform === "youtube") return await youtubeProfile(parsed);
    if (parsed.platform === "instagram") return await instagramProfile(parsed);
    if (parsed.platform === "facebook") return await facebookProfile(parsed);
    if (parsed.platform === "tiktok") return await tiktokProfile(parsed);
    return null;
  } catch {
    return null;
  }
}

export async function feedViaApi(parsed: Parsed, cursor?: string | null, drain = false): Promise<FeedPage | null> {
  try {
    if (drain) {
      if (parsed.platform === "youtube") return await youtubeFeedAll(parsed);
      if (parsed.platform === "instagram") return await drainPages((page) => instagramFeed(parsed, page, false));
      if (parsed.platform === "facebook") return await drainPages((page) => facebookFeed(parsed, page));
      if (parsed.platform === "tiktok") return await drainPages((page) => tiktokFeed(parsed, page));
      return null;
    }
    if (parsed.platform === "youtube") return await youtubeFeed(parsed, cursor);
    if (parsed.platform === "instagram") return await instagramFeed(parsed, cursor, false);
    if (parsed.platform === "facebook") return await facebookFeed(parsed, cursor);
    if (parsed.platform === "tiktok") return await tiktokFeed(parsed, cursor);
    return null;
  } catch {
    return null;
  }
}

async function drainPages(load: (cursor?: string | null) => Promise<FeedPage | null>): Promise<FeedPage | null> {
  const items: ProfileItem[] = [];
  const seen = new Set<string>();
  let next: string | null | undefined;
  for (let page = 0; page < 40; page++) {
    const pack = await load(next);
    if (!pack) return items.length ? { items, cursor: next ?? null } : null;
    for (const item of pack.items) {
      if (!item.id || seen.has(item.id)) continue;
      seen.add(item.id);
      items.push(item);
    }
    if (!pack.cursor || pack.cursor === next) return { items, cursor: null };
    next = pack.cursor;
  }
  return { items, cursor: next ?? null };
}

export async function trySocialToken(id: SocialId, token: string, extra = ""): Promise<{ ok: true; title: string }> {
  const t = token.trim();
  if (!t) throw new Error("Paste a token first");
  if (id === "youtube") {
    const data = await jsonGet(
      `${YT}/channels?part=snippet&forHandle=${encodeURIComponent((extra || "claudiaivory").replace(/^@/, ""))}&maxResults=1&key=${encodeURIComponent(t)}`,
    );
    const item = (data.items as { snippet?: { title?: string } }[])?.[0];
    if (!item) throw new Error("YouTube did not accept this key");
    return { ok: true, title: item.snippet?.title || "YouTube" };
  }
  if (id === "instagram") {
    try {
      const data = await jsonGet(`${IG_GRAPH}/me?fields=id,username,name&access_token=${encodeURIComponent(t)}`);
      return { ok: true, title: String(data.name || data.username || "Instagram") };
    } catch {
      const found = await igUserId(t, extra);
      const data = await jsonGet(
        `${found.host}/${encodeURIComponent(found.id)}?fields=id,username,name,followers_count&access_token=${encodeURIComponent(t)}`,
      );
      return { ok: true, title: String(data.name || data.username || "Instagram") };
    }
  }
  if (id === "facebook") {
    const page = extra.trim() || "me";
    const data = await jsonGet(`${GRAPH}/${encodeURIComponent(page)}?fields=id,name&access_token=${encodeURIComponent(t)}`);
    return { ok: true, title: String(data.name || "Facebook") };
  }
  const data = await jsonGet(`${TT}/user/info/?fields=display_name,username`, {
    Authorization: `Bearer ${t}`,
  });
  const user = (data.data as { user?: { display_name?: string; username?: string } } | undefined)?.user;
  return { ok: true, title: user?.display_name || user?.username || "TikTok" };
}

async function youtubeSplit(channelId: string, key: string): Promise<{ shorts: number | null; long: number | null }> {
  if (!channelId.startsWith("UC") || channelId.length < 4) return { shorts: null, long: null };
  const rest = channelId.slice(2);
  try {
    const data = await jsonGet(
      `${YT}/playlists?part=contentDetails&id=${encodeURIComponent(`UULF${rest},UUSH${rest}`)}&key=${encodeURIComponent(key)}`,
    );
    let shorts: number | null = null;
    let long: number | null = null;
    for (const row of (data.items as { id?: string; contentDetails?: { itemCount?: number } }[]) || []) {
      const count = row.contentDetails?.itemCount;
      if (typeof count !== "number") continue;
      if (row.id?.startsWith("UUSH")) shorts = count;
      if (row.id?.startsWith("UULF")) long = count;
    }
    return { shorts, long };
  } catch {
    return { shorts: null, long: null };
  }
}

async function youtubeEngagement(channelId: string, key: string): Promise<ProfileStat[]> {
  const cacheKey = `yt:${channelId}`;
  return onceTotals(cacheKey, async () => {
  const uploads = `UU${channelId.slice(2)}`;
  let page = "";
  let likes = 0;
  let comments = 0;
  for (let guard = 0; guard < 30; guard++) {
    const qs = new URLSearchParams({ part: "contentDetails", playlistId: uploads, maxResults: "50", key });
    if (page) qs.set("pageToken", page);
    const list = await jsonGet(`${YT}/playlistItems?${qs.toString()}`);
    const ids = ((list.items as { contentDetails?: { videoId?: string } }[]) || [])
      .map((row) => row.contentDetails?.videoId)
      .filter((id): id is string => Boolean(id));
    if (ids.length) {
      const stats = await jsonGet(`${YT}/videos?part=statistics&id=${ids.join(",")}&key=${encodeURIComponent(key)}`);
      for (const row of (stats.items as { statistics?: { likeCount?: string; commentCount?: string } }[]) || []) {
        likes += Number(row.statistics?.likeCount) || 0;
        comments += Number(row.statistics?.commentCount) || 0;
      }
    }
    page = typeof list.nextPageToken === "string" ? list.nextPageToken : "";
    if (!page) break;
  }
  const out: ProfileStat[] = [
    { key: "likes", label: "Likes", value: likes },
    { key: "comments", label: "Comments", value: comments },
  ];
  return out;
  });
}

async function youtubeProfile(parsed: Parsed): Promise<LookedProfile | null> {
  const key = await getSocialKey("youtube");
  if (!key) return null;
  const handle = parsed.handle.replace(/^@/, "");
  const data = await jsonGet(
    `${YT}/channels?part=snippet,statistics,contentDetails&forHandle=${encodeURIComponent(handle)}&maxResults=1&key=${encodeURIComponent(key.token)}`,
  );
  const item = (data.items as {
    id?: string;
    snippet?: { title?: string; thumbnails?: { high?: { url?: string }; default?: { url?: string } } };
    statistics?: { subscriberCount?: string; videoCount?: string; viewCount?: string };
  }[])?.[0];
  if (!item) return null;
  const stats: ProfileStat[] = [];
  const sub = n(item.statistics?.subscriberCount);
  const vids = n(item.statistics?.videoCount);
  const views = n(item.statistics?.viewCount);
  if (sub != null) stats.push({ key: "subscribers", label: "Subscribers", value: sub });
  if (vids != null) stats.push({ key: "videos", label: "Videos", value: vids });
  if (views != null) stats.push({ key: "views", label: "Views", value: views });
  if (item.id) {
    const split = await youtubeSplit(item.id, key.token);
    if (split.shorts != null) stats.push({ key: "shorts", label: "Shorts", value: split.shorts });
    if (split.long != null) stats.push({ key: "long", label: "Long", value: split.long });
    try {
      stats.push(...(await youtubeEngagement(item.id, key.token)));
    } catch {
      /* likes and comments stay off until the full catalog answers */
    }
  }
  return {
    id: `youtube:${parsed.handle}`,
    url: parsed.url,
    platform: "youtube",
    handle: parsed.handle,
    title: item.snippet?.title || parsed.handle,
    avatar: item.snippet?.thumbnails?.high?.url || item.snippet?.thumbnails?.default?.url || null,
    stats,
  };
}

function isoDurationSec(iso: string): number {
  const m = iso.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/i);
  if (!m) return 0;
  return Number(m[1] || 0) * 3600 + Number(m[2] || 0) * 60 + Number(m[3] || 0);
}

const youtubeShortCache = new Map<string, { at: number; ids: Set<string> }>();

async function youtubeShortIds(channelId: string, key: string): Promise<Set<string> | null> {
  if (!channelId.startsWith("UC") || channelId.length < 4) return null;
  const hit = youtubeShortCache.get(channelId);
  if (hit && Date.now() - hit.at < 30 * 60_000) return hit.ids;
  const playlistId = `UUSH${channelId.slice(2)}`;
  const ids = new Set<string>();
  let page = "";
  try {
    for (let guard = 0; guard < 20; guard++) {
      const qs = new URLSearchParams({ part: "contentDetails", playlistId, maxResults: "50", key });
      if (page) qs.set("pageToken", page);
      const list = await jsonGet(`${YT}/playlistItems?${qs.toString()}`);
      for (const row of (list.items as { contentDetails?: { videoId?: string } }[]) || []) {
        const id = row.contentDetails?.videoId;
        if (id) ids.add(id);
      }
      page = typeof list.nextPageToken === "string" ? list.nextPageToken : "";
      if (!page) break;
    }
  } catch {
    return null;
  }
  youtubeShortCache.set(channelId, { at: Date.now(), ids });
  return ids;
}

function classifyYoutube(
  id: string,
  shorts: Set<string> | null,
  duration: string,
  title: string,
  desc: string,
): "short" | "video" {
  if (shorts) return shorts.has(id) ? "short" : "video";
  const sec = isoDurationSec(duration);
  if (sec > 0 && sec <= 60) return "short";
  if (/#shorts?\b/i.test(`${title} ${desc}`)) return "short";
  return "video";
}

async function youtubeFeed(parsed: Parsed, cursor?: string | null): Promise<FeedPage | null> {
  const key = await getSocialKey("youtube");
  if (!key) return null;
  const handle = parsed.handle.replace(/^@/, "");
  let uploads = "";
  let page = "";
  if (cursor?.startsWith("Y|")) {
    const parts = cursor.split("|");
    uploads = parts[1] || "";
    page = parts[2] || "";
  } else {
    const ch = await jsonGet(
      `${YT}/channels?part=contentDetails,snippet&forHandle=${encodeURIComponent(handle)}&maxResults=1&key=${encodeURIComponent(key.token)}`,
    );
    uploads =
      (ch.items as { contentDetails?: { relatedPlaylists?: { uploads?: string } } }[])?.[0]?.contentDetails?.relatedPlaylists
        ?.uploads || "";
  }
  if (!uploads) return null;
  const channelId = uploads.startsWith("UU") ? `UC${uploads.slice(2)}` : "";
  const shorts = channelId ? await youtubeShortIds(channelId, key.token) : null;
  const qs = new URLSearchParams({
    part: "snippet,contentDetails",
    playlistId: uploads,
    maxResults: "50",
    key: key.token,
  });
  if (page) qs.set("pageToken", page);
  const list = await jsonGet(`${YT}/playlistItems?${qs.toString()}`);
  const next = typeof list.nextPageToken === "string" ? list.nextPageToken : "";
  const rows =
    (list.items as {
      contentDetails?: { videoId?: string; videoPublishedAt?: string };
      snippet?: { title?: string; publishedAt?: string; thumbnails?: { medium?: { url?: string }; high?: { url?: string } } };
    }[]) || [];
  const ids = rows.map((r) => r.contentDetails?.videoId).filter((id): id is string => Boolean(id));
  if (!ids.length) return { items: [], cursor: null };
  const statsJson = await jsonGet(
    `${YT}/videos?part=statistics,snippet,contentDetails&id=${ids.join(",")}&key=${encodeURIComponent(key.token)}`,
  );
  const byId = new Map(
    (
      (statsJson.items as {
        id?: string;
        statistics?: Record<string, string>;
        snippet?: { publishedAt?: string; title?: string; description?: string };
        contentDetails?: { duration?: string };
      }[]) || []
    ).map((v) => [v.id || "", v]),
  );
  const items: ProfileItem[] = [];
  for (const r of rows) {
    const id = r.contentDetails?.videoId;
    if (!id) continue;
    const hit = byId.get(id);
    const st = hit?.statistics || {};
    const stats: ProfileStat[] = [];
    const views = n(st.viewCount);
    const likes = n(st.likeCount);
    const comments = n(st.commentCount);
    if (views != null) stats.push({ key: "views", label: "Views", value: views });
    if (likes != null) stats.push({ key: "likes", label: "Likes", value: likes });
    if (comments != null) stats.push({ key: "comments", label: "Comments", value: comments });
    const published = hit?.snippet?.publishedAt || r.contentDetails?.videoPublishedAt || r.snippet?.publishedAt;
    const title = r.snippet?.title || hit?.snippet?.title || "Video";
    const kind = classifyYoutube(id, shorts, hit?.contentDetails?.duration || "", title, hit?.snippet?.description || "");
    items.push({
      id,
      url: kind === "short" ? `https://www.youtube.com/shorts/${id}` : `https://www.youtube.com/watch?v=${id}`,
      title,
      thumb: r.snippet?.thumbnails?.medium?.url || r.snippet?.thumbnails?.high?.url || `https://i.ytimg.com/vi/${id}/hqdefault.jpg`,
      at: published ? Date.parse(published) : 0,
      kind,
      stats,
    });
  }
  return { items, cursor: next ? `Y|${uploads}|${next}` : null };
}

async function youtubeFeedAll(parsed: Parsed): Promise<FeedPage | null> {
  return drainPages((cursor) => youtubeFeed(parsed, cursor));
}

async function igUserId(token: string, extra = ""): Promise<{ host: string; id: string }> {
  if (extra.trim()) {
    try {
      await jsonGet(`${IG_GRAPH}/${encodeURIComponent(extra.trim())}?fields=id&access_token=${encodeURIComponent(token)}`);
      return { host: IG_GRAPH, id: extra.trim() };
    } catch {
      return { host: GRAPH, id: extra.trim() };
    }
  }
  try {
    const me = await jsonGet(`${IG_GRAPH}/me?fields=id,username&access_token=${encodeURIComponent(token)}`);
    if (typeof me.id === "string" && me.id) return { host: IG_GRAPH, id: me.id };
  } catch {
    /* Facebook Page-linked professional account */
  }
  const me = await jsonGet(
    `${GRAPH}/me/accounts?fields=id,name,instagram_business_account&access_token=${encodeURIComponent(token)}`,
  );
  const pages = (me.data as { instagram_business_account?: { id?: string } }[] | undefined) || [];
  const id = pages.find((p) => p.instagram_business_account?.id)?.instagram_business_account?.id;
  if (!id) throw new Error("No Instagram professional account on this token");
  return { host: GRAPH, id };
}

async function instagramProfile(parsed: Parsed): Promise<LookedProfile | null> {
  const key = await getSocialKey("instagram");
  if (!key) return null;
  const { host, id } = await igUserId(key.token, key.extra);
  const data = await jsonGet(
    `${host}/${encodeURIComponent(id)}?fields=id,username,name,profile_picture_url,followers_count,follows_count,media_count&access_token=${encodeURIComponent(key.token)}`,
  );
  const stats: ProfileStat[] = [];
  const followers = n(data.followers_count);
  const following = n(data.follows_count);
  const posts = n(data.media_count);
  if (followers != null) stats.push({ key: "followers", label: "Followers", value: followers });
  if (following != null) stats.push({ key: "following", label: "Following", value: following });
  if (posts != null) stats.push({ key: "posts", label: "Posts", value: posts });
  try {
    for (const row of await instagramTotals(host, id, key.token)) {
      const prev = stats.find((s) => s.key === row.key);
      if (prev) prev.value = row.value;
      else stats.push(row);
    }
  } catch {
    /* followers stay; lifetime totals wait for the next pass */
  }
  return {
    id: `instagram:${String(data.username || parsed.handle)}`,
    url: `https://www.instagram.com/${data.username || parsed.handle}/`,
    platform: "instagram",
    handle: String(data.username || parsed.handle),
    title: String(data.name || data.username || parsed.handle),
    avatar: typeof data.profile_picture_url === "string" ? data.profile_picture_url : null,
    stats,
  };
}

const igInsightCache = new Map<string, { at: number; data: Record<string, number> }>();

async function instagramInsights(host: string, id: string, token: string): Promise<Record<string, number>> {
  const hit = igInsightCache.get(id);
  if (hit && Date.now() - hit.at < 180_000) return hit.data;
  for (const metric of ["views,reach,saved,likes,comments,shares,reposts", "impressions,reach,saved,likes,comments,shares"]) {
    try {
      const data = await jsonGet(`${host}/${encodeURIComponent(id)}/insights?metric=${metric}&access_token=${encodeURIComponent(token)}`);
      const out: Record<string, number> = {};
      for (const row of (data.data as { name?: string; values?: { value?: number }[] }[]) || []) {
        const v = row.values?.[0]?.value;
        if (row.name && typeof v === "number") out[row.name] = v;
      }
      if (Object.keys(out).length) {
        igInsightCache.set(id, { at: Date.now(), data: out });
        return out;
      }
    } catch {
      /* try next metric set */
    }
  }
  return {};
}

async function mapPool<T, R>(items: T[], size: number, fn: (item: T) => Promise<R>): Promise<R[]> {
  const out: R[] = [];
  let i = 0;
  await Promise.all(
    Array.from({ length: Math.min(size, items.length) }, async () => {
      while (i < items.length) {
        const idx = i++;
        out[idx] = await fn(items[idx]);
      }
    }),
  );
  return out;
}

async function instagramTotals(host: string, id: string, token: string): Promise<ProfileStat[]> {
  return onceTotals(`ig:${id}`, async () => {
  const media: { id: string; likes: number; comments: number }[] = [];
  const seen = new Set<string>();
  let after = "";
  for (let page = 0; page < 40; page++) {
    const qs = new URLSearchParams({ fields: "id,like_count,comments_count", limit: "50", access_token: token });
    if (after) qs.set("after", after);
    const data = await jsonGet(`${host}/${encodeURIComponent(id)}/media?${qs.toString()}`);
    const rows = (data.data as { id?: string; like_count?: number; comments_count?: number }[]) || [];
    if (!rows.length) break;
    for (const row of rows) {
      if (!row.id || seen.has(row.id)) continue;
      seen.add(row.id);
      media.push({ id: row.id, likes: Number(row.like_count) || 0, comments: Number(row.comments_count) || 0 });
    }
    const paging = data.paging as { next?: string; cursors?: { after?: string } } | undefined;
    if (!paging?.next) break;
    after = paging.cursors?.after || "";
    if (!after) break;
  }
  if (!media.length) return [];
  let views = 0;
  let shares = 0;
  let saves = 0;
  let reposts = 0;
  let got = 0;
  await mapPool(media, 8, async (row) => {
    try {
      const data = await jsonGet(
        `${host}/${encodeURIComponent(row.id)}/insights?metric=views,shares,saved,reposts&access_token=${encodeURIComponent(token)}`,
      );
      const bag: Record<string, number> = {};
      for (const item of (data.data as { name?: string; values?: { value?: number }[] }[]) || []) {
        const value = item.values?.[0]?.value;
        if (item.name && typeof value === "number") bag[item.name] = value;
      }
      if (typeof bag.views === "number") {
        views += bag.views;
        got += 1;
      }
      if (typeof bag.shares === "number") shares += bag.shares;
      if (typeof bag.saved === "number") saves += bag.saved;
      if (typeof bag.reposts === "number") reposts += bag.reposts;
    } catch {
      /* this post stays out of the view total */
    }
  });
  const out: ProfileStat[] = [
    { key: "posts", label: "Posts", value: media.length },
    { key: "likes", label: "Likes", value: media.reduce((sum, row) => sum + row.likes, 0) },
    { key: "comments", label: "Comments", value: media.reduce((sum, row) => sum + row.comments, 0) },
  ];
  if (got >= media.length * 0.9) {
    out.push(
      { key: "views", label: "Views", value: views },
      { key: "shares", label: "Shares", value: shares },
      { key: "saves", label: "Saves", value: saves },
      { key: "reposts", label: "Reposts", value: reposts },
    );
  }
  return out;
  });
}

export async function enrichInstagramByIds(ids: string[]): Promise<Record<string, ProfileStat[]>> {
  const key = await getSocialKey("instagram");
  if (!key) return {};
  const { host } = await igUserId(key.token, key.extra);
  const unique = [...new Set(ids.map((id) => id.trim()).filter(Boolean))].slice(0, 200);
  const rows = await mapPool(unique, 6, async (id) => [id, await instagramInsights(host, id, key.token)] as const);
  const out: Record<string, ProfileStat[]> = {};
  for (const [id, ig] of rows) {
    const stats: ProfileStat[] = [];
    const views = n(ig.views) ?? n(ig.impressions);
    const likes = n(ig.likes);
    const comments = n(ig.comments);
    const shares = n(ig.shares);
    const saved = n(ig.saved);
    const reach = n(ig.reach);
    const reposts = n(ig.reposts);
    if (views != null) stats.push({ key: "views", label: "Views", value: views });
    if (likes != null) stats.push({ key: "likes", label: "Likes", value: likes });
    if (comments != null) stats.push({ key: "comments", label: "Comments", value: comments });
    if (shares != null) stats.push({ key: "shares", label: "Shares", value: shares });
    if (saved != null) stats.push({ key: "saves", label: "Saves", value: saved });
    if (reach != null) stats.push({ key: "reach", label: "Reach", value: reach });
    if (reposts != null) stats.push({ key: "reposts", label: "Reposts", value: reposts });
    if (stats.length) out[id] = stats;
  }
  return out;
}

async function instagramFeed(parsed: Parsed, cursor?: string | null, enrich = false): Promise<FeedPage | null> {
  const key = await getSocialKey("instagram");
  if (!key) return null;
  const { host, id } = await igUserId(key.token, key.extra);
  const after = cursor?.startsWith("I|") ? cursor.slice(2) : "";
  const qs = new URLSearchParams({
    fields: "id,caption,media_type,media_url,thumbnail_url,permalink,timestamp,like_count,comments_count",
    limit: "25",
    access_token: key.token,
  });
  if (after) qs.set("after", after);
  const data = await jsonGet(`${host}/${encodeURIComponent(id)}/media?${qs.toString()}`);
  const rows =
    (data.data as {
      id?: string;
      caption?: string;
      media_type?: string;
      media_url?: string;
      thumbnail_url?: string;
      permalink?: string;
      timestamp?: string;
      like_count?: number;
      comments_count?: number;
    }[]) || [];
  const next = (data.paging as { cursors?: { after?: string } } | undefined)?.cursors?.after || "";
  const insightRows = enrich
    ? await mapPool(rows, 5, (row) => (row.id ? instagramInsights(host, row.id, key.token) : Promise.resolve({} as Record<string, number>)))
    : rows.map(() => ({} as Record<string, number>));
  return {
    items: rows.map((row, i) => {
      const ig = insightRows[i] || {};
      const stats: ProfileStat[] = [];
      const views = n(ig.views) ?? n(ig.impressions);
      const likes = n(ig.likes) ?? n(row.like_count);
      const comments = n(ig.comments) ?? n(row.comments_count);
      const shares = n(ig.shares);
      const saved = n(ig.saved);
      if (views != null) stats.push({ key: "views", label: "Views", value: views });
      if (likes != null) stats.push({ key: "likes", label: "Likes", value: likes });
      if (comments != null) stats.push({ key: "comments", label: "Comments", value: comments });
      if (shares != null) stats.push({ key: "shares", label: "Shares", value: shares });
      if (saved != null) stats.push({ key: "saves", label: "Saves", value: saved });
      const reel = (row.media_type || "").toUpperCase() === "VIDEO" || (row.media_type || "").toUpperCase() === "REELS";
      return {
        id: row.id || row.permalink || "",
        url: row.permalink || parsed.url,
        title: (row.caption || (reel ? "Reel" : "Post")).slice(0, 140),
        thumb: row.thumbnail_url || row.media_url || null,
        at: row.timestamp ? Date.parse(row.timestamp) : 0,
        kind: reel ? "reel" : "post",
        stats,
      };
    }),
    cursor: next ? `I|${next}` : null,
  };
}

async function graphPages(path: string, token: string, fields: string): Promise<Record<string, unknown>[]> {
  const rows: Record<string, unknown>[] = [];
  let after = "";
  for (let page = 0; page < 40; page++) {
    const qs = new URLSearchParams({ fields, limit: "50", access_token: token });
    if (after) qs.set("after", after);
    const data = await jsonGet(`${path}?${qs.toString()}`);
    const chunk = (data.data as Record<string, unknown>[]) || [];
    if (!chunk.length) break;
    rows.push(...chunk);
    const paging = data.paging as { next?: string; cursors?: { after?: string } } | undefined;
    if (!paging?.next) break;
    after = paging.cursors?.after || "";
    if (!after) break;
  }
  return rows;
}

async function facebookTotals(pageId: string, token: string): Promise<ProfileStat[]> {
  return onceTotals(`fb:${pageId}`, async () => {
    const base = `${GRAPH}/${encodeURIComponent(pageId)}`;
    const out: ProfileStat[] = [];
    try {
      const posts = await graphPages(
        `${base}/published_posts`,
        token,
        "id,shares,reactions.summary(true).limit(0),comments.summary(true).limit(0)",
      );
      let reactions = 0;
      let comments = 0;
      let shares = 0;
      for (const row of posts) {
        const reactionBag = row.reactions as { summary?: { total_count?: number } } | undefined;
        const commentBag = row.comments as { summary?: { total_count?: number } } | undefined;
        const shareBag = row.shares as { count?: number } | undefined;
        reactions += Number(reactionBag?.summary?.total_count) || 0;
        comments += Number(commentBag?.summary?.total_count) || 0;
        shares += Number(shareBag?.count) || 0;
      }
      if (posts.length) {
        out.push(
          { key: "posts", label: "Posts", value: posts.length },
          { key: "likes", label: "Reactions", value: reactions },
          { key: "comments", label: "Comments", value: comments },
          { key: "shares", label: "Shares", value: shares },
        );
      }
    } catch {
      /* keep the totals that did load */
    }
    try {
      const videos = await graphPages(`${base}/videos`, token, "id,views");
      let views = 0;
      for (const row of videos) views += Number(row.views) || 0;
      if (videos.length) out.push({ key: "views", label: "Views", value: views });
    } catch {
      /* views stay off this pass */
    }
    try {
      const reels = await graphPages(`${base}/video_reels`, token, "id");
      if (reels.length) out.push({ key: "reels", label: "Videos", value: reels.length });
    } catch {
      /* reels stay off this pass */
    }
    return out;
  });
}

async function facebookProfile(parsed: Parsed): Promise<LookedProfile | null> {
  const key = await getSocialKey("facebook");
  if (!key) return null;
  const page = key.extra.trim() || parsed.handle;
  const data = await jsonGet(
    `${GRAPH}/${encodeURIComponent(page)}?fields=id,name,username,fan_count,followers_count,picture.type(large)&access_token=${encodeURIComponent(key.token)}`,
  );
  const pic = data.picture as { data?: { url?: string } } | undefined;
  const stats: ProfileStat[] = [];
  const followers = n(data.followers_count) ?? n(data.fan_count);
  if (followers != null) stats.push({ key: "followers", label: "Followers", value: followers });
  const pageId = String(data.id || page);
  try {
    stats.push(...(await facebookTotals(pageId, key.token)));
  } catch {
    /* followers stay if the post walk fails */
  }
  return {
    id: `facebook:${pageId}`,
    url: `https://www.facebook.com/${pageId}`,
    platform: "facebook",
    handle: pageId,
    title: String(data.name || parsed.handle),
    avatar: pic?.data?.url || null,
    stats,
  };
}

async function facebookFeed(parsed: Parsed, cursor?: string | null): Promise<FeedPage | null> {
  const key = await getSocialKey("facebook");
  if (!key) return null;
  const page = key.extra.trim() || (/^\d{8,}$/.test(parsed.handle) ? parsed.handle : "105894818641566");
  const after = cursor?.startsWith("F|") ? cursor.replace(/^F\|(?:published_posts\||posts\||feed\|)?/, "") : "";
  const fields =
    "id,message,created_time,full_picture,permalink_url,shares,reactions.summary(true),comments.summary(true),attachments{media_type,type,url,target}";
  const preferred = cursor?.startsWith("F|published_posts|")
    ? "published_posts"
    : cursor?.startsWith("F|posts|")
      ? "posts"
      : cursor?.startsWith("F|feed|")
        ? "feed"
        : "";
  const paths = preferred ? [preferred] : ["published_posts", "posts", "feed"];
  let data: Record<string, unknown> | null = null;
  let used = preferred || "posts";
  for (const path of paths) {
    try {
      const qs = new URLSearchParams({ fields, limit: "25", access_token: key.token });
      if (after) qs.set("after", after);
      data = await jsonGet(`${GRAPH}/${encodeURIComponent(page)}/${path}?${qs.toString()}`);
      if (Array.isArray(data.data) && (data.data as unknown[]).length) {
        used = path;
        break;
      }
    } catch {
      data = null;
    }
  }
  if (!data) return { items: [], cursor: null };
  const rows =
    (data.data as {
      id?: string;
      message?: string;
      created_time?: string;
      full_picture?: string;
      permalink_url?: string;
      shares?: { count?: number };
      reactions?: { summary?: { total_count?: number } };
      comments?: { summary?: { total_count?: number } };
      attachments?: { data?: { url?: string; target?: { id?: string } }[] };
    }[]) || [];
  const next = (data.paging as { cursors?: { after?: string } } | undefined)?.cursors?.after || "";
  const videoIds = rows
    .map((row) => {
      const blob = `${row.permalink_url || ""} ${(row.attachments?.data || []).map((a) => `${a.url || ""} ${a.target?.id || ""}`).join(" ")}`;
      return blob.match(/\/reel\/(\d+)/)?.[1] || blob.match(/\/videos\/(\d+)/)?.[1] || row.attachments?.data?.[0]?.target?.id || "";
    })
    .filter(Boolean);
  const viewsById: Record<string, number> = {};
  for (let i = 0; i < videoIds.length; i += 20) {
    const chunk = videoIds.slice(i, i + 20);
    try {
      const pack = await jsonGet(
        `${GRAPH}/?ids=${encodeURIComponent(chunk.join(","))}&fields=id,views&access_token=${encodeURIComponent(key.token)}`,
      );
      for (const [id, row] of Object.entries(pack)) {
        if (id === "error" || !row || typeof row !== "object") continue;
        const v = n((row as { views?: unknown }).views);
        if (v != null) viewsById[id] = v;
      }
    } catch {
      /* views stay empty */
    }
  }
  return {
    items: rows.map((row) => {
      const stats: ProfileStat[] = [];
      const blob = `${row.permalink_url || ""} ${(row.attachments?.data || []).map((a) => `${a.url || ""} ${a.target?.id || ""}`).join(" ")}`;
      const vid = blob.match(/\/reel\/(\d+)/)?.[1] || blob.match(/\/videos\/(\d+)/)?.[1] || row.attachments?.data?.[0]?.target?.id || "";
      const views = vid ? viewsById[vid] : undefined;
      const likes = n(row.reactions?.summary?.total_count);
      const comments = n(row.comments?.summary?.total_count);
      const shares = n(row.shares?.count);
      if (views != null) stats.push({ key: "views", label: "Views", value: views });
      if (likes != null) stats.push({ key: "likes", label: "Reactions", value: likes });
      if (comments != null) stats.push({ key: "comments", label: "Comments", value: comments });
      if (shares != null) stats.push({ key: "shares", label: "Shares", value: shares });
      return {
        id: row.id || "",
        url: row.permalink_url || parsed.url,
        title: (row.message || "Post").slice(0, 140),
        thumb: row.full_picture || null,
        at: row.created_time ? Date.parse(row.created_time) : 0,
        kind: vid ? "reel" : "post",
        stats,
      };
    }),
    cursor: next ? `F|${used}|${next}` : null,
  };
}

async function tiktokProfile(parsed: Parsed): Promise<LookedProfile | null> {
  const key = await getSocialKey("tiktok");
  if (!key) return null;
  const data = await jsonGet(`${TT}/user/info/?fields=display_name,username,avatar_url,follower_count,following_count,likes_count,video_count`, {
    Authorization: `Bearer ${key.token}`,
  });
  const user = (data.data as {
    user?: {
      display_name?: string;
      username?: string;
      avatar_url?: string;
      follower_count?: number;
      following_count?: number;
      likes_count?: number;
      video_count?: number;
    };
  })?.user;
  if (!user) return null;
  const stats: ProfileStat[] = [];
  if (typeof user.follower_count === "number") stats.push({ key: "followers", label: "Followers", value: user.follower_count });
  if (typeof user.following_count === "number") stats.push({ key: "following", label: "Following", value: user.following_count });
  if (typeof user.video_count === "number") stats.push({ key: "videos", label: "Videos", value: user.video_count });
  if (typeof user.likes_count === "number") stats.push({ key: "likes", label: "Likes", value: user.likes_count });
  return {
    id: `tiktok:${user.username || parsed.handle}`,
    url: `https://www.tiktok.com/@${user.username || parsed.handle}`,
    platform: "tiktok",
    handle: user.username || parsed.handle,
    title: user.display_name || parsed.handle,
    avatar: user.avatar_url || null,
    stats,
  };
}

async function tiktokFeed(_parsed: Parsed, cursor?: string | null): Promise<FeedPage | null> {
  const key = await getSocialKey("tiktok");
  if (!key) return null;
  const body: Record<string, unknown> = { max_count: 20 };
  if (cursor?.startsWith("T|")) body.cursor = Number(cursor.slice(2)) || cursor.slice(2);
  const res = await fetch(
    `${TT}/video/list/?fields=id,title,cover_image_url,share_url,create_time,view_count,like_count,comment_count,share_count`,
    {
      method: "POST",
      headers: { Authorization: `Bearer ${key.token}`, "content-type": "application/json", accept: "application/json" },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(10_000),
    },
  );
  const data = (await res.json()) as {
    error?: { message?: string };
    data?: {
      cursor?: number | string;
      has_more?: boolean;
      videos?: {
        id?: string;
        title?: string;
        cover_image_url?: string;
        share_url?: string;
        create_time?: number;
        view_count?: number;
        like_count?: number;
        comment_count?: number;
        share_count?: number;
      }[];
    };
  };
  if (!res.ok) throw new Error(data.error?.message || `TikTok ${res.status}`);
  const items = (data.data?.videos || []).map((row) => {
    const stats: ProfileStat[] = [];
    if (typeof row.view_count === "number") stats.push({ key: "views", label: "Views", value: row.view_count });
    if (typeof row.like_count === "number") stats.push({ key: "likes", label: "Likes", value: row.like_count });
    if (typeof row.comment_count === "number") stats.push({ key: "comments", label: "Comments", value: row.comment_count });
    if (typeof row.share_count === "number") stats.push({ key: "shares", label: "Shares", value: row.share_count });
    return {
      id: row.id || "",
      url: row.share_url || "",
      title: row.title || "Video",
      thumb: row.cover_image_url || null,
      at: row.create_time ? row.create_time * 1000 : 0,
      kind: "video" as const,
      stats,
    };
  });
  const next = data.data?.has_more && data.data.cursor != null ? `T|${data.data.cursor}` : null;
  return { items, cursor: next };
}
