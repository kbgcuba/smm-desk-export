import { loadSmmAllServices, type SmmCatalogPayload } from "@/lib/smm/fn";
import { readCatalogSnap, writeCatalogSnap } from "@/lib/smm/catalog-idb";
import { catalogNeedsPull, type CatalogSnap } from "@/lib/smm/catalog-snap";

let cached: SmmCatalogPayload | null = null;
let at = 0;
let inflight: Promise<SmmCatalogPayload> | null = null;
let hydrating: Promise<SmmCatalogPayload | null> | null = null;
const listeners = new Set<(payload: SmmCatalogPayload) => void>();

function emit(payload: SmmCatalogPayload) {
  for (const fn of listeners) fn(payload);
}

function remember(payload: SmmCatalogPayload, when = Date.now()): SmmCatalogPayload {
  cached = payload;
  at = when;
  emit(payload);
  const snap: CatalogSnap = { ...payload, at: when };
  void writeCatalogSnap(snap);
  return payload;
}

function hydrate(): Promise<SmmCatalogPayload | null> {
  if (cached) return Promise.resolve(cached);
  if (hydrating) return hydrating;
  hydrating = readCatalogSnap()
    .then((snap) => {
      if (cached) return cached;
      if (!snap) return null;
      cached = { panels: snap.panels, services: snap.services };
      at = snap.at;
      emit(cached);
      return cached;
    })
    .catch(() => cached)
    .finally(() => {
      hydrating = null;
    });
  return hydrating;
}

function pull(): Promise<SmmCatalogPayload> {
  if (inflight) return inflight;
  inflight = loadSmmAllServices()
    .then((next) => remember(next))
    .finally(() => {
      inflight = null;
    });
  return inflight;
}

export function peekAllCatalog(): SmmCatalogPayload | null {
  return cached;
}

export function catalogSavedAt(): number {
  return at;
}

export function subscribeAllCatalog(fn: (payload: SmmCatalogPayload) => void): () => void {
  listeners.add(fn);
  if (cached) fn(cached);
  return () => {
    listeners.delete(fn);
  };
}

export async function loadAllCatalog(force = false): Promise<SmmCatalogPayload> {
  const stale = cached ?? (await hydrate());
  if (!catalogNeedsPull(Boolean(stale), at, force)) return stale!;
  if (stale && !force) {
    void pull().catch(() => undefined);
    return stale;
  }
  return pull();
}

export function warmAllCatalog() {
  void loadAllCatalog();
}

if (typeof window !== "undefined") {
  void hydrate();
}
