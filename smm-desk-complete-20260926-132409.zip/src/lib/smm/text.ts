const AMP = new RegExp(`&${"amp;"}`, "gi");
const LT = new RegExp(`&${"lt;"}`, "gi");
const GT = new RegExp(`&${"gt;"}`, "gi");
const QUOT = new RegExp(`&${"quot;"}`, "gi");
const APOS = new RegExp(`&${"apos;"}`, "gi");
const NUM39 = new RegExp(`&#${"39;"}`, "g");

export function decodeEntities(value: string): string {
  let next = value;
  for (let i = 0; i < 4; i++) {
    const prev = next;
    next = next
      .replace(AMP, "&")
      .replace(LT, "<")
      .replace(GT, ">")
      .replace(QUOT, '"')
      .replace(APOS, "'")
      .replace(NUM39, "'")
      .replace(/&#x([0-9a-f]+);/gi, (_, h: string) => {
        const n = parseInt(h, 16);
        return Number.isFinite(n) ? String.fromCodePoint(n) : _;
      })
      .replace(/&#(\d+);/g, (_, n: string) => {
        const v = Number(n);
        return Number.isFinite(v) ? String.fromCodePoint(v) : _;
      });
    if (next === prev) break;
  }
  return next;
}
