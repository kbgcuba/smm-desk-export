import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";

export type PanelAccount = {
  id: string;
  label: string;
  url: string;
  key: string;
  locked: boolean;
};

export type PanelPublic = {
  id: string;
  label: string;
  url: string;
  hint: string;
  locked: boolean;
};

const CORE: PanelAccount[] = [
  {
    id: "smmwiz",
    label: "SmmWiz",
    url: "https://smmwiz.com/api/v2",
    key: "de3287f940ed663f8c6dc2c7d797e639",
    locked: true,
  },
  {
    id: "jap",
    label: "JustAnotherPanel",
    url: "https://justanotherpanel.com/api/v2",
    key: "bd00b90a7deec5a5db8524a8bf70a80e",
    locked: true,
  },
  {
    id: "smmfanz",
    label: "SmmFanz",
    url: "https://smmfanz.com/api/v2",
    key: "5d0e0aa810000429da9e14366a898e78",
    locked: true,
  },
];

const FILE = path.join(process.cwd(), "data", "smm-panels.json");
const RESERVED = new Set(["smmwiz", "jap", "smmfanz", "settings", "orders", "refills", "api", "live"]);

function slugify(label: string): string {
  return label
    .toLowerCase()
    .trim()
    .replace(/https?:\/\//g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 24);
}

function mask(key: string): string {
  const k = key.trim();
  if (k.length <= 4) return "••••";
  return `••••${k.slice(-4)}`;
}

function asPublic(row: PanelAccount): PanelPublic {
  return { id: row.id, label: row.label, url: row.url, hint: mask(row.key), locked: row.locked };
}

function cleanUrl(raw: string): string {
  const url = raw.trim().replace(/\/+$/, "");
  if (!/^https:\/\/[^\s]+/i.test(url)) throw new Error("API URL must start with https://");
  return url;
}

async function readExtras(): Promise<PanelAccount[]> {
  try {
    const raw = await readFile(FILE, "utf8");
    const json = JSON.parse(raw) as { panels?: PanelAccount[] };
    if (!Array.isArray(json.panels)) return [];
    return json.panels
      .filter((row) => row && typeof row.id === "string" && row.key && row.url)
      .map((row) => ({
        id: row.id,
        label: String(row.label || row.id),
        url: String(row.url),
        key: String(row.key),
        locked: false,
      }));
  } catch {
    return [];
  }
}

async function writeExtras(panels: PanelAccount[]): Promise<void> {
  await mkdir(path.dirname(FILE), { recursive: true });
  await writeFile(FILE, JSON.stringify({ panels, savedAt: Date.now() }), "utf8");
}

function merge(extras: PanelAccount[]): PanelAccount[] {
  const extraMap = new Map(extras.map((row) => [row.id, row]));
  const core = CORE.map((row) => {
    const over = extraMap.get(row.id);
    return over ? { ...row, key: over.key || row.key, url: over.url || row.url } : row;
  });
  const more = extras.filter((row) => !CORE.some((c) => c.id === row.id) && !RESERVED.has(row.id));
  return [...core, ...more];
}

export async function listAccounts(): Promise<PanelAccount[]> {
  return merge(await readExtras());
}

export async function getAccount(id: string): Promise<PanelAccount | null> {
  return (await listAccounts()).find((row) => row.id === id) ?? null;
}

export async function listPublicAccounts(): Promise<PanelPublic[]> {
  return (await listAccounts()).map(asPublic);
}

export async function addAccount(input: { label: string; url: string; key: string }): Promise<PanelPublic> {
  const label = input.label.trim();
  const key = input.key.trim();
  const url = cleanUrl(input.url);
  if (!label) throw new Error("Enter a panel name");
  if (key.length < 8) throw new Error("API key looks too short");
  const extras = await readExtras();
  if (CORE.length + extras.length >= 12) throw new Error("Too many APIs");
  let id = slugify(label);
  if (!id || RESERVED.has(id) || extras.some((row) => row.id === id)) {
    id = `${id || "panel"}-${extras.length + 2}`;
  }
  if (RESERVED.has(id) || extras.some((row) => row.id === id)) throw new Error("Pick a different name");
  const next: PanelAccount = { id, label, url, key, locked: false };
  extras.push(next);
  await writeExtras(extras);
  return asPublic(next);
}

export async function updateAccountKey(id: string, key: string): Promise<PanelPublic> {
  const nextKey = key.trim();
  if (nextKey.length < 8) throw new Error("API key looks too short");
  const all = await listAccounts();
  const base = all.find((row) => row.id === id);
  if (!base) throw new Error("Unknown panel");
  const extras = await readExtras();
  const i = extras.findIndex((row) => row.id === id);
  const row: PanelAccount = { ...base, key: nextKey, locked: false };
  if (i >= 0) extras[i] = row;
  else extras.push(row);
  await writeExtras(extras);
  return asPublic({ ...base, key: nextKey });
}

export async function removeAccount(id: string): Promise<void> {
  if (CORE.some((row) => row.id === id)) throw new Error("Core APIs stay");
  const extras = (await readExtras()).filter((row) => row.id !== id);
  await writeExtras(extras);
}

export async function accountIds(): Promise<string[]> {
  return (await listAccounts()).map((row) => row.id);
}
