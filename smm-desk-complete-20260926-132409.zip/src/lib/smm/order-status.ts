/** Panel parent drip jobs report `Active` with no remains. That is not done. */

export function stillRunning(status?: string): boolean {
  return /pending|wait|queue|progress|process|sending|\bactive\b|drip|\bin progress\b|await/.test(
    (status ?? "").toLowerCase(),
  );
}

export function orderFinished(row: { panelStatus?: string; remains?: number }): boolean {
  const s = (row.panelStatus ?? "").toLowerCase();
  if (/cancel|refund|fail|error|reject/.test(s)) return false;
  if (stillRunning(s)) return false;
  if (/complet|success|done|finish/.test(s)) return true;
  if (row.remains === 0) return true;
  return false;
}

export function extraCounts(item: {
  start_count?: unknown;
  start?: unknown;
  remains?: unknown;
  refill?: unknown;
  runs?: unknown;
}): { start?: number; remains?: number; refill?: boolean; runs?: number } {
  const startRaw = item.start_count ?? item.start;
  const remainsRaw = item.remains;
  const start = startRaw != null && String(startRaw).trim() !== "" ? Number(startRaw) : NaN;
  const remains = remainsRaw != null && String(remainsRaw).trim() !== "" ? Number(remainsRaw) : NaN;
  const runsRaw = item.runs != null && String(item.runs).trim() !== "" ? Number(item.runs) : NaN;
  const refillFlag =
    item.refill === true ||
    item.refill === 1 ||
    item.refill === "1" ||
    item.refill === "true" ||
    item.refill === "yes" ||
    item.refill === "available"
      ? true
      : item.refill === false ||
          item.refill === 0 ||
          item.refill === "0" ||
          item.refill === "false" ||
          item.refill === "no" ||
          item.refill === "disabled"
        ? false
        : undefined;
  return {
    start: Number.isFinite(start) ? start : undefined,
    remains: Number.isFinite(remains) ? remains : undefined,
    refill: refillFlag,
    runs: Number.isFinite(runsRaw) && runsRaw > 0 ? Math.floor(runsRaw) : undefined,
  };
}
