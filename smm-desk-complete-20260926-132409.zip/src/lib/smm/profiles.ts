import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { LookedProfile, ProfileItem, TrackedProfile } from "@/lib/smm/profile-types";

export type { LookedProfile, TrackedProfile };

export const CORE_PROFILES: TrackedProfile[] = [
  {
    id: "tiktok:clauivory",
    url: "https://www.tiktok.com/@clauivory",
    platform: "tiktok",
    handle: "clauivory",
    title: "Clauivory",
    avatar: null,
    stats: [],
    at: 1,
  },
  {
    id: "youtube:claudiaivory",
    url: "https://www.youtube.com/@claudiaivory",
    platform: "youtube",
    handle: "claudiaivory",
    title: "Claudia Ivory",
    avatar: null,
    stats: [],
    at: 1,
  },
  {
    id: "instagram:clauivory",
    url: "https://www.instagram.com/clauivory/",
    platform: "instagram",
    handle: "clauivory",
    title: "Clauivory",
    avatar: null,
    stats: [],
    at: 1,
  },
  {
    id: "facebook:105894818641566",
    url: "https://www.facebook.com/105894818641566",
    platform: "facebook",
    handle: "105894818641566",
    title: "Claudia Ivory",
    avatar: null,
    stats: [],
    at: 1,
  },
];

function withCore(list: TrackedProfile[]): TrackedProfile[] {
  const out = list.filter((p) => !(p.platform === "facebook" && p.id !== "facebook:105894818641566"));
  return out.length ? out : CORE_PROFILES;
}

export type ProfileFeedState = { items: ProfileItem[]; cursor: string | null; at: number };

function mergeStats(a: LookedProfile["stats"] = [], b: LookedProfile["stats"] = []): LookedProfile["stats"] {
  const map = new Map(a.map((s) => [s.key, s]));
  for (const s of b) {
    if (s && Number.isFinite(s.value)) map.set(s.key, s);
  }
  return [...map.values()];
}

function mergeItem(old: ProfileItem, item: ProfileItem): ProfileItem {
  return {
    ...old,
    ...item,
    thumb: item.thumb || old.thumb,
    title: item.title || old.title,
    url: item.url || old.url,
    at: item.at || old.at,
    kind: item.kind || old.kind,
    stats: mergeStats(old.stats, item.stats),
  };
}

export function mergeFeedItems(prev: ProfileItem[], incoming: ProfileItem[]): ProfileItem[] {
  if (!prev.length) return incoming.filter((i) => i?.id);
  if (!incoming.length) return prev;
  const map = new Map(prev.map((i) => [i.id, i]));
  const order = prev.map((i) => i.id);
  const urls = new Set(prev.map((i) => (i.url || "").split("?")[0].replace(/\/$/, "")).filter(Boolean));
  for (const item of incoming) {
    if (!item?.id) continue;
    const old = map.get(item.id);
    if (old) {
      map.set(item.id, mergeItem(old, item));
      continue;
    }
    const href = (item.url || "").split("?")[0].replace(/\/$/, "");
    if (href && urls.has(href)) continue;
    map.set(item.id, item);
    order.push(item.id);
    if (href) urls.add(href);
  }
  return order.map((id) => map.get(id)!).filter(Boolean);
}

export function isPrefixRefresh(prev: ProfileItem[], incoming: ProfileItem[]): boolean {
  if (!prev.length || !incoming.length) return false;
  const have = new Set(prev.map((i) => i.id));
  const hit = incoming.filter((i) => have.has(i.id)).length;
  return hit >= Math.max(1, Math.ceil(Math.min(incoming.length, 8) * 0.6));
}

export function nextFeedCursor(
  prev: { items: ProfileItem[]; cursor: string | null } | undefined,
  incoming: ProfileItem[],
  cursor: string | null,
): string | null {
  const prevItems = prev?.items || [];
  const prevCursor = prev?.cursor ?? null;
  if (isPrefixRefresh(prevItems, incoming)) {
    if (prevItems.length > incoming.length) return prevCursor ?? cursor;
    return cursor ?? prevCursor;
  }
  return cursor;
}

function keepProfile(prev: TrackedProfile, row: LookedProfile & { at?: number }): TrackedProfile {
  return {
    ...prev,
    ...row,
    id: row.id || prev.id,
    url: row.url || prev.url,
    handle: row.handle || prev.handle,
    title: row.title || prev.title,
    avatar: row.avatar || prev.avatar,
    stats: mergeStats(prev.stats, row.stats),
    at: row.at ?? prev.at,
  };
}

function peekSaved(): { profiles: TrackedProfile[]; profilesAt: number; feeds: Record<string, ProfileFeedState> } {
  if (typeof window === "undefined") return { profiles: CORE_PROFILES, profilesAt: 0, feeds: {} };
  try {
    const raw = localStorage.getItem("smm-profiles");
    if (!raw) return { profiles: CORE_PROFILES, profilesAt: 0, feeds: {} };
    const state = JSON.parse(raw)?.state as {
      profiles?: TrackedProfile[];
      profilesAt?: number;
      feeds?: Record<string, ProfileFeedState>;
    } | undefined;
    const profiles = Array.isArray(state?.profiles) ? withCore(state.profiles) : CORE_PROFILES;
    const feeds: Record<string, ProfileFeedState> = {};
    if (state?.feeds && typeof state.feeds === "object") {
      for (const [id, pack] of Object.entries(state.feeds)) {
        if (pack && Array.isArray(pack.items) && pack.items.length) {
          const cap = 2000;
          feeds[id] = { items: pack.items.slice(0, cap), cursor: pack.cursor ?? null, at: pack.at || 0 };
        }
      }
    }
    return {
      profiles: profiles.length ? profiles : CORE_PROFILES,
      profilesAt: typeof state?.profilesAt === "number" ? state.profilesAt : 0,
      feeds,
    };
  } catch {
    return { profiles: CORE_PROFILES, profilesAt: 0, feeds: {} };
  }
}

const seeded = peekSaved();

type State = {
  profiles: TrackedProfile[];
  profilesAt: number;
  live: boolean;
  liveAt: number;
  feeds: Record<string, ProfileFeedState>;
  save: (row: LookedProfile) => void;
  remove: (id: string) => void;
  patch: (row: LookedProfile) => void;
  replaceAll: (profiles: TrackedProfile[], at?: number) => void;
  reorder: (fromId: string, toIndex: number) => void;
  setFeed: (id: string, items: ProfileItem[], cursor: string | null) => void;
  setLive: (live: boolean, at?: number) => void;
};

export const useSmmProfiles = create<State>()(
  persist(
    (set, get) => ({
      profiles: seeded.profiles,
      profilesAt: seeded.profilesAt,
      live: false,
      liveAt: 0,
      feeds: seeded.feeds,
      save: (row) => {
        const next: TrackedProfile = { ...row, at: Date.now() };
        const list = get().profiles.filter((p) => p.id !== next.id && p.url !== next.url);
        set({ profiles: [...list, next], profilesAt: Date.now() });
      },
      remove: (id) => {
        set({ profiles: get().profiles.filter((p) => p.id !== id), profilesAt: Date.now() });
      },
      patch: (row) => {
        const digits = (s: string) => s.match(/(\d{8,})/)?.[1] || "";
        set({
          profiles: get().profiles.map((p) => {
            const same =
              p.id === row.id ||
              p.url === row.url ||
              (p.platform === row.platform && p.handle === row.handle) ||
              (p.platform === "facebook" && row.platform === "facebook" && (digits(p.handle) === digits(row.handle) || digits(p.id) === digits(row.id) || !digits(p.handle) || !digits(row.handle)));
            if (!same) return p;
            return keepProfile(p, { ...row, at: Date.now() });
          }),
          profilesAt: get().profilesAt,
        });
      },
      replaceAll: (profiles, at) => {
        const have = new Map(get().profiles.map((p) => [p.id, p]));
        const next = withCore(profiles).map((row) => {
          const prev = have.get(row.id) || [...have.values()].find((p) => p.platform === row.platform && p.handle === row.handle);
          return prev ? keepProfile(prev, row) : row;
        });
        set({ profiles: next, profilesAt: at ?? Date.now() });
      },
      reorder: (fromId, toIndex) => {
        const list = get().profiles;
        const item = list.find((p) => p.id === fromId);
        if (!item) return;
        const rest = list.filter((p) => p.id !== fromId);
        const i = Math.max(0, Math.min(toIndex, rest.length));
        const next = [...rest.slice(0, i), item, ...rest.slice(i)];
        if (next.every((p, n) => p.id === list[n]?.id)) return;
        set({ profiles: next, profilesAt: Date.now() });
      },
      setFeed: (id, items, cursor) => {
        if (!id) return;
        const prev = get().feeds[id];
        const prevItems = prev?.items || [];
        if (!items.length) {
          if (prevItems.length) return;
          set({ feeds: { ...get().feeds, [id]: { items: [], cursor: null, at: Date.now() } } });
          return;
        }
        const merged = mergeFeedItems(prevItems, items);
        const nextCursor = nextFeedCursor(prev, items, cursor);
        if (
          prev &&
          prev.cursor === nextCursor &&
          prevItems.length === merged.length &&
          prevItems.every((row, i) => row === merged[i] || (row.id === merged[i]?.id && row.stats === merged[i]?.stats && row.thumb === merged[i]?.thumb))
        ) {
          return;
        }
        set({
          feeds: {
            ...get().feeds,
            [id]: { items: merged, cursor: nextCursor, at: Date.now() },
          },
        });
      },
      setLive: (live, at) => set({ live, liveAt: at ?? (live ? Date.now() : get().liveAt) }),
    }),
    {
      name: "smm-profiles",
      skipHydration: true,
      partialize: (s) => ({
        profiles: s.profiles,
        profilesAt: s.profilesAt,
        feeds: Object.fromEntries(
          Object.entries(s.feeds).map(([id, pack]) => [
            id,
            {
              ...pack,
              items: pack.items.slice(0, 2000),
            },
          ]),
        ),
      }),
    },
  ),
);
