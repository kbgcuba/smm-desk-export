import { createHmac, timingSafeEqual } from "node:crypto";

export const ACCESS_COOKIE = "smm-access";

export function signAccess(deviceId: string, secret: string): string {
  const id = deviceId.trim().slice(0, 64);
  const mac = createHmac("sha256", secret).update(`smm-access:v1:${id}`).digest("hex").slice(0, 32);
  return `${id}.${mac}`;
}

export function parseAccess(token: string, secret: string): string | null {
  const raw = token.trim();
  const i = raw.lastIndexOf(".");
  if (i < 8 || !secret) return null;
  const id = raw.slice(0, i);
  const mac = raw.slice(i + 1);
  if (!/^[a-zA-Z0-9-]{8,64}$/.test(id) || !/^[0-9a-f]{32}$/.test(mac)) return null;
  const expect = createHmac("sha256", secret).update(`smm-access:v1:${id}`).digest("hex").slice(0, 32);
  try {
    if (!timingSafeEqual(Buffer.from(mac), Buffer.from(expect))) return null;
  } catch {
    return null;
  }
  return id;
}

export function parseAccessHeader(request: Request | undefined, secret: string): string | null {
  if (!request) return null;
  const raw = request.headers.get("cookie") ?? "";
  const m = raw.match(/(?:^|;\s*)smm-access=([^;]*)/);
  if (!m?.[1]) return null;
  try {
    return parseAccess(decodeURIComponent(m[1]), secret);
  } catch {
    return null;
  }
}

export async function readAccessDevice(secret: string, request?: Request): Promise<string | null> {
  if (request) {
    const fromReq = parseAccessHeader(request, secret);
    if (fromReq) return fromReq;
  }
  try {
    const { getCookie, getRequest } = await import("@tanstack/react-start/server");
    const fromAls = parseAccessHeader(getRequest(), secret);
    if (fromAls) return fromAls;
    return parseAccess(getCookie(ACCESS_COOKIE) ?? "", secret);
  } catch {
    return null;
  }
}

function cookieSecure(): boolean {
  return process.env.NODE_ENV === "production";
}

export async function stampAccessCookie(deviceId: string, secret: string): Promise<void> {
  const { setCookie } = await import("@tanstack/react-start/server");
  setCookie(ACCESS_COOKIE, signAccess(deviceId, secret), {
    path: "/",
    httpOnly: true,
    sameSite: "lax",
    maxAge: 60 * 60 * 24 * 400,
    secure: cookieSecure(),
  });
}

export async function clearAccessCookie(): Promise<void> {
  try {
    const { setCookie } = await import("@tanstack/react-start/server");
    setCookie(ACCESS_COOKIE, "", {
      path: "/",
      httpOnly: true,
      sameSite: "lax",
      maxAge: 0,
      secure: cookieSecure(),
    });
  } catch {
    /* not in a request */
  }
}

export async function requireAccess(request?: Request): Promise<void> {
  const { readAccessPassword, accessGateStatus } = await import("./cloud.server.ts");
  const custom = await readAccessPassword();
  if (!custom) return;
  const id = await readAccessDevice(custom, request);
  if (!id) throw new Error("This device is locked");
  const gate = await accessGateStatus(id);
  if (!gate.allowed) throw new Error("This device is locked");
}
