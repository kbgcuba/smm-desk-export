import type { WpItem } from "./wp-list.ts";

/** Claudia Ivory links. Newest first. Source page listed oldest first. */
export function claudiaIvoryLinks(): WpItem[] {
  const rows: { title: string; url: string }[] = [
    { title: "PDRN Hydraglow Collagen Mask", url: "https://www.amazon.com/dp/B0H9KV5B3B?maas=maas_adg_D0A84337E5B2917AF47346B603B069BA_afap_abs&ref_=aa_maas&tag=maas" },
    { title: "Bedsure 2-in-1 Comforter Set", url: "https://www.amazon.com/dp/B0G34R9F1B?maas=maas_adg_4C1867282C919749260465D7893AA52D_afap_abs&ref_=aa_maas&tag=maas&th=1" },
    { title: "Bubble Pop Cleanser", url: "https://www.amazon.com/dp/B0HBV3XSY7?maas=maas_adg_E9DFEBF2F24CB4B90C14FC3D8FDA4B19_afap_abs&ref_=aa_maas&tag=maas" },
    { title: "MissFeel Loungewear", url: "https://www.missfeel.com/?ref=CLAUDIAIVORY" },
    { title: "Zima Silk Pillowcase", url: "https://www.amazon.com/zimasilk" },
    { title: "Foric Ring (CLAUDIA20)", url: "https://dada.link/o-Xhk2" },
    { title: "Tuplus Luggage", url: "https://go.wotohub.com/track/click2/eNp1j71uAjEQhN_FIp3P5_XfertEaXgHhE62gXCSg1HuHIQQ784hF1RIoylmpvhmo4EcIWeMM0DvjEbvwVszgNSk3ND6AY3WJKbUgexoMei86cZTLPW0k6v1PufymXKouzGM_-XvKlL5ZVyhIrCWODvO8_lDf_X9XM-5Ts-6_257sIxLzg4hT_snBaCwUkhhHXuli5IKgUBZkhCdwaCdjeQiYnIhSoVt9VPEpczlWGNDuN15e8L1gvEGdPsAWDdJrQ==.html" },
    { title: "Coach: Modern Luxury Made for Every Day", url: "https://go.ultrainfluence.com/u1-PA9544g5" },
    { title: "Aeroraise 3D Printed Sneakers", url: "https://tr.ee/sKdBzq" },
    { title: "Personal Blender", url: "https://go.wotohub.com/track/click2/eNptkM1qwzAQhN9FNDdZ1q5-LN0ax4TSVyhFrG3ZCThRiJ2atvTdG9eFXgoLe5hvBmZeFHjrDWeMMygcFt5p50HpAFJ5tGHVg9KFk2JsMpCZz8Bn2mbHc51u51Y-HOIwpMdmoFt7pONbur6LJp0YxwI9GOM5O0zTZdyobZ7P8yzoRB_pvDB5e8lLua-Ur56e_UbtT0R3rlpeoLYPZYk7owosd4BbBA9W7QrQptrqwqI0gTq6BKrHDdpr7MLdSxR-UtBO1P9mMS4562gY49ITpQCFwmgBXrM_4X6NQ9uBc21tvSPTRRUxdjFSE6MEJ1eqT2JOUzrc6rXo5xdf5-JqKfv_HK_fKNdoRA==.html" },
    { title: "Your new favorite bag just happens to be Coach", url: "https://go.ultrainfluence.com/u1-ByDgSdEc" },
    { title: "Epii", url: "https://www.amazon.com/epii-moisturizer-panthenol-squalane-sensitive/dp/B0GBTCG9WD/ref=sr_1_1?crid=31UWR36U62NR3&dib=eyJ2IjoiMSJ9.TPPfdY_zUxw87Hqg-AarLIaoBkezjBKuG6XvX7a8BFJy-x_TM_cx6iPs5amHoH5U9TwdFy74IMghmxOoAkXXDxQYMvto-UoC-bSjBxJsqGcXZyMUO7gDmq891p_by7yU42VzQIC95I2Y9lS--RUAq3W0FoEQk4Hft9lDh-to2xctFe1t_FlKdLWVYtMDeRHidg2LwWesE6Ebp0VuTLO0PIne6OEKgd3Kl4gigXghG2o.4SEN81vQCJ82I_0XxSW42du1Euwj9_YCsS8b9N8GvtY&dib_tag=se&keywords=epii&qid=1773727364&sprefix=epii%2Caps%2C352&sr=8-1&th=1" },
    { title: "Vacuum VortexIQ Pro", url: "https://get.aspr.app/SH1kp1" },
    { title: "Luxear Silky Cooling Pillowcases (10% off code: ZVWETUOX)", url: "http://url9637.mcn.noxinfluencer.com/ls/click?upn=u001.x38MKs5dFWv60-2BkXGWfimVoPtBPWsr8sBR3dTpV4TI4LWzR3AIi-2FKFfUTsZPgldiHSPn_xdUTvUhIjWlSJgufBblll6v6sjXsIcdzOKbcwKLPHQuFiIND-2BTFL55Lpf5I-2B1pIMncZ54-2BC5kaZTksXajbnZX06-2FtXo81f7GQH2-2F64VIrG0Z0ryEa7aH5QTlyZAf3jFFRhwKbfAooprGs824REuwIUi-2BXTrcm9Jvrrt7whneT2LxB44V7wupXej1Ov34PJ8r4GF6-2FCpm9l-2F-2FfkubvkfjQCHglehe8r59NvOYJ37eX0hFTMI5FaahGWVawMBrWXxA02ShWEPvDDbbydwpCGTOac9nmIpt0QUA9-2Brhodhll1DRxtQbA9jcv15FWPeeR0rs" },
    { title: "Coach Outlet: Iconic luxury styles at prices you\u2019ll absolutely love", url: "https://go.ultrainfluence.com/u1-Fy09TDEz" },
    { title: "Vivaia", url: "https://h7.cl/1ovLX" },
    { title: "Amazon", url: "https://www.amazon.com/shop/influencer-c2f5f0ea?ref_=cm_sw_r_apin_aipsfshop_AQ1466RTB355JTR0A5WV_1&language=en-US" },
    { title: "Shop My Outfits", url: "https://www.shopltk.com/explore/claudiaivory?utm_campaign=creator_shop_share_template_flow&utm_source=ioscreatorapp" },
  ];
  return rows.map((row, i) => ({
    id: `ci${String(i + 1).padStart(2, "0")}`,
    title: row.title,
    url: row.url,
    image: "",
    badge: "",
    published: true,
    children: [],
  }));
}
