import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { PanelBalance } from "@/lib/smm/fn";

type State = {
  panels: PanelBalance[];
  live: boolean;
  apply: (incoming: PanelBalance[]) => void;
  setLive: (live: boolean) => void;
};

function merge(prev: PanelBalance[], incoming: PanelBalance[]): PanelBalance[] {
  const map = new Map(prev.map((row) => [row.id, row]));
  for (const row of incoming) {
    if (row.balance === "—" || row.balance === "…") continue;
    map.set(row.id, row);
  }
  return [...map.values()];
}

export const useSmmLive = create<State>()(
  persist(
    (set, get) => ({
      panels: [],
      live: false,
      apply: (incoming) => set({ panels: merge(get().panels, incoming) }),
      setLive: (live) => set({ live }),
    }),
    { name: "smm-live", partialize: (s) => ({ panels: s.panels }) },
  ),
);
