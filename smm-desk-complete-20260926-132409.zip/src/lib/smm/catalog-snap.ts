import type { SmmService } from "./types.ts";

export type CatalogPanel = { id: string; label: string; balance: string; currency: string };
export type CatalogPayload = { panels: CatalogPanel[]; services: SmmService[] };
export type CatalogSnap = CatalogPayload & { at: number };

export const CATALOG_FRESH_MS = 5 * 60 * 1000;

export function isCatalogFresh(at: number, now = Date.now(), ttl = CATALOG_FRESH_MS): boolean {
  return at > 0 && now - at < ttl;
}

/** Whether loadAllCatalog should hit the panels. Stale lists still show. */
export function catalogNeedsPull(hasList: boolean, savedAt: number, force = false, now = Date.now()): boolean {
  if (force) return true;
  if (!hasList) return true;
  return !isCatalogFresh(savedAt, now);
}

function asService(row: unknown): SmmService | null {
  if (!row || typeof row !== "object") return null;
  const d = row as Record<string, unknown>;
  const panel = typeof d.panel === "string" ? d.panel.trim() : "";
  const id = Number(d.id);
  const name = typeof d.name === "string" ? d.name : "";
  if (!panel || !Number.isFinite(id) || id < 1 || !name) return null;
  return {
    panel,
    id: Math.floor(id),
    name,
    category: typeof d.category === "string" ? d.category : "",
    rate: d.rate == null ? "0" : String(d.rate),
    min: Number.isFinite(Number(d.min)) ? Number(d.min) : 1,
    max: Number.isFinite(Number(d.max)) ? Number(d.max) : 100_000_000,
    type: typeof d.type === "string" ? d.type : "Default",
    dripfeed: d.dripfeed === true,
    refill: d.refill === true,
    cancel: d.cancel === true,
    averageTime: typeof d.averageTime === "string" ? d.averageTime : null,
    speed: typeof d.speed === "string" ? d.speed : null,
  };
}

function asPanel(row: unknown): CatalogPanel | null {
  if (!row || typeof row !== "object") return null;
  const d = row as Record<string, unknown>;
  const id = typeof d.id === "string" ? d.id.trim() : "";
  if (!id) return null;
  return {
    id,
    label: typeof d.label === "string" ? d.label : id,
    balance: typeof d.balance === "string" ? d.balance : "—",
    currency: typeof d.currency === "string" ? d.currency : "USD",
  };
}

export function parseCatalogSnap(raw: unknown): CatalogSnap | null {
  if (!raw || typeof raw !== "object") return null;
  const d = raw as { services?: unknown; panels?: unknown; at?: unknown };
  if (!Array.isArray(d.services)) return null;
  const services: SmmService[] = [];
  const seen = new Set<string>();
  for (const row of d.services) {
    const s = asService(row);
    if (!s) continue;
    const key = `${s.panel}:${s.id}`;
    if (seen.has(key)) continue;
    seen.add(key);
    services.push(s);
  }
  if (!services.length) return null;
  const panels: CatalogPanel[] = [];
  if (Array.isArray(d.panels)) {
    for (const row of d.panels) {
      const p = asPanel(row);
      if (p) panels.push(p);
    }
  }
  const at = Number(d.at);
  return { services, panels, at: Number.isFinite(at) && at > 0 ? at : 0 };
}
