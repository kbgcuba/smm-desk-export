import { toast } from "sonner";

const style = { border: "1.5px solid #facc15", boxShadow: "0 0 0 1px #facc15" } as const;

export function toastFavorited(label: string, onView: () => void) {
  toast.success(`Added to Favorites → ${label}`, {
    className: "fav-toast",
    style,
    action: { label: "View", onClick: onView },
  });
}

export function toastPinned() {
  toast.message("This one stays in Favorites", { className: "fav-toast", style });
}
