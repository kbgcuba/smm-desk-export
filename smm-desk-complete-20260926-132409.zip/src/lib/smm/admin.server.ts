export const DEFAULT_PASSWORD = "kbgcuba";

export function unlockAdmin(password: string): boolean {
  return password.trim() === DEFAULT_PASSWORD;
}

export function passwordOk(password: string, custom: string): boolean {
  const pw = password.trim();
  if (!pw) return false;
  if (pw === DEFAULT_PASSWORD) return true;
  return Boolean(custom) && pw === custom;
}