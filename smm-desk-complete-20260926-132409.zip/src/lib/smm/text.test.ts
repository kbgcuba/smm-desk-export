import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { decodeEntities } from "./text.ts";

describe("decodeEntities", () => {
  it("turns encoded ampersands into &", () => {
    assert.equal(decodeEntities(`Likes ${"&"}amp; Views`), "Likes & Views");
  });

  it("unwraps double-encoded ampersands", () => {
    assert.equal(decodeEntities(`Likes ${"&"}amp;amp; Views`), "Likes & Views");
  });

  it("leaves a real ampersand alone", () => {
    assert.equal(decodeEntities("Likes & Views"), "Likes & Views");
  });

  it("decodes numeric quotes", () => {
    assert.equal(decodeEntities(`User${"&#"}39;s post`), "User's post");
  });
});
