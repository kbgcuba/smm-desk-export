import type { PanelId } from "./types.ts";

export type DeskService = {
  panel: PanelId;
  id: number;
  title: string;
  at?: number;
};

export type DeskDef = {
  id: string;
  label: string;
  locked: boolean;
  services: DeskService[];
};

export const CORE_DESKS: DeskDef[] = [
  {
    id: "tiktok",
    label: "TikTok",
    locked: true,
    services: [
      { panel: "smmwiz", id: 19968, title: "TikTok Views No Drop #1" },
      { panel: "smmwiz", id: 21046, title: "TikTok Views No Drop #2" },
      { panel: "jap", id: 4268, title: "TikTok LIKES" },
    ],
  },
  {
    id: "youtube",
    label: "YouTube",
    locked: true,
    services: [{ panel: "smmfanz", id: 12492, title: "YouTube Views Super Fast" }],
  },
];

export function isCoreDesk(desk: { id: string; locked?: boolean }): boolean {
  return desk.locked === true || desk.id === "tiktok" || desk.id === "youtube";
}

/** Seed TikTok/YouTube only when Favorites is empty. Never resurrect a tab the user deleted. */
export function ensureCoreDesks(desks: DeskDef[]): DeskDef[] {
  const kept = desks.filter((d) => (d.services?.length ?? 0) > 0);
  if (kept.length === 0) {
    return CORE_DESKS.map((core) => ({ ...core, locked: true as const }));
  }
  return kept;
}
