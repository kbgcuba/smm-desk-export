export type PanelId = string;
export type SmmDesk = string;

export type SmmService = {
  panel: PanelId;
  id: number;
  name: string;
  category: string;
  rate: string;
  min: number;
  max: number;
  type: string;
  dripfeed: boolean;
  refill: boolean;
  cancel: boolean;
  averageTime: string | null;
  speed: string | null;
};

export function serviceKey(s: { panel: PanelId; id: number }): string {
  return `${s.panel}:${s.id}`;
}

export type LineParam = "comments" | "usernames" | "groups" | "keywords";

export type OrderNeeds = {
  target: "link" | "username";
  quantity: "normal" | "from-lines" | "hidden";
  lines?: { param: LineParam; label: string; hint: string };
  username?: { label: string; hint: string };
  hashtag?: boolean;
  media?: boolean;
  answer?: boolean;
  subscription?: boolean;
  drip: boolean;
};

function typeName(s: { type?: string }): string {
  return (s.type ?? "Default").toLowerCase().replace(/[_-]+/g, " ").trim();
}

export function orderNeeds(s: { type?: string; name?: string; dripfeed?: boolean; panel?: PanelId; id?: number }): OrderNeeds {
  const type = typeName(s);
  const drip = Boolean(s.dripfeed) && `${s.panel ?? ""}:${s.id ?? ""}` !== "smmfanz:12492";
  const base: OrderNeeds = { target: "link", quantity: "normal", drip };

  if (type === "package") return { ...base, quantity: "hidden", drip: false };
  if (type === "custom comments") {
    return { ...base, quantity: "from-lines", lines: { param: "comments", label: "Messages", hint: "One message per line" } };
  }
  if (type === "custom comments package") {
    return {
      ...base,
      quantity: "from-lines",
      lines: { param: "comments", label: "Messages", hint: "One message per line" },
      drip: false,
    };
  }
  if (type === "comment replies") {
    return { ...base, quantity: "from-lines", lines: { param: "comments", label: "Replies", hint: "One reply per line" } };
  }
  if (type === "mentions custom list") {
    return { ...base, quantity: "from-lines", lines: { param: "usernames", label: "Usernames", hint: "One username per line" } };
  }
  if (type === "mentions with hashtags") {
    return { ...base, lines: { param: "usernames", label: "Usernames", hint: "One username per line" } };
  }
  if (type === "mentions hashtag") return { ...base, hashtag: true };
  if (type === "mentions user followers") {
    return { ...base, username: { label: "Whose followers", hint: "Username to take followers from" } };
  }
  if (type === "mentions media likers") return { ...base, media: true };
  if (type === "comment likes") {
    return { ...base, username: { label: "Comment owner", hint: "Username of that comment" } };
  }
  if (type === "poll") return { ...base, answer: true };
  if (type === "subscriptions") {
    return { target: "username", quantity: "hidden", subscription: true, drip: false };
  }
  if (type === "seo" || type === "web traffic") {
    return { ...base, lines: { param: "keywords", label: "Keywords", hint: "One keyword per line" } };
  }
  if (type === "mentions") {
    return { ...base, quantity: "from-lines", lines: { param: "usernames", label: "Usernames", hint: "One username per line" } };
  }
  if (type === "invites from groups") {
    return { ...base, lines: { param: "groups", label: "Groups", hint: "One group link per line" } };
  }

  const name = (s.name ?? "").toLowerCase();
  if (/(custom|costum)\s+comments?/.test(name) && !/package/.test(name)) {
    return { ...base, quantity: "from-lines", lines: { param: "comments", label: "Messages", hint: "One message per line" } };
  }
  if (/comment repl(y|ies)/.test(name)) {
    return { ...base, quantity: "from-lines", lines: { param: "comments", label: "Replies", hint: "One reply per line" } };
  }
  return base;
}

export function isCommentOrder(s: { name?: string; type?: string; metric?: string }): boolean {
  if (s.metric === "comments") return true;
  const hay = `${s.type ?? ""} ${s.name ?? ""}`.toLowerCase();
  if (/comment like/.test(hay)) return false;
  return /(custom|costum)\s+comments?|comment repl(y|ies)/.test(hay);
}

export function parseMemo(raw: string, max: number): string[] {
  const cap = Math.max(1, Math.min(Math.floor(max) || 1, 2_000));
  const out: string[] = [];
  for (const line of raw.split(/\r\n|\n|\u2028|\u2029/)) {
    const text = line.trim().slice(0, 500);
    if (!text) continue;
    out.push(text);
    if (out.length >= cap) break;
  }
  return out;
}

export function asUsername(raw: string): string {
  const t = raw.trim().replace(/^@+/, "");
  const m = t.match(/(?:instagram\.com|tiktok\.com|x\.com|twitter\.com|youtube\.com\/(?:@|c\/|user\/))\/@?([^/?#]+)/i);
  return (m ? m[1] : t).replace(/^@+/, "").trim();
}

export function orderCharge(s: { type?: string; rate?: string }, qty: number): number {
  const rate = Number(s.rate) || 0;
  const type = typeName(s);
  if (type === "package" || type === "custom comments package" || type === "subscriptions") {
    return rate * Math.max(1, qty || 1);
  }
  return (Math.max(0, qty) / 1000) * rate;
}