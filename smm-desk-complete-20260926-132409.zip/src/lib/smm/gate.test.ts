import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { parseAccess, parseAccessHeader, signAccess } from "./gate.server.ts";

describe("access cookie", () => {
  it("round-trips a device id", () => {
    const token = signAccess("a1b2c3d4-e5f6-7890-abcd-ef1234567890", "secret-pw");
    assert.equal(parseAccess(token, "secret-pw"), "a1b2c3d4-e5f6-7890-abcd-ef1234567890");
  });

  it("rejects a forged token", () => {
    const token = signAccess("a1b2c3d4-e5f6-7890-abcd-ef1234567890", "secret-pw");
    assert.equal(parseAccess(token, "other-pw"), null);
    assert.equal(parseAccess(token.slice(0, -1) + "0", "secret-pw"), null);
    assert.equal(parseAccess("not-a-token", "secret-pw"), null);
    assert.equal(parseAccess("", "secret-pw"), null);
  });

  it("does not accept another device id pasted onto a valid mac", () => {
    const token = signAccess("a1b2c3d4-e5f6-7890-abcd-ef1234567890", "secret-pw");
    const mac = token.slice(token.lastIndexOf(".") + 1);
    assert.equal(parseAccess(`zzzzzzzz-e5f6-7890-abcd-ef1234567890.${mac}`, "secret-pw"), null);
  });

  it("reads the cookie from a request header", () => {
    const token = signAccess("a1b2c3d4-e5f6-7890-abcd-ef1234567890", "desk");
    const req = new Request("https://desk.local/api/smm-live", {
      headers: { cookie: `theme=dark; smm-access=${token}; other=1` },
    });
    assert.equal(parseAccessHeader(req, "desk"), "a1b2c3d4-e5f6-7890-abcd-ef1234567890");
    assert.equal(parseAccessHeader(req, "nope"), null);
    assert.equal(parseAccessHeader(new Request("https://desk.local/"), "desk"), null);
  });

  it("accepts a client-set cookie next to other cookies", () => {
    const token = signAccess("device01-aaaa-bbbb-cccc-ddddee000001", "kbgcuba");
    const req = new Request("https://socialclau.grok.me/_serverFn", {
      headers: { cookie: `smm-access=${encodeURIComponent(token)}` },
    });
    assert.equal(parseAccessHeader(req, "kbgcuba"), "device01-aaaa-bbbb-cccc-ddddee000001");
  });
});
