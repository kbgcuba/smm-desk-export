import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { PanelId } from "@/lib/smm/types";
import { unionOrders, unionRefills } from "@/lib/smm/merge";
import { addDays, dayStart, wallInZone, weekday, zonedUtc } from "@/lib/tz";
import { orderFinished, stillRunning } from "@/lib/smm/order-status";

export { orderFinished, stillRunning } from "@/lib/smm/order-status";

export type SavedOrder = {
  panel: PanelId;
  order: string;
  service: number;
  name: string;
  link: string;
  quantity: number;
  refill: boolean;
  at: number;
  desk?: string;
  thumb?: string | null;
  mediaTitle?: string | null;
  refilledAt?: number;
  actual?: number | null;
  actualAt?: number;
  metric?: "views" | "likes" | "comments";
  start?: number;
  remains?: number;
  panelStatus?: string;
  panelRefill?: boolean;
  source?: "post" | "panel" | null;
  startOnPost?: number | null;
  doneOnPost?: number | null;
  /** First time the post count rose above the count at order time. View orders only. */
  viewsAt?: number;
  /** When a view order ended (canceled or failed) without the post count rising. */
  viewsClosedAt?: number;
  runs?: number;
  panelRuns?: number;
};

export type RefillLog = {
  panel: PanelId;
  order: string;
  at: number;
};

type State = {
  orders: SavedOrder[];
  refills: RefillLog[];
  remember: (order: SavedOrder) => void;
  patchMedia: (order: string, panel: PanelId, media: { thumb?: string | null; mediaTitle?: string | null }) => void;
  patchLive: (
    rows: {
      panel: PanelId;
      order: string;
      actual: number | null;
      metric: "views" | "likes" | "comments";
      start?: number;
      remains?: number;
      status?: string;
      refill?: boolean;
      source?: "post" | "panel" | null;
      runs?: number;
    }[],
  ) => void;
  hydrate: (orders: SavedOrder[], refills: RefillLog[]) => void;
  markRefilled: (keys: { panel: PanelId; order: string }[]) => void;
  clear: () => void;
};

export function unionSaved(a: SavedOrder[], b: SavedOrder[]): SavedOrder[] {
  return unionOrders(a, b);
}

function statusRank(status?: string, remains?: number): number {
  const s = (status ?? "").toLowerCase();
  if (/cancel|refund|fail|error|reject/.test(s)) return 5;
  if (stillRunning(s)) return /pending|wait|queue/.test(s) ? 1 : 2;
  if (/complet|success|done|finish/.test(s)) return 4;
  if (/partial/.test(s)) return 3;
  if (remains === 0) return 4;
  return 0;
}

export const useSmmOrders = create<State>()(
  persist(
    (set, get) => ({
      orders: [],
      refills: [],
      remember: (order) => set({ orders: unionSaved(get().orders, [order]) }),
      patchMedia: (order, panel, media) => {
        set({
          orders: get().orders.map((row) =>
            row.order === order && row.panel === panel ? { ...row, ...media } : row,
          ),
        });
      },
      patchLive: (rows) => {
        if (rows.length === 0) return;
        const now = Date.now();
        const map = new Map(rows.map((row) => [`${row.panel}:${row.order}`, row]));
        set({
          orders: get().orders.map((row) => {
            const hit = map.get(`${row.panel}:${row.order}`);
            if (!hit) return row;
            const incomingStatus = (hit.status && hit.status.trim()) || row.panelStatus;
            const incomingRunning = stillRunning(incomingStatus);
            const incomingRemains = incomingRunning && hit.remains == null ? undefined : (hit.remains ?? row.remains);
            const wasDone = orderFinished(row) || row.doneOnPost != null;
            const refillFresh = row.refilledAt != null && now - row.refilledAt < 5 * 60_000;
            const incomingDone = orderFinished({ panelStatus: incomingStatus, remains: incomingRemains });
            const incomingFail = /cancel|refund|fail|error|reject/.test((incomingStatus ?? "").toLowerCase());
            const lockDone = wasDone && !refillFresh && !incomingFail && !incomingRunning;
            const nextStatus = lockDone && statusRank(incomingStatus, incomingRemains) < 4 ? row.panelStatus : incomingStatus;
            const nextRemains =
              lockDone && row.remains === 0 && (incomingRemains == null || incomingRemains > 0)
                ? 0
                : incomingRemains;
            const done = !incomingRunning && (lockDone || incomingDone);
            const fromPost = hit.source === "post" && hit.actual != null;
            const panelStart = hit.start ?? row.start;
            const delivered =
              nextRemains != null ? Math.max(0, row.quantity - nextRemains) : done ? row.quantity : 0;
            let startOnPost = row.startOnPost;
            if (startOnPost == null) {
              if (!done && fromPost) startOnPost = hit.actual;
              else if (panelStart != null) startOnPost = panelStart;
              else if (done && fromPost) startOnPost = Math.max(0, (hit.actual as number) - delivered);
            }
            const startKnown = startOnPost;
            const liveCount = fromPost ? hit.actual : row.actual;
            const metricNow = hit.metric ?? row.metric;
            const viewOrder = metricNow === "views" || (metricNow == null && /view/i.test(row.name));
            let viewsAt = row.viewsAt;
            if (viewOrder && viewsAt == null && startKnown != null && liveCount != null && liveCount > startKnown) {
              viewsAt = now;
            }
            let viewsClosedAt = row.viewsClosedAt;
            if (viewOrder && viewsAt == null && incomingFail && viewsClosedAt == null) viewsClosedAt = now;
            return {
              ...row,
              metric: metricNow,
              start: panelStart,
              remains: nextRemains,
              panelStatus: nextStatus,
              panelRefill: hit.refill ?? row.panelRefill,
              panelRuns: hit.runs ?? row.panelRuns,
              source: fromPost ? "post" : row.source,
              actual: fromPost ? hit.actual : row.actual,
              actualAt: fromPost ? now : row.actualAt,
              startOnPost,
              doneOnPost: incomingRunning
                ? null
                : row.doneOnPost != null
                  ? row.doneOnPost
                  : done && fromPost
                    ? hit.actual
                    : row.doneOnPost,
              viewsAt,
              viewsClosedAt: viewsAt != null ? undefined : viewsClosedAt,
            };
          }),
        });
      },
      hydrate: (orders, refills) => {
        set({
          orders: unionOrders(orders, get().orders),
          refills: unionRefills(refills, get().refills),
        });
      },
      markRefilled: (keys) => {
        if (keys.length === 0) return;
        const hit = new Set(keys.map((row) => `${row.panel}:${row.order}`));
        const now = Date.now();
        const extra: RefillLog[] = keys.map((row) => ({ panel: row.panel, order: row.order, at: now }));
        set({
          orders: get().orders.map((row) =>
            hit.has(`${row.panel}:${row.order}`) ? { ...row, refilledAt: now } : row,
          ),
          refills: [...extra, ...get().refills].slice(0, 2000),
        });
      },
      clear: () => set({ orders: [] }),
    }),
    {
      name: "smm-orders",
      merge: (persisted, current) => {
        const p = (persisted ?? {}) as Partial<State>;
        const persistedOrders = Array.isArray(p.orders) ? p.orders : [];
        const orders = unionSaved(persistedOrders, current.orders);
        const persistedRefills = Array.isArray(p.refills) ? p.refills : [];
        let refills = unionRefills(persistedRefills, current.refills);
        if (refills.length === 0) {
          refills = orders
            .filter((row) => row.refilledAt)
            .map((row) => ({ panel: row.panel, order: row.order, at: row.refilledAt as number }));
        }
        return { ...current, ...p, orders, refills };
      },
    },
  ),
);

export const REFILL_WAIT_MS = 24 * 60 * 60 * 1000;
export const REFILL_COOLDOWN_MS = 2 * 60 * 1000;

export function refillDueAt(order: { at: number; refilledAt?: number }): number {
  return (order.refilledAt ?? order.at) + REFILL_WAIT_MS;
}

export function isRefillDue(order: { at: number; refilledAt?: number }, now = Date.now()): boolean {
  return now >= refillDueAt(order);
}

export function canAutoRefill(order: { refilledAt?: number }, now = Date.now()): boolean {
  if (!order.refilledAt) return true;
  return now - order.refilledAt >= REFILL_COOLDOWN_MS;
}

export function formatRefillWait(ms: number): string {
  if (ms <= 0) return "now";
  const hours = Math.max(1, Math.ceil(ms / (60 * 60 * 1000)));
  if (hours < 24) return `${hours}h`;
  const days = Math.ceil(hours / 24);
  return `${days}d`;
}

export function refillStats(logs: RefillLog[], now = Date.now()) {
  const wall = wallInZone(now);
  const day = dayStart(now);
  const week = addDays(day, -weekday(day));
  const month = zonedUtc(wall.y, wall.m, 1);
  const year = zonedUtc(wall.y, 0, 1);
  let today = 0;
  let thisWeek = 0;
  let thisMonth = 0;
  let thisYear = 0;
  for (const row of logs) {
    if (row.at >= year) {
      thisYear += 1;
      if (row.at >= month) {
        thisMonth += 1;
        if (row.at >= week) {
          thisWeek += 1;
          if (row.at >= day) today += 1;
        }
      }
    }
  }
  return { today, thisWeek, thisMonth, thisYear };
}
