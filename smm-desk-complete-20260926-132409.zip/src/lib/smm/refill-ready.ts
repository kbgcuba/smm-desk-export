export function refillStoresReady(opts: {
  ordersHydrated: boolean;
  desksHydrated: boolean;
  desksSkipHydration: boolean;
}): boolean {
  if (!opts.ordersHydrated) return false;
  if (opts.desksSkipHydration) return true;
  return opts.desksHydrated;
}
