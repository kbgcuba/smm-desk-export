import type { ProfileItem } from "@/lib/smm/profile-types";

export function tiktokOwnVideo(handle: string, url: string, id?: string): boolean {
  const want = handle.replace(/^@/, "").toLowerCase();
  try {
    const path = new URL(url).pathname.toLowerCase();
    const m = path.match(/^\/@([^/]+)\/video\/(\d+)/);
    if (!m) return false;
    if (m[1] !== want) return false;
    if (id && m[2] !== String(id)) return false;
    return true;
  } catch {
    return false;
  }
}

export function tiktokConsecutive(items: ProfileItem[], handle: string): ProfileItem[] {
  const seen = new Set<string>();
  const mine: ProfileItem[] = [];
  for (const item of items) {
    if (!item.id || seen.has(item.id) || !tiktokOwnVideo(handle, item.url, item.id)) continue;
    seen.add(item.id);
    mine.push(item);
  }
  return mine.sort((a, b) => {
    try {
      const ia = BigInt(a.id.replace(/\D/g, "") || "0");
      const ib = BigInt(b.id.replace(/\D/g, "") || "0");
      if (ia === ib) return 0;
      return ia > ib ? -1 : 1;
    } catch {
      return (b.at || 0) - (a.at || 0);
    }
  });
}
