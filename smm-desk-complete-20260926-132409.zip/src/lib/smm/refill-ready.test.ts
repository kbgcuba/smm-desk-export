import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { refillStoresReady } from "./refill-ready.ts";

describe("refillStoresReady", () => {
  it("waits for orders even if desks are seeded", () => {
    assert.equal(
      refillStoresReady({ ordersHydrated: false, desksHydrated: false, desksSkipHydration: true }),
      false,
    );
  });

  it("starts when orders are ready and desks skipped hydration (current desks store)", () => {
    assert.equal(
      refillStoresReady({ ordersHydrated: true, desksHydrated: false, desksSkipHydration: true }),
      true,
    );
  });

  it("still waits on desks when they hydrate normally", () => {
    assert.equal(
      refillStoresReady({ ordersHydrated: true, desksHydrated: false, desksSkipHydration: false }),
      false,
    );
    assert.equal(
      refillStoresReady({ ordersHydrated: true, desksHydrated: true, desksSkipHydration: false }),
      true,
    );
  });
});
