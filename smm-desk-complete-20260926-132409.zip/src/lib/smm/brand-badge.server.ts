import { lookup } from "node:dns/promises";
import {
  linkReady,
  normBrand,
  publicHttpUrl,
  resolveBrand,
  safePath,
  svgDataUri,
  type BrandHit,
} from "./brand-badge.ts";

export type BrandSearch = { ok: true; hit: BrandHit } | { ok: false; error: string };

const SKIP = new Set(["hermes"]);

function ipAllowed(address: string): boolean {
  const host = address.toLowerCase().split("%")[0] ?? "";
  if (!host) return false;
  if (host.includes(":")) {
    if (host === "::1" || host === "::") return false;
    if (/^fe[89ab]/.test(host) || host.startsWith("fc") || host.startsWith("fd")) return false;
    return true;
  }
  return publicHttpUrl(`http://${host}/`) !== null;
}

async function hostAllowed(host: string): Promise<boolean> {
  const name = host.toLowerCase().replace(/\.$/, "");
  if (!publicHttpUrl(`https://${name}/`)) return false;
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(name) || name.includes(":")) return ipAllowed(name);
  try {
    const rows = await lookup(name, { all: true, verbatim: true });
    return rows.length > 0 && rows.every((row) => ipAllowed(row.address));
  } catch {
    return false;
  }
}

async function fetchPublic(
  start: string,
  accept: string,
  maxBytes: number,
): Promise<{ finalUrl: string; buf: Buffer; type: string } | null> {
  let current = publicHttpUrl(start);
  for (let hop = 0; hop < 4 && current; hop++) {
    let host = "";
    try {
      host = new URL(current).hostname;
    } catch {
      return null;
    }
    if (!(await hostAllowed(host))) return null;
    let res: Response;
    try {
      res = await fetch(current, {
        redirect: "manual",
        headers: {
          Accept: accept,
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
        },
        signal: AbortSignal.timeout(8_000),
      });
    } catch {
      return null;
    }
    if (res.status >= 300 && res.status < 400) {
      const loc = res.headers.get("location");
      if (!loc) return null;
      try {
        current = publicHttpUrl(new URL(loc, current).toString());
      } catch {
        return null;
      }
      continue;
    }
    if (!res.ok || !res.body) return null;
    const reader = res.body.getReader();
    const chunks: Buffer[] = [];
    let total = 0;
    while (total < maxBytes) {
      const { done, value } = await reader.read();
      if (done) break;
      const buf = Buffer.from(value);
      const room = maxBytes - total;
      chunks.push(buf.length > room ? buf.subarray(0, room) : buf);
      total += Math.min(buf.length, room);
      if (buf.length > room) {
        await reader.cancel().catch(() => undefined);
        break;
      }
    }
    return { finalUrl: current, buf: Buffer.concat(chunks), type: res.headers.get("content-type") || "" };
  }
  return null;
}

function imageData(buf: Buffer, type: string): string {
  const head = buf.subarray(0, 240).toString("utf8");
  const mime = type.split(";")[0]?.trim().toLowerCase() || "";
  if (mime === "image/svg+xml" || head.includes("<svg")) return svgDataUri(buf.toString("utf8"));
  const kind = mime === "image/png" || mime === "image/jpeg" || mime === "image/webp" ? mime : "";
  if (!kind || buf.length < 32 || buf.length > 60_000) return "";
  return `data:${kind};base64,${buf.toString("base64")}`;
}

async function lookupIcon(name: string): Promise<{ path: string; hex: string } | null> {
  const slug = normBrand(name);
  const trimmed = slug.replace(/(corporation|incorporated|company|llc|ltd|inc)$/g, "");
  const keys = [...new Set([trimmed, slug])].filter((key) => key.length >= 2 && !SKIP.has(key));
  for (const key of keys) {
    const got = await fetchPublic(
      `https://cdn.jsdelivr.net/npm/simple-icons@15.16.0/icons/${key}.svg`,
      "image/svg+xml,*/*",
      80_000,
    );
    if (!got) continue;
    const xml = got.buf.toString("utf8");
    if (/<script|foreignobject|onload|javascript:/i.test(xml)) continue;
    const parts = [...xml.matchAll(/\bd=["']([^"']+)["']/gi)].map((row) => row[1] ?? "");
    const path = safePath(parts.join(" "));
    if (!path) continue;
    return { path, hex: "" };
  }
  return null;
}

async function lookupImage(icons: string[], host: string): Promise<string> {
  const ranked = icons
    .filter((url) => publicHttpUrl(url))
    .sort((a, b) => Number(/apple-touch/i.test(b)) - Number(/apple-touch/i.test(a)))
    .slice(0, 3);
  const bare = host.replace(/^www\./, "");
  ranked.push(`https://www.google.com/s2/favicons?domain=${encodeURIComponent(bare)}&sz=128`);
  for (const url of ranked) {
    const got = await fetchPublic(url, "image/png,image/jpeg,image/webp,image/svg+xml,image/*;q=0.8,*/*;q=0.5", 70_000);
    if (!got) continue;
    const data = imageData(got.buf, got.type);
    if (data) return data;
  }
  return "";
}

export async function findBrandFromUrl(raw: string): Promise<BrandSearch> {
  const safe = linkReady(raw);
  if (!safe) return { ok: false, error: "Enter a public link" };
  const page = await fetchPublic(safe, "text/html,application/xhtml+xml", 180_000);
  if (!page) {
    const hit = await resolveBrand({ pageUrl: safe, html: "", lookupIcon, lookupImage });
    if (hit) return { ok: true, hit };
    return { ok: false, error: "Could not read that page" };
  }
  const hit = await resolveBrand({
    pageUrl: page.finalUrl,
    html: page.buf.toString("utf8"),
    lookupIcon,
    lookupImage,
  });
  if (!hit) return { ok: false, error: "No brand found on that page" };
  return { ok: true, hit };
}
