import { hex6, publicHttpUrl, safePath, safeSvgMarkup } from "@/lib/smm/brand-badge.ts";
import { wpBadgeId } from "@/lib/smm/wp-badges.ts";

export type WpLook = "soft" | "glass" | "outline" | "solid" | "neon" | "pill";
export type WpTone = "ink" | "paper" | "blue" | "gold" | "rose" | "mint";
export type WpSize = "sm" | "md" | "lg";
export type WpLayout = "stack" | "row" | "grid";
export type WpThumb = "off" | "left" | "top";
export type WpBadge = "off" | "corner" | "inline";

export type WpStyle = {
  look: WpLook;
  tone: WpTone;
  size: WpSize;
  layout: WpLayout;
  thumb: WpThumb;
  badge: WpBadge;
};

export type WpChild = {
  id: string;
  title: string;
  url: string;
  image: string;
  badge: string;
};

export type WpItem = {
  id: string;
  title: string;
  url: string;
  image: string;
  badge: string;
  published: boolean;
  children: WpChild[];
  pinned?: boolean;
  /** User picked this badge while editing. Match leaves it alone. */
  badgeManual?: boolean;
};

export type WpSavedBadge = {
  id: string;
  label: string;
  bg: string;
  fg: string;
  img: string;
  path: string;
  listed: boolean;
};

export type WpList = {
  items: WpItem[];
  hookUrl: string;
  secret: string;
  updatedAt: number;
  style: WpStyle;
  badges: WpSavedBadge[];
};

export const WP_LOOKS: { id: WpLook; label: string }[] = [
  { id: "soft", label: "Soft" },
  { id: "glass", label: "Glass" },
  { id: "outline", label: "Line" },
  { id: "solid", label: "Solid" },
  { id: "neon", label: "Neon" },
  { id: "pill", label: "Pill" },
];

export const WP_TONES: { id: WpTone; label: string }[] = [
  { id: "ink", label: "Ink" },
  { id: "paper", label: "Paper" },
  { id: "blue", label: "Blue" },
  { id: "gold", label: "Gold" },
  { id: "rose", label: "Rose" },
  { id: "mint", label: "Mint" },
];

export const WP_SIZES: { id: WpSize; label: string }[] = [
  { id: "sm", label: "Small" },
  { id: "md", label: "Medium" },
  { id: "lg", label: "Large" },
];

export const WP_LAYOUTS: { id: WpLayout; label: string }[] = [
  { id: "stack", label: "Stack" },
  { id: "row", label: "Row" },
  { id: "grid", label: "Grid" },
];

export const WP_THUMBS: { id: WpThumb; label: string }[] = [
  { id: "off", label: "No photo" },
  { id: "left", label: "Photo left" },
  { id: "top", label: "Photo top" },
];

export const WP_BADGES: { id: WpBadge; label: string }[] = [
  { id: "off", label: "No badge" },
  { id: "corner", label: "Corner" },
  { id: "inline", label: "Beside title" },
];

export function defaultWpStyle(): WpStyle {
  return { look: "soft", tone: "blue", size: "md", layout: "stack", thumb: "left", badge: "corner" };
}

export function wireBadgeId(id: string): string {
  const raw = id.trim().toLowerCase();
  if (/^c-[a-z0-9]{2,32}$/.test(raw)) return raw;
  if (/^[a-z0-9]{2,30}$/.test(raw)) return `c-${raw}`;
  return "";
}

/** Copy each used badge as a picture the plugin can draw even when it does not know that name. */
export function transferBadges(
  list: WpList,
  artwork: ReadonlyMap<string, Pick<WpSavedBadge, "label" | "bg" | "fg" | "img" | "path">>,
): { items: WpItem[]; badges: WpSavedBadge[] } {
  const badges: WpSavedBadge[] = [];
  const seen = new Set<string>();
  const saved = new Map((list.badges ?? []).map((row) => [row.id, row]));

  function carry(id: string): string {
    if (!id) return "";
    const wire = wireBadgeId(id);
    const art = artwork.get(id);
    const prev = saved.get(id);
    const img = art?.img || prev?.img || "";
    const path = img ? "" : art?.path || prev?.path || "";
    if (!wire || (!img && !path)) return id;
    if (!seen.has(wire)) {
      seen.add(wire);
      badges.push({
        id: wire,
        label: (art?.label || prev?.label || id).slice(0, 32),
        bg: art?.bg || prev?.bg || "#111111",
        fg: art?.fg || prev?.fg || "#ffffff",
        img,
        path,
        listed: false,
      });
    }
    return wire;
  }

  const items = list.items.map((item) => ({
    ...item,
    badge: carry(item.badge),
    children: (item.children ?? []).map((child) => ({ ...child, badge: carry(child.badge) })),
  }));
  for (const row of list.badges ?? []) carry(row.id);
  return { items, badges: badges.slice(0, 80) };
}

export function emptyWpList(): WpList {
  return { items: [], hookUrl: "", secret: "", updatedAt: 0, style: defaultWpStyle(), badges: [] };
}

export const WP_REST_HOOK = "http://claudiaivory.com/wp-json/smm-desk/v1/list";

function clip(value: unknown, max: number): string {
  return String(value ?? "").trim().slice(0, max);
}

function linkOf(value: unknown): string {
  let url = clip(value, 2000);
  if (url && !/^https?:\/\//i.test(url)) url = `https://${url.replace(/^\/+/, "")}`;
  return /^https?:\/\/\S+\.\S+/i.test(url) ? url : "";
}

function imageOf(value: unknown): string {
  const raw = String(value ?? "").trim();
  if (/^https?:\/\//i.test(raw)) return raw.slice(0, 400);
  if (/^data:image\/(jpeg|png|webp);base64,[a-z0-9+/=\s]+$/i.test(raw) && raw.length <= 120_000) return raw.replace(/\s/g, "");
  return "";
}

function keepBadge(value: unknown, extra?: ReadonlySet<string>): string {
  const id = wpBadgeId(value);
  if (id) return id;
  const raw = String(value ?? "").trim().toLowerCase();
  return extra?.has(raw) ? raw : "";
}

function badgeImg(value: unknown): string {
  const raw = String(value ?? "").trim();
  if (/^https?:\/\//i.test(raw)) {
    const safe = publicHttpUrl(raw);
    return safe ? safe.slice(0, 2000) : "";
  }
  if (/^data:image\/(jpeg|png|webp);base64,[a-z0-9+/=]+$/i.test(raw) && raw.length <= 80_000) return raw;
  const svg = raw.match(/^data:image\/svg\+xml;base64,([a-z0-9+/=]+)$/i);
  if (!svg || raw.length > 80_000) return "";
  try {
    return safeSvgMarkup(atob(svg[1] ?? "")) ? raw : "";
  } catch {
    return "";
  }
}

export function sanitizeBadges(raw: unknown): WpSavedBadge[] {
  if (!Array.isArray(raw)) return [];
  const out: WpSavedBadge[] = [];
  const seen = new Set<string>();
  for (const row of raw) {
    if (!row || typeof row !== "object") continue;
    const d = row as Record<string, unknown>;
    const id = String(d.id ?? "").trim().toLowerCase();
    if (!/^c-[a-z0-9]{2,32}$/.test(id) || seen.has(id)) continue;
    const img = badgeImg(d.img);
    const path = safePath(String(d.path ?? ""));
    if (!img && !path) continue;
    seen.add(id);
    out.push({
      id,
      label: clip(d.label, 32) || id.slice(2),
      bg: hex6(String(d.bg ?? "")) || "#111111",
      fg: hex6(String(d.fg ?? "")) || "#ffffff",
      img,
      path,
      listed: d.listed !== false,
    });
    if (out.length >= 80) break;
  }
  return out;
}

export function mergeSavedBadges(prev: WpSavedBadge[], incoming: WpSavedBadge[]): WpSavedBadge[] {
  const map = new Map<string, WpSavedBadge>();
  for (const row of prev) map.set(row.id, row);
  for (const row of incoming) map.set(row.id, row);
  return [...map.values()].slice(0, 80);
}

function sanitizeChildren(raw: unknown, extra?: ReadonlySet<string>): WpChild[] {
  if (!Array.isArray(raw)) return [];
  const out: WpChild[] = [];
  const seen = new Set<string>();
  for (const row of raw) {
    if (!row || typeof row !== "object") continue;
    const d = row as Record<string, unknown>;
    const title = clip(d.title, 180);
    if (!title) continue;
    let id = clip(d.id, 40).replace(/[^a-zA-Z0-9_-]/g, "");
    if (!id || seen.has(id)) id = `s${out.length + 1}${Math.random().toString(36).slice(2, 8)}`;
    seen.add(id);
    out.push({ id, title, url: linkOf(d.url), image: imageOf(d.image), badge: keepBadge(d.badge, extra) });
    if (out.length >= 40) break;
  }
  return out;
}

export function sanitizeWpItems(raw: unknown, extra?: ReadonlySet<string>): WpItem[] {
  if (!Array.isArray(raw)) return [];
  const out: WpItem[] = [];
  const seen = new Set<string>();
  for (const row of raw) {
    if (!row || typeof row !== "object") continue;
    const d = row as Record<string, unknown>;
    const title = clip(d.title, 180);
    if (!title) continue;
    let id = clip(d.id, 40).replace(/[^a-zA-Z0-9_-]/g, "");
    if (!id || seen.has(id)) id = `i${out.length + 1}${Math.random().toString(36).slice(2, 8)}`;
    const badge = keepBadge(d.badge, extra);
    seen.add(id);
    out.push({
      id,
      title,
      url: linkOf(d.url),
      image: imageOf(d.image),
      badge,
      published: true,
      children: sanitizeChildren(d.children, extra),
      ...(d.pinned === true ? { pinned: true } : {}),
      ...(d.badgeManual === true && badge ? { badgeManual: true } : {}),
    });
    if (out.length >= 200) break;
  }
  return out;
}

/** New link takes the first open slot. Pinned rows keep their index. */
export function insertLink<T extends { pinned?: boolean }>(items: readonly T[], item: T): T[] {
  const n = items.length + 1;
  const open = new Array<boolean>(n).fill(true);
  const out = new Array<T>(n);
  items.forEach((row, i) => {
    if (row.pinned) {
      out[i] = row;
      open[i] = false;
    }
  });
  const loose = [item, ...items.filter((row) => !row.pinned)];
  let k = 0;
  for (let i = 0; i < n; i++) {
    if (open[i]) out[i] = loose[k++];
  }
  return out;
}

/** Nearest slot a drag can use. Pinned indexes are not targets. */
export function unpinnedDrop<T extends { pinned?: boolean }>(items: readonly T[], from: number, to: number): number {
  if (from < 0 || from >= items.length || items[from]?.pinned) return from;
  let dest = Math.max(0, Math.min(items.length - 1, to));
  if (!items[dest]?.pinned) return dest;
  const dir = dest >= from ? 1 : -1;
  let i = dest;
  while (i >= 0 && i < items.length && items[i]?.pinned) i += dir;
  if (i >= 0 && i < items.length && !items[i]?.pinned) return i;
  i = dest;
  while (i >= 0 && i < items.length && items[i]?.pinned) i -= dir;
  if (i >= 0 && i < items.length && !items[i]?.pinned) return i;
  return from;
}

/** Reorder unpinned links only. Pinned rows stay on their index. */
export function moveUnpinned<T extends { pinned?: boolean }>(items: readonly T[], from: number, to: number): T[] | null {
  if (from < 0 || from >= items.length || items[from]?.pinned) return null;
  const dest = unpinnedDrop(items, from, to);
  if (dest === from) return null;
  const order = items.filter((row) => !row.pinned);
  const free = items.flatMap((row, i) => (row.pinned ? [] : [i]));
  const fromSlot = free.indexOf(from);
  const destSlot = free.indexOf(dest);
  if (fromSlot < 0 || destSlot < 0) return null;
  const [moved] = order.splice(fromSlot, 1);
  if (!moved) return null;
  order.splice(destSlot, 0, moved);
  const out: T[] = [];
  let k = 0;
  for (let i = 0; i < items.length; i++) {
    out.push(items[i]?.pinned ? items[i] : order[k++]);
  }
  return out;
}

function oneOf<T extends string>(value: unknown, allowed: readonly T[], fallback: T): T {
  return allowed.includes(value as T) ? (value as T) : fallback;
}

export function parseStyle(raw: unknown): WpStyle {
  const base = defaultWpStyle();
  if (!raw || typeof raw !== "object") return base;
  const d = raw as Record<string, unknown>;
  return {
    look: oneOf(d.look, ["soft", "glass", "outline", "solid", "neon", "pill"] as const, base.look),
    tone: oneOf(d.tone, ["ink", "paper", "blue", "gold", "rose", "mint"] as const, base.tone),
    size: oneOf(d.size, ["sm", "md", "lg"] as const, base.size),
    layout: oneOf(d.layout, ["stack", "row", "grid"] as const, base.layout),
    thumb: oneOf(d.thumb, ["off", "left", "top"] as const, base.thumb),
    badge: oneOf(d.badge, ["off", "corner", "inline"] as const, base.badge),
  };
}

export function parseWpList(raw: unknown): WpList {
  if (!raw || typeof raw !== "object") return emptyWpList();
  const d = raw as Record<string, unknown>;
  const badges = Array.isArray(d.badges) ? sanitizeBadges(d.badges) : [];
  const extra = new Set(badges.map((row) => row.id));
  return {
    items: sanitizeWpItems(d.items, extra),
    hookUrl: clip(d.hookUrl, 400),
    secret: clip(d.secret, 80),
    updatedAt: Number(d.updatedAt) || 0,
    style: parseStyle(d.style),
    badges,
  };
}

/** Public http or https. No local or private hosts. */
export function safeHookUrl(raw: string): string | null {
  let url: URL;
  try {
    url = new URL(raw.trim());
  } catch {
    return null;
  }
  if (url.protocol !== "https:" && url.protocol !== "http:") return null;
  if (url.username || url.password) return null;
  const host = url.hostname.toLowerCase().replace(/^\[|\]$/g, "");
  if (!host || host === "localhost" || host.endsWith(".local") || host.endsWith(".internal")) return null;
  if (host === "0.0.0.0" || host === "::1" || host === "::") return null;
  const v4 = host.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
  if (v4) {
    const n = v4.slice(1).map(Number);
    if (n.some((p) => p > 255)) return null;
    const [a, b] = n;
    if (a === 10 || a === 127 || a === 0 || (a === 169 && b === 254) || (a === 192 && b === 168)) return null;
    if (a === 172 && b >= 16 && b <= 31) return null;
  }
  return url.toString();
}
