import type { PanelId } from "@/lib/smm/types";
import { youtubeId } from "@/lib/smm/preview.server.ts";
import { statusMany, type OrderProgress } from "@/lib/smm/panel.server.ts";
import { mapPool } from "@/lib/smm/panel-queue.ts";

export type OrderLive = {
  panel: PanelId;
  order: string;
  actual: number | null;
  start?: number;
  remains?: number;
  status?: string;
  refill?: boolean;
  metric: "views" | "likes" | "comments";
  source?: "post" | "panel" | null;
  runs?: number;
};

type Query = {
  panel: PanelId;
  order: string;
  link: string;
  name: string;
  quantity: number;
};

const UA =
  "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1";

const publicCache = new Map<string, { at: number; n: number | null }>();
const PUBLIC_TTL = 8_000;

export function metricOf(name: string): "views" | "likes" | "comments" {
  if (/comment\s*likes?/i.test(name)) return "likes";
  if (/(custom|costum)\s+comments?|comment repl(y|ies)/i.test(name)) return "comments";
  if (/\bdislikes?\b/i.test(name) && !/(?<!dis)\blikes?\b/i.test(name)) return "views";
  return /(?<!dis)\blikes?\b/i.test(name) ? "likes" : "views";
}

export function skipsPostCount(name: string): boolean {
  return /comment\s*likes?/i.test(name);
}

function pickNum(raw: string, keys: string[]): number | null {
  for (const key of keys) {
    const re = new RegExp(`"${key}"\\s*:\\s*"?(\\d+)`);
    const m = raw.match(re);
    if (m) {
      const n = Number(m[1]);
      if (Number.isFinite(n)) return n;
    }
  }
  return null;
}

function parseAbbrev(raw: string): number | null {
  const m = raw.replace(/,/g, "").trim().match(/^([\d.]+)\s*([kmb])?$/i);
  if (!m) return null;
  const n = Number(m[1]);
  if (!Number.isFinite(n)) return null;
  const u = (m[2] ?? "").toLowerCase();
  if (u === "k") return Math.round(n * 1_000);
  if (u === "m") return Math.round(n * 1_000_000);
  if (u === "b") return Math.round(n * 1_000_000_000);
  return Math.round(n);
}

function walkLikes(node: unknown, depth = 0): number | null {
  if (depth > 14 || node == null) return null;
  if (typeof node === "number" && Number.isFinite(node) && node >= 0) return null;
  if (typeof node === "object") {
    const o = node as Record<string, unknown>;
    if ("likeCount" in o) {
      const n = Number(String(o.likeCount).replace(/,/g, ""));
      if (Number.isFinite(n) && n >= 0) return n;
    }
    const label = typeof o.label === "string" ? o.label : typeof o.accessibilityText === "string" ? o.accessibilityText : "";
    if (label) {
      const along = label.match(/along with ([\d,.]+[kmb]?) other/i);
      const likes = label.match(/([\d,.]+[kmb]?)\s+likes/i);
      const hit = parseAbbrev((along ?? likes)?.[1] ?? "");
      if (hit != null) return hit;
    }
    const list = Array.isArray(node) ? node : Object.values(o);
    for (const v of list) {
      const n = walkLikes(v, depth + 1);
      if (n != null) return n;
    }
  }
  return null;
}

async function youtubeCount(id: string): Promise<number | null> {
  try {
    const res = await fetch("https://www.youtube.com/youtubei/v1/player?prettyPrint=false", {
      method: "POST",
      headers: { "content-type": "application/json", "user-agent": UA },
      body: JSON.stringify({
        context: { client: { clientName: "WEB", clientVersion: "2.20240101.00.00", hl: "en" } },
        videoId: id,
      }),
      signal: AbortSignal.timeout(4000),
    });
    if (!res.ok) return null;
    const json = (await res.json()) as { videoDetails?: { viewCount?: unknown } };
    const n = Number(json.videoDetails?.viewCount);
    return Number.isFinite(n) ? n : null;
  } catch {
    return null;
  }
}

async function youtubeLikes(id: string): Promise<number | null> {
  try {
    const res = await fetch("https://www.youtube.com/youtubei/v1/next?prettyPrint=false", {
      method: "POST",
      headers: { "content-type": "application/json", "user-agent": UA },
      body: JSON.stringify({
        context: { client: { clientName: "WEB", clientVersion: "2.20240101.00.00", hl: "en" } },
        videoId: id,
      }),
      signal: AbortSignal.timeout(4500),
    });
    if (res.ok) {
      const json: unknown = await res.json();
      const n = walkLikes(json);
      if (n != null) return n;
    }
  } catch {
    /* html fallback */
  }
  try {
    const res = await fetch(`https://www.youtube.com/watch?v=${encodeURIComponent(id)}`, {
      headers: { accept: "text/html", "user-agent": UA },
      signal: AbortSignal.timeout(4500),
    });
    if (!res.ok) return null;
    const html = await res.text();
    const quoted = pickNum(html, ["likeCount"]);
    if (quoted != null) return quoted;
    const along = html.match(/along with ([\d,.]+[kmb]?) other people/i);
    if (along) return parseAbbrev(along[1] ?? "");
    const likes = html.match(/"label":"([\d,.]+[kmb]?) likes"/i);
    if (likes) return parseAbbrev(likes[1] ?? "");
    return null;
  } catch {
    return null;
  }
}

async function pageCount(url: string, metric: "views" | "likes"): Promise<number | null> {
  try {
    const res = await fetch(url, {
      headers: {
        accept: "text/html,application/xhtml+xml",
        "accept-language": "en-US,en;q=0.9",
        "user-agent": UA,
      },
      redirect: "follow",
      signal: AbortSignal.timeout(6000),
    });
    if (!res.ok) return null;
    const html = await res.text();
    const keys =
      metric === "likes"
        ? ["diggCount", "likeCount", "likes", "edge_liked_by"]
        : ["playCount", "play_count", "viewCount", "videoViewCount", "interactionCount"];
    return pickNum(html, keys);
  } catch {
    return null;
  }
}

async function withRetry(fn: () => Promise<number | null>, times: number): Promise<number | null> {
  let last: number | null = null;
  for (let i = 0; i < times; i += 1) {
    last = await fn();
    if (last != null) return last;
    if (i < times - 1) await new Promise((r) => setTimeout(r, 350 * (i + 1)));
  }
  return last;
}

async function publicCount(url: string, metric: "views" | "likes"): Promise<number | null> {
  const href = url.trim();
  if (!/^https?:\/\//i.test(href)) return null;
  const key = `${metric}:${href}`;
  const hit = publicCache.get(key);
  if (hit && hit.n != null && Date.now() - hit.at < PUBLIC_TTL) return hit.n;

  let n: number | null = null;
  const yt = youtubeId(href);
  if (yt) n = metric === "likes" ? await youtubeLikes(yt) : await youtubeCount(yt);
  if (n == null) {
    const tries = /tiktok\.com/i.test(href) ? 3 : 1;
    n = await withRetry(() => pageCount(href, metric), tries);
  }

  if (n != null) publicCache.set(key, { at: Date.now(), n });
  return n;
}

export async function countOnPost(url: string, metric: "views" | "likes"): Promise<number | null> {
  return publicCount(url, metric);
}

function implied(quantity: number, prog?: OrderProgress): number | null {
  if (!prog) return null;
  if (prog.start != null && prog.remains != null) {
    const delivered = Math.max(0, quantity - prog.remains);
    return prog.start + delivered;
  }
  if (prog.start != null) return prog.start;
  return null;
}

export async function loadOrderLive(queries: Query[]): Promise<OrderLive[]> {
  const rows = queries.slice(0, 20);
  const groups = new Map<PanelId, string[]>();
  for (const row of rows) {
    const list = groups.get(row.panel) ?? [];
    list.push(row.order);
    groups.set(row.panel, list);
  }

  const progress = new Map<string, OrderProgress>();
  await Promise.all(
    [...groups.entries()].map(async ([panel, ids]) => {
      const unique = [...new Set(ids)];
      const map = await statusMany(panel, unique);
      for (const [order, hit] of map) progress.set(`${panel}:${order}`, hit);
    }),
  );

  const publics = await mapPool(rows, 4, async (row) => {
    const metric = metricOf(row.name);
    if (skipsPostCount(row.name) || metric === "comments" || !row.link) return null;
    return publicCount(row.link, metric);
  });

  const out: OrderLive[] = [];
  for (let i = 0; i < rows.length; i += 1) {
    const row = rows[i]!;
    const metric = metricOf(row.name);
    const prog = progress.get(`${row.panel}:${row.order}`);
    const fromPost = publics[i] ?? null;
    const fromPanel = implied(row.quantity, prog);
    const actual = fromPost ?? fromPanel;
    const status = prog?.error && !prog.status ? "" : (prog?.status ?? "").trim();
    out.push({
      panel: row.panel,
      order: row.order,
      actual,
      start: prog?.start,
      remains: prog?.remains,
      status: status || undefined,
      refill: prog?.refill,
      metric,
      source: fromPost != null ? "post" : fromPanel != null ? "panel" : null,
      runs: prog?.runs,
    });
  }
  return out;
}
