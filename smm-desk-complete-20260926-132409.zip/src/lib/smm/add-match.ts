export const PLATFORM_RE: Record<string, RegExp> = {
  tiktok: /tiktok|\btik\s*tok\b|\btt\b/i,
  youtube: /youtube|youtu\.be|\byt\b/i,
  instagram: /instagram|\binsta\b|\big\b/i,
  facebook: /facebook|\bfb\b/i,
  twitter: /twitter|\btweets?\b|\bx\.com\b/i,
  telegram: /telegram|\btg\b/i,
  spotify: /spotify/i,
};

export const METRIC_RE: Record<string, RegExp> = {
  story: /\bstor(?:y|ies)\b/i,
  live: /\blive\b/i,
  page: /page\s*likes?/i,
  comments: /\bcomments?\b/i,
  shares: /\bshares?\b|\breposts?\b|\bforwards?\b/i,
  saves: /\bsaves?\b|\bsaved\b|\bbookmarks?\b|\bfavorites?\b/i,
  likes: /\blikes?\b/i,
  reactions: /\breactions?\b|\blove\b|\bhaha\b|\bangry\b|\bcare\b|\bwow\b/i,
  followers: /\bfollow(?:ers?|s)?\b/i,
  subs: /\bsubscribers?\b|\bsubs?\b/i,
  watch: /watch\s*hours?|watch\s*time|\bretention\b/i,
  reach: /\breach\b|\bimpressions?\b/i,
  views: /\bviews?\b|\bplays?\b/i,
};

const PRODUCT_IDS = [
  "page",
  "comments",
  "shares",
  "saves",
  "reactions",
  "likes",
  "followers",
  "subs",
  "watch",
  "reach",
  "views",
] as const;

export function isCommentLikeName(hay: string): boolean {
  return /comments?\s+likes?/i.test(hay) || /comment\s*likes?/i.test(hay);
}

function decodeHay(value: string): string {
  return value.replace(/&(amp|AMP);/g, "&").replace(/&(lt|LT);/g, "<").replace(/&(gt|GT);/g, ">");
}

export function metricOf(hay: string): string | null {
  if (!hay) return null;
  const text = decodeHay(hay);
  if (isCommentLikeName(text)) return "comment-likes";
  if (/page\s*likes?/i.test(text) && !/post\s*likes?/i.test(text)) return "page";
  let best: { id: string; at: number } | null = null;
  for (const id of PRODUCT_IDS) {
    const m = METRIC_RE[id]?.exec(text);
    if (!m || m.index == null) continue;
    if (!best || m.index < best.at) best = { id, at: m.index };
  }
  return best?.id ?? null;
}

export function metricsEqual(platform: string, a: string, b: string): boolean {
  if (a === b) return true;
  if (platform === "facebook" && (b === "reactions" || b === "likes")) {
    return a === "likes" || a === "reactions";
  }
  if (platform === "youtube" && (b === "subs" || b === "followers")) {
    return a === "subs" || a === "followers";
  }
  return false;
}

function cleanHay(value: string): string {
  return decodeHay(value).replace(/\[[^\]]*\]/g, " ").replace(/\s+/g, " ").trim();
}

function nameHay(s: { name?: string; title?: string; type?: string }): string {
  return cleanHay(`${s.name ?? s.title ?? ""}`);
}

function allHay(s: { name?: string; title?: string; category?: string; type?: string }): string {
  return cleanHay(`${s.category ?? ""} ${s.name ?? s.title ?? ""} ${s.type ?? ""}`);
}

export function primaryPlatform(hay: string): string | null {
  const text = hay.replace(/\bfrom\s+(?:tiktok|youtube|instagram|facebook|twitter|x)\b/gi, " ");
  let best: { id: string; at: number } | null = null;
  for (const [id, re] of Object.entries(PLATFORM_RE)) {
    const m = re.exec(text);
    if (!m || m.index == null) continue;
    if (!best || m.index < best.at) best = { id, at: m.index };
  }
  return best?.id ?? null;
}

export function belongsTo(platform: string, hay: string, extra?: RegExp): boolean {
  const target = hay.replace(/\bfrom\s+(?:tiktok|youtube|instagram|facebook|twitter|x)\b/gi, " ");
  const head = (target.split(/[|–—]/)[0] ?? target).slice(0, 72);
  const primary = primaryPlatform(head);
  if (primary) return primary === platform;
  if (extra?.test(head) && !primaryPlatform(head)) return true;
  return false;
}

function headHay(hay: string): string {
  const cut = hay.split(/[|–—]/)[0] ?? hay;
  return cut.slice(0, 80);
}

export function productOf(s: { name?: string; title?: string; category?: string; type?: string }): string | null {
  const name = nameHay(s);
  return metricOf(headHay(name)) ?? metricOf(name);
}

function nameHasMetric(platform: string, metric: string, name: string): boolean {
  if (METRIC_RE[metric]?.test(name)) return true;
  if (platform === "facebook" && (metric === "reactions" || metric === "likes")) {
    return Boolean(METRIC_RE.likes.test(name) || METRIC_RE.reactions.test(name));
  }
  if (platform === "youtube" && (metric === "subs" || metric === "followers")) {
    return Boolean(METRIC_RE.subs.test(name) || METRIC_RE.followers.test(name));
  }
  return false;
}

export type ContentKind = "short" | "reel" | "post" | "video" | "story" | "live" | "any";

export function contentOf(hay: string): ContentKind {
  const text = decodeHay(hay);
  if (/\bshorts?\b/i.test(text)) return "short";
  if (/\breels?\b/i.test(text)) return "reel";
  if (/\bigtv\b/i.test(text)) return "reel";
  if (/\bstor(?:y|ies)\b/i.test(text)) return "story";
  if (/\blive\s*(streams?|chats?|videos?|broadcasts?|rooms?)\b/i.test(text)) return "live";
  if (/\bposts?\b/i.test(text) && !/\breposts?\b/i.test(text)) return "post";
  if (/\b(videos?|watch)\b/i.test(text)) return "video";
  const product = metricOf(headHay(text)) ?? metricOf(text);
  if (product === "views") return "video";
  return "any";
}

export function kindFits(itemKind: string, serviceKind: ContentKind): boolean {
  if (!itemKind || serviceKind === "any") return true;
  if (serviceKind === "story" || serviceKind === "live") return itemKind === serviceKind;
  if (itemKind === "short") return serviceKind === "short";
  if (itemKind === "reel") return serviceKind === "reel" || serviceKind === "video";
  if (itemKind === "post") return serviceKind === "post";
  if (itemKind === "video") return serviceKind === "video";
  return serviceKind === itemKind;
}

export function kindRank(itemKind: string, serviceKind: ContentKind): number {
  if (!itemKind || serviceKind === itemKind) return 0;
  if (itemKind === "reel" && serviceKind === "video") return 1;
  if (serviceKind === "any") return 2;
  return 9;
}

export type ServiceAttr = {
  platform: string | null;
  via: string[];
  metric: string | null;
  kind: ContentKind;
};

function platformsIn(hay: string): { id: string; at: number }[] {
  const hits: { id: string; at: number }[] = [];
  for (const [id, re] of Object.entries(PLATFORM_RE)) {
    const m = re.exec(hay);
    if (m && m.index != null) hits.push({ id, at: m.index });
  }
  return hits.sort((a, b) => a.at - b.at);
}

export function attributeName(hay: string): ServiceAttr {
  const text = decodeHay(hay);
  const stripped = text.replace(/\bfrom\s+(?:tiktok|youtube|instagram|facebook|twitter|x)\b/gi, " ");
  const primary = primaryPlatform(stripped) || primaryPlatform(text);
  const via = platformsIn(text)
    .map((row) => row.id)
    .filter((id, i, all) => id !== primary && all.indexOf(id) === i);
  const name = cleanHay(text);
  const metric = metricOf(headHay(name)) ?? metricOf(name);
  return { platform: primary, via, metric, kind: contentOf(name || text) };
}

export function attributeService(s: { name?: string; title?: string; category?: string; type?: string }): ServiceAttr {
  return attributeName(nameHay(s) || allHay(s));
}

export function attributionScore(kind: string | undefined, attr: ServiceAttr): number {
  let n = kindRank(kind || "", attr.kind);
  if (attr.via.length) n += 3;
  return n;
}

export function matchesAdd(
  platform: string,
  metric: string,
  s: { name?: string; title?: string; category?: string; type?: string },
  deskId?: string,
  extra?: RegExp,
  kind?: string,
): boolean {
  const raw = decodeHay(`${s.name ?? ""} ${s.title ?? ""}`);
  const name = nameHay(s);
  const hay = name || allHay(s);
  const attr = attributeName(hay);
  if (attr.platform && attr.platform !== platform) return false;
  if (attr.via.includes(platform) && attr.platform !== platform) return false;
  if (!belongsTo(platform, hay, extra) && deskId !== platform) return false;
  if (/community\s*posts?/i.test(raw)) return false;
  if (attr.kind === "live" || /\blive\s*(streams?|chats?|videos?|broadcasts?|rooms?)\b/i.test(raw)) return false;
  if (/\blive\b/i.test(raw) && metric !== "comments") return false;
  if (kind && !kindFits(kind, attr.kind)) return false;
  if (attr.metric) return metricsEqual(platform, attr.metric, metric);
  return nameHasMetric(platform, metric, name);
}

export function metricIdFor(platform: string, statKey: string, label: string): string {
  if (platform === "facebook" && (statKey === "likes" || /react/i.test(label))) return "reactions";
  if (statKey === "likes" && /react/i.test(label)) return "reactions";
  if (statKey === "subscribers") return "subs";
  if (statKey === "reposts") return "shares";
  if (statKey === "saved" || statKey === "saves") return "saves";
  if (statKey === "plays") return "views";
  return statKey;
}

export const PILL_METRICS: Record<string, { key: string; label: string }[]> = {
  tiktok: [
    { key: "views", label: "Views" },
    { key: "likes", label: "Likes" },
    { key: "comments", label: "Comments" },
    { key: "shares", label: "Shares" },
    { key: "saves", label: "Saves" },
  ],
  youtube: [
    { key: "views", label: "Views" },
    { key: "likes", label: "Likes" },
    { key: "comments", label: "Comments" },
  ],
  instagram: [
    { key: "views", label: "Views" },
    { key: "likes", label: "Likes" },
    { key: "comments", label: "Comments" },
    { key: "shares", label: "Shares" },
    { key: "saves", label: "Saves" },
  ],
  facebook: [
    { key: "views", label: "Views" },
    { key: "likes", label: "Reactions" },
    { key: "comments", label: "Comments" },
    { key: "shares", label: "Shares" },
  ],
};
