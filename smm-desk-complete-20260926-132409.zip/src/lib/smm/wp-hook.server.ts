import { timingSafeEqual } from "node:crypto";
import { readFile } from "node:fs/promises";
import { safePath } from "@/lib/smm/brand-badge.ts";
import { wpBadge } from "@/lib/smm/wp-badges.ts";
import type { WpList, WpSavedBadge } from "./wp-list.ts";
import { safeHookUrl, transferBadges } from "./wp-list.ts";

export function sameSecret(a: string, b: string): boolean {
  const left = Buffer.from(a);
  const right = Buffer.from(b);
  if (!left.length || left.length !== right.length) return false;
  return timingSafeEqual(left, right);
}

export type HookResult = { ok: boolean; status: number; error: string };

function svgData(markup: string): string {
  const low = markup.toLowerCase();
  if (!low.includes("<svg")) return "";
  for (const bad of ["<script", "foreignobject", "onload", "onerror", "javascript:", "<iframe", "<embed", "<object"]) {
    if (low.includes(bad)) return "";
  }
  const uri = `data:image/svg+xml;base64,${Buffer.from(markup).toString("base64")}`;
  return uri.length <= 80_000 ? uri : "";
}

const brandSvgs = import.meta.glob("../../../public/brands/*.svg", {
  query: "?raw",
  import: "default",
  eager: true,
}) as Record<string, string>;

async function brandFile(img: string): Promise<string> {
  const name = img.startsWith("/brands/") ? img.slice("/brands/".length) : "";
  if (!/^[a-z0-9-]+\.svg$/.test(name)) return "";
  const packed = Object.entries(brandSvgs).find(([key]) => key.endsWith(`/${name}`));
  if (packed?.[1]) return svgData(packed[1]);
  try {
    const text = await readFile(new URL(`../../../public/brands/${name}`, import.meta.url), "utf8");
    return svgData(text);
  } catch {
    return "";
  }
}

function svgClosed(img: string): boolean {
  if (!img.startsWith("data:image/svg+xml;base64,")) return true;
  try {
    const raw = Buffer.from(img.slice(img.indexOf(",") + 1), "base64").toString("utf8");
    return raw.includes("</svg>");
  } catch {
    return false;
  }
}

async function oneBadge(id: string, saved?: WpSavedBadge): Promise<Pick<WpSavedBadge, "label" | "bg" | "fg" | "img" | "path"> | null> {
  if (saved?.img && svgClosed(saved.img)) {
    return { label: saved.label, bg: saved.bg, fg: saved.fg, img: saved.img, path: saved.path };
  }
  if (saved?.path && !saved.img) {
    return { label: saved.label, bg: saved.bg, fg: saved.fg, img: "", path: saved.path };
  }
  const def = wpBadge(id);
  if (!def) return null;
  if (def.img) {
    const img = def.img.startsWith("/") ? await brandFile(def.img) : def.img;
    if (!img) return null;
    return { label: def.label, bg: def.bg, fg: def.fg, img, path: "" };
  }
  const path = safePath(def.path ?? "");
  if (!path) return null;
  const img = svgData(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="${def.fg}" d="${path}"/></svg>`);
  if (!img) return null;
  return { label: def.label, bg: def.bg, fg: def.fg, img, path: "" };
}

export async function badgeArtwork(list: WpList): Promise<Map<string, Pick<WpSavedBadge, "label" | "bg" | "fg" | "img" | "path">>> {
  const ids = new Set<string>();
  for (const item of list.items) {
    if (item.badge) ids.add(item.badge);
    for (const child of item.children ?? []) if (child.badge) ids.add(child.badge);
  }
  for (const row of list.badges ?? []) ids.add(row.id);
  const saved = new Map((list.badges ?? []).map((row) => [row.id, row]));
  const out = new Map<string, Pick<WpSavedBadge, "label" | "bg" | "fg" | "img" | "path">>();
  for (const id of ids) {
    const art = await oneBadge(id, saved.get(id));
    if (art) out.set(id, art);
  }
  return out;
}

export async function pushWpHook(list: WpList): Promise<HookResult> {
  const url = safeHookUrl(list.hookUrl);
  if (!list.hookUrl.trim()) return { ok: false, status: 0, error: "Add the WordPress webhook address" };
  if (!url) return { ok: false, status: 0, error: "Webhook address must be a public link" };
  if (!list.secret.trim()) return { ok: false, status: 0, error: "Add a secret first" };
  const target = new URL(url);
  target.searchParams.set("secret", list.secret);
  const sent = transferBadges(list, await badgeArtwork(list));
  try {
    const res = await fetch(target.toString(), {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        Authorization: `Bearer ${list.secret}`,
        "X-SMM-Secret": list.secret,
      },
      body: JSON.stringify({
        updatedAt: list.updatedAt,
        items: sent.items,
        style: list.style,
        badges: sent.badges,
        secret: list.secret,
      }),
      redirect: "error",
      signal: AbortSignal.timeout(12_000),
    });
    if (!res.ok) {
      const text = (await res.text().catch(() => "")).trim().slice(0, 180);
      return { ok: false, status: res.status, error: hookError(res.status, text) };
    }
    return { ok: true, status: res.status, error: "" };
  } catch (err) {
    return { ok: false, status: 0, error: err instanceof Error ? err.message : "Could not reach WordPress" };
  }
}

function hookError(status: number, text: string): string {
  if (status === 401 || text.includes("smm_desk_denied")) {
    return "WordPress secret does not match. Paste the same Secret into Settings, SMM Desk List, on the site.";
  }
  if (status === 404) return "The list address was not found. Install the plugin on the site.";
  return text || `WordPress returned ${status}`;
}
