export type LinkKind = "tiktok" | "youtube" | "instagram" | "other";

export function looksUrl(value: string): boolean {
  return /^https?:\/\//i.test(value.trim());
}

export function linkKind(url: string): LinkKind {
  const u = url.trim().toLowerCase();
  if (u.includes("tiktok.com") || u.includes("vt.tiktok")) return "tiktok";
  if (u.includes("youtube.com") || u.includes("youtu.be")) return "youtube";
  if (u.includes("instagram.com")) return "instagram";
  return "other";
}

export function deskKind(id: string): LinkKind | "any" {
  const s = id.toLowerCase();
  if (s.includes("youtube")) return "youtube";
  if (s.includes("instagram")) return "instagram";
  if (s.includes("tiktok")) return "tiktok";
  return "any";
}

export function linkMismatch(url: string, deskId: string): boolean {
  if (!looksUrl(url)) return false;
  const want = deskKind(deskId);
  if (want === "any") return false;
  const got = linkKind(url);
  return got !== "other" && got !== want;
}
