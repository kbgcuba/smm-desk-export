import { createServerFn } from "@tanstack/react-start";
import type { PanelId, SmmDesk, SmmService } from "@/lib/smm/types";
import { serviceKey, orderNeeds } from "@/lib/smm/types";
import { decodeEntities } from "@/lib/smm/text";

export type { PanelId, SmmDesk, SmmService };
export { serviceKey, parseMemo, orderNeeds, asUsername, orderCharge, isCommentOrder } from "@/lib/smm/types";

export const PANEL_LABELS: Record<string, string> = {
  smmwiz: "SmmWiz",
  jap: "JustAnotherPanel",
  smmfanz: "SmmFanz",
};

export function panelLabel(id: string): string {
  return PANEL_LABELS[id] ?? id;
}

export function stripPanelPrefix(title: string, panel?: string): string {
  let name = decodeEntities(title).trim();
  const labels = new Set(Object.values(PANEL_LABELS));
  if (panel) labels.add(panelLabel(panel));
  for (const label of labels) {
    const re = new RegExp(`^${label.replace(/[.*+?^${}()|[\\]\\\\]/g, "\\$&")}[-–—:\\s]+`, "i");
    name = name.replace(re, "");
  }
  return name.trim() || title.trim();
}

export function nameWithId(s: { panel?: PanelId; id: number; name?: string; title?: string }): string {
  const name = stripPanelPrefix(s.name || s.title || "", s.panel);
  if (!name) return `(${s.id})`;
  if (new RegExp(`\\(\\s*${s.id}\\s*\\)\\s*$`).test(name)) return name;
  return `${name} (${s.id})`;
}

export function serviceTitle(s: { panel: PanelId; id: number; name: string }): string {
  return nameWithId(s);
}

export function assignTitle(s: { panel: PanelId; id: number; name: string }): string {
  return stripPanelPrefix(s.name, s.panel);
}

export function optionLabel(s: SmmService, title?: string): string {
  const bits = [nameWithId({ ...s, name: title || s.name })];
  const rate = Number(s.rate);
  if (Number.isFinite(rate) && rate > 0) {
    const money = rate >= 0.01 ? `$${rate.toFixed(2)}` : `$${rate.toFixed(4)}`;
    bits.push(`${money}/1k`);
  }
  if (s.averageTime) bits.push(s.averageTime);
  if (s.min > 1) bits.push(`min ${s.min >= 1000 ? `${Math.round(s.min / 1000)}K` : s.min}`);
  return `${bits.join(" · ")} — (${panelLabel(s.panel)})`;
}

export function allowsRefill(s: { refill?: boolean; name?: string; category?: string }): boolean {
  const hay = `${s.name ?? ""} ${s.category ?? ""}`.toLowerCase();
  if (/(?:^|[^a-z])(?:no|non|without)[\s-]*refill|refill\s*:\s*(?:no|false|0|none|off)/.test(hay)) return false;
  return s.refill === true;
}

export function allowsDrip(s: {
  panel: PanelId;
  id: number;
  dripfeed?: boolean;
  name?: string;
  category?: string;
  type?: string;
}): boolean {
  return orderNeeds(s).drip;
}

export const DESK_PANELS: Record<string, readonly PanelId[]> = {
  tiktok: ["smmwiz", "jap"],
  youtube: ["smmfanz"],
};

export const REFILL_PANELS: readonly PanelId[] = ["smmwiz", "jap", "smmfanz"];

export type PanelBalance = {
  id: PanelId;
  label: string;
  balance: string;
  currency: string;
};

export type SmmCatalogPayload = {
  panels: PanelBalance[];
  services: SmmService[];
};

export type RefillOrderInput = {
  panel: PanelId;
  order: string;
  refill: boolean;
  service: number;
  name: string;
  link: string;
};

export type RefillItem = {
  panel: PanelId;
  label: string;
  order: string;
  service: number;
  name: string;
  link: string;
  status: string;
  ready: boolean;
  dueAt?: number;
};

export type RefillAccount = {
  id: PanelId;
  label: string;
  ready: number;
};

export type RefillPayload = {
  accounts: RefillAccount[];
  items: RefillItem[];
};

function asDesk(v: unknown): SmmDesk {
  return v === "youtube" ? "youtube" : "tiktok";
}

function asPanel(v: unknown): PanelId | null {
  if (typeof v !== "string") return null;
  const id = v.trim().toLowerCase();
  if (!/^[a-z0-9][a-z0-9-]{0,31}$/.test(id)) return null;
  return id;
}

function parsePicks(input: unknown): { panel: PanelId; id: number }[] {
  const raw = (input as { picks?: unknown } | null)?.picks;
  if (!Array.isArray(raw)) return [];
  const out: { panel: PanelId; id: number }[] = [];
  const seen = new Set<string>();
  for (const row of raw.slice(0, 40)) {
    const d = row as { panel?: unknown; id?: unknown };
    const panel = asPanel(d.panel);
    const id = Number(d.id);
    if (!panel || !Number.isFinite(id) || id < 1) continue;
    const key = `${panel}:${id}`;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push({ panel, id: Math.floor(id) });
  }
  return out;
}

export const loadSmmCatalog = createServerFn({ method: "POST" })
  .validator((input: unknown) => ({ picks: parsePicks(input) }))
  .handler(async ({ data }): Promise<SmmCatalogPayload> => {
    const { requireAccess } = await import("./gate.server.ts");
    await requireAccess();
    const { loadPicks } = await import("./panel.server.ts");
    return loadPicks(data.picks);
  });

export const loadSmmAllServices = createServerFn({ method: "POST" }).handler(async (): Promise<SmmCatalogPayload> => {
  const { requireAccess } = await import("./gate.server.ts");
  await requireAccess();
  const { loadAllCatalogs } = await import("./panel.server.ts");
  return loadAllCatalogs();
});

export const lookupSmmService = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const d = (input ?? {}) as { panel?: unknown; id?: unknown };
    const panel = asPanel(d.panel);
    const id = Number(d.id);
    if (!panel) throw new Error("Pick a panel");
    if (!Number.isFinite(id) || id < 1) throw new Error("Enter a service number");
    return { panel, id: Math.floor(id) };
  })
  .handler(async ({ data }): Promise<SmmService> => {
    const { requireAccess } = await import("./gate.server.ts");
    await requireAccess();
    const { lookupService } = await import("./panel.server.ts");
    return lookupService(data.panel, data.id);
  });

export const loadSmmBalances = createServerFn({ method: "POST" })
  .validator((input: unknown) => ({ desk: asDesk((input as { desk?: unknown } | null)?.desk) }))
  .handler(async ({ data }): Promise<PanelBalance[]> => {
    const { requireAccess } = await import("./gate.server.ts");
    await requireAccess();
    const { loadBalances } = await import("./panel.server.ts");
    return loadBalances(data.desk);
  });

export const loadSmmLive = createServerFn({ method: "POST" }).handler(async (): Promise<PanelBalance[]> => {
  const { requireAccess } = await import("./gate.server.ts");
  await requireAccess();
  const { loadAllBalances } = await import("./panel.server.ts");
  return loadAllBalances();
});

export type LinkPreview = { thumb: string | null; title: string | null };

export const loadLinkPreview = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const url = String((input as { url?: unknown } | null)?.url ?? "").trim();
    if (!/^https?:\/\//i.test(url)) throw new Error("Need a link");
    return { url };
  })
  .handler(async ({ data }): Promise<LinkPreview> => {
    const { requireAccess } = await import("./gate.server.ts");
    await requireAccess();
    const { loadLinkPreview: load } = await import("./preview.server.ts");
    return load(data.url);
  });

export type { LookedProfile, ProfileStat, ProfileFeed, ProfileItem } from "@/lib/smm/profile-types";

export const lookupSmmProfile = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const d = (input ?? {}) as { url?: unknown; live?: unknown };
    const url = String(d.url ?? "").trim();
    if (!url) throw new Error("Need a profile link");
    return { url, live: d.live === true };
  })
  .handler(async ({ data }) => {
    const { requireAccess } = await import("./gate.server.ts");
    await requireAccess();
    const { lookupProfile } = await import("./profile.server.ts");
    return lookupProfile(data.url, data.live);
  });

export const loadSmmProfileFeed = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const d = (input ?? {}) as { url?: unknown; cursor?: unknown; live?: unknown; drain?: unknown };
    const url = String(d.url ?? "").trim();
    if (!url) throw new Error("Need a profile link");
    const cursor = typeof d.cursor === "string" && d.cursor.trim() ? d.cursor.trim() : null;
    return { url, cursor, live: d.live === true, drain: d.drain === true };
  })
  .handler(async ({ data }) => {
    const { requireAccess } = await import("./gate.server.ts");
    await requireAccess();
    const { loadProfileFeed } = await import("./profile.server.ts");
    return loadProfileFeed(data.url, data.cursor, data.live, data.drain);
  });

export const enrichSmmInstagram = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const d = (input ?? {}) as { ids?: unknown };
    const ids = Array.isArray(d.ids) ? d.ids.map((id) => String(id || "").trim()).filter(Boolean) : [];
    return { ids: ids.slice(0, 200) };
  })
  .handler(async ({ data }) => {
    const { requireAccess } = await import("./gate.server.ts");
    await requireAccess();
    const { enrichInstagramByIds } = await import("./social-api.server.ts");
    return enrichInstagramByIds(data.ids);
  });

export type SocialPublic = {
  id: "youtube" | "instagram" | "facebook" | "tiktok";
  label: string;
  hint: string;
  extra: string;
  ready: boolean;
  until: number | null;
  status: "off" | "live" | "soon" | "dead";
  note: string;
};

function asSocial(raw: unknown): SocialPublic["id"] | null {
  const id = String(raw ?? "");
  return id === "youtube" || id === "instagram" || id === "facebook" || id === "tiktok" ? id : null;
}

export const loadSocialKeys = createServerFn({ method: "GET" }).handler(async (): Promise<SocialPublic[]> => {
  const { requireAccess } = await import("./gate.server.ts");
  await requireAccess();
  const { listSocialPublic } = await import("./social.server.ts");
  return listSocialPublic();
});

export type ApiWatch = {
  id: string;
  label: string;
  status: SocialPublic["status"];
  note: string;
};

export const loadApiWatch = createServerFn({ method: "GET" }).handler(async (): Promise<ApiWatch[]> => {
  const { requireAccess } = await import("./gate.server.ts");
  await requireAccess();
  const { listSocialPublic } = await import("./social.server.ts");
  const social = await listSocialPublic();
  const out: ApiWatch[] = social.map((row) => ({
    id: row.id,
    label: row.id === "youtube" ? "YouTube" : row.id === "instagram" ? "Instagram" : row.id === "facebook" ? "Facebook" : "TikTok",
    status: row.status,
    note: row.note,
  }));
  try {
    const { listAccounts } = await import("./accounts.server.ts");
    const { fetchBalances } = await import("./panel.server.ts");
    const accounts = await listAccounts();
    const bals = await fetchBalances(accounts.map((a) => a.id as import("./types").PanelId));
    for (const row of bals) {
      const dead = row.balance === "—" || row.balance === "";
      out.push({
        id: row.id,
        label: row.label,
        status: dead ? "dead" : "live",
        note: dead ? `${row.label} API key failed. Balance did not load.` : `Live · $${row.balance}`,
      });
    }
  } catch {
    /* panels optional */
  }
  return out;
});

export const trySocialKey = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const d = (input ?? {}) as { id?: unknown; token?: unknown; extra?: unknown };
    const id = asSocial(d.id);
    if (!id) throw new Error("Unknown platform");
    return { id, token: String(d.token ?? "").trim(), extra: String(d.extra ?? "").trim() };
  })
  .handler(async ({ data }) => {
    const { requireAccess } = await import("./gate.server.ts");
    await requireAccess();
    const { trySocialToken } = await import("./social-api.server.ts");
    return trySocialToken(data.id, data.token, data.extra);
  });

export const saveSocialKey = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const d = (input ?? {}) as { id?: unknown; token?: unknown; extra?: unknown };
    const id = asSocial(d.id);
    if (!id) throw new Error("Unknown platform");
    return { id, token: String(d.token ?? "").trim(), extra: String(d.extra ?? "").trim() };
  })
  .handler(async ({ data }) => {
    const { requireAccess } = await import("./gate.server.ts");
    await requireAccess();
    const { trySocialToken } = await import("./social-api.server.ts");
    await trySocialToken(data.id, data.token, data.extra);
    const { saveSocialKey: save } = await import("./social.server.ts");
    return save(data.id, data.token, data.extra);
  });

export const removeSocialKey = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const id = asSocial((input as { id?: unknown } | null)?.id);
    if (!id) throw new Error("Unknown platform");
    return { id };
  })
  .handler(async ({ data }) => {
    const { requireAccess } = await import("./gate.server.ts");
    await requireAccess();
    const { removeSocialKey: remove } = await import("./social.server.ts");
    await remove(data.id);
    return { ok: true as const };
  });

export const unlockSmmAdmin = createServerFn({ method: "POST" })
  .validator((input: unknown) => ({
    password: String((input as { password?: unknown } | null)?.password ?? ""),
  }))
  .handler(async ({ data }): Promise<{ ok: true }> => {
    const { unlockAdmin } = await import("./admin.server.ts");
    if (!unlockAdmin(data.password)) throw new Error("Wrong password");
    return { ok: true };
  });

export const loadSmmGate = createServerFn({ method: "POST" })
  .validator((input: unknown) => ({
    deviceId: String((input as { deviceId?: unknown } | null)?.deviceId ?? ""),
  }))
  .handler(async ({ data }) => {
    const { accessGateStatus } = await import("./cloud.server.ts");
    return accessGateStatus(data.deviceId);
  });

export const unlockSmmGate = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const d = (input ?? {}) as { password?: unknown; deviceId?: unknown; name?: unknown };
    return {
      password: String(d.password ?? ""),
      deviceId: String(d.deviceId ?? ""),
      name: String(d.name ?? "Device"),
    };
  })
  .handler(async ({ data }) => {
    const { unlockAccessGate } = await import("./cloud.server.ts");
    return unlockAccessGate(data.password, { id: data.deviceId, name: data.name });
  });

export const saveSmmGate = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const d = (input ?? {}) as { admin?: unknown; password?: unknown; deviceId?: unknown; name?: unknown };
    return {
      admin: String(d.admin ?? ""),
      password: String(d.password ?? ""),
      deviceId: String(d.deviceId ?? ""),
      name: String(d.name ?? ""),
    };
  })
  .handler(async ({ data }) => {
    const { requireAccess } = await import("./gate.server.ts");
    await requireAccess();
    const { saveAccessGate } = await import("./cloud.server.ts");
    return saveAccessGate(data.admin, data.password, data.deviceId ? { id: data.deviceId, name: data.name } : undefined);
  });

export const revokeSmmDevice = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const d = (input ?? {}) as { admin?: unknown; deviceId?: unknown };
    return { admin: String(d.admin ?? ""), deviceId: String(d.deviceId ?? "") };
  })
  .handler(async ({ data }) => {
    const { requireAccess } = await import("./gate.server.ts");
    await requireAccess();
    const { revokeAccessDevice } = await import("./cloud.server.ts");
    return revokeAccessDevice(data.admin, data.deviceId);
  });

export const placeSmmOrder = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const d = (input ?? {}) as {
      panel?: string;
      service?: number;
      link?: string;
      quantity?: number;
      runs?: number;
      interval?: number;
      extras?: Record<string, string>;
    };
    const panel = asPanel(d.panel);
    if (!panel) throw new Error("Unknown panel");
    const service = Number(d.service);
    const quantity = Number(d.quantity);
    const link = typeof d.link === "string" ? d.link : "";
    if (!Number.isFinite(service) || !Number.isFinite(quantity)) throw new Error("Invalid order");
    const extras: Record<string, string> = {};
    const raw = d.extras && typeof d.extras === "object" ? d.extras : {};
    const allow = new Set([
      "comments",
      "usernames",
      "username",
      "hashtag",
      "media",
      "answer_number",
      "groups",
      "keywords",
      "min",
      "max",
      "posts",
      "delay",
      "expiry",
    ]);
    for (const [k, v] of Object.entries(raw)) {
      if (!allow.has(k) || typeof v !== "string") continue;
      extras[k] = v.slice(0, 20_000);
    }
    return {
      panel,
      service,
      link,
      quantity,
      runs: typeof d.runs === "number" ? d.runs : undefined,
      interval: typeof d.interval === "number" ? d.interval : undefined,
      extras,
    };
  })
  .handler(async ({ data }): Promise<{ order: string; panels: PanelBalance[]; startOnPost: number | null; metric: "views" | "likes" | "comments" }> => {
    const { requireAccess } = await import("./gate.server.ts");
    await requireAccess();
    const { addOrder } = await import("./panel.server.ts");
    return addOrder(data);
  });

function parseRefillOrders(input: unknown): RefillOrderInput[] {
  const raw = (input as { orders?: unknown } | null)?.orders;
  if (!Array.isArray(raw)) return [];
  const out: RefillOrderInput[] = [];
  for (const row of raw.slice(0, 300)) {
    const d = row as Partial<RefillOrderInput>;
    const panel = asPanel(d.panel);
    const order = typeof d.order === "string" ? d.order.trim() : "";
    if (!panel || !order) continue;
    out.push({
      panel,
      order,
      refill: Boolean(d.refill),
      service: Number(d.service) || 0,
      name: typeof d.name === "string" ? d.name : "",
      link: typeof d.link === "string" ? d.link : "",
    });
  }
  return out;
}

export const loadSmmRefills = createServerFn({ method: "POST" })
  .validator((input: unknown) => ({ orders: parseRefillOrders(input) }))
  .handler(async ({ data }): Promise<RefillPayload> => {
    const { requireAccess } = await import("./gate.server.ts");
    await requireAccess();
    const { loadRefills } = await import("./panel.server.ts");
    return loadRefills(data.orders);
  });

export const runSmmRefills = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const orders = parseRefillOrders(input).map((row) => ({ panel: row.panel, order: row.order }));
    if (orders.length === 0) throw new Error("No refills ready");
    return { orders };
  })
  .handler(async ({ data }): Promise<{ ok: number; fail: { order: string; error: string }[] }> => {
    const { requireAccess } = await import("./gate.server.ts");
    await requireAccess();
    const { runRefills } = await import("./panel.server.ts");
    return runRefills(data.orders);
  });

export const cancelSmmOrder = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const orders = parseRefillOrders(input).map((row) => ({ panel: row.panel, order: row.order }));
    if (orders.length === 0) throw new Error("Nothing to cancel");
    return { orders };
  })
  .handler(async ({ data }): Promise<{ ok: number; fail: { order: string; error: string }[] }> => {
    const { requireAccess } = await import("./gate.server.ts");
    await requireAccess();
    const { cancelOrders } = await import("./panel.server.ts");
    return cancelOrders(data.orders);
  });

export type OrderLive = {
  panel: PanelId;
  order: string;
  actual: number | null;
  start?: number;
  remains?: number;
  status?: string;
  refill?: boolean;
  metric: "views" | "likes" | "comments";
  source?: "post" | "panel" | null;
  runs?: number;
};

export const loadOrderLive = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const raw = (input as { orders?: unknown } | null)?.orders;
    if (!Array.isArray(raw)) return { orders: [] as { panel: PanelId; order: string; link: string; name: string; quantity: number }[] };
    const orders: { panel: PanelId; order: string; link: string; name: string; quantity: number }[] = [];
    for (const row of raw.slice(0, 20)) {
      const d = row as Partial<{ panel: PanelId; order: string; link: string; name: string; quantity: number }>;
      const panel = asPanel(d.panel);
      const order = typeof d.order === "string" ? d.order.trim() : "";
      if (!panel || !order) continue;
      orders.push({
        panel,
        order,
        link: typeof d.link === "string" ? d.link : "",
        name: typeof d.name === "string" ? d.name : "",
        quantity: Number(d.quantity) || 0,
      });
    }
    return { orders };
  })
  .handler(async ({ data }): Promise<OrderLive[]> => {
    const { requireAccess } = await import("./gate.server.ts");
    await requireAccess();
    const { loadOrderLive: load } = await import("./stats.server.ts");
    return load(data.orders);
  });

export type CloudDump = {
  orders: unknown[];
  refills: unknown[];
  desks: unknown[];
  desksAt?: number;
  gone?: Record<string, number>;
  prefs: {
    lastService: Record<string, string>;
    lastQty: Record<string, number>;
    recentLinks: string[];
    autoRefill: boolean;
    lastAccount?: string;
    lastAccountAt?: number;
  };
  panels: unknown[];
  profiles?: unknown[];
  profilesAt?: number;
  savedAt: number;
};

export const loadWpList = createServerFn({ method: "GET" }).handler(async () => {
  const { requireAccess } = await import("./gate.server.ts");
  await requireAccess();
  const { readWpList } = await import("./cloud.server.ts");
  return readWpList();
});

export const saveWpList = createServerFn({ method: "POST" })
  .validator((input: unknown) => input as import("./wp-list.ts").WpList)
  .handler(async ({ data }) => {
    const { requireAccess } = await import("./gate.server.ts");
    await requireAccess();
    const { saveWpList: save } = await import("./cloud.server.ts");
    return save(data);
  });

export const findBrandBadge = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const url = input && typeof input === "object" && "url" in input ? String((input as { url: unknown }).url ?? "") : "";
    return { url: url.slice(0, 2000) };
  })
  .handler(async ({ data }) => {
    const { requireAccess } = await import("./gate.server.ts");
    await requireAccess();
    const { findBrandFromUrl } = await import("./brand-badge.server.ts");
    return findBrandFromUrl(data.url);
  });

export const pullSmmCloud = createServerFn({ method: "POST" }).handler(async () => {
  const { requireAccess } = await import("./gate.server.ts");
  await requireAccess();
  const { pullCloud } = await import("./cloud.server.ts");
  return pullCloud();
});

export const pushSmmCloud = createServerFn({ method: "POST" })
  .validator((input: unknown) => input as CloudDump)
  .handler(async ({ data }) => {
    const { requireAccess } = await import("./gate.server.ts");
    await requireAccess();
    const { pushCloud } = await import("./cloud.server.ts");
    return pushCloud(data as Parameters<typeof pushCloud>[0]);
  });

export const loadSmmOrderIndex = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const d = (input ?? {}) as { start?: unknown; end?: unknown; desk?: unknown };
    const start = Number(d.start);
    const end = Number(d.end);
    if (!Number.isFinite(start) || !Number.isFinite(end)) throw new Error("Need a date range");
    const desk = typeof d.desk === "string" ? d.desk : "";
    return { start, end, desk };
  })
  .handler(async ({ data }) => {
    const { requireAccess } = await import("./gate.server.ts");
    await requireAccess();
    const { loadOrderIndex } = await import("./cloud.server.ts");
    return loadOrderIndex(data.start, data.end, data.desk);
  });

export const loadSmmOrdersRange = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const d = (input ?? {}) as { start?: unknown; end?: unknown; desk?: unknown };
    const start = Number(d.start);
    const end = Number(d.end);
    if (!Number.isFinite(start) || !Number.isFinite(end)) throw new Error("Need a date range");
    const desk = typeof d.desk === "string" ? d.desk : "";
    return { start, end, desk };
  })
  .handler(async ({ data }) => {
    const { requireAccess } = await import("./gate.server.ts");
    await requireAccess();
    const { loadOrdersRange } = await import("./cloud.server.ts");
    return loadOrdersRange(data.start, data.end, data.desk);
  });

export type PanelPublic = {
  id: string;
  label: string;
  url: string;
  hint: string;
  locked: boolean;
};

export const loadSmmAccounts = createServerFn({ method: "GET" }).handler(async (): Promise<PanelPublic[]> => {
  const { requireAccess } = await import("./gate.server.ts");
  await requireAccess();
  const { listPublicAccounts } = await import("./accounts.server.ts");
  return listPublicAccounts();
});

export const addSmmAccount = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const d = (input ?? {}) as { label?: unknown; url?: unknown; key?: unknown };
    return {
      label: String(d.label ?? "").trim(),
      url: String(d.url ?? "").trim(),
      key: String(d.key ?? "").trim(),
    };
  })
  .handler(async ({ data }): Promise<PanelPublic> => {
    const { requireAccess } = await import("./gate.server.ts");
    await requireAccess();
    const { addAccount } = await import("./accounts.server.ts");
    return addAccount(data);
  });

export const updateSmmAccountKey = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const d = (input ?? {}) as { id?: unknown; key?: unknown };
    const id = asPanel(d.id);
    const key = String(d.key ?? "").trim();
    if (!id) throw new Error("Unknown panel");
    return { id, key };
  })
  .handler(async ({ data }): Promise<PanelPublic> => {
    const { requireAccess } = await import("./gate.server.ts");
    await requireAccess();
    const { updateAccountKey } = await import("./accounts.server.ts");
    return updateAccountKey(data.id, data.key);
  });

export const removeSmmAccount = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const id = asPanel((input as { id?: unknown } | null)?.id);
    if (!id) throw new Error("Unknown panel");
    return { id };
  })
  .handler(async ({ data }): Promise<{ ok: true }> => {
    const { requireAccess } = await import("./gate.server.ts");
    await requireAccess();
    const { removeAccount } = await import("./accounts.server.ts");
    await removeAccount(data.id);
    return { ok: true };
  });
