import { parseCatalogSnap, type CatalogSnap } from "@/lib/smm/catalog-snap";

const DB = "smm-desk";
const STORE = "kv";
const KEY = "catalog-v1";

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE);
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export async function readCatalogSnap(): Promise<CatalogSnap | null> {
  if (typeof indexedDB === "undefined") return null;
  try {
    const db = await openDb();
    const raw = await new Promise<unknown>((resolve, reject) => {
      const tx = db.transaction(STORE, "readonly");
      const req = tx.objectStore(STORE).get(KEY);
      req.onsuccess = () => resolve(req.result ?? null);
      req.onerror = () => reject(req.error);
    });
    db.close();
    return parseCatalogSnap(raw);
  } catch {
    return null;
  }
}

export async function writeCatalogSnap(snap: CatalogSnap): Promise<void> {
  if (typeof indexedDB === "undefined") return;
  try {
    const db = await openDb();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE, "readwrite");
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
      tx.objectStore(STORE).put(snap, KEY);
    });
    db.close();
  } catch {
    /* quota / private mode */
  }
}
