/** One lane per panel: mutations on SmmWiz never block JAP, but two SmmWiz adds stay in order. */
export function createPanelQueue() {
  const lanes = new Map<string, Promise<unknown>>();

  function enqueue<T>(id: string, fn: () => Promise<T>): Promise<T> {
    const run = (lanes.get(id) ?? Promise.resolve()).then(fn, fn);
    lanes.set(
      id,
      run.then(
        () => undefined,
        () => undefined,
      ),
    );
    return run;
  }

  return { enqueue };
}

export async function mapPool<T, R>(items: readonly T[], limit: number, fn: (item: T, i: number) => Promise<R>): Promise<R[]> {
  const out: R[] = new Array(items.length);
  let next = 0;
  const workers = Array.from({ length: Math.max(1, Math.min(limit, items.length) || 1) }, async () => {
    while (next < items.length) {
      const i = next;
      next += 1;
      out[i] = await fn(items[i]!, i);
    }
  });
  if (items.length) await Promise.all(workers);
  return out;
}
