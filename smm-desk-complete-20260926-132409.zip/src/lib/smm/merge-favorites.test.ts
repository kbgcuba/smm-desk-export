import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { desksEqual, mergeFavorites } from "./merge.ts";

function desk(services: { panel: "smmwiz"; id: number; title: string; at?: number }[], id = "tiktok") {
  return { id, label: "TikTok", locked: false, services };
}

describe("mergeFavorites gone", () => {
  it("does not resurrect a service another device deleted", () => {
    const views = { panel: "smmwiz" as const, id: 1, title: "Views", at: 1 };
    const likes = { panel: "smmwiz" as const, id: 2, title: "Likes", at: 1 };
    const fav = mergeFavorites(
      { desks: [desk([views])], gone: { "smmwiz:2": 50 } },
      { desks: [desk([views, likes])], gone: {} },
    );
    assert.deepEqual(
      fav.desks[0]?.services.map((s) => s.id),
      [1],
    );
    assert.equal(fav.gone["smmwiz:2"], 50);
  });

  it("keeps a service re-added after it was gone", () => {
    const likes = { panel: "smmwiz" as const, id: 2, title: "Likes", at: 100 };
    const fav = mergeFavorites(
      { desks: [desk([likes])], gone: {} },
      { desks: [desk([])], gone: { "smmwiz:2": 50 } },
    );
    assert.equal(fav.desks[0]?.services.length, 1);
    assert.equal(fav.desks[0]?.services[0]?.id, 2);
  });
});

describe("desksEqual", () => {
  it("treats a live name change as different", () => {
    const a = desk([{ panel: "smmwiz", id: 1, title: "Old" }]);
    const b = desk([{ panel: "smmwiz", id: 1, title: "New from panel" }]);
    assert.equal(desksEqual([a], [b]), false);
    assert.equal(desksEqual([a], [a]), true);
  });
});

describe("favorite chip order", () => {
  it("keeps the newer device's tab order", () => {
    const tt = desk([{ panel: "smmwiz", id: 1, title: "Views" }], "tiktok");
    const yt = { id: "youtube", label: "YouTube", locked: true, services: [{ panel: "smmfanz" as const, id: 12492, title: "YT" }] };
    const ig = { id: "instagram", label: "Instagram", locked: false, services: [{ panel: "jap" as const, id: 9, title: "IG" }] };
    const fav = mergeFavorites(
      { desks: [ig, tt, yt], gone: {} },
      { desks: [tt, yt, ig], gone: {} },
    );
    assert.deepEqual(
      fav.desks.map((d) => d.id),
      ["instagram", "tiktok", "youtube"],
    );
  });
});
