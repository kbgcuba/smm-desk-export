import { mkdir, readFile, writeFile } from "node:fs/promises";
import { readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { env } from "@/lib/env.server.ts";

export type SocialId = "youtube" | "instagram" | "facebook" | "tiktok";

export type SocialKey = {
  id: SocialId;
  token: string;
  extra: string;
};

export type SocialPublic = {
  id: SocialId;
  label: string;
  hint: string;
  extra: string;
  ready: boolean;
  until: number | null;
  status: "off" | "live" | "soon" | "dead";
  note: string;
};

const LABELS: Record<SocialId, string> = {
  youtube: "YouTube Data API key",
  instagram: "Instagram Graph token",
  facebook: "Facebook Page token",
  tiktok: "TikTok access token",
};

const ENV_TOKEN: Record<SocialId, string> = {
  youtube: "YOUTUBE_API_KEY",
  instagram: "INSTAGRAM_ACCESS_TOKEN",
  facebook: "FACEBOOK_ACCESS_TOKEN",
  tiktok: "TIKTOK_ACCESS_TOKEN",
};

const ENV_EXTRA: Record<SocialId, string> = {
  youtube: "YOUTUBE_CHANNEL_ID",
  instagram: "INSTAGRAM_USER_ID",
  facebook: "FACEBOOK_PAGE_ID",
  tiktok: "TIKTOK_OPEN_ID",
};

const FILE = path.join(process.cwd(), "data", "smm-social.json");
const HERE = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../../../data/smm-social.json");
const FILES = [HERE, FILE, "/workspace/data/smm-social.json"];
const SEED: SocialKey[] = [
  { id: "youtube", token: "AIzaSyC0I5iFuMx-6zpaOdcd19LHULxn15zbmNQ", extra: "" },
  {
    id: "instagram",
    token:
      "EAAImDX1pZBdQBSvqNjvjDZCkoMGZBpeeJERNtpN72uo7vZAZCDZBUe0gotjqFbfoK1bgM6AQz13vx4XFZBabTbdaRfVmHe4IgF3jK9IixFtx5FwkznHsmZALpfN6lKexm3s8ZAZAiK2IiO0N7AjzeBQCbC9BLffbsqc1T3CjsL3einR6zRexFwggdfeNOsf4P7cZBbK98RS3vaozyHBAqdlERYZD",
    extra: "17841428425483244",
  },
  {
    id: "facebook",
    token:
      "EAAImDX1pZBdQBSvqNjvjDZCkoMGZBpeeJERNtpN72uo7vZAZCDZBUe0gotjqFbfoK1bgM6AQz13vx4XFZBabTbdaRfVmHe4IgF3jK9IixFtx5FwkznHsmZALpfN6lKexm3s8ZAZAiK2IiO0N7AjzeBQCbC9BLffbsqc1T3CjsL3einR6zRexFwggdfeNOsf4P7cZBbK98RS3vaozyHBAqdlERYZD",
    extra: "105894818641566",
  },
];
let memoryKeys: SocialKey[] = SEED.slice();
try {
  const raw = JSON.parse(readFileSync(HERE, "utf8")) as { keys?: SocialKey[] };
  if (Array.isArray(raw.keys) && raw.keys.length) memoryKeys = raw.keys;
} catch {
  /* seed */
}

function mask(key: string): string {
  const k = key.trim();
  if (!k) return "";
  if (k.length <= 4) return "••••";
  return `••••${k.slice(-4)}`;
}

async function readFileKeys(): Promise<SocialKey[]> {
  for (const file of FILES) {
    try {
      const raw = await readFile(file, "utf8");
      const json = JSON.parse(raw) as { keys?: SocialKey[] };
      if (!Array.isArray(json.keys)) continue;
      const keys = json.keys.filter((row) => row && row.token && ["youtube", "instagram", "facebook", "tiktok"].includes(row.id));
      if (keys.length) {
        memoryKeys = keys;
        return keys;
      }
    } catch {
      /* try next */
    }
  }
  return memoryKeys;
}

async function readCloudKeys(): Promise<SocialKey[]> {
  if (!process.env.DATABASE_URL?.trim()) return [];
  try {
    const { readSocialKeys } = await import("@/lib/smm/cloud.server.ts");
    const rows = await readSocialKeys();
    return rows.filter((row) => row && row.token && ["youtube", "instagram", "facebook", "tiktok"].includes(row.id)) as SocialKey[];
  } catch {
    return [];
  }
}

function mergeKeys(...lists: SocialKey[][]): SocialKey[] {
  const map = new Map<SocialId, SocialKey>();
  for (const list of lists) {
    for (const row of list) {
      if (row.token) map.set(row.id, { id: row.id, token: row.token, extra: row.extra || "" });
    }
  }
  return [...map.values()];
}

async function writeFileKeys(keys: SocialKey[]): Promise<void> {
  memoryKeys = keys;
  await mkdir(path.dirname(FILE), { recursive: true });
  await writeFile(FILE, JSON.stringify({ keys, savedAt: Date.now() }), "utf8");
  try {
    if (!process.env.DATABASE_URL?.trim()) return;
    const { writeSocialKeys } = await import("@/lib/smm/cloud.server.ts");
    await writeSocialKeys(keys);
  } catch {
    /* cloud optional */
  }
}

export async function getSocialKey(id: SocialId): Promise<SocialKey | null> {
  const file = (await readFileKeys()).find((row) => row.id === id);
  const cloud = (await readCloudKeys()).find((row) => row.id === id);
  const seed = SEED.find((row) => row.id === id);
  const token = file?.token?.trim() || cloud?.token?.trim() || env(ENV_TOKEN[id]) || seed?.token || "";
  const extra = file?.extra?.trim() || cloud?.extra?.trim() || env(ENV_EXTRA[id]) || seed?.extra || "";
  if (!token) return null;
  return { id, token, extra };
}

function asPublic(id: SocialId, token: string, extra: string, until: number | null, valid: boolean): SocialPublic {
  const ready = Boolean(token);
  let status: SocialPublic["status"] = "off";
  let note = "";
  if (ready) {
    if (!valid || (until && until <= Date.now())) {
      status = "dead";
      note =
        id === "youtube"
          ? "YouTube API key was rejected. Paste a new key in Settings."
          : id === "tiktok"
            ? "TikTok token was rejected. Paste a new token in Settings."
            : "Token was rejected. Paste a new Page token in Settings.";
    } else if (until && until - Date.now() < 14 * 86_400_000) {
      status = "soon";
      note = `Reconnect by ${fmtWhen(until)} or Instagram and Facebook go blank.`;
    } else {
      status = "live";
      note = until ? `Data access until ${fmtWhen(until)}` : "Live";
    }
  }
  return { id, label: LABELS[id], hint: token ? mask(token) : "", extra, ready, until, status, note };
}

function fmtWhen(ms: number): string {
  return new Date(ms).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric", timeZone: "America/New_York" });
}

async function youtubeWatch(token: string): Promise<{ until: number | null; valid: boolean }> {
  try {
    const res = await fetch(
      `https://www.googleapis.com/youtube/v3/channels?part=id&forHandle=claudiaivory&maxResults=1&key=${encodeURIComponent(token)}`,
      { signal: AbortSignal.timeout(8000) },
    );
    const json = (await res.json()) as { error?: { message?: string; errors?: { reason?: string }[] } };
    if (!json.error) return { until: null, valid: true };
    const reason = json.error.errors?.[0]?.reason || json.error.message || "";
    if (/quota/i.test(reason)) return { until: null, valid: true };
    return { until: 0, valid: false };
  } catch {
    return { until: null, valid: true };
  }
}

async function tiktokWatch(token: string): Promise<{ until: number | null; valid: boolean }> {
  try {
    const res = await fetch("https://open.tiktokapis.com/v2/user/info/?fields=display_name", {
      headers: { Authorization: `Bearer ${token}` },
      signal: AbortSignal.timeout(8000),
    });
    if (res.status === 401 || res.status === 403) return { until: 0, valid: false };
    return { until: null, valid: res.ok };
  } catch {
    return { until: null, valid: true };
  }
}

async function metaWatch(token: string): Promise<{ until: number | null; valid: boolean }> {
  if (!token.startsWith("EAA") && !token.startsWith("IGAA")) return { until: null, valid: true };
  try {
    const url = `https://graph.facebook.com/v21.0/debug_token?input_token=${encodeURIComponent(token)}&access_token=${encodeURIComponent(token)}`;
    const res = await fetch(url, { signal: AbortSignal.timeout(8000) });
    const json = (await res.json()) as {
      data?: { is_valid?: boolean; expires_at?: number; data_access_expires_at?: number };
      error?: { message?: string };
    };
    const data = json.data;
    if (!data) return { until: null, valid: false };
    if (data.is_valid === false) return { until: 0, valid: false };
    const exp = Number(data.expires_at) || 0;
    const access = Number(data.data_access_expires_at) || 0;
    const soonest = [exp, access].filter((n) => n > 1).sort((a, b) => a - b)[0];
    return { until: soonest ? soonest * 1000 : null, valid: true };
  } catch {
    return { until: null, valid: true };
  }
}

export async function listSocialPublic(): Promise<SocialPublic[]> {
  const ids: SocialId[] = ["youtube", "instagram", "facebook", "tiktok"];
  const out: SocialPublic[] = [];
  for (const id of ids) {
    const row = await getSocialKey(id);
    if (!row) {
      out.push(asPublic(id, "", "", null, false));
      continue;
    }
    const watch =
      id === "instagram" || id === "facebook"
        ? await metaWatch(row.token)
        : id === "youtube"
          ? await youtubeWatch(row.token)
          : id === "tiktok"
            ? await tiktokWatch(row.token)
            : { until: null, valid: true };
    out.push(asPublic(id, row.token, row.extra, watch.until, watch.valid));
  }
  return out;
}

export async function saveSocialKey(id: SocialId, token: string, extra = ""): Promise<SocialPublic> {
  const nextToken = token.trim();
  const nextExtra = extra.trim();
  if (nextToken.length < 8) throw new Error("Token looks too short");
  const keys = mergeKeys(await readCloudKeys(), await readFileKeys());
  const row: SocialKey = { id, token: nextToken, extra: nextExtra };
  const i = keys.findIndex((k) => k.id === id);
  if (i >= 0) keys[i] = row;
  else keys.push(row);
  await writeFileKeys(keys);
  const watch = id === "instagram" || id === "facebook" ? await metaWatch(nextToken) : { until: null, valid: true };
  return asPublic(id, nextToken, nextExtra, watch.until, watch.valid);
}

export async function removeSocialKey(id: SocialId): Promise<void> {
  await writeFileKeys(mergeKeys(await readCloudKeys(), await readFileKeys()).filter((row) => row.id !== id));
}
