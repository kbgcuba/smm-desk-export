import { create } from "zustand";
import { persist } from "zustand/middleware";

type State = {
  lastService: Record<string, string>;
  lastQty: Record<string, number>;
  recentLinks: string[];
  autoRefill: boolean;
  lastAccount: string;
  lastAccountAt: number;
  setLastService: (deskId: string, key: string) => void;
  setLastQty: (serviceKey: string, qty: number) => void;
  rememberLink: (link: string) => void;
  setAutoRefill: (on: boolean) => void;
  setLastAccount: (id: string) => void;
  replace: (next: Partial<Pick<State, "lastService" | "lastQty" | "recentLinks" | "autoRefill" | "lastAccount" | "lastAccountAt">>) => void;
};

export const useSmmPrefs = create<State>()(
  persist(
    (set, get) => ({
      lastService: {},
      lastQty: {},
      recentLinks: [],
      autoRefill: true,
      lastAccount: "",
      lastAccountAt: 0,
      setLastService: (deskId, key) => set({ lastService: { ...get().lastService, [deskId]: key } }),
      setLastQty: (serviceKey, qty) => set({ lastQty: { ...get().lastQty, [serviceKey]: qty } }),
      rememberLink: (link) => {
        const href = link.trim();
        if (!href) return;
        const rest = get().recentLinks.filter((row) => row !== href);
        set({ recentLinks: [href, ...rest].slice(0, 8) });
      },
      setAutoRefill: (on) => set({ autoRefill: on }),
      setLastAccount: (id) => {
        if (!id || get().lastAccount === id) return;
        set({ lastAccount: id, lastAccountAt: Date.now() });
      },
      replace: (next) =>
        set({
          lastService: next.lastService ?? get().lastService,
          lastQty: next.lastQty ?? get().lastQty,
          recentLinks: next.recentLinks ?? get().recentLinks,
          autoRefill: next.autoRefill ?? get().autoRefill,
          lastAccount: next.lastAccount ?? get().lastAccount,
          lastAccountAt: next.lastAccountAt ?? get().lastAccountAt,
        }),
    }),
    { name: "smm-prefs" },
  ),
);
