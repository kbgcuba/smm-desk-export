export type ProfileStat = { key: string; label: string; value: number };

export type LookedProfile = {
  id: string;
  url: string;
  platform: string;
  handle: string;
  title: string;
  avatar: string | null;
  stats: ProfileStat[];
};

export type TrackedProfile = LookedProfile & { at: number };

export type ProfileItem = {
  id: string;
  url: string;
  title: string;
  thumb: string | null;
  at: number;
  kind: string;
  stats: ProfileStat[];
};

export type ProfileFeed = {
  platform: string;
  handle: string;
  items: ProfileItem[];
  cursor: string | null;
};
