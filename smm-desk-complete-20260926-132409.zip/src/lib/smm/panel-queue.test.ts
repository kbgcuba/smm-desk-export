import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { createPanelQueue, mapPool } from "./panel-queue.ts";

function wait(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

describe("panel queue", () => {
  it("keeps the same panel in order and runs other panels at the same time", async () => {
    const q = createPanelQueue();
    const log: string[] = [];
    const a1 = q.enqueue("a", async () => {
      log.push("a-start");
      await wait(40);
      log.push("a-end");
      return 1;
    });
    const b1 = q.enqueue("b", async () => {
      log.push("b-start");
      await wait(5);
      log.push("b-end");
      return 2;
    });
    const a2 = q.enqueue("a", async () => {
      log.push("a2");
      return 3;
    });
    assert.deepEqual(await Promise.all([a1, b1, a2]), [1, 2, 3]);
    assert.deepEqual(log, ["a-start", "b-start", "b-end", "a-end", "a2"]);
  });
});

describe("mapPool", () => {
  it("caps concurrency and keeps order", async () => {
    const active: number[] = [];
    let peak = 0;
    const out = await mapPool([1, 2, 3, 4], 2, async (n) => {
      active.push(n);
      peak = Math.max(peak, active.length);
      await wait(15);
      active.splice(active.indexOf(n), 1);
      return n * 10;
    });
    assert.deepEqual(out, [10, 20, 30, 40]);
    assert.equal(peak, 2);
  });
});
