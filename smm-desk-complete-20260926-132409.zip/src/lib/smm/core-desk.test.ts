import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { CORE_DESKS, ensureCoreDesks, isCoreDesk } from "./desk-core.ts";
import { mergeFavorites } from "./merge.ts";

describe("isCoreDesk", () => {
  it("treats tiktok and youtube as core even if locked was lost", () => {
    assert.equal(isCoreDesk({ id: "tiktok", locked: false }), true);
    assert.equal(isCoreDesk({ id: "youtube" }), true);
    assert.equal(isCoreDesk({ id: "instagram", locked: true }), true);
    assert.equal(isCoreDesk({ id: "instagram", locked: false }), false);
  });
});

describe("ensureCoreDesks", () => {
  it("does not put TikTok back after the user deleted it", () => {
    const next = ensureCoreDesks([{ id: "instagram", label: "Instagram", locked: false, services: [{ panel: "jap", id: 1, title: "X" }] }]);
    assert.equal(next.some((d) => d.id === "tiktok"), false);
    assert.equal(next.some((d) => d.id === "youtube"), false);
    assert.equal(next[0]?.id, "instagram");
  });

  it("keeps existing TikTok services instead of resetting them", () => {
    const next = ensureCoreDesks([
      { id: "tiktok", label: "TikTok", locked: false, services: [{ panel: "smmwiz", id: 19968, title: "Views" }] },
    ]);
    assert.deepEqual(
      next[0]?.services.map((s) => s.id),
      [19968],
    );
    assert.equal(next.some((d) => d.id === "youtube"), false);
  });

  it("seeds TikTok and YouTube only when favorites would be empty", () => {
    const next = ensureCoreDesks([]);
    assert.equal(next[0]?.id, "tiktok");
    assert.equal(next[1]?.id, "youtube");
    assert.ok((next[0]?.services.length || 0) >= 1);
  });
});

describe("mergeFavorites deleted tabs", () => {
  it("drops an empty TikTok tab when another favorite remains", () => {
    const views = { panel: "smmwiz" as const, id: 19968, title: "Views", at: 1 };
    const ig = { panel: "jap" as const, id: 1, title: "IG", at: 1 };
    const fav = mergeFavorites(
      {
        desks: [
          { id: "tiktok", label: "TikTok", locked: true, services: [] },
          { id: "instagram", label: "Instagram", locked: false, services: [ig] },
        ],
        gone: { "smmwiz:19968": 99 },
      },
      {
        desks: [
          { id: "tiktok", label: "TikTok", locked: true, services: [views] },
          { id: "instagram", label: "Instagram", locked: false, services: [ig] },
        ],
        gone: {},
      },
    );
    assert.equal(fav.desks.some((d) => d.id === "tiktok"), false);
    assert.equal(fav.desks.some((d) => d.id === "instagram"), true);
  });
});

describe("CORE_DESKS", () => {
  it("locks tiktok and youtube as the empty-state seed", () => {
    assert.equal(CORE_DESKS[0]?.id, "tiktok");
    assert.equal(CORE_DESKS[0]?.locked, true);
    assert.equal(CORE_DESKS[1]?.id, "youtube");
  });
});
