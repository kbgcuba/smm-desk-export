import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { Comment } from "@/data/catalog";

type IdMap = Record<string, boolean>;

type SocialState = {
  liked: IdMap;
  saved: IdMap;
  followed: IdMap;
  viewedStories: IdMap;
  extraComments: Record<string, Comment[]>;
  toggleLike: (id: string) => void;
  toggleSave: (id: string) => void;
  toggleFollow: (id: string) => void;
  markStory: (id: string) => void;
  addComment: (postId: string, text: string) => void;
  isLiked: (id: string) => boolean;
  isSaved: (id: string) => boolean;
  isFollowed: (id: string) => boolean;
};

function flip(map: IdMap, id: string): IdMap {
  return { ...map, [id]: !map[id] };
}

export const useSocial = create<SocialState>()(
  persist(
    (set, get) => ({
      liked: {},
      saved: {},
      followed: {},
      viewedStories: {},
      extraComments: {},
      toggleLike: (id) => set({ liked: flip(get().liked, id) }),
      toggleSave: (id) => set({ saved: flip(get().saved, id) }),
      toggleFollow: (id) => set({ followed: flip(get().followed, id) }),
      markStory: (id) => set({ viewedStories: { ...get().viewedStories, [id]: true } }),
      addComment: (postId, text) => {
        const trimmed = text.trim();
        if (!trimmed) return;
        const next: Comment = {
          id: `u-${Date.now()}`,
          handle: "you",
          text: trimmed,
          likes: 0,
        };
        const extra = get().extraComments;
        set({
          extraComments: {
            ...extra,
            [postId]: [...(extra[postId] ?? []), next],
          },
        });
      },
      isLiked: (id) => Boolean(get().liked[id]),
      isSaved: (id) => Boolean(get().saved[id]),
      isFollowed: (id) => Boolean(get().followed[id]),
    }),
    { name: "social-hub" },
  ),
);

export function withLike(base: number, id: string, liked: IdMap): number {
  return base + (liked[id] ? 1 : 0);
}

export function withSave(base: number, id: string, saved: IdMap): number {
  return base + (saved[id] ? 1 : 0);
}

export function mergeComments(seed: Comment[], extra: Comment[] | undefined): Comment[] {
  return extra?.length ? [...seed, ...extra] : seed;
}
