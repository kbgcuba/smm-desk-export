export function formatCount(n: number): string {
  const abs = Math.abs(n);
  if (abs >= 1_000_000) {
    const v = n / 1_000_000;
    const digits = abs >= 10_000_000 ? 0 : 1;
    return `${trimDec(v, digits)}M`;
  }
  if (abs >= 1_000) {
    const v = n / 1_000;
    const digits = abs >= 10_000 ? 0 : 1;
    return `${trimDec(v, digits)}K`;
  }
  return String(n);
}

function trimDec(n: number, digits: number): string {
  return n.toFixed(digits).replace(/\.0$/, "");
}

export function formatMoney(n: number): string {
  return `$${n.toFixed(2)}`;
}

export function clampInt(value: number, min: number, max: number): number {
  const n = Math.floor(Number(value));
  const lo = Math.floor(Number(min));
  const hi = Math.floor(Number(max));
  if (!Number.isFinite(n)) return Number.isFinite(lo) ? lo : 1;
  if (Number.isFinite(lo) && n < lo) return lo;
  if (Number.isFinite(hi) && n > hi) return hi;
  return n;
}

export function formatViews(n: number): string {
  return `${formatCount(n)} views`;
}
