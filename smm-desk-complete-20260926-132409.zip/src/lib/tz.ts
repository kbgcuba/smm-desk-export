export const APP_TZ = "America/New_York";

export type Wall = { y: number; m: number; d: number; h: number; min: number; s: number };

export function wallInZone(ts: number, timeZone = APP_TZ): Wall {
  const fmt = new Intl.DateTimeFormat("en-US", {
    timeZone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  });
  const map: Record<string, string> = {};
  for (const p of fmt.formatToParts(new Date(ts))) {
    if (p.type !== "literal") map[p.type] = p.value;
  }
  let h = Number(map.hour);
  if (h === 24) h = 0;
  return {
    y: Number(map.year),
    m: Number(map.month) - 1,
    d: Number(map.day),
    h,
    min: Number(map.minute),
    s: Number(map.second),
  };
}

export function zonedUtc(y: number, m: number, d: number, h = 0, min = 0, s = 0, timeZone = APP_TZ): number {
  let utc = Date.UTC(y, m, d, h, min, s);
  for (let i = 0; i < 4; i++) {
    const p = wallInZone(utc, timeZone);
    const diff = Date.UTC(y, m, d, h, min, s) - Date.UTC(p.y, p.m, p.d, p.h, p.min, p.s);
    if (diff === 0) break;
    utc += diff;
  }
  return utc;
}

export function dayStart(ts: number, timeZone = APP_TZ): number {
  const p = wallInZone(ts, timeZone);
  return zonedUtc(p.y, p.m, p.d, 0, 0, 0, timeZone);
}

export function addDays(day: number, delta: number, timeZone = APP_TZ): number {
  const p = wallInZone(day, timeZone);
  return zonedUtc(p.y, p.m, p.d + delta, 0, 0, 0, timeZone);
}

export function weekday(ts: number, timeZone = APP_TZ): number {
  const name = new Intl.DateTimeFormat("en-US", { timeZone, weekday: "short" }).format(ts);
  return ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].indexOf(name);
}

export function daysInMonth(year: number, month: number, timeZone = APP_TZ): number {
  const next = zonedUtc(year, month + 1, 1, 0, 0, 0, timeZone);
  return wallInZone(next - 1, timeZone).d;
}

export function zoneOffsetMinutes(ts: number, timeZone = APP_TZ): number {
  const p = wallInZone(ts, timeZone);
  return (Date.UTC(p.y, p.m, p.d, p.h, p.min, p.s) - ts) / 60_000;
}

export function msUntilNextDay(now = Date.now(), timeZone = APP_TZ): number {
  return Math.max(250, addDays(dayStart(now, timeZone), 1, timeZone) - now + 50);
}
