export type Creator = {
  id: string;
  name: string;
  handle: string;
  avatar: string;
  bio: string;
  followers: number;
  following: number;
  verified: boolean;
};

export type Comment = {
  id: string;
  handle: string;
  text: string;
  likes: number;
};

export type TikTokClip = {
  id: string;
  creatorId: string;
  image: string;
  caption: string;
  sound: string;
  likes: number;
  comments: number;
  shares: number;
  saves: number;
  thread: Comment[];
};

export type YtVideo = {
  id: string;
  creatorId: string;
  title: string;
  image: string;
  duration: string;
  durationSec: number;
  views: number;
  posted: string;
  description: string;
  likes: number;
  thread: Comment[];
  isShort?: boolean;
};

export type IgPost = {
  id: string;
  creatorId: string;
  image: string;
  caption: string;
  location?: string;
  likes: number;
  posted: string;
  thread: Comment[];
};

export type IgStory = {
  id: string;
  creatorId: string;
  image: string;
};

export const CREATORS: Creator[] = [
  {
    id: "nova",
    name: "Nova Lane",
    handle: "novalane",
    avatar: "/media/av-nova.jpg",
    bio: "Nights, rooftops, and whatever the city is humming.",
    followers: 1_240_000,
    following: 182,
    verified: true,
  },
  {
    id: "kenji",
    name: "Kenji Sato",
    handle: "kenjifire",
    avatar: "/media/av-kenji.jpg",
    bio: "Fire first. Seasoning later. Tokyo kitchens.",
    followers: 890_000,
    following: 94,
    verified: true,
  },
  {
    id: "miles",
    name: "Miles West",
    handle: "milewest",
    avatar: "/media/av-miles.jpg",
    bio: "One more try. Then one more.",
    followers: 420_000,
    following: 310,
    verified: false,
  },
  {
    id: "aria",
    name: "Aria Tide",
    handle: "ariatide",
    avatar: "/media/av-aria.jpg",
    bio: "Empty roads. Early light. Still showing up.",
    followers: 2_100_000,
    following: 64,
    verified: true,
  },
  {
    id: "lumen",
    name: "Lumen Cole",
    handle: "lumencole",
    avatar: "/media/av-lumen.jpg",
    bio: "Live sets. No encore. Leave it on the floor.",
    followers: 3_400_000,
    following: 41,
    verified: true,
  },
  {
    id: "sol",
    name: "Sol Varga",
    handle: "solframe",
    avatar: "/media/av-sol.jpg",
    bio: "Linen, concrete, and the light that does the work.",
    followers: 510_000,
    following: 228,
    verified: true,
  },
];

const CREATOR_MAP = Object.fromEntries(CREATORS.map((c) => [c.id, c]));

export function creator(id: string): Creator {
  const c = CREATOR_MAP[id];
  if (!c) throw new Error(`Unknown creator: ${id}`);
  return c;
}

export const TIKTOK: TikTokClip[] = [
  {
    id: "tt-nova",
    creatorId: "nova",
    image: "/media/tt-1.jpg",
    caption: "the city keeps time. i just move.",
    sound: "original sound - novalane",
    likes: 842_000,
    comments: 3184,
    shares: 41_200,
    saves: 96_400,
    thread: [
      { id: "c1", handle: "ariatide", text: "this light is doing everything", likes: 2104 },
      { id: "c2", handle: "solframe", text: "the coat moving like a second skyline", likes: 891 },
      { id: "c3", handle: "milewest", text: "need this song on a loop", likes: 440 },
    ],
  },
  {
    id: "tt-kenji",
    creatorId: "kenji",
    image: "/media/tt-2.jpg",
    caption: "fire first. seasoning later.",
    sound: "Midnight Oil - kitchen tape",
    likes: 512_000,
    comments: 1902,
    shares: 22_800,
    saves: 74_100,
    thread: [
      { id: "c1", handle: "lumencole", text: "this is a live set with pans", likes: 1203 },
      { id: "c2", handle: "novalane", text: "the sparks look like a chorus", likes: 670 },
    ],
  },
  {
    id: "tt-miles",
    creatorId: "miles",
    image: "/media/tt-3.jpg",
    caption: "one more try. then one more.",
    sound: "Concrete Hymn",
    likes: 301_000,
    comments: 980,
    shares: 11_400,
    saves: 28_600,
    thread: [
      { id: "c1", handle: "kenjifire", text: "commitment looks like this", likes: 512 },
      { id: "c2", handle: "ariatide", text: "golden hour never misses", likes: 388 },
    ],
  },
  {
    id: "tt-aria",
    creatorId: "aria",
    image: "/media/tt-4.jpg",
    caption: "5am. no audience. still showing up.",
    sound: "Tide at 5am",
    likes: 1_120_000,
    comments: 6402,
    shares: 88_000,
    saves: 201_000,
    thread: [
      { id: "c1", handle: "solframe", text: "quiet is a location", likes: 3401 },
      { id: "c2", handle: "novalane", text: "saving this for the days I forget why", likes: 1888 },
      { id: "c3", handle: "lumencole", text: "the wind is the mix", likes: 702 },
    ],
  },
];

export const YOUTUBE: YtVideo[] = [
  {
    id: "yt-lumen",
    creatorId: "lumen",
    title: "Night Set, No Encore",
    image: "/media/yt-1.jpg",
    duration: "18:42",
    durationSec: 1122,
    views: 4_820_000,
    posted: "3 days ago",
    description:
      "One room. One guitar. No encore. Recorded live with the house lights down and the mix left raw.",
    likes: 312_000,
    thread: [
      { id: "c1", handle: "novalane", text: "the haze in the first chorus — I felt that from the floor.", likes: 8400 },
      { id: "c2", handle: "milewest", text: "leave it on the floor is right.", likes: 1203 },
    ],
  },
  {
    id: "yt-kenji",
    creatorId: "kenji",
    title: "Hand-cut pasta, no shortcuts",
    image: "/media/yt-2.jpg",
    duration: "12:08",
    durationSec: 728,
    views: 1_960_000,
    posted: "1 week ago",
    description:
      "Flour, eggs, a dark plate, and the kind of patience a Tuesday night actually has. No gadgets.",
    likes: 148_000,
    thread: [
      { id: "c1", handle: "ariatide", text: "the oil catch at 7:12 is the whole film.", likes: 2100 },
      { id: "c2", handle: "solframe", text: "that plate is doing quiet work.", likes: 640 },
    ],
  },
  {
    id: "yt-aria",
    creatorId: "aria",
    title: "The Empty Road",
    image: "/media/yt-3.jpg",
    duration: "24:11",
    durationSec: 1451,
    views: 6_410_000,
    posted: "2 weeks ago",
    description:
      "A drone study of a canyon that does not need us. Blue hour to last light. No voiceover.",
    likes: 401_000,
    thread: [
      { id: "c1", handle: "lumencole", text: "this is what silence looks like from above.", likes: 11_200 },
      { id: "c2", handle: "novalane", text: "watched it twice. then sat still.", likes: 3301 },
    ],
  },
  {
    id: "yt-sol",
    creatorId: "sol",
    title: "Quiet Hours: a studio after midnight",
    image: "/media/yt-4.jpg",
    duration: "9:33",
    durationSec: 573,
    views: 812_000,
    posted: "5 days ago",
    description:
      "Rain on the glass, one lamp, the work you only do when nobody is asking for it.",
    likes: 64_200,
    thread: [
      { id: "c1", handle: "kenjifire", text: "this is the kitchen after service.", likes: 890 },
      { id: "c2", handle: "ariatide", text: "saving this for the next late one.", likes: 512 },
    ],
  },
  {
    id: "yt-s-nova",
    creatorId: "nova",
    title: "Rooftop, one take",
    image: "/media/tt-1.jpg",
    duration: "0:18",
    durationSec: 18,
    views: 2_200_000,
    posted: "14 hours ago",
    description: "A short from the roof. Teal, rain, no choreography notes.",
    likes: 190_000,
    isShort: true,
    thread: [{ id: "c1", handle: "solframe", text: "looping this.", likes: 400 }],
  },
  {
    id: "yt-s-miles",
    creatorId: "miles",
    title: "The try after the try",
    image: "/media/tt-3.jpg",
    duration: "0:22",
    durationSec: 22,
    views: 980_000,
    posted: "1 day ago",
    description: "Skatepark, last light, one more.",
    likes: 74_000,
    isShort: true,
    thread: [{ id: "c1", handle: "lumencole", text: "the dust is the drum fill.", likes: 210 }],
  },
  {
    id: "yt-s-kenji",
    creatorId: "kenji",
    title: "Fire first",
    image: "/media/tt-2.jpg",
    duration: "0:15",
    durationSec: 15,
    views: 1_540_000,
    posted: "2 days ago",
    description: "A fifteen-second reminder.",
    likes: 121_000,
    isShort: true,
    thread: [{ id: "c1", handle: "novalane", text: "seasoning later. noted.", likes: 330 }],
  },
  {
    id: "yt-s-aria",
    creatorId: "aria",
    title: "Still showing up",
    image: "/media/tt-4.jpg",
    duration: "0:27",
    durationSec: 27,
    views: 3_100_000,
    posted: "3 days ago",
    description: "Cliff, dawn, no audience.",
    likes: 260_000,
    isShort: true,
    thread: [{ id: "c1", handle: "milewest", text: "needed this today.", likes: 1900 }],
  },
];

export const INSTAGRAM: IgPost[] = [
  {
    id: "ig-sol-1",
    creatorId: "sol",
    image: "/media/ig-1.jpg",
    caption: "Linen and concrete. The corridor did the rest.",
    location: "Silver Lake",
    likes: 48_200,
    posted: "2h",
    thread: [
      { id: "c1", handle: "novalane", text: "this is a still from a film I want to see", likes: 320 },
      { id: "c2", handle: "ariatide", text: "the shadow on the wall is the whole sentence", likes: 140 },
    ],
  },
  {
    id: "ig-kenji-1",
    creatorId: "kenji",
    image: "/media/ig-2.jpg",
    caption: "Sunday loaf. Still learning the crumb.",
    location: "Home kitchen",
    likes: 36_400,
    posted: "5h",
    thread: [
      { id: "c1", handle: "solframe", text: "north light on tomatoes is a love letter", likes: 210 },
      { id: "c2", handle: "lumencole", text: "I can hear this photo", likes: 88 },
    ],
  },
  {
    id: "ig-sol-2",
    creatorId: "sol",
    image: "/media/ig-3.jpg",
    caption: "The light does the work. I just waited.",
    likes: 29_100,
    posted: "1d",
    thread: [{ id: "c1", handle: "ariatide", text: "dust in the beam. that's the clock.", likes: 190 }],
  },
  {
    id: "ig-aria-1",
    creatorId: "aria",
    image: "/media/ig-4.jpg",
    caption: "Pulled over for the sky. The car understood.",
    location: "Highway 62",
    likes: 91_800,
    posted: "1d",
    thread: [
      { id: "c1", handle: "milewest", text: "this is the shot after the session", likes: 640 },
      { id: "c2", handle: "novalane", text: "peach hour. always.", likes: 401 },
    ],
  },
  {
    id: "ig-nova-1",
    creatorId: "nova",
    image: "/media/ig-5.jpg",
    caption: "Brought the meadow inside. It kept the weather.",
    likes: 22_700,
    posted: "2d",
    thread: [{ id: "c1", handle: "kenjifire", text: "quiet table. I get it.", likes: 76 }],
  },
  {
    id: "ig-nova-2",
    creatorId: "nova",
    image: "/media/ig-6.jpg",
    caption: "After the rain. The alley kept the color.",
    location: "Shimokitazawa",
    likes: 67_300,
    posted: "3d",
    thread: [
      { id: "c1", handle: "lumencole", text: "that lantern is a metronome", likes: 502 },
      { id: "c2", handle: "solframe", text: "wet pavement is the only mirror I trust", likes: 277 },
    ],
  },
];

export const STORIES: IgStory[] = [
  { id: "st-nova", creatorId: "nova", image: "/media/tt-1.jpg" },
  { id: "st-kenji", creatorId: "kenji", image: "/media/tt-2.jpg" },
  { id: "st-miles", creatorId: "miles", image: "/media/tt-3.jpg" },
  { id: "st-aria", creatorId: "aria", image: "/media/tt-4.jpg" },
  { id: "st-lumen", creatorId: "lumen", image: "/media/yt-1.jpg" },
  { id: "st-sol", creatorId: "sol", image: "/media/ig-1.jpg" },
];

export const LONG_FORM = YOUTUBE.filter((v) => !v.isShort);
export const SHORTS = YOUTUBE.filter((v) => v.isShort);

export function postsByCreator(id: string): IgPost[] {
  return INSTAGRAM.filter((p) => p.creatorId === id);
}

export function ytById(id: string): YtVideo | undefined {
  return YOUTUBE.find((v) => v.id === id);
}
