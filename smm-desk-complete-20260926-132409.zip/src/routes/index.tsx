import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef } from "react";
import { Toaster } from "sonner";
import { PlatformTabs, type View } from "@/components/platform-tabs";
import { OrdersView } from "@/components/orders-view";
import { CloudSync } from "@/components/cloud-sync";
import { RefillSync } from "@/components/refill-sync";
import { SettingsView } from "@/components/settings-view";
import { StatsView } from "@/components/stats-view";
import { SmmLive } from "@/components/smm-live";
import { CatalogWarm } from "@/components/catalog-warm";
import { ProfileLive } from "@/components/profile-live";
import { SmmPanels } from "@/components/smm-panels";
import { AllServicesView } from "@/components/all-services-view";
import { WpListSheet } from "@/components/wp-list-sheet";
import { ApiWatch } from "@/components/api-watch";
import { AccessGate } from "@/components/access-gate";
import { useSmmDesks } from "@/lib/smm/desks";

type Search = { tab: View; link?: string; svc?: string };

export const Route = createFileRoute("/")({
  ssr: false,
  validateSearch: (s: Record<string, unknown>): Search => {
    const raw = typeof s.tab === "string" && s.tab ? s.tab : "stats";
    const tab = raw === "refills" ? "orders" : raw;
    return {
      tab,
      link: typeof s.link === "string" && s.link ? s.link : undefined,
      svc: typeof s.svc === "string" && s.svc ? s.svc : undefined,
    };
  },
  head: ({ match }) => ({
    meta: [{ title: titleFor(match.search.tab) }],
  }),
  component: Home,
});

function titleFor(tab: string): string {
  if (tab === "orders" || tab === "refills") return "Orders";
  if (tab === "settings") return "Settings";
  if (tab === "stats") return "My Accounts";
  if (tab === "links") return "Links";
  if (tab === "youtube") return "YouTube";
  if (tab === "tiktok") return "TikTok";
  if (tab === "instagram") return "Instagram";
  return tab[0] ? tab[0].toUpperCase() + tab.slice(1) : "Home";
}

function Home() {
  const { tab } = Route.useSearch();
  const navigate = Route.useNavigate();
  const desks = useSmmDesks((s) => s.desks);
  const desk = tab === "favorites" ? desks[0] : desks.find((d) => d.id === tab);
  const booted = useRef(false);

  useEffect(() => {
    if (booted.current) return;
    booted.current = true;
    let fresh = true;
    try {
      fresh = sessionStorage.getItem("smm-booted") !== "1";
      sessionStorage.setItem("smm-booted", "1");
    } catch {
      fresh = true;
    }
    if (fresh && tab !== "stats") {
      void navigate({ to: "/", search: { tab: "stats" }, replace: true });
    }
  }, [navigate, tab]);

  return (
    <AccessGate>
    <div className="flex h-svh flex-col bg-bg text-fg" data-platform={tab} data-rev="26">
      <SmmLive />
      <CatalogWarm />
      <ProfileLive />
      <CloudSync />
      <RefillSync />
      <PlatformTabs
        tab={tab}
        onTab={(next) => {
          void navigate({ to: "/", search: { tab: next } });
        }}
      />
      <ApiWatch />
      <main className="flex min-h-0 flex-1 flex-col overflow-hidden">
        {desk ? (
          <div className="smm-scroll h-full overflow-y-auto bg-bg" data-smm-scroll>
            <SmmPanels key={desk.id} desk={desk} />
          </div>
        ) : null}
        {tab === "all" ? (
          <div className="smm-scroll h-full overflow-y-auto bg-bg" data-smm-scroll>
            <AllServicesView />
          </div>
        ) : null}
        {tab === "orders" ? <OrdersView /> : null}
        {tab === "stats" ? (
          <div className="h-full min-h-0">
            <StatsView />
          </div>
        ) : null}
        {tab === "settings" ? <SettingsView /> : null}
        {tab === "links" ? <WpListSheet /> : null}
      </main>
      <Toaster theme="dark" position="bottom-center" style={{ zIndex: 120 }} />
    </div>
    </AccessGate>
  );
}