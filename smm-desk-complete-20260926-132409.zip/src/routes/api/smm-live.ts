import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/smm-live")({
  server: {
    handlers: {
      GET: ({ request }) => {
        const encoder = new TextEncoder();
        const stream = new ReadableStream({
          start(controller) {
            let closed = false;
            const send = (chunk: string) => {
              if (closed) return;
              try {
                controller.enqueue(encoder.encode(chunk));
              } catch {
                closed = true;
              }
            };
            const ping = setInterval(() => send(`: ping\n\n`), 15_000);

            async function tick() {
              if (closed) return;
              try {
                const { requireAccess } = await import("@/lib/smm/gate.server.ts");
                await requireAccess(request);
                const { loadAllBalances } = await import("@/lib/smm/panel.server.ts");
                const panels = await loadAllBalances();
                if (closed) return;
                send(`data: ${JSON.stringify({ panels })}\n\n`);
              } catch {
                send(`: wait\n\n`);
              }
            }

            void tick();
            const loop = setInterval(() => {
              void tick();
            }, 3_000);

            const stop = () => {
              if (closed) return;
              closed = true;
              clearInterval(loop);
              clearInterval(ping);
              try {
                controller.close();
              } catch {
                /* already closed */
              }
            };

            request.signal.addEventListener("abort", stop);
            setTimeout(stop, 25_000);
          },
        });

        return new Response(stream, {
          headers: {
            "Content-Type": "text/event-stream; charset=utf-8",
            "Cache-Control": "no-cache, no-transform",
            Connection: "keep-alive",
          },
        });
      },
    },
  },
});
