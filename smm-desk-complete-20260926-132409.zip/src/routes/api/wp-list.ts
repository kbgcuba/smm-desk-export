import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/wp-list")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        try {
          const { readWpListStored } = await import("@/lib/smm/cloud.server.ts");
          const { sameSecret } = await import("@/lib/smm/wp-hook.server.ts");
          const list = await readWpListStored();
          const header = request.headers.get("authorization") || "";
          const token = header.replace(/^Bearer\s+/i, "").trim();
          if (!sameSecret(token, list.secret)) {
            return Response.json({ error: "Unauthorized" }, { status: 401 });
          }
          return Response.json({
            updatedAt: list.updatedAt,
            style: list.style,
            items: list.items,
            badges: list.badges ?? [],
          });
        } catch (err) {
          return Response.json({ error: err instanceof Error ? err.message : "List failed" }, { status: 500 });
        }
      },
    },
  },
});
