import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/smm-cloud")({
  server: {
    handlers: {
      GET: ({ request }) => {
        const encoder = new TextEncoder();
        const stream = new ReadableStream({
          start(controller) {
            let closed = false;
            let last = "";

            const send = (chunk: string) => {
              if (closed) return;
              try {
                controller.enqueue(encoder.encode(chunk));
              } catch {
                closed = true;
              }
            };

            const ping = setInterval(() => send(`: ping\n\n`), 15_000);

            async function tick() {
              if (closed) return;
              try {
                const { requireAccess } = await import("@/lib/smm/gate.server.ts");
                await requireAccess(request);
                const { pullCloud } = await import("@/lib/smm/cloud.server.ts");
                const dump = await pullCloud();
                if (closed || !dump) return;
                const payload = JSON.stringify({
                  orders: dump.orders,
                  refills: dump.refills,
                  desks: dump.desks,
                  desksAt: dump.desksAt,
                  gone: dump.gone,
                  prefs: dump.prefs,
                  panels: dump.panels,
                  profiles: dump.profiles,
                  profilesAt: dump.profilesAt,
                  savedAt: dump.savedAt,
                });
                if (payload === last) return;
                last = payload;
                send(`data: ${payload}\n\n`);
              } catch {
                send(`: wait\n\n`);
              }
            }

            void tick();
            const loop = setInterval(() => {
              void tick();
            }, 2_000);

            let unsub: (() => void) | undefined;
            void import("@/lib/smm/cloud.server.ts").then(({ onCloudWrite }) => {
              if (closed) return;
              unsub = onCloudWrite(() => {
                void tick();
              });
            });

            const stop = () => {
              if (closed) return;
              closed = true;
              unsub?.();
              clearInterval(loop);
              clearInterval(ping);
              try {
                controller.close();
              } catch {
                /* already closed */
              }
            };

            request.signal.addEventListener("abort", stop);
            setTimeout(stop, 25_000);
          },
          cancel() {
            /* start()'s abort listener also runs */
          },
        });

        return new Response(stream, {
          headers: {
            "Content-Type": "text/event-stream; charset=utf-8",
            "Cache-Control": "no-cache, no-transform",
            Connection: "keep-alive",
          },
        });
      },
    },
  },
});
