import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/smm-account")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const q = new URL(request.url);
        const platform = (q.searchParams.get("platform") || "facebook").toLowerCase();
        const url =
          q.searchParams.get("url") ||
          (platform === "facebook"
            ? "https://www.facebook.com/105894818641566"
            : platform === "instagram"
              ? "https://www.instagram.com/clauivory/"
              : platform === "youtube"
                ? "https://www.youtube.com/@claudiaivory"
                : "https://www.tiktok.com/@clauivory");
        try {
          const { requireAccess } = await import("@/lib/smm/gate.server.ts");
          await requireAccess(request);
          const { lookupProfile, loadProfileFeed } = await import("@/lib/smm/profile.server.ts");
          const look = await lookupProfile(url, true);
          const feed = await loadProfileFeed(url, q.searchParams.get("cursor"), true, q.searchParams.get("drain") === "1");
          return Response.json({ look, feed });
        } catch (err) {
          return Response.json({ error: err instanceof Error ? err.message : "Lookup failed" }, { status: 502 });
        }
      },
    },
  },
});
