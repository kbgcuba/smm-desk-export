import { createFileRoute } from "@tanstack/react-router";

function allowed(raw: string): URL | null {
  try {
    const u = new URL(raw);
    if (u.protocol !== "https:") return null;
    const h = u.hostname.replace(/^www\./, "").toLowerCase();
    const ok =
      h === "instagram.com" ||
      h.endsWith(".instagram.com") ||
      h.endsWith("cdninstagram.com") ||
      h.includes("fbcdn.net") ||
      h.startsWith("scontent") ||
      h.includes("tiktokcdn") ||
      h.endsWith("tiktok.com") ||
      h === "socialblade.com" ||
      h.endsWith(".socialblade.com");
    return ok ? u : null;
  } catch {
    return null;
  }
}

export const Route = createFileRoute("/api/smm-media")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const raw = new URL(request.url).searchParams.get("u") || "";
        const target = allowed(raw);
        if (!target) return new Response("Bad media link", { status: 400 });
        try {
          const { requireAccess } = await import("@/lib/smm/gate.server.ts");
          await requireAccess(request);
          const res = await fetch(target.toString(), {
            headers: {
              "user-agent":
                "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
              accept: "image/avif,image/webp,image/apng,image/*,*/*;q=0.8",
              "accept-language": "en-US,en;q=0.9",
            },
            redirect: "follow",
            signal: AbortSignal.timeout(12_000),
          });
          if (!res.ok) return new Response("Media missing", { status: 404 });
          const type = res.headers.get("content-type") || "image/jpeg";
          if (!type.startsWith("image/")) return new Response("Not an image", { status: 415 });
          const buf = await res.arrayBuffer();
          if (buf.byteLength > 6_000_000) return new Response("Too large", { status: 413 });
          return new Response(buf, {
            headers: {
              "Content-Type": type.split(";")[0] || "image/jpeg",
              "Cache-Control": "public, max-age=3600",
            },
          });
        } catch {
          return new Response("Media failed", { status: 502 });
        }
      },
    },
  },
});
