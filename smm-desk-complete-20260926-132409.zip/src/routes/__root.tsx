import { createRootRoute, HeadContent, Outlet, Scripts } from "@tanstack/react-router";
import { AuthProvider } from "@/lib/auth/provider";
import { PreviewHostBridge } from "@/components/preview-host-bridge";
import appCssText from "../styles.css?inline";
import appCss from "../styles.css?url";

const APP_NAME = "TikTok, YouTube, Instagram";

function sheetHref(url: string): string {
  if (!import.meta.env.PROD) return url;
  return `${url}${url.includes("?") ? "&" : "?"}r=27`;
}

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1, maximum-scale=1, viewport-fit=cover" },
      { httpEquiv: "Permissions-Policy", content: "clipboard-read=(self), clipboard-write=(self)" },
      { title: APP_NAME },
      { name: "theme-color", content: "#0c0c0e" },
      {
        name: "description",
        content: "TikTok, YouTube, and Instagram — three taps, one place.",
      },
    ],
    links: [
      { rel: "icon", type: "image/svg+xml", href: "/favicon.svg" },
      { rel: "stylesheet", href: sheetHref(appCss) },
      { rel: "manifest", href: "/__grok/manifest.webmanifest" },
      { rel: "apple-touch-icon", href: "/__grok/icon-180.png" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@600;700&family=Outfit:wght@400;500;600;700&family=Syne:wght@700;800&display=optional",
      },
    ],
  }),
  component: () => (
    <html lang="en" suppressHydrationWarning className="antialiased">
      <head>
        <style dangerouslySetInnerHTML={{ __html: appCssText }} />
        <HeadContent />
      </head>
      <body className="bg-bg text-fg">
        <PreviewHostBridge />
        <AuthProvider>
          <Outlet />
        </AuthProvider>
        <Scripts />
      </body>
    </html>
  ),
});
