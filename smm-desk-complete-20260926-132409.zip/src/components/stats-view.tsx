import { memo, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { enrichSmmInstagram, loadLinkPreview, loadSmmProfileFeed, lookupSmmProfile } from "@/lib/smm/fn";
import { formatCount } from "@/lib/format";
import { TabMark } from "@/components/platform-tabs";
import { mergeFeedItems, useSmmProfiles } from "@/lib/smm/profiles";
import { useSmmPrefs } from "@/lib/smm/prefs";
import { syncCloudNow } from "@/components/cloud-sync";
import type { LookedProfile, ProfileItem, TrackedProfile } from "@/lib/smm/profile-types";
import { tiktokConsecutive } from "@/lib/smm/tiktok-own";
import { AddServiceSheet, metricIdFor } from "@/components/add-service-sheet";
import { OrderConfirm } from "@/components/order-button";
import { cn } from "@/lib/utils";

type SortId = "latest" | "oldest" | "views" | "likes" | "comments" | "shares" | "short" | "video";
type KindFilter = "all" | "video" | "short";

const EMPTY_ITEMS: ProfileItem[] = [];
const ROW_H = 118;
const CARD_H = 108;

const STAT_RANK: Record<string, number> = {
  followers: 1,
  subscribers: 1,
  following: 2,
  videos: 3,
  posts: 3,
  views: 4,
  likes: 5,
  comments: 6,
  shares: 7,
  saves: 8,
  reach: 9,
  reposts: 10,
  reactions: 11,
  talking: 11,
};

const IG_SLOTS = [
  { key: "views", label: "Views" },
  { key: "likes", label: "Likes" },
  { key: "comments", label: "Comments" },
  { key: "shares", label: "Shares" },
  { key: "saves", label: "Saves" },
  { key: "reach", label: "Reach" },
  { key: "reposts", label: "Reposts" },
];

function rankStats<T extends { key: string }>(stats: T[]): T[] {
  return [...stats].sort((a, b) => (STAT_RANK[a.key] ?? 50) - (STAT_RANK[b.key] ?? 50));
}

const HEADER_SLOTS: { key: string; label: string; alts?: string[] }[] = [
  { key: "followers", label: "Followers", alts: ["subscribers"] },
  { key: "following", label: "Following" },
  { key: "videos", label: "Videos", alts: ["posts"] },
  { key: "views", label: "Views" },
  { key: "likes", label: "Likes" },
  { key: "comments", label: "Comments" },
  { key: "shares", label: "Shares" },
  { key: "saves", label: "Saves" },
];

function sumKey(items: ProfileItem[], key: string): number | null {
  let total = 0;
  let any = false;
  for (const item of items) {
    const hit = item.stats.find((s) => s.key === key);
    if (hit && Number.isFinite(hit.value)) {
      total += hit.value;
      any = true;
    }
  }
  return any ? total : null;
}

function headerStats(row: TrackedProfile, items: ProfileItem[]): { key: string; label: string; value: number | null }[] {
  const stats = row.stats.filter((s) => s.key !== "talking").map((s) => ({ ...s }));
  const by = new Map(stats.map((s) => [s.key, s]));
  const hide = new Set<string>(
    row.platform === "youtube"
      ? ["following", "shares", "saves"]
      : row.platform === "facebook"
        ? ["following", "saves"]
        : [],
  );
  const core = HEADER_SLOTS.filter((slot) => !hide.has(slot.key)).map((slot) => {
    const src = by.get(slot.key) || slot.alts?.map((k) => by.get(k)).find(Boolean);
    const label =
      slot.key === "likes" && row.platform === "facebook"
        ? "Reactions"
        : slot.key === "followers" && src?.key === "subscribers"
          ? "Subscribers"
          : slot.key === "videos" && (src?.key === "posts" || row.platform === "instagram" || row.platform === "facebook")
            ? "Posts"
            : slot.label;
    let value = src && Number.isFinite(src.value) ? src.value : null;
    if (value == null && row.platform === "facebook") {
      value =
        slot.key === "videos"
          ? items.length || null
          : slot.key === "views" || slot.key === "likes" || slot.key === "comments" || slot.key === "shares"
            ? sumKey(items, slot.key)
            : null;
    }
    return { key: slot.key, label, value };
  });
  const extra: { key: string; label: string; value: number | null }[] = [];
  if (row.platform === "youtube") {
    extra.push(
      { key: "shorts", label: "Shorts", value: by.get("shorts")?.value ?? null },
      { key: "long", label: "Long", value: by.get("long")?.value ?? null },
    );
  } else if (row.platform === "instagram") {
    extra.push(
      { key: "reach", label: "Reach", value: by.get("reach")?.value ?? null },
      { key: "reposts", label: "Reposts", value: by.get("reposts")?.value ?? null },
    );
  } else if (row.platform === "facebook") {
    extra.push({
      key: "reels",
      label: "Videos",
      value: by.get("reels")?.value ?? (items.filter((item) => item.kind === "reel" || item.kind === "video").length || null),
    });
  }
  return [...core, ...extra].filter((s, _, all) => s.value != null || all.every((x) => x.value == null));
}

function sortsFor(platform: string, items: ProfileItem[]): { id: SortId; label: string }[] {
  const keys = new Set(items.flatMap((i) => i.stats.map((s) => s.key)));
  const kinds = new Set(items.map((i) => i.kind));
  const out: { id: SortId; label: string }[] = [
    { id: "latest", label: "Latest" },
    { id: "oldest", label: "Oldest" },
  ];
  if (keys.has("views")) out.push({ id: "views", label: "Most views" });
  if (keys.has("likes")) out.push({ id: "likes", label: "Most likes" });
  if (keys.has("comments")) out.push({ id: "comments", label: "Most comments" });
  if (keys.has("shares")) out.push({ id: "shares", label: "Most shares" });
  if (platform === "youtube" && kinds.has("short") && kinds.has("video")) {
    out.push({ id: "short", label: "Shorts first" }, { id: "video", label: "Videos first" });
  }
  if (platform === "instagram" && kinds.has("reel") && kinds.has("post")) {
    out.push({ id: "short", label: "Reels first" }, { id: "video", label: "Posts first" });
  }
  return out;
}

function statOf(item: ProfileItem, key: string): number {
  return item.stats.find((s) => s.key === key)?.value ?? -1;
}

function applySort(items: ProfileItem[], sort: SortId): ProfileItem[] {
  const list = items.map((item, i) => ({ item, i }));
  const byStat = (key: string) => (a: (typeof list)[number], b: (typeof list)[number]) =>
    statOf(b.item, key) - statOf(a.item, key) || b.item.at - a.item.at || a.i - b.i;
  if (sort === "oldest") list.sort((a, b) => (a.item.at || Number.MAX_SAFE_INTEGER) - (b.item.at || Number.MAX_SAFE_INTEGER) || a.i - b.i);
  else if (sort === "views") list.sort(byStat("views"));
  else if (sort === "likes") list.sort(byStat("likes"));
  else if (sort === "comments") list.sort(byStat("comments"));
  else if (sort === "shares") list.sort(byStat("shares"));
  else if (sort === "short") {
    list.sort(
      (a, b) =>
        Number(b.item.kind === "short" || b.item.kind === "reel") - Number(a.item.kind === "short" || a.item.kind === "reel") ||
        b.item.at - a.item.at ||
        a.i - b.i,
    );
  } else if (sort === "video") {
    list.sort(
      (a, b) =>
        Number(a.item.kind === "short" || a.item.kind === "reel") - Number(b.item.kind === "short" || b.item.kind === "reel") ||
        b.item.at - a.item.at ||
        a.i - b.i,
    );
  } else {
    list.sort((a, b) => b.item.at - a.item.at || a.i - b.i);
  }
  return list.map((row) => row.item);
}

function when(at: number): string {
  if (!at) return "";
  const d = new Date(at);
  if (Number.isNaN(d.getTime())) return "";
  return `${d.getMonth() + 1}/${d.getDate()}/${d.getFullYear()}`;
}

function prettyHandle(row: TrackedProfile): string {
  if (row.platform === "facebook") return row.title || row.handle.replace(/-\d+$/, "").replace(/-/g, " ");
  return row.handle.replace(/^@/, "");
}

function feedUrlOf(row: TrackedProfile): string {
  if (row.platform === "facebook") return "https://www.facebook.com/105894818641566";
  if (row.platform === "instagram") return "https://www.instagram.com/clauivory/";
  if (row.platform === "youtube") return "https://www.youtube.com/@claudiaivory";
  if (row.platform === "tiktok") return "https://www.tiktok.com/@clauivory";
  return row.url;
}

function peekAccount(): string {
  if (typeof window === "undefined") return "";
  try {
    const raw = localStorage.getItem("smm-prefs");
    const id = JSON.parse(raw || "{}")?.state?.lastAccount;
    return typeof id === "string" ? id : "";
  } catch {
    return "";
  }
}

function mediaSrc(url: string | null | undefined): string | null {
  if (!url) return null;
  try {
    const host = new URL(url).hostname.replace(/^www\./, "").toLowerCase();
    if (
      host.includes("instagram") ||
      host.includes("fbcdn") ||
      host.startsWith("scontent") ||
      host.includes("tiktokcdn") ||
      host.includes("socialblade") ||
      /instagram\.com\/.+\/media/i.test(url)
    ) {
      return `/api/smm-media?u=${encodeURIComponent(url)}`;
    }
  } catch {
    return url;
  }
  return url;
}

function isShort(item: ProfileItem): boolean {
  return item.kind === "short" || /\/shorts\//i.test(item.url);
}

function kindLabel(kind: string): string {
  if (kind === "short") return "Short";
  if (kind === "reel") return "Reel";
  if (kind === "post") return "Post";
  return "Video";
}

const FeedCard = memo(function FeedCard({
  item,
  platform,
  top,
  onAdd,
}: {
  item: ProfileItem;
  platform: string;
  top: number;
  onAdd: (item: ProfileItem, key: string, label: string) => void;
}) {
  const thumb = mediaSrc(item.thumb);
  const [src, setSrc] = useState(thumb);
  const tried = useRef(false);
  useEffect(() => {
    tried.current = false;
    setSrc(thumb);
  }, [thumb]);
  const by = new Map(item.stats.map((s) => [s.key, s]));
  const stats =
    platform === "instagram"
      ? IG_SLOTS.map((slot) => ({ key: slot.key, label: slot.label, value: by.get(slot.key)?.value ?? null }))
      : rankStats(item.stats).filter((s) => {
          if (platform === "facebook" && item.kind === "post" && metricIdFor(platform, s.key, s.label) === "views") return false;
          return true;
        });
  return (
    <a
      href={item.url}
      target="_blank"
      rel="noreferrer"
      style={{ transform: `translate3d(0, ${top}px, 0)`, height: CARD_H }}
      className="acct-card absolute inset-x-0 top-0 flex gap-3 overflow-hidden rounded-2xl bg-surface ring-1 ring-border"
    >
      {src ? (
        <img
          src={src}
          alt=""
          width={112}
          height={CARD_H}
          loading="lazy"
          decoding="async"
          className="h-full w-24 shrink-0 object-cover sm:w-28"
          onError={() => {
            if (tried.current || platform !== "tiktok" || !item.url) {
              setSrc(null);
              return;
            }
            tried.current = true;
            void loadLinkPreview({ data: { url: item.url } })
              .then((preview) => {
                const next = mediaSrc(preview.thumb);
                setSrc(next && next !== src ? next : null);
              })
              .catch(() => setSrc(null));
          }}
        />
      ) : (
        <div className="flex h-full w-24 shrink-0 items-center justify-center bg-elevated sm:w-28">
          <TabMark id={platform} selected />
        </div>
      )}
      <div className="flex min-w-0 flex-1 flex-col justify-center py-2 pr-3">
        <p className="truncate text-sm font-semibold text-fg">{item.title}</p>
        <p className="mt-0.5 text-[11px] text-muted">
          {kindLabel(item.kind)}
          {item.at ? ` · ${when(item.at)}` : ""}
        </p>
        <div
          className="mt-1 grid w-full text-[11px] font-semibold text-fg"
          style={{ gridTemplateColumns: `repeat(${Math.max(stats.length, 1)}, minmax(0, 1fr))` }}
        >
          {stats.map((s, si) => (
            <span key={s.key} className={cn("flex min-w-0 flex-col items-center gap-0.5 px-0.5", si > 0 && "border-l border-border")}>
              <span className="max-w-full truncate text-[8px] font-medium leading-none text-muted">{s.label}</span>
              <span className="max-w-full truncate tabular-nums leading-none">{s.value == null ? "—" : formatCount(s.value)}</span>
              <button
                type="button"
                className="add-pill max-w-full px-1"
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  onAdd(item, s.key, s.label);
                }}
              >
                to add
              </button>
            </span>
          ))}
        </div>
      </div>
    </a>
  );
});

function placeProfiles(list: TrackedProfile[], id: string, slot: number): TrackedProfile[] {
  const item = list.find((p) => p.id === id);
  if (!item) return list;
  const rest = list.filter((p) => p.id !== id);
  const i = Math.max(0, Math.min(slot, rest.length));
  return [...rest.slice(0, i), item, ...rest.slice(i)];
}

function AccountLogos({ tab, onTab }: { tab: string; onTab: (id: string) => void }) {
  const profiles = useSmmProfiles((s) => s.profiles);
  const rowRef = useRef<HTMLDivElement>(null);
  const drag = useRef<{
    id: string;
    x: number;
    y: number;
    ox: number;
    oy: number;
    w: number;
    from: number;
    moved: boolean;
    ready: boolean;
    mouse: boolean;
    timer: number;
  } | null>(null);
  const [holding, setHolding] = useState<string | null>(null);
  const [slot, setSlot] = useState<number | null>(null);
  const [ghost, setGhost] = useState<{ id: string; platform: string; x: number; y: number } | null>(null);
  const [focus, setFocus] = useState(tab);
  const ghostRef = useRef<HTMLDivElement>(null);
  const slotNow = useRef<number | null>(null);
  const raf = useRef(0);

  function slotAt(x: number, y: number): number {
    const row = rowRef.current;
    const skip = drag.current?.id;
    if (!row) return 0;
    const chips = [...row.querySelectorAll<HTMLElement>("[data-account]")].filter((el) => el.dataset.account !== skip);
    for (let i = 0; i < chips.length; i++) {
      const r = chips[i]!.getBoundingClientRect();
      if (y < r.top - 4) return i;
      if (y <= r.bottom + 4 && x < r.left + r.width / 2) return i;
    }
    return chips.length;
  }

  function ghostPos(d: NonNullable<typeof drag.current>, x: number, y: number) {
    return { x: x - d.ox + d.w / 2, y: y - d.oy + d.w / 2 };
  }

  function moveGhost(x: number, y: number) {
    const el = ghostRef.current;
    if (!el) return;
    el.style.transform = `translate3d(${x}px, ${y}px, 0) translate(-50%, -50%) scale(1.08)`;
  }

  function lift(d: NonNullable<typeof drag.current>, x: number, y: number) {
    if (d.ready) return;
    d.ready = true;
    window.clearTimeout(d.timer);
    const p = ghostPos(d, x, y);
    const platform = useSmmProfiles.getState().profiles.find((row) => row.id === d.id)?.platform || d.id;
    slotNow.current = d.from;
    setHolding(d.id);
    setFocus(d.id);
    setSlot(d.from);
    setGhost({ id: d.id, platform, x: p.x, y: p.y });
    requestAnimationFrame(() => moveGhost(p.x, p.y));
  }

  useEffect(() => {
    function lockScroll(on: boolean) {
      document.documentElement.style.overflow = on ? "hidden" : "";
      document.body.style.overflow = on ? "hidden" : "";
      document.body.style.touchAction = on ? "none" : "";
    }
    function blockTouch(e: TouchEvent) {
      if (drag.current) e.preventDefault();
    }
    function move(e: PointerEvent) {
      const d = drag.current;
      if (!d) return;
      e.preventDefault();
      const dist = Math.hypot(e.clientX - d.x, e.clientY - d.y);
      if (!d.ready) {
        if (dist < (d.mouse ? 4 : 8)) return;
        lift(d, e.clientX, e.clientY);
        lockScroll(true);
      }
      d.moved = true;
      const p = ghostPos(d, e.clientX, e.clientY);
      cancelAnimationFrame(raf.current);
      raf.current = requestAnimationFrame(() => moveGhost(p.x, p.y));
      const next = slotAt(e.clientX, e.clientY);
      if (slotNow.current !== next) {
        slotNow.current = next;
        setSlot(next);
      }
    }
    function up(e: PointerEvent) {
      const d = drag.current;
      drag.current = null;
      cancelAnimationFrame(raf.current);
      lockScroll(false);
      if (!d) return;
      window.clearTimeout(d.timer);
      onTab(d.id);
      setFocus(d.id);
      if (d.ready && d.moved) {
        useSmmProfiles.getState().reorder(d.id, slotNow.current ?? slotAt(e.clientX, e.clientY));
        void syncCloudNow();
      }
      setHolding(null);
      setSlot(null);
      setGhost(null);
      slotNow.current = null;
    }
    window.addEventListener("pointermove", move, { passive: false });
    window.addEventListener("pointerup", up);
    window.addEventListener("pointercancel", up);
    window.addEventListener("touchmove", blockTouch, { passive: false });
    return () => {
      lockScroll(false);
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      window.removeEventListener("pointercancel", up);
      window.removeEventListener("touchmove", blockTouch);
    };
  }, [onTab]);

  useEffect(() => {
    if (!holding) setFocus(tab);
  }, [tab, holding]);

  const shown = holding && slot != null ? placeProfiles(profiles, holding, slot) : profiles;

  return (
    <>
      <div className="acct-logo-wrap">
        <div
          ref={rowRef}
          className={cn("acct-logo-tray", holding && "is-edit")}
          role="tablist"
          aria-label="Accounts"
        >
          {shown.map((p) => {
            const on = p.id === (holding || focus || tab);
            return (
              <div key={p.id} data-account={p.id} className="fav-chip-wrap">
                <button
                  type="button"
                  role="tab"
                  aria-label={p.title || p.platform}
                  aria-selected={on}
                  onPointerDown={(e) => {
                    if (e.button !== 0) return;
                    e.currentTarget.setPointerCapture(e.pointerId);
                    const r = e.currentTarget.getBoundingClientRect();
                    const id = p.id;
                    const mouse = e.pointerType === "mouse" || e.pointerType === "pen";
                    const timer = mouse
                      ? 0
                      : window.setTimeout(() => {
                          const cur = drag.current;
                          if (!cur || cur.id !== id) return;
                          lift(cur, cur.x, cur.y);
                          document.documentElement.style.overflow = "hidden";
                          document.body.style.overflow = "hidden";
                          document.body.style.touchAction = "none";
                          navigator.vibrate?.(12);
                        }, 280);
                    drag.current = {
                      id,
                      x: e.clientX,
                      y: e.clientY,
                      ox: e.clientX - r.left,
                      oy: e.clientY - r.top,
                      w: r.width,
                      from: useSmmProfiles.getState().profiles.findIndex((row) => row.id === id),
                      moved: false,
                      ready: false,
                      mouse,
                      timer,
                    };
                  }}
                  className={cn("acct-logo-btn", on && "is-on", holding === p.id && "is-lift")}
                >
                  <span className="scale-150">
                    <TabMark id={p.platform} selected={on} />
                  </span>
                </button>
              </div>
            );
          })}
        </div>
      </div>
      {ghost
        ? createPortal(
            <div
              ref={ghostRef}
              className="acct-ghost"
              style={{ transform: `translate3d(${ghost.x}px, ${ghost.y}px, 0) translate(-50%, -50%) scale(1.08)` }}
            >
              <span className="scale-150">
                <TabMark id={ghost.platform} selected />
              </span>
            </div>,
            document.body,
          )
        : null}
    </>
  );
}

export function StatsView() {
  const profiles = useSmmProfiles((s) => s.profiles);
  const live = useSmmProfiles((s) => s.live);
  const liveAt = useSmmProfiles((s) => s.liveAt);
  const feeds = useSmmProfiles((s) => s.feeds);
  const lastAccount = useSmmPrefs((s) => s.lastAccount);
  const pickedAt = useRef(0);
  const [tab, setTab] = useState(() => peekAccount() || lastAccount || profiles[0]?.id || "");
  const [sort, setSort] = useState<SortId>("latest");
  const [kind, setKind] = useState<KindFilter>("all");
  const [more, setMore] = useState(false);
  const [catalogReady, setCatalogReady] = useState(false);
  const [picker, setPicker] = useState<{ platform: string; metric: string; label: string; link: string; kind: string } | null>(null);
  const [placedOk, setPlacedOk] = useState(false);
  const scroller = useRef<HTMLDivElement>(null);
  const sentinel = useRef<HTMLDivElement>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const loading = useRef(false);
  const paging = useRef(false);
  const raf = useRef(0);
  const shownLen = useRef(0);
  const vis = useRef({ start: 0, end: 16 });
  const [range, setRange] = useState({ start: 0, end: 16 });

  const row = profiles.find((p) => p.id === tab) || profiles[0];
  const pack = row ? feeds[row.id] : undefined;
  const rawItems = pack?.items ?? EMPTY_ITEMS;
  const items = useMemo(
    () => (row?.platform === "tiktok" ? tiktokConsecutive(rawItems, row.handle) : rawItems),
    [rawItems, row?.platform, row?.handle],
  );
  const cursor = pack?.cursor || null;
  const busy = Boolean(row) && !pack && !items.length;

  useEffect(() => {
    if (!profiles.length) return;
    if (tab && profiles.some((p) => p.id === tab)) return;
    const saved = useSmmPrefs.getState().lastAccount || peekAccount();
    setTab(profiles.find((p) => p.id === saved)?.id || profiles[0]!.id);
  }, [profiles, tab]);

  useEffect(() => {
    if (!lastAccount || lastAccount === tab) return;
    const at = useSmmPrefs.getState().lastAccountAt ?? 0;
    if (pickedAt.current && at < pickedAt.current) return;
    if (profiles.some((p) => p.id === lastAccount)) setTab(lastAccount);
  }, [lastAccount, profiles, tab]);

  const pickAccount = useCallback((id: string) => {
    pickedAt.current = Date.now();
    setTab(id);
    useSmmPrefs.getState().setLastAccount(id);
  }, []);

  useEffect(() => {
    setSort("latest");
    setKind("all");
  }, [row?.id]);

  const igMiss = useRef(new Map<string, number>());
  useEffect(() => {
    if (!row || row.platform !== "instagram" || !items.length) return;
    let alive = true;
    let pass = 0;
    async function fill() {
      const packNow = useSmmProfiles.getState().feeds[row!.id];
      const ids = (packNow?.items || [])
        .filter((item) => item.id && !item.stats.some((s) => s.key === "views") && (igMiss.current.get(item.id) ?? 0) < 2)
        .map((item) => item.id)
        .slice(0, 12);
      if (!alive || !ids.length || pass >= 6) return;
      pass += 1;
      const map = await enrichSmmInstagram({ data: { ids } }).catch(() => null);
      if (!alive) return;
      const latest = useSmmProfiles.getState().feeds[row!.id];
      const prev = latest?.items || [];
      const next = prev.map((item) => {
        const extra = map?.[item.id];
        if (!extra?.length) {
          if (ids.includes(item.id)) igMiss.current.set(item.id, (igMiss.current.get(item.id) ?? 0) + 1);
          return item;
        }
        const bag = new Map(item.stats.map((s) => [s.key, s]));
        for (const s of extra) bag.set(s.key, s);
        return { ...item, stats: [...bag.values()] };
      });
      useSmmProfiles.getState().setFeed(row!.id, next, latest?.cursor ?? null);
      if (next.some((item) => item.id && !item.stats.some((s) => s.key === "views") && (igMiss.current.get(item.id) ?? 0) < 2)) {
        window.setTimeout(() => void fill(), 800);
      }
    }
    void fill();
    return () => {
      alive = false;
    };
  }, [row?.id, items.length]);

  useEffect(() => {
    if (!row) return;
    const skipFeed = Boolean(pack?.items.length && Date.now() - pack.at < 20_000 && !(row.platform === "tiktok" && !pack.cursor));
    if (skipFeed && row.stats.length) {
      setCatalogReady(true);
      return;
    }
    let alive = true;
    loading.current = !skipFeed;
    const url = feedUrlOf(row);
    const wait = window.setTimeout(() => {
      if (!alive) return;
      loading.current = false;
    }, 15_000);

    async function pull() {
      try {
        if (!row.stats.length) {
          const next = await lookupSmmProfile({ data: { url, live: true } }).catch(() => null);
          if (alive && next) useSmmProfiles.getState().patch(next);
        }
        if (!skipFeed) {
          const feed = await loadSmmProfileFeed({ data: { url, live: true } }).catch(() => null);
          const have = useSmmProfiles.getState().feeds[row.id]?.items.length || 0;
          if (alive && feed?.items.length && feed.items.length >= have) {
            useSmmProfiles.getState().setFeed(row.id, feed.items, feed.cursor);
          }
        }
        const needStats = !useSmmProfiles.getState().profiles.find((p) => p.id === row.id)?.stats.length;
        const needFeed = !useSmmProfiles.getState().feeds[row.id]?.items.length;
        if (needStats || needFeed) {
          const res = await fetch(`/api/smm-account?platform=${encodeURIComponent(row.platform)}&url=${encodeURIComponent(url)}`);
          const json = (await res.json()) as { look?: LookedProfile; feed?: { items: ProfileItem[]; cursor: string | null } };
          if (!alive) return;
          if (json.look) useSmmProfiles.getState().patch(json.look);
          const have = useSmmProfiles.getState().feeds[row.id]?.items.length || 0;
          if (json.feed?.items.length && json.feed.items.length >= have) {
            useSmmProfiles.getState().setFeed(row.id, json.feed.items, json.feed.cursor);
          }
        }
      } catch {
        /* keep last snapshot */
      } finally {
        loading.current = false;
        window.clearTimeout(wait);
        setCatalogReady(true);
      }
    }

    void pull();
    return () => {
      alive = false;
      window.clearTimeout(wait);
    };
  }, [row?.id, row?.url]);

  useEffect(() => {
    if (!row?.id || !cursor || paging.current) return;
    const accountId = row.id;
    const platform = row.platform;
    const handle = row.handle;
    let alive = true;
    paging.current = true;
    void (async () => {
      try {
        while (alive) {
          const packNow = useSmmProfiles.getState().feeds[accountId];
          const cur = packNow?.cursor;
          const have = packNow?.items.length || 0;
          const total =
            useSmmProfiles.getState().profiles.find((p) => p.id === accountId)?.stats.find((s) => s.key === "videos")?.value ||
            useSmmProfiles.getState().profiles.find((p) => p.id === accountId)?.stats.find((s) => s.key === "posts")?.value ||
            0;
          if (!cur) return;
          if (total > 0 && have >= total + 5) {
            useSmmProfiles.getState().setFeed(accountId, packNow?.items || [], null);
            return;
          }
          const feed = await loadSmmProfileFeed({ data: { url: feedUrlOf(row), cursor: cur } }).catch(() => null);
          if (!alive || !feed) return;
          const prev = useSmmProfiles.getState().feeds[accountId]?.items || [];
          const mine = platform === "tiktok" ? tiktokConsecutive([...prev, ...feed.items], handle) : mergeFeedItems(prev, feed.items);
          const grew = mine.length > prev.length;
          const done = !grew || !feed.cursor || (total > 0 && mine.length >= total + 5);
          useSmmProfiles.getState().setFeed(accountId, mine, done ? null : feed.cursor);
          if (done) return;
        }
      } finally {
        paging.current = false;
      }
    })();
    return () => {
      alive = false;
      paging.current = false;
    };
  }, [row?.id, Boolean(cursor)]);

  async function loadMore() {
    if (!row || loading.current || paging.current) return;
    const packNow = useSmmProfiles.getState().feeds[row.id];
    const cur = packNow?.cursor;
    if (!cur) return;
    const total =
      row.stats.find((s) => s.key === "videos")?.value || row.stats.find((s) => s.key === "posts")?.value || 0;
    if (total && (packNow?.items.length || 0) >= total) {
      useSmmProfiles.getState().setFeed(row.id, packNow.items, null);
      return;
    }
    loading.current = true;
    setMore(true);
    try {
      const feed = await loadSmmProfileFeed({ data: { url: feedUrlOf(row), cursor: cur } });
      const prev = useSmmProfiles.getState().feeds[row.id]?.items || items;
      const mine =
        row.platform === "tiktok"
          ? tiktokConsecutive([...prev, ...feed.items], row.handle)
          : mergeFeedItems(prev, feed.items);
      const grew = mine.length > prev.length;
      const done = !grew || (total > 0 && mine.length >= total) || !feed.cursor;
      useSmmProfiles.getState().setFeed(row.id, mine, done ? null : feed.cursor);
    } catch {
      /* keep what we have */
    } finally {
      loading.current = false;
      setMore(false);
    }
  }

  useEffect(() => {
    const root = scroller.current;
    const el = sentinel.current;
    if (!root || !el || !cursor) return;
    const io = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) void loadMore();
      },
      { root, rootMargin: "480px 0px" },
    );
    io.observe(el);
    return () => io.disconnect();
  }, [cursor, row?.id]);

  const options = useMemo(() => (row ? sortsFor(row.platform, items) : []), [row, items]);
  const kindOn = row?.platform === "youtube";
  const shown = useMemo(() => {
    const list =
      !kindOn || kind === "all" ? items : items.filter((item) => (kind === "short" ? isShort(item) : !isShort(item)));
    return applySort(list, sort);
  }, [items, sort, kind, kindOn]);
  const videoTotal = row?.stats.find((s) => s.key === "videos")?.value || row?.stats.find((s) => s.key === "posts")?.value || 0;
  const catalogWait = Boolean(row) && !catalogReady;
  shownLen.current = shown.length;
  const start = range.start;
  const end = Math.min(shown.length, range.end);
  const slice = shown.slice(start, end);
  const head = useMemo(() => (row ? headerStats(row, items) : []), [row, items]);
  const platform = row?.platform;
  const onAdd = useCallback(
    (item: ProfileItem, key: string, label: string) => {
      if (!platform) return;
      setPicker({
        platform,
        metric: metricIdFor(platform, key, label),
        label,
        link: item.url,
        kind: item.kind,
      });
    },
    [platform],
  );

  useEffect(() => {
    const el = scroller.current;
    if (!el) return;
    vis.current = { start: 0, end: 16 };
    setRange({ start: 0, end: 16 });
    el.scrollTop = 0;
    const sync = () => {
      raf.current = 0;
      const list = listRef.current;
      const y = list
        ? Math.max(0, el.getBoundingClientRect().top - list.getBoundingClientRect().top)
        : el.scrollTop;
      const h = el.clientHeight || 420;
      const nextStart = Math.max(0, Math.floor(y / ROW_H) - 3);
      const nextEnd = Math.min(shownLen.current, nextStart + Math.ceil(h / ROW_H) + 6);
      if (vis.current.start === nextStart && vis.current.end === nextEnd) return;
      vis.current = { start: nextStart, end: nextEnd };
      setRange(vis.current);
    };
    const onScroll = () => {
      if (!raf.current) raf.current = requestAnimationFrame(sync);
    };
    el.addEventListener("scroll", onScroll, { passive: true });
    const ro = new ResizeObserver(onScroll);
    ro.observe(el);
    sync();
    return () => {
      el.removeEventListener("scroll", onScroll);
      ro.disconnect();
      if (raf.current) cancelAnimationFrame(raf.current);
      raf.current = 0;
    };
  }, [sort, kind, row?.id]);

  useEffect(() => {
    if (!cursor || loading.current) return;
    if (end >= shown.length - 6) void loadMore();
  }, [end, shown.length, cursor]);

  if (!row) {
    return <p className="px-3 py-6 text-sm text-muted">No accounts yet. Admin can add profile links in Settings.</p>;
  }

  return (
    <>
    <div className="flex h-full min-h-0 flex-col bg-bg">
      <div className="acct-stick">
        <div className="mx-auto flex max-w-2xl flex-col gap-3">
          <div className="flex items-center justify-between gap-3">
            <p className="acct-title">My Accounts</p>
            <p className="flex items-center gap-1.5 text-[11px] font-semibold text-fg">
              <span className={live || liveAt || row.stats.length || items.length ? "live-dot" : "size-1.5 rounded-full bg-muted"} />
              {live || liveAt || row.stats.length || items.length ? "Live" : "Connecting…"}
            </p>
          </div>
          <AccountLogos tab={tab} onTab={pickAccount} />
        </div>
      </div>
      <div ref={scroller} className="acct-feed mx-auto min-h-0 w-full max-w-2xl flex-1 overflow-y-auto px-3 py-3">
        <article className="overflow-hidden rounded-xl bg-surface ring-1 ring-border">
          <div className="flex items-center gap-2 px-2.5 py-2">
            {mediaSrc(row.avatar) ? (
              <img src={mediaSrc(row.avatar)!} alt="" className="size-9 shrink-0 rounded-full object-cover" />
            ) : (
              <div className="flex size-9 shrink-0 items-center justify-center rounded-full bg-elevated">
                <TabMark id={row.platform} selected />
              </div>
            )}
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-semibold leading-tight text-fg">{row.title || prettyHandle(row)}</p>
              <a href={row.url} target="_blank" rel="noreferrer" className="truncate text-[11px] leading-tight text-muted">
                {row.platform === "facebook" ? row.title || "Facebook" : `@${prettyHandle(row)}`}
              </a>
            </div>
          </div>
          <div className="flex flex-wrap border-t border-border">
              {head.map((s) => (
                <div key={s.key} className="w-1/4 box-border border-b border-r border-border px-1.5 py-1.5 text-center">
                  <p className="text-[9px] font-medium tracking-wide text-muted uppercase">{s.label}</p>
                  <p className={cn("text-sm font-bold leading-tight", s.value == null ? "text-muted" : "text-fg")}>
                    {s.value == null ? <span className="stat-skel" aria-hidden /> : formatCount(s.value)}
                  </p>
                </div>
              ))}
            </div>
        </article>
        <div className="mt-3 flex items-center gap-2">
          <p className="shrink-0 text-xs font-medium tracking-wide text-muted uppercase">Content</p>
          {kindOn ? (
            <div className="ml-auto flex items-center gap-1">
              {(
                [
                  ["video", "Videos"],
                  ["short", "Shorts"],
                  ["all", "All"],
                ] as const
              ).map(([id, label]) => {
                const on = kind === id;
                return (
                  <button
                    key={id}
                    type="button"
                    aria-pressed={on}
                    onClick={() => setKind(id)}
                    className={cn("flex items-center gap-1 text-[10px] font-semibold", on ? "text-fg" : "text-muted")}
                  >
                    <span
                      className={cn(
                        "flex size-3.5 items-center justify-center rounded-[3px] border text-[9px] leading-none",
                        on ? "border-[#3dff6a] bg-[#3dff6a] text-black" : "border-current",
                      )}
                    >
                      {on ? "✓" : ""}
                    </span>
                    {label}
                  </button>
                );
              })}
            </div>
          ) : null}
          {options.length ? (
            <label className={cn("flex items-center gap-2 text-xs text-muted", !kindOn && "ml-auto")}>
              Sort
              <select
                value={sort}
                onChange={(e) => setSort(e.target.value as SortId)}
                className="rounded-lg bg-elevated px-2 py-1 text-xs font-semibold text-fg"
              >
                {options.map((o) => (
                  <option key={o.id} value={o.id}>
                    {o.label}
                  </option>
                ))}
              </select>
            </label>
          ) : null}
        </div>
        {kindOn && kind !== "all" && !shown.length && !catalogWait ? (
          <p className="mt-2 text-center text-xs text-muted">
            {cursor || more ? `Looking for ${kind === "short" ? "Shorts" : "Videos"}…` : `No ${kind === "short" ? "Shorts" : "Videos"} in this list.`}
          </p>
        ) : null}
        {catalogWait && !shown.length ? (
          <p className="mt-2 rounded-xl bg-elevated px-3 py-1.5 text-center text-[11px] font-semibold text-fg ring-1 ring-border">
            Loading posts…
          </p>
        ) : null}
        {busy && !shown.length ? <p className="mt-3 text-sm text-muted">Loading posts…</p> : null}
        {!busy && !shown.length && !catalogWait && !(kindOn && kind !== "all") ? (
          <p className="mt-3 text-sm text-muted">
            {row.platform === "facebook"
              ? "Facebook posts didn’t load. Open this tab again in a moment."
              : row.platform === "instagram"
                ? "Public Instagram hid this post list just now. Pull again in a moment."
                : "No public posts yet."}
          </p>
        ) : null}

        <div ref={listRef} className="relative mt-3" style={{ height: shown.length * ROW_H }}>
          {slice.map((item, i) => (
            <FeedCard
              key={item.id}
              item={item}
              platform={row.platform}
              top={(start + i) * ROW_H}
              onAdd={onAdd}
            />
          ))}
        </div>
        <div ref={sentinel} className="h-8" />
        {more ? (
          <p className="py-2 text-center text-xs text-muted">Loading more…</p>
        ) : null}
        {!catalogWait && !more && items.length ? (
          <p className="py-2 text-center text-[11px] leading-relaxed text-muted">
            {row.platform === "tiktok"
              ? (() => {
                  const total = row.stats.find((s) => s.key === "videos")?.value;
                  if (cursor) {
                    return total
                      ? `Ranking ${items.length} of ${formatCount(total)}`
                      : "Loading the rest of this account…";
                  }
                  return total && items.length < total
                    ? `Showing ${items.length} of ${formatCount(total)} videos.`
                    : "End of the videos we could load from this profile.";
                })()
              : cursor && videoTotal && items.length < videoTotal
                ? `Ranking ${items.length} of ${formatCount(videoTotal)}`
                : !cursor
                  ? sort === "oldest" && (!videoTotal || items.length >= videoTotal)
                    ? row.platform === "youtube"
                      ? "This list starts at the first public upload."
                      : row.platform === "instagram"
                        ? "This list starts at the first Instagram post."
                        : row.platform === "facebook"
                          ? "This list starts at the first Facebook post."
                          : "End of list"
                    : "End of list"
                  : null}
          </p>
        ) : null}
      </div>
    </div>
    {picker ? (
      <AddServiceSheet
        open
        platform={picker.platform}
        metric={picker.metric}
        label={picker.label}
        link={picker.link}
        kind={picker.kind}
        onClose={() => setPicker(null)}
        onPlaced={() => setPlacedOk(true)}
      />
    ) : null}
    <OrderConfirm open={placedOk} onClose={() => setPlacedOk(false)} />
    </>
  );
}
