import { useEffect } from "react";
import { warmAllCatalog } from "@/lib/smm/all-catalog";
import { CATALOG_FRESH_MS } from "@/lib/smm/catalog-snap";

/** Pulls the service lists in the background so All services / To add open from cache. */
export function CatalogWarm() {
  useEffect(() => {
    warmAllCatalog();
    const kick = () => {
      if (document.visibilityState === "visible") warmAllCatalog();
    };
    document.addEventListener("visibilitychange", kick);
    const id = window.setInterval(kick, CATALOG_FRESH_MS);
    return () => {
      document.removeEventListener("visibilitychange", kick);
      window.clearInterval(id);
    };
  }, []);
  return null;
}
