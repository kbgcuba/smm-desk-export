import { useEffect, useState } from "react";
import { loadApiWatch, type ApiWatch } from "@/lib/smm/fn";
import { cn } from "@/lib/utils";

export function ApiWatch() {
  const [rows, setRows] = useState<ApiWatch[]>([]);

  useEffect(() => {
    let alive = true;
    async function tick() {
      try {
        const next = await loadApiWatch();
        if (alive) setRows(next);
      } catch {
        /* keep last */
      }
    }
    void tick();
    const id = window.setInterval(() => void tick(), 6 * 60_000);
    return () => {
      alive = false;
      window.clearInterval(id);
    };
  }, []);

  const alerts = rows.filter((row) => row.status === "soon" || row.status === "dead");
  if (!alerts.length) return null;

  return (
    <div className="flex flex-col gap-1.5 px-3 pt-2">
      {alerts.map((row) => (
        <p
          key={row.id}
          className={cn(
            "rounded-xl px-3 py-2 text-xs font-semibold",
            row.status === "dead"
              ? "bg-elevated text-neon-red ring-1 ring-neon-red/50"
              : "bg-elevated text-yellow-200 ring-1 ring-yellow-300/60",
          )}
        >
          {row.label}: {row.note || "Reconnect this API in Settings."}
        </p>
      ))}
    </div>
  );
}
