import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { BarChart3, Calendar, Globe, LayoutGrid, NotebookText, Settings, Star, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { brandPath } from "@/lib/smm/wp-badges";
import { useSmmDesks } from "@/lib/smm/desks";
import { syncCloudNow } from "@/components/cloud-sync";
import { useSmmLive } from "@/lib/smm/live-store";
import { PANEL_LABELS } from "@/lib/smm/fn";
import { formatMoney } from "@/lib/format";

export type View = string;

const TOP = ["all", "links", "stats"] as const;

export function PlatformTabs({ tab, onTab }: { tab: View; onTab: (tab: View) => void }) {
  const desks = useSmmDesks((s) => s.desks);
  const deskOn = desks.some((d) => d.id === tab);
  const lastDesk = useRef(desks[0]?.id ?? "tiktok");
  if (deskOn) lastDesk.current = tab;
  const topTab = tab === "all" || tab === "orders" || tab === "settings" || tab === "stats" || tab === "favorites" || tab === "links" ? tab : "favorites";
  const index = TOP.indexOf(topTab as (typeof TOP)[number]);
  const settingsOn = tab === "settings";
  const favOn = topTab === "favorites";
  const ordersOn = tab === "orders";
  const [editing, setEditing] = useState(false);

  function openFavorites() {
    const id = desks.some((d) => d.id === lastDesk.current) ? lastDesk.current : desks[0]?.id;
    onTab(id || "favorites");
  }

  return (
    <header className="shrink-0 border-b border-border bg-bg pt-[env(safe-area-inset-top)]" data-fav={favOn ? "" : undefined}>
      <BalanceBar
        settingsOn={settingsOn}
        onSettings={() => onTab("settings")}
      />
      <div className="nav-rule" aria-hidden />
      <div className={cn("flex items-center gap-2 px-3", favOn ? "pt-2 pb-1" : "py-2")}>
          <button
            type="button"
            aria-label="Favorites"
            aria-pressed={favOn}
            onClick={openFavorites}
            data-on={favOn || undefined}
            className={cn(
              "icon-badge is-fav relative flex size-14 shrink-0 items-center justify-center rounded-full",
              "transition-[color,transform,background-color,box-shadow] duration-150 ease-out",
              "active:scale-[0.96]",
              favOn ? "bg-surface" : "bg-elevated",
            )}
          >
            <Star
              className="size-5"
              fill={favOn ? "currentColor" : "none"}
              strokeWidth={favOn ? 0 : 2.4}
            />
          </button>
          <span className="nav-sep" aria-hidden />
          <div
            className="tab-track min-h-14 min-w-0 flex-1"
            style={{ ["--tabs" as string]: TOP.length }}
            role="tablist"
            aria-label="Platform"
          >
            <div
              className="tab-pill"
              data-i={index}
              hidden={index < 0}
              style={index >= 0 ? { transform: `translateX(${index * 100}%)` } : { opacity: 0 }}
            />
            {TOP.map((id) => {
              const selected = topTab === id;
              const label = id === "all" ? "All services" : id === "links" ? "Links" : "My Accounts";
              return (
                <button
                  key={id}
                  type="button"
                  role="tab"
                  aria-selected={selected}
                  onClick={() => onTab(id)}
                  className={cn(
                    "relative z-10 flex min-h-14 min-w-0 items-center justify-center gap-1.5 overflow-hidden rounded-full px-1.5",
                    "text-base font-bold tracking-tight",
                    "transition-[color] duration-150 ease-out",
                    "active:scale-[0.96]",
                    selected ? "text-fg" : "text-muted",
                  )}
                >
                  <TabMark id={id} selected={selected} />
                  <span className="tab-label min-w-0 truncate">{label}</span>
                </button>
              );
            })}
          </div>
          <span className="nav-sep" aria-hidden />
          <button
            type="button"
            aria-label="Orders"
            aria-pressed={ordersOn}
            onClick={() => onTab("orders")}
            data-on={ordersOn || undefined}
            className={cn(
              "icon-badge is-orders relative flex size-14 shrink-0 items-center justify-center rounded-full",
              "transition-[color,transform,background-color,box-shadow] duration-150 ease-out",
              "active:scale-[0.96]",
              ordersOn ? "bg-surface" : "bg-elevated",
            )}
          >
            <Calendar className="size-5" strokeWidth={2.4} />
          </button>
      </div>
      {favOn && desks.length ? (
        <>
          <div className="nav-rule" aria-hidden />
          <FavSub tab={tab} onTab={onTab} editing={editing} setEditing={setEditing} />
        </>
      ) : null}
    </header>
  );
}

function placeDesks<T extends { id: string }>(list: T[], id: string, slot: number): T[] {
  const item = list.find((d) => d.id === id);
  if (!item) return list;
  const rest = list.filter((d) => d.id !== id);
  const i = Math.max(0, Math.min(slot, rest.length));
  return [...rest.slice(0, i), item, ...rest.slice(i)];
}

function FavSub({
  tab,
  onTab,
  editing,
  setEditing,
}: {
  tab: string;
  onTab: (tab: string) => void;
  editing: boolean;
  setEditing: (v: boolean | ((on: boolean) => boolean)) => void;
}) {
  const desks = useSmmDesks((s) => s.desks);
  const rowRef = useRef<HTMLDivElement>(null);
  const drag = useRef<{
    id: string;
    x: number;
    y: number;
    ox: number;
    oy: number;
    w: number;
    from: number;
    moved: boolean;
    ready: boolean;
    mouse: boolean;
    label: string;
    timer: number;
  } | null>(null);
  const [holding, setHolding] = useState<string | null>(null);
  const [slot, setSlot] = useState<number | null>(null);
  const [ghost, setGhost] = useState<{ label: string; id: string; x: number; y: number } | null>(null);
  const [dropDesk, setDropDesk] = useState<{ id: string; label: string } | null>(null);
  const [focus, setFocus] = useState(tab);
  const ghostRef = useRef<HTMLDivElement>(null);
  const slotNow = useRef<number | null>(null);
  const raf = useRef(0);

  function slotAt(x: number, y: number): number {
    const row = rowRef.current;
    const skip = drag.current?.id;
    if (!row) return 0;
    const chips = [...row.querySelectorAll<HTMLElement>("[data-desk]")].filter((el) => el.dataset.desk !== skip);
    for (let i = 0; i < chips.length; i++) {
      const r = chips[i]!.getBoundingClientRect();
      if (y < r.top - 4) return i;
      if (y <= r.bottom + 4 && x < r.left + r.width / 2) return i;
    }
    return chips.length;
  }

  function ghostPos(d: NonNullable<typeof drag.current>, x: number, y: number) {
    return { x: x - d.ox + d.w / 2, y: y - d.oy + 18 };
  }

  function moveGhost(x: number, y: number) {
    const el = ghostRef.current;
    if (!el) return;
    el.style.transform = `translate3d(${x}px, ${y}px, 0) translate(-50%, -50%) scale(1.08)`;
  }

  function lift(d: NonNullable<typeof drag.current>, x: number, y: number) {
    if (d.ready) return;
    d.ready = true;
    window.clearTimeout(d.timer);
    const p = ghostPos(d, x, y);
    slotNow.current = d.from;
    setHolding(d.id);
    setFocus(d.id);
    setSlot(d.from);
    setGhost({ id: d.id, label: d.label, x: p.x, y: p.y });
    requestAnimationFrame(() => moveGhost(p.x, p.y));
  }

  useEffect(() => {
    function lockScroll(on: boolean) {
      document.documentElement.style.overflow = on ? "hidden" : "";
      document.body.style.overflow = on ? "hidden" : "";
      document.body.style.touchAction = on ? "none" : "";
    }
    function blockTouch(e: TouchEvent) {
      if (drag.current) e.preventDefault();
    }
    function move(e: PointerEvent) {
      const d = drag.current;
      if (!d) return;
      e.preventDefault();
      const dist = Math.hypot(e.clientX - d.x, e.clientY - d.y);
      if (!d.ready) {
        if (dist < (d.mouse ? 4 : 8)) return;
        lift(d, e.clientX, e.clientY);
        lockScroll(true);
      }
      d.moved = true;
      const p = ghostPos(d, e.clientX, e.clientY);
      cancelAnimationFrame(raf.current);
      raf.current = requestAnimationFrame(() => moveGhost(p.x, p.y));
      const next = slotAt(e.clientX, e.clientY);
      if (slotNow.current !== next) {
        slotNow.current = next;
        setSlot(next);
      }
    }
    function up(e: PointerEvent) {
      const d = drag.current;
      drag.current = null;
      cancelAnimationFrame(raf.current);
      lockScroll(false);
      if (!d) return;
      window.clearTimeout(d.timer);
      onTab(d.id);
      setFocus(d.id);
      if (d.ready && d.moved) {
        useSmmDesks.getState().reorderDesks(d.id, slotNow.current ?? slotAt(e.clientX, e.clientY));
        void syncCloudNow();
      }
      setHolding(null);
      setSlot(null);
      setGhost(null);
      slotNow.current = null;
    }
    window.addEventListener("pointermove", move, { passive: false });
    window.addEventListener("pointerup", up);
    window.addEventListener("pointercancel", up);
    window.addEventListener("touchmove", blockTouch, { passive: false });
    return () => {
      lockScroll(false);
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      window.removeEventListener("pointercancel", up);
      window.removeEventListener("touchmove", blockTouch);
    };
  }, [onTab]);

  useEffect(() => {
    if (!holding) setFocus(tab);
  }, [tab, holding]);

  const shown = holding && slot != null ? placeDesks(desks, holding, slot) : desks;

  return (
    <>
      <div className="fav-sub-wrap">
      <div
        ref={rowRef}
        className={cn("fav-sub", (holding || editing) && "is-edit")}
        role="tablist"
        aria-label="Favorite platforms"
      >
        {shown.map((d) => {
          const selected = d.id === (holding || focus || tab);
          const canDelete = desks.length > 1;
          return (
            <div key={d.id} className="fav-chip-wrap" data-desk={d.id}>
            <button
              type="button"
              role="tab"
              aria-selected={selected}
              onPointerDown={(e) => {
                if (e.button !== 0) return;
                e.currentTarget.setPointerCapture(e.pointerId);
                const r = e.currentTarget.getBoundingClientRect();
                const id = d.id;
                const mouse = e.pointerType === "mouse" || e.pointerType === "pen";
                const timer = mouse
                  ? 0
                  : window.setTimeout(() => {
                      const cur = drag.current;
                      if (!cur || cur.id !== id) return;
                      lift(cur, cur.x, cur.y);
                      document.documentElement.style.overflow = "hidden";
                      document.body.style.overflow = "hidden";
                      document.body.style.touchAction = "none";
                      navigator.vibrate?.(12);
                    }, 280);
                drag.current = {
                  id,
                  x: e.clientX,
                  y: e.clientY,
                  ox: e.clientX - r.left,
                  oy: e.clientY - r.top,
                  w: r.width,
                  from: useSmmDesks.getState().desks.findIndex((row) => row.id === id),
                  moved: false,
                  ready: false,
                  mouse,
                  label: d.label,
                  timer,
                };
              }}
              className={cn("fav-sub-btn", selected && "is-on", holding === d.id && "is-lift")}
            >
              <TabMark id={d.id} selected={selected} />
              <span className="max-w-[8rem] truncate">{d.label}</span>
            </button>
            {editing && canDelete ? (
              <button
                type="button"
                aria-label={`Delete ${d.label}`}
                className="fav-del"
                onPointerDown={(e) => e.stopPropagation()}
                onClick={(e) => {
                  e.stopPropagation();
                  setDropDesk({ id: d.id, label: d.label });
                }}
              >
                <X className="size-2.5" strokeWidth={3} />
              </button>
            ) : null}
            </div>
          );
        })}
      </div>
      <button
        type="button"
        className="fav-sub-edit"
        aria-pressed={editing}
        onClick={() => setEditing((on) => !on)}
      >
        {editing ? "Done" : "Edit"}
      </button>
      </div>
      {ghost
        ? createPortal(
            <div
              ref={ghostRef}
              className="fav-ghost"
              style={{ transform: `translate3d(${ghost.x}px, ${ghost.y}px, 0) translate(-50%, -50%) scale(1.08)` }}
            >
              <TabMark id={ghost.id} selected />
              <span className="max-w-[8rem] truncate">{ghost.label}</span>
            </div>,
            document.body,
          )
        : null}
      {dropDesk
        ? createPortal(
            <div className="order-verify" role="dialog" aria-modal="true" aria-labelledby="del-desk-title">
              <button type="button" className="order-verify-scrim" aria-label="Cancel" onClick={() => setDropDesk(null)} />
              <div className="order-verify-card">
                <p id="del-desk-title" className="flex items-center justify-center gap-2 text-base font-bold text-fg">
                  <TabMark id={dropDesk.id} selected />
                  <span>Delete {dropDesk.label}?</span>
                </p>
                <p className="mt-2 text-center text-sm text-muted">
                  This removes {dropDesk.label} and its services from Favorites.
                </p>
                <div className="order-verify-acts">
                  <button
                    type="button"
                    className="order-verify-yes"
                    onClick={() => {
                      const id = dropDesk.id;
                      const at = useSmmDesks.getState().desks.findIndex((d) => d.id === id);
                      setDropDesk(null);
                      useSmmDesks.getState().removeDesk(id);
                      void syncCloudNow();
                      const next = useSmmDesks.getState().desks;
                      if (tab === id && next.length) {
                        const pick = next[Math.min(Math.max(at, 0), next.length - 1)] ?? next[0];
                        if (pick) {
                          onTab(pick.id);
                          setFocus(pick.id);
                        }
                      }
                    }}
                  >
                    Yes
                  </button>
                  <button type="button" className="order-verify-no" onClick={() => setDropDesk(null)}>
                    No
                  </button>
                </div>
              </div>
            </div>,
            document.body,
          )
        : null}
    </>
  );
}

function BalanceBar({
  settingsOn,
  onSettings,
}: {
  settingsOn: boolean;
  onSettings: () => void;
}) {
  const live = useSmmLive((s) => s.panels);
  const ids = ["smmwiz", "jap", "smmfanz"] as const;
  const panels = ids.map((id) => {
    const hit = live.find((row) => row.id === id);
    return {
      id,
      label: hit?.label || PANEL_LABELS[id] || id,
      balance: hit?.balance ?? "…",
    };
  });

  return (
    <div className="flex items-stretch gap-1.5 px-3 pt-1.5">
      <div className="balance-pair min-w-0 flex-1" data-n={panels.length}>
        {panels.map((p) => (
          <div key={p.id} className="flex min-w-0 items-center gap-1 overflow-hidden rounded-lg bg-surface px-2 py-1">
            <p className="min-w-0 flex-1 truncate text-[9px] font-medium tracking-wide text-muted uppercase">
              {p.label}
            </p>
            <p
              className="balance-amt money shrink-0 whitespace-nowrap text-sm leading-none text-fg"
              data-tone={balanceTone(p.balance)}
            >
              {p.balance === "—" || p.balance === "…" ? p.balance : formatMoney(Number(p.balance) || 0)}
            </p>
          </div>
        ))}
      </div>
      <span className="rail-sep" aria-hidden />
      <button
        type="button"
        aria-label="Settings"
        aria-pressed={settingsOn}
        onClick={onSettings}
        data-on={settingsOn || undefined}
        className={cn(
          "icon-badge settings-btn relative flex aspect-square h-auto shrink-0 items-center justify-center rounded-lg",
          "transition-[color,transform,background-color] duration-150 ease-out",
          "active:scale-[0.96]",
          settingsOn ? "bg-surface text-fg" : "bg-elevated text-muted",
        )}
      >
        <Settings className="size-3.5" />
      </button>
    </div>
  );
}

function balanceTone(balance: string): "ok" | "low" | "wait" {
  if (balance === "—" || balance === "…") return "wait";
  const n = Number(balance);
  return Number.isFinite(n) && n >= 1 ? "ok" : "low";
}

export function TabMark({ id, selected }: { id: string; selected: boolean }) {
  const cls = cn("size-5 shrink-0", selected ? markClass(id) : "text-current");
  if (id === "favorites") {
    return (
      <Star
        className={cn("size-5 shrink-0", selected ? "text-fav-star" : "text-current")}
        fill={selected ? "currentColor" : "none"}
        strokeWidth={selected ? 0 : 2}
        aria-hidden
      />
    );
  }
  if (id === "tiktok") return <TikTokMark className={cls} selected={selected} />;
  if (id === "telegram") return <TelegramMark className={cls} />;
  if (id === "traffic") return <Globe className={cls} aria-hidden />;
  if (id === "orders") return <Calendar className={cls} aria-hidden />;
  if (id === "stats") return <BarChart3 className={cn(cls, selected && "text-[var(--color-neon-green)]")} aria-hidden />;
  if (id === "links") return <NotebookText className={cn(cls, "text-[#c084fc]")} aria-hidden />;
  if (id === "all") return <LayoutGrid className={cls} aria-hidden />;
  if (brandPath(id)) return <OfficialMark id={id} className={cls} />;
  return (
    <span
      className={cn(
        "flex size-5 shrink-0 items-center justify-center rounded-full text-[10px] font-extrabold",
        selected ? "bg-fg text-accent-fg" : "bg-surface text-muted",
      )}
      aria-hidden
    >
      {(id[0] ?? "?").toUpperCase()}
    </span>
  );
}

function markClass(id: string): string {
  if (id === "tiktok") return "text-tt";
  if (id === "youtube") return "text-yt";
  if (id === "instagram") return "text-ig";
  if (id === "facebook") return "text-[#1877F2]";
  if (id === "twitter") return "text-fg";
  if (id === "telegram") return "text-[#2AABEE]";
  if (id === "spotify") return "text-[#1DB954]";
  if (id === "linkedin") return "text-[#0A66C2]";
  if (id === "twitch") return "text-[#9146FF]";
  if (id === "traffic") return "text-cyan-400";
  return "text-fg";
}

function OfficialMark({ id, className }: { id: string; className?: string }) {
  const d = brandPath(id);
  if (!d) return null;
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden>
      {id === "youtube" ? <path d="M9.4 8.3h5.4v7.4H9.4z" fill="#fff" /> : null}
      <path fill="currentColor" d={d} />
    </svg>
  );
}

function TikTokMark({ className, selected }: { className?: string; selected: boolean }) {
  const d = brandPath("tiktok") ?? "";
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden>
      {selected ? (
        <>
          <path d={d} className="fill-tt-cyan" transform="translate(-0.7 0.45)" />
          <path d={d} fill="#FE2C55" transform="translate(0.7 -0.35)" />
        </>
      ) : null}
      <path d={d} fill="currentColor" />
    </svg>
  );
}

function TelegramMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden>
      <path
        fill="currentColor"
        d="M21.2 3.4 2.9 10.6c-1.2.5-1.2 1.1-.2 1.4l4.6 1.4 10.8-6.8c.5-.3.9-.1.6.2l-8.7 7.9-.3 4.6c.4 0 .6-.2.8-.4l2.1-2 4.4 3.2c.8.5 1.4.2 1.6-.8l3.1-14.8c.3-1.3-.5-1.9-1.5-1.5Z"
      />
    </svg>
  );
}

