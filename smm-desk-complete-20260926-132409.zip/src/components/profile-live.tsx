import { useEffect } from "react";
import { loadSmmProfileFeed, lookupSmmProfile } from "@/lib/smm/fn";
import { useSmmProfiles } from "@/lib/smm/profiles";

const GAP = 18_000;

export function ProfileLive() {
  const setLive = useSmmProfiles((s) => s.setLive);

  useEffect(() => {
    let alive = true;
    let timer = 0;
    let running = false;

    function mark() {
      if (alive) setLive(true, Date.now());
    }

    function alreadyHot() {
      const s = useSmmProfiles.getState();
      return s.profiles.some((p) => p.stats.length) || Object.values(s.feeds).some((f) => f.items.length);
    }

    async function one(row: { id: string; url: string; platform?: string }) {
      const url =
        row.platform === "facebook"
          ? "https://www.facebook.com/105894818641566"
          : row.platform === "instagram"
            ? "https://www.instagram.com/clauivory/"
            : row.platform === "youtube"
              ? "https://www.youtube.com/@claudiaivory"
              : row.platform === "tiktok"
                ? "https://www.tiktok.com/@clauivory"
                : row.url;
      try {
        const next = await lookupSmmProfile({ data: { url, live: true } }).catch(() => null);
        if (!alive) return;
        if (next && (next.stats.length || next.avatar || next.title)) {
          useSmmProfiles.getState().patch(next);
          mark();
        }
      } catch {
        /* keep last */
      }
      try {
        const feed = await loadSmmProfileFeed({ data: { url, live: true } }).catch(() => null);
        if (!alive) return;
        if (feed?.items.length) {
          const have = useSmmProfiles.getState().feeds[row.id]?.items.length || 0;
          if (have && have > feed.items.length) {
            useSmmProfiles.getState().setFeed(row.id, feed.items, useSmmProfiles.getState().feeds[row.id]?.cursor ?? feed.cursor);
          } else {
            useSmmProfiles.getState().setFeed(row.id, feed.items, feed.cursor);
          }
          mark();
        } else if (useSmmProfiles.getState().feeds[row.id]?.items.length) {
          mark();
        }
      } catch {
        /* keep last */
      }
    }

    async function tick() {
      if (!alive || running) return;
      running = true;
      if (alreadyHot()) mark();
      const rows = useSmmProfiles.getState().profiles;
      await Promise.all(rows.map((row) => one(row)));
      running = false;
      if (!alive) return;
      if (alreadyHot() || useSmmProfiles.getState().liveAt) mark();
      timer = window.setTimeout(() => {
        if (document.visibilityState === "visible") void tick();
        else timer = window.setTimeout(() => void tick(), GAP);
      }, GAP);
    }

    function onVis() {
      if (document.visibilityState === "visible") {
        window.clearTimeout(timer);
        void tick();
      }
    }

    document.addEventListener("visibilitychange", onVis);
    void tick();

    return () => {
      alive = false;
      window.clearTimeout(timer);
      document.removeEventListener("visibilitychange", onVis);
    };
  }, [setLive]);

  return null;
}
