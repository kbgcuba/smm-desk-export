import { useEffect, useSyncExternalStore } from "react";
import { pullSmmCloud, pushSmmCloud, type PanelBalance } from "@/lib/smm/fn";
import { useSmmDesks, type DeskDef } from "@/lib/smm/desks";
import { useSmmOrders, type SavedOrder, type RefillLog } from "@/lib/smm/orders";
import { useSmmPrefs } from "@/lib/smm/prefs";
import { useSmmLive } from "@/lib/smm/live-store";
import { mergeFavorites, mergePrefs, mergeProfiles, desksEqual } from "@/lib/smm/merge";
import { useSmmProfiles, type TrackedProfile } from "@/lib/smm/profiles";

// Anything the user can see belongs on the server so every device shows the same desk:
// orders, refills, tabs/services, prefs, last balances. Do not add device-only copies.

let pushing = false;
let pendingPush = false;
let ready = false;
let timer: number | null = null;
let applying = false;
let stamp = { at: 0, live: false, ready: false };
const stampSubs = new Set<() => void>();

function setStamp(at: number, live: boolean, ready = true) {
  stamp = { at, live, ready };
  stampSubs.forEach((fn) => fn());
}

export function useCloudStamp() {
  return useSyncExternalStore(
    (fn) => {
      stampSubs.add(fn);
      return () => stampSubs.delete(fn);
    },
    () => stamp,
    () => stamp,
  );
}

function snapshot() {
  const prefs = useSmmPrefs.getState();
  return {
    orders: useSmmOrders.getState().orders,
    refills: useSmmOrders.getState().refills,
    desks: useSmmDesks.getState().desks,
    desksAt: useSmmDesks.getState().desksAt,
    gone: useSmmDesks.getState().gone,
    prefs: {
      lastService: prefs.lastService,
      lastQty: prefs.lastQty,
      recentLinks: prefs.recentLinks,
      autoRefill: prefs.autoRefill,
      lastAccount: prefs.lastAccount,
      lastAccountAt: prefs.lastAccountAt,
    },
    panels: useSmmLive.getState().panels,
    profiles: useSmmProfiles.getState().profiles,
    profilesAt: useSmmProfiles.getState().profilesAt,
    savedAt: Date.now(),
  };
}

type Dump = {
  orders?: unknown;
  refills?: unknown;
  desks?: unknown;
  desksAt?: number;
  gone?: Record<string, number>;
  prefs?: {
    lastService: Record<string, string>;
    lastQty: Record<string, number>;
    recentLinks: string[];
    autoRefill: boolean;
    lastAccount?: string;
    lastAccountAt?: number;
  };
  panels?: unknown;
  profiles?: unknown;
  profilesAt?: number;
  savedAt?: number;
};

function applyDump(dump: Dump | null) {
  if (!dump) return;
  applying = true;
  try {
    useSmmOrders.getState().hydrate((dump.orders as SavedOrder[]) ?? [], (dump.refills as RefillLog[]) ?? []);
    if (Array.isArray(dump.desks) && dump.desks.length) {
      const local = useSmmDesks.getState();
      const dumpAt = typeof dump.desksAt === "number" ? dump.desksAt : dump.savedAt ?? 0;
      const dumpNewer = dumpAt >= local.desksAt;
      const fav = mergeFavorites(
        dumpNewer ? { desks: dump.desks as DeskDef[], gone: dump.gone } : { desks: local.desks, gone: local.gone },
        dumpNewer ? { desks: local.desks, gone: local.gone } : { desks: dump.desks as DeskDef[], gone: dump.gone },
      );
      const goneSame =
        Object.keys(fav.gone).length === Object.keys(local.gone).length &&
        Object.entries(fav.gone).every(([k, t]) => local.gone[k] === t);
      if (!desksEqual(fav.desks, local.desks) || !goneSame) {
        useSmmDesks.getState().replaceAll(fav.desks, Math.max(local.desksAt, dumpAt), fav.gone);
      }
    }
    if (dump.prefs) {
      const prefs = useSmmPrefs.getState();
      useSmmPrefs.getState().replace(
        mergePrefs(
          {
            lastService: prefs.lastService,
            lastQty: prefs.lastQty,
            recentLinks: prefs.recentLinks,
            autoRefill: prefs.autoRefill,
            lastAccount: prefs.lastAccount,
            lastAccountAt: prefs.lastAccountAt,
          },
          dump.prefs,
          0,
          typeof dump.savedAt === "number" ? dump.savedAt : Date.now(),
        ),
      );
    }
    if (Array.isArray(dump.panels) && dump.panels.length) {
      useSmmLive.getState().apply(dump.panels as PanelBalance[]);
    }
    if (Array.isArray(dump.profiles) && dump.profiles.length) {
      const local = useSmmProfiles.getState();
      const dumpAt = typeof dump.profilesAt === "number" ? dump.profilesAt : 0;
      if (dumpAt > local.profilesAt) {
        const next = mergeProfiles(dump.profiles as TrackedProfile[], local.profiles);
        useSmmProfiles.getState().replaceAll(next, dumpAt);
      } else if (dumpAt === local.profilesAt) {
        const next = mergeProfiles(local.profiles, dump.profiles as TrackedProfile[]);
        if (next.some((p, i) => p.id !== local.profiles[i]?.id) || next.length !== local.profiles.length) {
          useSmmProfiles.getState().replaceAll(next, local.profilesAt);
        }
      }
    }
    const at = typeof dump.savedAt === "number" ? dump.savedAt : Date.now();
    setStamp(at, true);
  } finally {
    applying = false;
  }
}

async function pushNow() {
  if (!ready || applying) return;
  if (pushing) {
    pendingPush = true;
    return;
  }
  pushing = true;
  const killer = typeof window !== "undefined" ? window.setTimeout(() => {
    pushing = false;
  }, 10_000) : null;
  try {
    const dump = await pushSmmCloud({ data: snapshot() as never });
    if (dump) applyDump(dump);
    else setStamp(Date.now(), true);
  } catch {
    /* keep local; queued / next subscribe retries */
  } finally {
    if (killer != null) window.clearTimeout(killer);
    pushing = false;
    if (pendingPush) {
      pendingPush = false;
      void pushNow();
    }
  }
}

function schedulePush() {
  if (!ready || applying) return;
  if (timer) window.clearTimeout(timer);
  timer = window.setTimeout(() => {
    void pushNow();
  }, 250);
}

async function pullNow() {
  try {
    const dump = await pullSmmCloud();
    applyDump(dump);
    if (!dump) setStamp(stamp.at, stamp.live, true);
  } catch {
    setStamp(stamp.at, false, true);
  }
}

export async function syncCloudNow() {
  ready = true;
  await pushNow();
}

function waitHydrated(store: {
  persist?: { hasHydrated: () => boolean; onFinishHydration: (cb: () => void) => () => void };
}): Promise<void> {
  const persist = store.persist;
  if (!persist || persist.hasHydrated()) return Promise.resolve();
  return new Promise((resolve) => {
    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      resolve();
    };
    const unsub = persist.onFinishHydration(() => {
      unsub();
      finish();
    });
    window.setTimeout(finish, 80);
  });
}

export function CloudSync() {
  useEffect(() => {
    let alive = true;
    let source: EventSource | null = null;
    let fallback: number | undefined;
    let retry: number | undefined;

    async function boot() {
      await Promise.all([
        waitHydrated(useSmmOrders),
        waitHydrated(useSmmPrefs),
        waitHydrated(useSmmLive),
      ]);
      if (!alive) return;
      await pullNow();
      if (!alive) return;
      ready = true;
      void pushNow();
      connect();
    }

    function applyFrame(raw: string) {
      try {
        const dump = JSON.parse(raw) as Dump;
        if (!Array.isArray(dump.orders) && !Array.isArray(dump.desks)) return;
        applyDump(dump);
      } catch {
        /* ignore a bad frame */
      }
    }

    async function poll() {
      await pullNow();
      if (alive && document.visibilityState === "visible") {
        fallback = window.setTimeout(() => {
          void poll();
        }, 3_000);
      }
    }

    let fails = 0;

    function startFallback() {
      source?.close();
      source = null;
      void poll();
    }

    function connect() {
      if (!alive || document.visibilityState !== "visible") return;
      window.clearTimeout(fallback);
      window.clearTimeout(retry);
      try {
        source = new EventSource("/api/smm-cloud");
      } catch {
        startFallback();
        return;
      }
      source.onopen = () => {
        fails = 0;
      };
      source.onmessage = (event) => {
        fails = 0;
        applyFrame(event.data);
      };
      source.onerror = () => {
        source?.close();
        source = null;
        if (!alive) return;
        fails += 1;
        if (fails >= 2) {
          startFallback();
          return;
        }
        retry = window.setTimeout(connect, 1_200);
      };
    }

    void boot();

    const a = useSmmOrders.subscribe(schedulePush);
    const b = useSmmDesks.subscribe(schedulePush);
    const c = useSmmPrefs.subscribe(schedulePush);
    let lastProfilesAt = useSmmProfiles.getState().profilesAt;
    const p = useSmmProfiles.subscribe((s) => {
      if (s.profilesAt === lastProfilesAt) return;
      lastProfilesAt = s.profilesAt;
      schedulePush();
    });

    function onVis() {
      window.clearTimeout(fallback);
      window.clearTimeout(retry);
      if (document.visibilityState === "hidden") {
        source?.close();
        source = null;
        if (timer) window.clearTimeout(timer);
        void pushNow();
        return;
      }
      void pullNow().then(() => {
        if (!alive) return;
        void pushNow();
        connect();
      });
    }

    document.addEventListener("visibilitychange", onVis);
    window.addEventListener("pagehide", () => void pushNow());

    return () => {
      alive = false;
      ready = false;
      a();
      b();
      c();
      p();
      source?.close();
      if (timer) window.clearTimeout(timer);
      window.clearTimeout(fallback);
      window.clearTimeout(retry);
      document.removeEventListener("visibilitychange", onVis);
    };
  }, []);

  return null;
}
