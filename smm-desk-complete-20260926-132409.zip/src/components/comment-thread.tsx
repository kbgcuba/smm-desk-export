import { useState } from "react";
import { formatCount } from "@/lib/format";
import { mergeComments, useSocial } from "@/lib/store";
import type { Comment } from "@/data/catalog";

export function CommentThread({
  postId,
  seed,
}: {
  postId: string;
  seed: Comment[];
}) {
  const extra = useSocial((s) => s.extraComments[postId]);
  const comments = mergeComments(seed, extra);

  if (comments.length === 0) {
    return <p className="py-8 text-center text-sm text-muted">Be the first to comment.</p>;
  }

  return (
    <ul className="flex flex-col gap-4">
      {comments.map((c) => (
        <li key={c.id} className="flex gap-3">
          <span className="mt-0.5 flex size-8 shrink-0 items-center justify-center rounded-full bg-elevated text-xs font-semibold text-fg">
            {c.handle.slice(0, 1).toUpperCase()}
          </span>
          <div className="min-w-0">
            <p className="text-sm text-fg">
              <span className="font-semibold">{c.handle}</span>{" "}
              <span className="text-fg/90">{c.text}</span>
            </p>
            {c.likes > 0 ? (
              <p className="mt-1 text-xs text-muted tabular-nums">{formatCount(c.likes)} likes</p>
            ) : null}
          </div>
        </li>
      ))}
    </ul>
  );
}

export function CommentComposer({ postId }: { postId: string }) {
  const addComment = useSocial((s) => s.addComment);
  const [value, setValue] = useState("");

  function submit() {
    addComment(postId, value);
    setValue("");
  }

  return (
    <form
      className="flex items-center gap-2"
      onSubmit={(e) => {
        e.preventDefault();
        submit();
      }}
    >
      <input
        value={value}
        onChange={(e) => setValue(e.target.value)}
        placeholder="Add a comment"
        aria-label="Add a comment"
        className="min-h-11 min-w-0 flex-1 rounded-full bg-elevated px-4 text-sm text-fg outline-none ring-0 placeholder:text-subtle"
      />
      <button
        type="submit"
        disabled={!value.trim()}
        className="min-h-11 rounded-full px-4 text-sm font-semibold text-fg transition-opacity disabled:opacity-40 active:scale-[0.96]"
      >
        Post
      </button>
    </form>
  );
}
