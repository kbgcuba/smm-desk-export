import { useEffect, useState, type ReactNode } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Lock } from "lucide-react";
import { loadSmmGate, unlockSmmGate } from "@/lib/smm/fn";
import { warmAllCatalog } from "@/lib/smm/all-catalog";

const STAMP_KEY = "smm-gate-stamp";
const DEVICE_KEY = "smm-device-id";
const TOKEN_KEY = "smm-access-token";
let memDevice = "";
const fieldClass = "min-h-11 w-full rounded-lg bg-elevated px-3 text-base text-fg outline-none";

function applyAccessCookie(token: string) {
  const value = token.trim();
  if (!value || typeof document === "undefined") return;
  try {
    localStorage.setItem(TOKEN_KEY, value);
  } catch {
    /* private mode */
  }
  const secure = typeof location !== "undefined" && location.protocol === "https:" ? "; Secure" : "";
  document.cookie = `${encodeURIComponent("smm-access")}=${encodeURIComponent(value)}; Path=/; Max-Age=${60 * 60 * 24 * 400}; SameSite=Lax${secure}`;
}

export function deviceName(): string {
  if (typeof navigator === "undefined") return "Device";
  const ua = navigator.userAgent;
  if (/iPhone|iPad/.test(ua)) return "iPhone";
  if (/Android/.test(ua)) return "Android";
  if (/Mac/.test(ua)) return "Mac";
  if (/Win/.test(ua)) return "Windows";
  if (/Linux/.test(ua)) return "Linux";
  return "This device";
}

export function deviceId(): string {
  try {
    const have = localStorage.getItem(DEVICE_KEY);
    if (have && have.length >= 8) return have;
    const id = crypto.randomUUID();
    localStorage.setItem(DEVICE_KEY, id);
    memDevice = id;
    return id;
  } catch {
    if (!memDevice) memDevice = crypto.randomUUID();
    return memDevice;
  }
}

export function AccessGate({ children }: { children: ReactNode }) {
  const navigate = useNavigate();
  const [ready, setReady] = useState(false);
  const [locked, setLocked] = useState(false);
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    let alive = true;
    try {
      const saved = localStorage.getItem(TOKEN_KEY);
      if (saved) applyAccessCookie(saved);
    } catch {
      /* private mode */
    }
    const id = deviceId();
    void loadSmmGate({ data: { deviceId: id } })
      .then((gate) => {
        if (!alive) return;
        if (!gate.locked || gate.allowed) {
          if (gate.stamp) {
            try {
              localStorage.setItem(STAMP_KEY, gate.stamp);
            } catch {
              /* private mode */
            }
          }
          if (gate.token) applyAccessCookie(gate.token);
          setLocked(false);
          setReady(true);
          warmAllCatalog();
          return;
        }
        try {
          if (localStorage.getItem(STAMP_KEY) === gate.stamp && gate.allowed) {
            setLocked(false);
            setReady(true);
            warmAllCatalog();
            return;
          }
        } catch {
          /* private mode */
        }
        setLocked(true);
        setReady(true);
      })
      .catch(() => {
        if (!alive) return;
        setError("Can't reach the desk");
        setLocked(true);
        setReady(true);
      });
    return () => {
      alive = false;
    };
  }, []);

  async function enter() {
    if (busy || !password.trim()) return;
    setBusy(true);
    setError("");
    try {
      const { stamp, token } = await unlockSmmGate({
        data: { password, deviceId: deviceId(), name: deviceName() },
      });
      try {
        localStorage.setItem(STAMP_KEY, stamp);
      } catch {
        /* private mode */
      }
      if (token) applyAccessCookie(token);
      setPassword("");
      setLocked(false);
      warmAllCatalog();
      void navigate({ to: "/", search: { tab: "stats" }, replace: true });
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Wrong password");
    } finally {
      setBusy(false);
    }
  }

  if (!ready) {
    return <div className="flex h-svh items-center justify-center bg-bg text-sm text-muted">Opening…</div>;
  }

  if (locked) {
    return (
      <div className="flex h-svh flex-col items-center justify-center bg-bg px-6 text-fg">
        <form
          className="w-full max-w-sm rounded-2xl bg-surface p-5 ring-1 ring-border"
          onSubmit={(e) => {
            e.preventDefault();
            void enter();
          }}
        >
          <p className="text-xs font-medium tracking-wide text-muted uppercase">Access</p>
          <p className="mt-2 text-lg font-bold text-fg">This device is locked</p>
          <p className="mt-1 text-sm text-muted">Enter the access password. Only this device stays unlocked.</p>
          <label className="mt-4 block">
            <span className="mb-2 block text-xs font-medium tracking-wide text-muted uppercase">Password</span>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete="current-password"
              autoFocus
              aria-label="Access password"
              className={fieldClass}
            />
          </label>
          {error ? <p className="mt-2 text-sm text-rose-400">{error}</p> : null}
          <button
            type="submit"
            disabled={busy || !password.trim()}
            className="mt-4 flex min-h-11 w-full items-center justify-center gap-2 rounded-full bg-fg px-5 text-sm font-semibold text-accent-fg disabled:opacity-40"
          >
            <Lock className="size-4" />
            {busy ? "Checking…" : "Enter"}
          </button>
        </form>
      </div>
    );
  }

  return <>{children}</>;
}