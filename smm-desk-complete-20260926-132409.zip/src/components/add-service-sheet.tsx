import { useEffect, useMemo, useRef, useState } from "react";
import {
  allowsDrip,
  allowsRefill,
  loadSmmLive,
  nameWithId,
  panelLabel,
  serviceKey,
  type PanelBalance,
  type PanelId,
  type SmmCatalogPayload,
  type SmmService,
} from "@/lib/smm/fn";
import { loadAllCatalog, peekAllCatalog, subscribeAllCatalog } from "@/lib/smm/all-catalog";
import { useSmmDesks } from "@/lib/smm/desks";
import { useSmmPrefs } from "@/lib/smm/prefs";
import { useSmmLive } from "@/lib/smm/live-store";
import { ServiceForm, ServiceFav } from "@/components/smm-panels";
import {
  POPULAR,
  SORTS,
  VirtualSvcList,
  brandOf,
  filterSplits,
  hasCustomComments,
  pillName,
  rowMeta,
  sortServices,
  type SortId,
} from "@/components/all-services-view";
import { BottomSheet } from "@/components/bottom-sheet";
import { matchesAdd, metricIdFor, attributionScore, attributeService } from "@/lib/smm/add-match";

export { matchesAdd, metricIdFor };

const LIST_CAP = 2000;
const EMPTY_SERVICES: SmmService[] = [];
const fieldClass =
  "min-h-11 w-full rounded-lg bg-elevated px-3 text-base text-fg outline-none placeholder:text-subtle disabled:opacity-40";

export type FavHit = { deskId: string; panel: PanelId; id: number; title: string };

export function findFavoritesFor(platform: string, metricId: string, kind?: string): FavHit[] {
  const desks = useSmmDesks.getState().desks;
  const seen = new Set<string>();
  const hits: FavHit[] = [];
  const prefer = desks.filter((d) => d.id === platform);
  const rest = desks.filter((d) => d.id !== platform);
  for (const desk of [...prefer, ...rest]) {
    for (const svc of desk.services) {
      const key = `${svc.panel}:${svc.id}`;
      if (seen.has(key)) continue;
      if (!matchesAdd(platform, metricId, svc, desk.id, POPULAR.find((row) => row.id === platform)?.test, kind)) continue;
      seen.add(key);
      hits.push({ deskId: desk.id, panel: svc.panel, id: svc.id, title: svc.title });
    }
  }
  const last = useSmmPrefs.getState().lastService;
  hits.sort((a, b) => {
    const aLast = last[a.deskId] === `${a.panel}:${a.id}` ? 0 : 1;
    const bLast = last[b.deskId] === `${b.panel}:${b.id}` ? 0 : 1;
    if (aLast !== bLast) return aLast - bLast;
    return attributionScore(kind, attributeService({ name: a.title })) - attributionScore(kind, attributeService({ name: b.title }));
  });
  return hits;
}

function debitPanel(panels: PanelBalance[], id: PanelId, amount: number): PanelBalance[] {
  if (!Number.isFinite(amount) || amount <= 0) return panels;
  return panels.map((p) => {
    if (p.id !== id) return p;
    if (p.balance === "—" || p.balance === "…") return p;
    const n = Number(p.balance);
    if (!Number.isFinite(n)) return p;
    return { ...p, balance: Math.max(0, n - amount).toFixed(2) };
  });
}

export function AddServiceSheet({
  open,
  platform,
  metric,
  label,
  link,
  kind,
  onClose,
  onPlaced,
}: {
  open: boolean;
  platform: string;
  metric: string;
  label: string;
  link: string;
  kind?: string;
  onClose: () => void;
  onPlaced?: () => void;
}) {
  const [data, setData] = useState<SmmCatalogPayload | null>(() => peekAllCatalog());
  const [loading, setLoading] = useState(() => !peekAllCatalog());
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState<SortId>("fastest");
  const [wantComments, setWantComments] = useState(false);
  const [wantDrip, setWantDrip] = useState(false);
  const [wantRefill, setWantRefill] = useState(false);
  const [picked, setPicked] = useState("");
  const [favs, setFavs] = useState<FavHit[]>([]);
  const listRef = useRef<HTMLUListElement | null>(null);
  const formRef = useRef<HTMLDivElement | null>(null);
  const seqRef = useRef(0);
  const livePanels = useSmmLive((s) => s.panels);
  const desks = useSmmDesks((s) => s.desks);
  const favKeys = useMemo(
    () => new Set(desks.flatMap((d) => d.services.map((x) => `${x.panel}:${x.id}`))),
    [desks],
  );

  useEffect(() => {
    if (!open) return;
    const hits = findFavoritesFor(platform, metric, kind);
    setFavs(hits);
    setQuery("");
    setWantComments(false);
    setWantDrip(false);
    setWantRefill(false);
    setPicked("");
  }, [open, platform, metric, kind]);

  useEffect(() => {
    if (!open) return;
    const stop = subscribeAllCatalog((next) => {
      setData(next);
      setLoading(false);
    });
    let alive = true;
    if (!peekAllCatalog()) setLoading(true);
    void loadAllCatalog()
      .then((next) => {
        if (!alive) return;
        setData(next);
        setLoading(false);
      })
      .catch(() => {
        if (alive) setLoading(false);
      });
    return () => {
      alive = false;
      stop();
    };
  }, [open]);

  const services = data?.services ?? EMPTY_SERVICES;
  const platformLabel = POPULAR.find((row) => row.id === platform)?.label ?? platform;
  const heading = `Add ${platformLabel} ${label}`;

  const chosenPool = useMemo(() => {
    const extra = POPULAR.find((row) => row.id === platform)?.test;
    return services.filter((s) => matchesAdd(platform, metric, s, undefined, extra, kind));
  }, [services, platform, metric, kind]);

  const showComments = filterSplits(chosenPool, hasCustomComments);
  const showDrip = filterSplits(chosenPool, allowsDrip);
  const showRefill = filterSplits(chosenPool, allowsRefill);
  const showFilters = showComments || showDrip || showRefill;

  const rows = useMemo(() => {
    const q = query.trim().toLowerCase();
    let list = chosenPool;
    if (q) {
      list = list.filter((s) => `${s.name} ${s.category} ${s.id} ${panelLabel(s.panel)}`.toLowerCase().includes(q));
    }
    if (wantComments && showComments) list = list.filter(hasCustomComments);
    if (wantDrip && showDrip) list = list.filter(allowsDrip);
    if (wantRefill && showRefill) list = list.filter(allowsRefill);
    list = sortServices(list, sort);
    list = [...list].sort((a, b) => {
      const aFav = favKeys.has(serviceKey(a)) ? 0 : 1;
      const bFav = favKeys.has(serviceKey(b)) ? 0 : 1;
      if (aFav !== bFav) return aFav - bFav;
      return attributionScore(kind, attributeService(a)) - attributionScore(kind, attributeService(b));
    });
    list = list.slice(0, LIST_CAP);
    return list.map((service) => ({
      key: serviceKey(service),
      service,
      title: pillName(service),
      meta: rowMeta(service),
    }));
  }, [chosenPool, query, sort, wantComments, wantDrip, wantRefill, showComments, showDrip, showRefill, kind, favKeys]);

  const selected = rows.find((row) => row.key === picked)?.service ?? null;
  const deskId = favs.find((f) => `${f.panel}:${f.id}` === picked)?.deskId || platform || "all";
  const tone = (selected ? brandOf(selected) : null) || POPULAR.find((row) => row.id === platform)?.tone || "other";

  useEffect(() => {
    if (!picked || rows.length === 0) return;
    if (!rows.some((row) => row.key === picked)) setPicked("");
  }, [rows, picked]);

  function pickService(key: string) {
    setPicked(key);
    requestAnimationFrame(() => {
      formRef.current?.scrollIntoView({ behavior: "smooth", block: "nearest" });
    });
  }

  return (
    <BottomSheet open={open} onClose={onClose} title={heading} full>
      <div className="flex flex-col gap-3">
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={`Search ${platformLabel} ${label}…`}
          className={fieldClass}
        />
        <label>
          <span className="mb-1 block text-center text-[11px] font-medium tracking-wide text-muted uppercase">Sort</span>
          <select value={sort} onChange={(e) => setSort(e.target.value as SortId)} className={`field-select ${fieldClass}`}>
            {SORTS.map((row) => (
              <option key={row.id} value={row.id}>
                {row.label}
              </option>
            ))}
          </select>
        </label>
        {showFilters ? (
          <div className="flex flex-wrap items-center justify-center gap-x-4 gap-y-1 rounded-xl bg-elevated px-3 py-2">
            {showComments ? (
              <label className="flex min-h-10 items-center gap-2 text-sm font-semibold">
                <input type="checkbox" checked={wantComments} onChange={(e) => setWantComments(e.target.checked)} className="size-4 accent-tt" />
                Custom comments
              </label>
            ) : null}
            {showDrip ? (
              <label className="flex min-h-10 items-center gap-2 text-sm font-semibold">
                <input type="checkbox" checked={wantDrip} onChange={(e) => setWantDrip(e.target.checked)} className="size-4 accent-tt" />
                Drip-feed
              </label>
            ) : null}
            {showRefill ? (
              <label className="flex min-h-10 items-center gap-2 text-sm font-semibold">
                <input type="checkbox" checked={wantRefill} onChange={(e) => setWantRefill(e.target.checked)} className="size-4 accent-tt" />
                Refill
              </label>
            ) : null}
          </div>
        ) : null}
        <p className="text-xs font-medium tracking-wide text-muted uppercase">
          {loading && !data ? "Loading…" : `${rows.length} ${platformLabel} ${label}`}
        </p>
        {loading && !data ? (
          <p className="text-sm text-muted">Loading services…</p>
        ) : rows.length === 0 ? (
          <p className="text-sm text-muted">No {platformLabel} {label.toLowerCase()} services match.</p>
        ) : (
          <VirtualSvcList
            rows={rows}
            picked={picked}
            favKeys={favKeys}
            listRef={listRef}
            className={selected ? "is-picked" : undefined}
            onPick={pickService}
            onStar={() => undefined}
          />
        )}
        <div ref={formRef} className="mt-4">
          {selected ? (
            <div className="svc-form-tile" data-brand={tone}>
              <div className="mb-4 flex items-center gap-2">
                <ServiceFav service={selected} deskId={deskId} />
                <p className="brand-chip svc-form-pill mb-0 min-w-0 flex-1" data-brand={tone} title={nameWithId(selected)}>
                  {pillName(selected)}
                </p>
              </div>
              <ServiceForm
                key={serviceKey(selected)}
                service={selected}
                deskId={deskId}
                seedLink={link}
                lockLink
                panelBalance={livePanels.find((p) => p.id === selected.panel)}
                onOrderStart={(panel, amount) => {
                  const seq = ++seqRef.current;
                  useSmmLive.getState().apply(debitPanel(livePanels, panel, amount));
                  return seq;
                }}
                onOrdered={(nextPanels, seq) => {
                  if (seq !== seqRef.current) return;
                  useSmmLive.getState().apply(nextPanels);
                  onPlaced?.();
                  onClose();
                }}
                onOrderFailed={(seq) => {
                  if (seq !== seqRef.current) return;
                  const next = ++seqRef.current;
                  void loadSmmLive()
                    .then((panels) => {
                      if (next !== seqRef.current) return;
                      useSmmLive.getState().apply(panels);
                    })
                    .catch(() => {
                      /* keep last known */
                    });
                }}
                linkHint={link}
                accentClass={platform === "youtube" ? "accent-yt" : platform === "instagram" ? "accent-ig" : "accent-tt"}
                showFav={false}
              />
            </div>
          ) : null}
        </div>
      </div>
    </BottomSheet>
  );
}