import { useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { useNavigate, useSearch } from "@tanstack/react-router";
import { toast } from "sonner";
import { ClipboardPaste, Check, X, Star } from "lucide-react";
import {
  loadSmmLive,
  loadLinkPreview,
  PANEL_LABELS,
  panelLabel,
  placeSmmOrder,
  type PanelBalance,
  type PanelId,
  type SmmCatalogPayload,
  type SmmService,
  allowsRefill,
  orderNeeds,
  orderCharge,
  asUsername,
  parseMemo,
  serviceKey,
  nameWithId,
  optionLabel,
  stripPanelPrefix,
} from "@/lib/smm/fn";
import { loadAllCatalog, peekAllCatalog, subscribeAllCatalog } from "@/lib/smm/all-catalog";
import { type DeskDef, isPinned, useSmmDesks } from "@/lib/smm/desks";
import { toastFavorited, toastPinned } from "@/lib/smm/fav-toast";
import { OrderButton, OrderConfirm, OrderVerify } from "@/components/order-button";
import { formatCount, formatMoney, clampInt } from "@/lib/format";
import { useSmmLive } from "@/lib/smm/live-store";
import { useSmmOrders } from "@/lib/smm/orders";
import { useSmmPrefs } from "@/lib/smm/prefs";
import { syncCloudNow } from "@/components/cloud-sync";
import { linkMismatch, looksUrl } from "@/lib/smm/link";

function formatCap(n: number): string {
  if (n >= 1_000_000_000) return "No cap";
  return formatCount(n);
}

function formatCharge(n: number): string {
  if (!Number.isFinite(n) || n <= 0) return "$0.00";
  if (n >= 0.01) return formatMoney(n);
  return `$${n.toFixed(4).replace(/0+$/, "").replace(/\.$/, "")}`;
}

const DRIP_INTERVALS: { min: number; label: string }[] = [
  { min: 5, label: "5 min" },
  { min: 10, label: "10 min" },
  { min: 20, label: "20 min" },
  { min: 30, label: "30 min" },
  { min: 60, label: "1 h" },
];

function formatSpan(minutes: number): string {
  const n = Math.max(0, Math.floor(minutes));
  if (n < 60) return `${n} min`;
  const h = Math.floor(n / 60);
  const m = n % 60;
  if (h < 24) return m ? `${h}h ${m} min` : `${h}h`;
  const d = Math.floor(h / 24);
  const rh = h % 24;
  return rh ? `${d}d/ ${rh}h` : `${d}d`;
}

function formatRateAmount(n: number): string {
  if (!Number.isFinite(n) || n <= 0) return "$0.00";
  const cents = Math.round(n * 100) / 100;
  if (Math.abs(n - cents) < 0.0005) return formatMoney(n);
  return `$${n.toFixed(3)}`;
}

function formatRate(n: number): string {
  return `${formatRateAmount(n)}/1k`;
}

const SERVICE_CACHE = "smm-service-cache";

function readServiceCache(): SmmService[] {
  try {
    const raw = JSON.parse(localStorage.getItem(SERVICE_CACHE) ?? "[]") as unknown;
    return Array.isArray(raw) ? (raw as SmmService[]) : [];
  } catch {
    return [];
  }
}

function writeServiceCache(rows: SmmService[]) {
  try {
    const map = new Map(readServiceCache().map((s) => [serviceKey(s), s]));
    for (const s of rows) map.set(serviceKey(s), s);
    localStorage.setItem(SERVICE_CACHE, JSON.stringify([...map.values()].slice(-120)));
  } catch {
    /* quota */
  }
}

function pickDeskServices(desk: DeskDef, all: SmmCatalogPayload | null): SmmService[] {
  if (!all?.services.length) return [];
  const out: SmmService[] = [];
  for (const row of desk.services) {
    const hit = all.services.find((s) => s.panel === row.panel && s.id === row.id);
    if (hit) out.push(hit);
  }
  return out;
}

function stubService(row: { panel: PanelId; id: number; title: string }): SmmService {
  const hit = readServiceCache().find((s) => s.panel === row.panel && s.id === row.id);
  if (hit) return { ...hit, name: hit.name || row.title };
  return {
    panel: row.panel,
    id: row.id,
    name: row.title,
    category: "",
    rate: "0",
    min: 1,
    max: 100_000_000,
    type: "Default",
    dripfeed: false,
    refill: true,
    cancel: false,
    averageTime: null,
    speed: null,
  };
}

const fieldClass =
  "min-h-11 w-full rounded-lg bg-elevated px-3 text-base text-fg outline-none placeholder:text-subtle disabled:opacity-40";

function mergePanels(prev: PanelBalance[], incoming: PanelBalance[]): PanelBalance[] {
  return incoming.map((p) => {
    if (p.balance === "—" || p.balance === "…") {
      return prev.find((x) => x.id === p.id) ?? p;
    }
    return p;
  });
}

function debitPanel(panels: PanelBalance[], id: PanelId, amount: number): PanelBalance[] {
  if (!Number.isFinite(amount) || amount <= 0) return panels;
  return panels.map((p) => {
    if (p.id !== id) return p;
    if (p.balance === "—" || p.balance === "…") return p;
    const n = Number(p.balance);
    if (!Number.isFinite(n)) return p;
    return { ...p, balance: Math.max(0, n - amount).toFixed(2) };
  });
}

function deskHint(id: string): string {
  if (id.includes("youtube")) return "https://www.youtube.com/…";
  if (id.includes("instagram")) return "https://www.instagram.com/…";
  if (id.includes("tiktok")) return "https://www.tiktok.com/…";
  return "https://…";
}

function deskAccent(id: string): string {
  if (id.includes("youtube")) return "accent-yt";
  if (id.includes("instagram")) return "accent-ig";
  return "accent-tt";
}

export function SmmPanels({ desk }: { desk: DeskDef }) {
  const search = useSearch({ from: "/" });
  const navigate = useNavigate({ from: "/" });
  const [data, setData] = useState<SmmCatalogPayload | null>(() => ({
    panels: [],
    services: desk.services.map(stubService),
  }));
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [serviceKeyValue, setServiceKeyValue] = useState(
    () => useSmmPrefs.getState().lastService[desk.id] || (desk.services[0] ? `${desk.services[0].panel}:${desk.services[0].id}` : ""),
  );
  const [seedLink, setSeedLink] = useState("");
  const seqRef = useRef(0);
  const deskIds = [...new Set(desk.services.map((row) => row.panel))];
  const linkHint = deskHint(desk.id);
  const accent = deskAccent(desk.id);
  const pickKey = desk.services.map((row) => `${row.panel}:${row.id}`).join(",");
  const prefillRef = useRef({ svc: search.svc, link: search.link });
  prefillRef.current = { svc: search.svc, link: search.link };

  function applyPanels(incoming: PanelBalance[], seq: number) {
    if (seq !== seqRef.current) return;
    useSmmLive.getState().apply(incoming);
    setData((prev) => {
      if (!prev) return prev;
      return { ...prev, panels: mergePanels(prev.panels, incoming) };
    });
  }

  useEffect(() => {
    let alive = true;
    seqRef.current = 0;
    const boot = seqRef.current;
    const fallback = desk.services.map(stubService);
    setError(null);
    setData((prev) => {
      const fromAll = pickDeskServices(desk, peekAllCatalog());
      const have = fromAll.length ? fromAll : prev?.services.length ? prev.services : fallback;
      return { panels: prev?.panels ?? [], services: have };
    });
    setServiceKeyValue((prev) => {
      const wanted = prefillRef.current.svc || useSmmPrefs.getState().lastService[desk.id] || prev;
      if (wanted && fallback.some((s) => serviceKey(s) === wanted)) return wanted;
      return fallback[0] ? serviceKey(fallback[0]) : "";
    });
    const stop = subscribeAllCatalog((all) => {
      if (!alive) return;
      const services = pickDeskServices(desk, all);
      if (!services.length) return;
      writeServiceCache(services);
      useSmmDesks.getState().syncServiceNames(services);
      setData((prev) => ({ panels: prev?.panels ?? [], services }));
      setLoading(false);
    });
    void loadAllCatalog()
      .then((all) => {
        if (!alive) return;
        const services = pickDeskServices(desk, all);
        if (services.length) {
          writeServiceCache(services);
          useSmmDesks.getState().syncServiceNames(services);
          setData((prev) => ({ panels: prev?.panels ?? [], services }));
        }
        setServiceKeyValue((prev) => {
          const wanted = prefillRef.current.svc || useSmmPrefs.getState().lastService[desk.id];
          const list = services.length ? services : fallback;
          if (wanted && list.some((s) => serviceKey(s) === wanted)) return wanted;
          if (list.some((s) => serviceKey(s) === prev)) return prev;
          return list[0] ? serviceKey(list[0]) : "";
        });
        if (prefillRef.current.link) setSeedLink(prefillRef.current.link);
      })
      .catch((err: unknown) => {
        if (!alive) return;
        if (seqRef.current !== boot) return;
        if (pickDeskServices(desk, peekAllCatalog()).length) return;
        setError(err instanceof Error ? err.message : "Could not load services");
      })
      .finally(() => {
        if (alive) setLoading(false);
      });
    return () => {
      alive = false;
      stop();
    };
  }, [desk.id, pickKey]);

  useEffect(() => {
    if (search.tab !== desk.id) return;
    if (!search.link && !search.svc) return;
    if (search.link) setSeedLink(search.link);
    if (search.svc) setServiceKeyValue(search.svc);
    void navigate({ to: "/", search: { tab: desk.id }, replace: true });
  }, [search.tab, search.link, search.svc, desk.id, navigate]);

  const livePanels = useSmmLive((s) => s.panels);

  const selected: SmmService | undefined = useMemo(
    () => data?.services.find((s) => serviceKey(s) === serviceKeyValue),
    [data, serviceKeyValue],
  );

  const panels: PanelBalance[] = deskIds.map((id) => {
    const live = livePanels.find((row) => row.id === id);
    const local = data?.panels.find((row) => row.id === id);
    return (
      live ??
      local ?? {
        id,
        label: PANEL_LABELS[id] ?? id,
        balance: loading ? "…" : "—",
        currency: "USD",
      }
    );
  });

  return (
    <div className="mx-auto flex max-w-2xl flex-col gap-6 px-3 py-4 pb-10 lg:px-6">
      {error ? <p className={`text-sm ${desk.id.includes("youtube") ? "text-yt" : "text-tt"}`}>{error}</p> : null}

      {desk.services.length === 0 ? (
        <p className="rounded-xl bg-surface px-4 py-6 text-sm text-muted">
          No favorites here. Star a service in All services.
        </p>
      ) : (
      <>
      <div>
        <span className="mb-2 block text-xs font-medium tracking-wide text-muted uppercase">Service</span>
        <div className="flex items-center gap-2">
          {selected ? <ServiceFav service={selected} deskId={desk.id} /> : null}
          <select
            value={serviceKeyValue}
            disabled={!data || data.services.length === 0}
            onChange={(e) => {
              setServiceKeyValue(e.target.value);
              useSmmPrefs.getState().setLastService(desk.id, e.target.value);
            }}
            aria-label="Service"
            className={`field-select min-w-0 flex-1 ${fieldClass}`}
          >
            {data?.services.length ? (
              data.services.map((s) => (
                <option key={serviceKey(s)} value={serviceKey(s)}>
                  {optionLabel(
                    s,
                    desk.services.find((row) => row.panel === s.panel && row.id === s.id)?.title,
                  )}
                </option>
              ))
            ) : (
              <option value="">{loading ? "Loading…" : "No services"}</option>
            )}
          </select>
        </div>
      </div>

      {selected ? (
        <ServiceForm
          key={serviceKey(selected)}
          service={selected}
          deskId={desk.id}
          seedLink={seedLink}
          panelBalance={panels.find((p) => p.id === selected.panel)}
          onOrderStart={(panel, amount) => {
            const seq = ++seqRef.current;
            setData((prev) => (prev ? { ...prev, panels: debitPanel(prev.panels, panel, amount) } : prev));
            return seq;
          }}
          onOrdered={(nextPanels, seq) => applyPanels(nextPanels, seq)}
          onOrderFailed={(seq) => {
            if (seq !== seqRef.current) return;
            const next = ++seqRef.current;
            void loadSmmLive()
              .then((nextPanels) => applyPanels(nextPanels, next))
              .catch(() => {
                /* keep last known */
              });
            toast.message("Balance restored");
          }}
          linkHint={linkHint}
          accentClass={accent}
          showFav={false}
        />
      ) : null}
      </>
      )}
    </div>
  );
}

function favHint(service: SmmService, deskId: string): { id: string; label: string } {
  const desks = useSmmDesks.getState().desks;
  const desk = desks.find((d) => d.id === deskId);
  if (desk) return { id: desk.id, label: desk.label };
  const hay = `${service.category} ${service.name}`.toLowerCase();
  if (hay.includes("tiktok")) return { id: "tiktok", label: "TikTok" };
  if (hay.includes("youtube") || hay.includes("youtu.be")) return { id: "youtube", label: "YouTube" };
  if (hay.includes("instagram")) return { id: "instagram", label: "Instagram" };
  if (hay.includes("facebook") || /\bfb\b/.test(hay)) return { id: "facebook", label: "Facebook" };
  if (hay.includes("telegram")) return { id: "telegram", label: "Telegram" };
  if (hay.includes("spotify")) return { id: "spotify", label: "Spotify" };
  if (hay.includes("twitter") || hay.includes("tweet")) return { id: "twitter", label: "Twitter" };
  if (/web\s*traffic|website/.test(hay)) return { id: "traffic", label: "Web traffic" };
  return { id: "other", label: "Other" };
}

export function ServiceFav({
  service,
  deskId,
  compact,
}: {
  service: SmmService;
  deskId: string;
  compact?: boolean;
}) {
  const desks = useSmmDesks((s) => s.desks);
  const fav = desks.some((d) => d.services.some((row) => row.panel === service.panel && row.id === service.id));
  const pinned = isPinned(service.panel, service.id);
  const [ask, setAsk] = useState(false);
  const navigate = useNavigate({ from: "/" });

  if (pinned) return null;

  function apply() {
    const adding = !useSmmDesks
      .getState()
      .desks.some((d) => d.services.some((row) => row.panel === service.panel && row.id === service.id));
    const hint = favHint(service, deskId);
    const err = useSmmDesks.getState().toggleFavorite(
      { panel: service.panel, id: service.id, title: stripPanelPrefix(service.name, service.panel) },
      hint,
    );
    if (err === "pinned") toastPinned();
    else if (err) toast.warning(err);
    else if (adding) {
      const hit =
        useSmmDesks.getState().desks.find((d) => d.services.some((row) => row.panel === service.panel && row.id === service.id)) ??
        null;
      toastFavorited(hit?.label ?? hint.label, () => {
        void navigate({ to: "/", search: { tab: hit?.id ?? hint.id } });
      });
    }
    setAsk(false);
  }

  return (
    <>
      <button
        type="button"
        aria-label={fav ? "Remove from favorites" : "Add to favorites"}
        aria-pressed={fav}
        onClick={(e) => {
          e.stopPropagation();
          if (fav) {
            if (pinned) {
              toastPinned();
              return;
            }
            setAsk(true);
            return;
          }
          apply();
        }}
        className={
          compact
            ? "flex size-11 shrink-0 items-center justify-center rounded-lg touch-manipulation lg:size-9"
            : "flex size-11 shrink-0 items-center justify-center rounded-full bg-elevated touch-manipulation lg:size-9"
        }
      >
        <Star className={`size-5 ${fav ? "text-fav-star" : "text-muted"}`} fill={fav ? "currentColor" : "none"} strokeWidth={fav ? 0 : 2} />
      </button>
      {ask
        ? createPortal(
            <div className="order-verify" role="dialog" aria-modal="true" aria-labelledby="unfav-title">
              <button type="button" className="order-verify-scrim" aria-label="Cancel" onClick={() => setAsk(false)} />
              <div className="order-verify-card">
                <p id="unfav-title" className="text-base font-bold text-fg">
                  Remove from Favorites?
                </p>
                <p className="mt-2 text-sm text-muted">This service will leave the Favorites tab.</p>
                <div className="order-verify-acts">
                  <button type="button" className="order-verify-yes" onClick={apply}>
                    Yes
                  </button>
                  <button type="button" className="order-verify-no" onClick={() => setAsk(false)}>
                    No
                  </button>
                </div>
              </div>
            </div>,
            document.body,
          )
        : null}
    </>
  );
}

export function ServiceForm({
  service,
  deskId,
  seedLink,
  panelBalance,
  onOrderStart,
  onOrdered,
  onOrderFailed,
  linkHint,
  accentClass,
  showFav = true,
  lockLink = false,
}: {
  service: SmmService;
  deskId: string;
  seedLink: string;
  panelBalance?: PanelBalance;
  onOrderStart: (panel: PanelId, amount: number) => number;
  onOrdered: (panels: PanelBalance[], seq: number) => void;
  onOrderFailed: (seq: number) => void;
  linkHint: string;
  accentClass: string;
  showFav?: boolean;
  lockLink?: boolean;
}) {
  const lastQty = useSmmPrefs((s) => s.lastQty[serviceKey(service)]);
  const [link, setLink] = useState(seedLink);
  const [qty, setQty] = useState(String(lastQty ? clampInt(lastQty, service.min, service.max) : service.min));
  const [snap, setSnap] = useState<string | null>(null);
  const [dripOn, setDripOn] = useState(false);
  const [runs, setRuns] = useState("1");
  const [interval, setInterval] = useState("10");
  const [memo, setMemo] = useState("");
  const [who, setWho] = useState("");
  const [hashtag, setHashtag] = useState("");
  const [media, setMedia] = useState("");
  const [answer, setAnswer] = useState("1");
  const [subMin, setSubMin] = useState(String(service.min));
  const [subMax, setSubMax] = useState(String(service.max));
  const [posts, setPosts] = useState("0");
  const [delay, setDelay] = useState("0");
  const [expiry, setExpiry] = useState("");
  const [busy, setBusy] = useState(false);
  const [confirmed, setConfirmed] = useState(false);
  const [verify, setVerify] = useState(false);
  const [preview, setPreview] = useState<{ thumb: string | null; title: string | null } | null>(null);
  const [pasteHit, setPasteHit] = useState(false);
  const [clearHit, setClearHit] = useState(false);
  const submittingRef = useRef(false);
  const linkRef = useRef<HTMLInputElement>(null);
  const linkDirty = useRef(false);
  const rememberOrder = useSmmOrders((s) => s.remember);
  const patchMedia = useSmmOrders((s) => s.patchMedia);

  useEffect(() => {
    if (!seedLink || linkDirty.current) return;
    setLink(seedLink);
  }, [seedLink]);

  useEffect(() => {
    const href = link.trim();
    if (!looksUrl(href)) {
      setPreview(null);
      return;
    }
    let alive = true;
    const t = window.setTimeout(() => {
      void loadLinkPreview({ data: { url: href } })
        .then((data) => {
          if (alive) setPreview(data);
        })
        .catch(() => {
          if (alive) setPreview(null);
        });
    }, 400);
    return () => {
      alive = false;
      window.clearTimeout(t);
    };
  }, [link]);

  const needs = orderNeeds(service);
  const drip = needs.drip;
  const memoLines = needs.lines ? parseMemo(memo, service.max) : [];
  const quantity =
    needs.quantity === "from-lines"
      ? memoLines.length
      : needs.quantity === "hidden"
        ? 1
        : clampInt(Number(qty), service.min, service.max);
  const runCount = drip && dripOn ? clampInt(Number(runs), 1, 1_000_000) : 1;
  const intervalMin = drip && dripOn ? clampInt(Number(interval), 1, 1_000_000) : 0;
  const units = Math.max(quantity, 0) * runCount;
  const dripOver = drip && dripOn && units > service.max;
  const charge = orderCharge(service, units);
  const bal =
    panelBalance && panelBalance.balance !== "—" && panelBalance.balance !== "…"
      ? Number(panelBalance.balance)
      : NaN;
  const short = Number.isFinite(bal) && charge > bal + 0.0001;
  const mismatch = needs.target === "link" && linkMismatch(link, deskId);
  const memoReady =
    !needs.lines ||
    needs.quantity !== "from-lines" ||
    (memoLines.length >= service.min && memoLines.length <= service.max);
  const extraReady =
    (!needs.username || Boolean(asUsername(who))) &&
    (!needs.hashtag || Boolean(hashtag.replace(/^#/, "").trim())) &&
    (!needs.media || looksUrl(media)) &&
    (!needs.answer || Math.floor(Number(answer)) >= 1) &&
    (!needs.subscription || Boolean(asUsername(link)));
  const targetOk = needs.target === "link" ? Boolean(link.trim()) : Boolean(asUsername(link));
  const ready = targetOk && !short && !mismatch && !busy && memoReady && extraReady && !dripOver;

  function applyQty(n: number) {
    const next = clampInt(n, service.min, service.max);
    const raw = Number(qty);
    if (Number.isFinite(raw) && raw !== next && String(qty).trim() !== "") {
      setSnap(`${Math.floor(raw)} → ${next}`);
    } else {
      setSnap(null);
    }
    setQty(String(next));
  }

  const qtyField =
    needs.quantity === "hidden" ? null : (
      <label className="block">
        <span className="mb-2 block text-xs font-medium tracking-wide text-muted uppercase">
          {drip && dripOn ? "Quantity each time" : "Quantity"}
        </span>
        <input
          type="number"
          min={service.min}
          max={service.max}
          value={needs.quantity === "from-lines" ? String(memoLines.length || "") : qty}
          readOnly={needs.quantity === "from-lines"}
          onChange={(e) => {
            if (needs.quantity === "from-lines") return;
            setSnap(null);
            setQty(e.target.value);
          }}
          onBlur={() => {
            if (needs.quantity !== "from-lines") applyQty(Number(qty));
          }}
          aria-label="Quantity"
          className={fieldClass}
        />
        <span className="mt-2 block text-xs text-muted">
          {needs.quantity === "from-lines"
            ? "Matches how many lines you typed"
            : `${formatCap(service.min)} – ${formatCap(service.max)}`}
          {snap ? <span className="text-fg"> · {snap}</span> : null}
        </span>
      </label>
    );

  const pasteListen = useRef<((e: ClipboardEvent) => void) | null>(null);

  function applyPaste(raw: string) {
    const text = raw.trim();
    if (!text || lockLink) return false;
    linkDirty.current = true;
    setLink(text);
    setPasteHit(true);
    window.setTimeout(() => setPasteHit(false), 480);
    return true;
  }

  function clipText(data: DataTransfer | null | undefined): string {
    if (!data) return "";
    return (data.getData("text/plain") || data.getData("text/uri-list") || data.getData("text") || "").trim();
  }

  function catchPaste(e: { clipboardData: DataTransfer | null; preventDefault: () => void }) {
    if (applyPaste(clipText(e.clipboardData))) e.preventDefault();
  }

  function armPasteCatch() {
    if (pasteListen.current) window.removeEventListener("paste", pasteListen.current, true);
    const onPaste = (e: ClipboardEvent) => {
      catchPaste(e);
      window.removeEventListener("paste", onPaste, true);
      pasteListen.current = null;
    };
    pasteListen.current = onPaste;
    window.addEventListener("paste", onPaste, true);
    window.setTimeout(() => {
      if (pasteListen.current !== onPaste) return;
      window.removeEventListener("paste", onPaste, true);
      pasteListen.current = null;
    }, 12_000);
  }

  function appleWeb() {
    const ua = navigator.userAgent;
    if (/iPhone|iPad|iPod/i.test(ua)) return true;
    if (/Macintosh/i.test(ua) && navigator.maxTouchPoints > 1) return true;
    return /Safari/i.test(ua) && !/Chrome|Chromium|Android/i.test(ua);
  }

  function startPaste() {
    armPasteCatch();
    linkRef.current?.focus({ preventScroll: true });
    if (appleWeb()) return;
    const clip = navigator.clipboard;
    if (!clip?.readText) return;
    void clip.readText().then((text) => {
      applyPaste(text);
    }).catch(() => {
      /* native paste catch stays armed */
    });
  }

  useEffect(
    () => () => {
      if (pasteListen.current) window.removeEventListener("paste", pasteListen.current, true);
    },
    [],
  );

  function clearLink() {
    if (lockLink || !link.trim()) return;
    linkDirty.current = true;
    setClearHit(true);
    setLink("");
    setPreview(null);
    window.setTimeout(() => setClearHit(false), 480);
  }

  async function submit() {
    if (submittingRef.current || short || mismatch || !targetOk || !memoReady || !extraReady) return;
    const nextQty =
      needs.quantity === "from-lines"
        ? memoLines.length
        : needs.quantity === "hidden"
          ? 1
          : clampInt(Number(qty), service.min, service.max);
    if (needs.quantity === "from-lines" && nextQty < service.min) return;
    const perRun = nextQty;
    const runCap = drip && dripOn ? Math.max(1, Math.floor(service.max / Math.max(perRun, 1))) : 1;
    const nextRuns = drip && dripOn ? clampInt(Number(runs), 1, runCap) : 1;
    const nextInterval = drip && dripOn ? clampInt(Number(interval), 1, 1_000_000) : 1;
    setQty(String(nextQty));
    if (drip && dripOn) {
      setRuns(String(nextRuns));
      setInterval(String(nextInterval));
    }
    submittingRef.current = true;
    setBusy(true);
    const seq = onOrderStart(service.panel, orderCharge(service, nextQty * nextRuns));
    const extras: Record<string, string> = {};
    if (needs.lines) extras[needs.lines.param] = memoLines.join("\n");
    if (needs.username) extras.username = asUsername(who);
    if (needs.subscription) extras.username = asUsername(link);
    if (needs.hashtag) extras.hashtag = hashtag.replace(/^#/, "").trim();
    if (needs.media) extras.media = media.trim();
    if (needs.answer) extras.answer_number = String(Math.max(1, Math.floor(Number(answer) || 1)));
    if (needs.subscription) {
      extras.min = String(clampInt(Number(subMin), 1, 1_000_000_000));
      extras.max = String(Math.max(clampInt(Number(subMax), 1, 1_000_000_000), Number(extras.min)));
      extras.posts = String(Math.max(0, Math.floor(Number(posts) || 0)));
      extras.delay = String(Math.max(0, Math.floor(Number(delay) || 0)));
      if (expiry) {
        const [y, m, d] = expiry.split("-");
        if (y && m && d) extras.expiry = `${d}/${m}/${y}`;
      }
    }
    try {
      const res = await placeSmmOrder({
        data: {
          panel: service.panel,
          service: service.id,
          link,
          quantity: nextQty,
          runs: drip && dripOn ? nextRuns : undefined,
          interval: drip && dripOn ? nextInterval : undefined,
          extras,
        },
      });
      rememberOrder({
        panel: service.panel,
        order: res.order,
        service: service.id,
        name: nameWithId(service),
        link,
        quantity: nextQty * nextRuns,
        refill: allowsRefill(service),
        at: Date.now(),
        desk: deskId,
        thumb: preview?.thumb ?? null,
        mediaTitle: preview?.title ?? null,
        startOnPost: res.startOnPost,
        metric: res.metric,
        actual: res.startOnPost,
        actualAt: Date.now(),
        source: res.startOnPost != null ? "post" : null,
        runs: drip && dripOn ? nextRuns : undefined,
      });
      void syncCloudNow();
      useSmmPrefs.getState().setLastQty(serviceKey(service), nextQty);
      useSmmPrefs.getState().rememberLink(link);
      const placed = { order: res.order, panel: service.panel, url: link };
      void loadLinkPreview({ data: { url: placed.url } })
        .then((data) => {
          patchMedia(placed.order, placed.panel, {
            thumb: data.thumb ?? "",
            mediaTitle: data.title,
          });
        })
        .catch(() => {
          patchMedia(placed.order, placed.panel, { thumb: "", mediaTitle: null });
        });
      onOrdered(res.panels, seq);
      setLink("");
      setPreview(null);
      setQty(String(nextQty));
      setSnap(null);
      setDripOn(false);
      setRuns("1");
      setInterval("10");
      setMemo("");
      setWho("");
      setHashtag("");
      setMedia("");
      setAnswer("1");
      setPosts("0");
      setDelay("0");
      setExpiry("");
      setConfirmed(true);
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Could not place order");
      onOrderFailed(seq);
    } finally {
      submittingRef.current = false;
      setBusy(false);
    }
  }

  return (
    <div className="flex flex-col gap-5">
      {showFav ? (
        <div className="flex justify-end">
          <ServiceFav service={service} deskId={deskId} />
        </div>
      ) : null}
      <div>
        <span className="mb-2 block text-xs font-medium tracking-wide text-muted uppercase">
          {needs.target === "username" ? "Username" : "Link"}
        </span>
        <div className="relative z-[2] flex gap-2">
          <input
            ref={linkRef}
            value={link}
            readOnly={lockLink}
            onChange={(e) => {
              if (lockLink) return;
              linkDirty.current = true;
              setLink(e.target.value);
            }}
            onPaste={(e) => {
              if (lockLink) {
                e.preventDefault();
                return;
              }
              catchPaste(e);
            }}
            placeholder={needs.target === "username" ? "@username" : linkHint}
            aria-label={needs.target === "username" ? "Username" : "Link"}
            autoComplete="off"
            autoCorrect="off"
            autoCapitalize="off"
            spellCheck={false}
            inputMode="url"
            className={`${fieldClass} min-w-0 flex-1 ${lockLink ? "cursor-default" : ""}`}
          />
          {lockLink ? null : (
            <>
              <button
                type="button"
                onPointerDown={(e) => {
                  if (e.button !== 0) return;
                  startPaste();
                }}
                onPaste={catchPaste}
                aria-label="Paste link"
                className={pasteHit ? "paste-btn paste-btn--in is-hit" : "paste-btn paste-btn--in"}
              >
                {pasteHit ? <Check className="size-4" strokeWidth={2.6} /> : <ClipboardPaste className="size-4" />}
              </button>
              <button
                type="button"
                disabled={!link.trim()}
                onPointerDown={(e) => {
                  e.preventDefault();
                  clearLink();
                }}
                aria-label="Clear link"
                className={clearHit ? "paste-btn paste-btn--off is-hit" : "paste-btn paste-btn--off"}
              >
                <X className="size-4" strokeWidth={2.6} />
              </button>
            </>
          )}
        </div>
      </div>
      {mismatch ? <p className="text-sm text-neon-red">This link doesn’t match this tab.</p> : null}
      {preview && (preview.thumb || preview.title) ? (
        <div className="flex items-center gap-3 rounded-xl bg-surface px-3 py-3">
          {preview.thumb ? (
            <img src={preview.thumb} alt="" referrerPolicy="no-referrer" className="size-14 rounded-lg object-cover" />
          ) : (
            <div className="size-14 rounded-lg bg-elevated" />
          )}
          <p className="min-w-0 truncate text-sm font-semibold text-fg">{preview.title || "Post"}</p>
        </div>
      ) : null}

      {needs.lines ? (
        <label className="block">
          <span className="mb-2 block text-xs font-medium tracking-wide text-muted uppercase">
            {needs.lines.label}
          </span>
          <textarea
            value={memo}
            onChange={(e) => setMemo(e.target.value)}
            rows={6}
            aria-label={needs.lines.label}
            placeholder={needs.lines.hint}
            autoComplete="off"
            spellCheck={needs.lines.param === "comments"}
            className={`${fieldClass} min-h-28 resize-y py-3 leading-snug`}
          />
          <span className="mt-2 block text-xs text-muted">
            {memoLines.length} {needs.lines.label.toLowerCase()}
            {needs.quantity === "from-lines"
              ? ` · min ${formatCap(service.min)} · max ${formatCap(service.max)}`
              : null}
            {needs.quantity === "from-lines" && memoLines.length < service.min
              ? ` · add ${service.min - memoLines.length} more`
              : null}
          </span>
        </label>
      ) : null}

      {needs.username ? (
        <label className="block">
          <span className="mb-2 block text-xs font-medium tracking-wide text-muted uppercase">{needs.username.label}</span>
          <input
            value={who}
            onChange={(e) => setWho(e.target.value)}
            placeholder={needs.username.hint}
            aria-label={needs.username.label}
            autoComplete="off"
            autoCorrect="off"
            autoCapitalize="off"
            spellCheck={false}
            className={fieldClass}
          />
        </label>
      ) : null}

      {needs.hashtag ? (
        <label className="block">
          <span className="mb-2 block text-xs font-medium tracking-wide text-muted uppercase">Hashtag</span>
          <input
            value={hashtag}
            onChange={(e) => setHashtag(e.target.value)}
            placeholder="#hashtag"
            aria-label="Hashtag"
            autoComplete="off"
            autoCorrect="off"
            autoCapitalize="off"
            spellCheck={false}
            className={fieldClass}
          />
        </label>
      ) : null}

      {needs.media ? (
        <label className="block">
          <span className="mb-2 block text-xs font-medium tracking-wide text-muted uppercase">Media link</span>
          <input
            value={media}
            onChange={(e) => setMedia(e.target.value)}
            placeholder="https://…"
            aria-label="Media link"
            autoComplete="off"
            autoCorrect="off"
            autoCapitalize="off"
            spellCheck={false}
            className={fieldClass}
          />
        </label>
      ) : null}

      {needs.answer ? (
        <label className="block">
          <span className="mb-2 block text-xs font-medium tracking-wide text-muted uppercase">Poll answer</span>
          <input
            type="number"
            min={1}
            value={answer}
            onChange={(e) => setAnswer(e.target.value)}
            onBlur={() => setAnswer(String(Math.max(1, Math.floor(Number(answer) || 1))))}
            aria-label="Poll answer"
            className={fieldClass}
          />
          <span className="mt-2 block text-xs text-muted">Which option to vote for (1, 2, 3…)</span>
        </label>
      ) : null}

      {needs.subscription ? (
        <div className="grid grid-cols-2 gap-3">
          <label className="block min-w-0">
            <span className="mb-2 block text-xs font-medium tracking-wide text-muted uppercase">Min per post</span>
            <input
              type="number"
              min={1}
              value={subMin}
              onChange={(e) => setSubMin(e.target.value)}
              aria-label="Min per post"
              className={fieldClass}
            />
          </label>
          <label className="block min-w-0">
            <span className="mb-2 block text-xs font-medium tracking-wide text-muted uppercase">Max per post</span>
            <input
              type="number"
              min={1}
              value={subMax}
              onChange={(e) => setSubMax(e.target.value)}
              aria-label="Max per post"
              className={fieldClass}
            />
          </label>
          <label className="block min-w-0">
            <span className="mb-2 block text-xs font-medium tracking-wide text-muted uppercase">Posts</span>
            <input
              type="number"
              min={0}
              value={posts}
              onChange={(e) => setPosts(e.target.value)}
              aria-label="Posts"
              className={fieldClass}
            />
            <span className="mt-2 block text-xs text-muted">0 = unlimited</span>
          </label>
          <label className="block min-w-0">
            <span className="mb-2 block text-xs font-medium tracking-wide text-muted uppercase">Delay (min)</span>
            <input
              type="number"
              min={0}
              value={delay}
              onChange={(e) => setDelay(e.target.value)}
              aria-label="Delay"
              className={fieldClass}
            />
          </label>
          <label className="col-span-2 block min-w-0">
            <span className="mb-2 block text-xs font-medium tracking-wide text-muted uppercase">Expiry</span>
            <input
              type="date"
              value={expiry}
              onChange={(e) => setExpiry(e.target.value)}
              aria-label="Expiry"
              className={fieldClass}
            />
            <span className="mt-2 block text-xs text-muted">Optional</span>
          </label>
        </div>
      ) : null}

      {!(drip && dripOn) ? qtyField : null}

      <div>
        <span className="mb-2 block text-xs font-medium tracking-wide text-muted uppercase">Average time</span>
        <p className="rounded-lg bg-elevated px-3 py-3 text-base text-fg">
          {service.averageTime || "Not listed"}
        </p>
      </div>

      {drip ? (
        <div className="rounded-xl bg-surface px-4 py-4">
          <label className="flex min-h-11 items-center gap-3">
            <input
              type="checkbox"
              checked={dripOn}
              onChange={(e) => setDripOn(e.target.checked)}
              className={`size-4 ${accentClass}`}
            />
            <span className="text-sm font-semibold text-fg">Drip-feed</span>
          </label>
          {dripOn ? (
            <>
              <div className="mt-4">{qtyField}</div>
              <div className="mt-4 grid grid-cols-2 gap-3">
                <label className="block min-w-0">
                  <span className="mb-2 block text-xs font-medium tracking-wide text-muted uppercase">Runs</span>
                  <input
                    type="number"
                    min={1}
                    value={runs}
                    onChange={(e) => setRuns(e.target.value)}
                    onBlur={() => {
                      const cap = Math.max(1, Math.floor(service.max / Math.max(quantity, 1)));
                      setRuns(String(clampInt(Number(runs), 1, cap)));
                    }}
                    aria-label="Drip runs"
                    className={fieldClass}
                  />
                </label>
                <label className="block min-w-0">
                  <span className="mb-2 block text-xs font-medium tracking-wide text-muted uppercase">Wait between</span>
                  <input
                    type="number"
                    min={1}
                    value={interval}
                    onChange={(e) => setInterval(e.target.value)}
                    onBlur={() => setInterval(String(clampInt(Number(interval), 1, 1_000_000)))}
                    aria-label="Wait between runs, in minutes"
                    className={fieldClass}
                  />
                  <span className="mt-2 block text-xs text-muted">Minutes</span>
                </label>
              </div>
              <div className="mt-3 flex flex-wrap justify-end gap-2">
                {DRIP_INTERVALS.map((row) => {
                  const on = intervalMin === row.min;
                  return (
                    <button
                      key={row.min}
                      type="button"
                      aria-pressed={on}
                      onClick={() => setInterval(String(row.min))}
                      className={`min-h-11 rounded-full px-3 text-sm font-semibold lg:min-h-9 ${
                        on ? "bg-elevated text-fg ring-1 ring-fg/30" : "bg-bg text-muted"
                      }`}
                    >
                      {row.label}
                    </button>
                  );
                })}
              </div>
              <div className="mt-4 rounded-lg bg-bg px-3 py-3">
                <p className="text-xs font-medium tracking-wide text-muted uppercase">Total</p>
                <p className="money mt-1 text-2xl leading-none text-fg tabular-nums">{formatCount(units)}</p>
                <p className="mt-2 text-sm text-muted">
                  {formatCount(quantity)} each × {formatCount(runCount)} runs
                </p>
                <p className="mt-1 text-sm text-muted">
                  {runCount > 1
                    ? `First batch now, then every ${formatCount(intervalMin)} min. Last batch in ${formatSpan(intervalMin * (runCount - 1))}.`
                    : "One batch, sent now."}
                </p>
                {dripOver ? (
                  <p className="mt-2 text-xs text-neon-red">
                    Total {formatCap(units)} is over this service max ({formatCap(service.max)}). Lower quantity or runs.
                  </p>
                ) : null}
              </div>
            </>
          ) : null}
        </div>
      ) : null}

      <div className="order-dock flex items-end justify-between gap-3">
        <div>
          <p className="text-xs font-medium tracking-wide text-muted uppercase">Charge</p>
          <p className="money mt-1 text-[1.75rem] leading-none text-matte-green">{formatCharge(charge)}</p>
          {short ? (
            <p className="mt-1 text-xs text-neon-red">Add funds on {panelLabel(service.panel)}</p>
          ) : null}
        </div>
        <OrderButton ready={ready} busy={busy} onPress={() => setVerify(true)} />
      </div>
      <OrderVerify
        open={verify}
        info={
          verify
            ? {
                name: nameWithId(service),
                link: link.trim(),
                quantity: units,
                charge: formatCharge(charge),
                panel: panelLabel(service.panel),
                dripFeed: Boolean(drip && dripOn),
                drip:
                  drip && dripOn
                    ? `${formatCount(quantity)} each · ${formatCount(runCount)} runs · first now, then every ${formatCount(intervalMin)} min${
                        runCount > 1 ? ` · last batch in ${formatSpan(intervalMin * (runCount - 1))}` : ""
                      }`
                    : null,
                memo: [
                  needs.lines ? `${memoLines.length} ${needs.lines.label.toLowerCase()}` : "",
                  needs.username ? `@${asUsername(who)}` : "",
                  needs.hashtag ? `#${hashtag.replace(/^#/, "")}` : "",
                  needs.answer ? `Answer ${answer}` : "",
                  needs.subscription ? `@${asUsername(link)}` : "",
                ]
                  .filter(Boolean)
                  .join(" · ") || null,
                thumb: preview?.thumb ?? null,
              }
            : null
        }
        onYes={() => {
          setVerify(false);
          void submit();
        }}
        onNo={() => setVerify(false)}
      />
      <OrderConfirm open={confirmed} onClose={() => setConfirmed(false)} />
    </div>
  );
}
