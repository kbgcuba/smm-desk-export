import { useEffect, useRef, useState, type PointerEvent } from "react";
import { createPortal } from "react-dom";
import { GripVertical, Pin, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { loadWpList, saveWpList, findBrandBadge } from "@/lib/smm/fn";
import { linkReady, type BrandHit } from "@/lib/smm/brand-badge";
import { WP_BADGE_DEFS, wpBadge } from "@/lib/smm/wp-badges";
import {
  WP_BADGES,
  WP_LAYOUTS,
  WP_LOOKS,
  WP_SIZES,
  WP_THUMBS,
  WP_TONES,
  defaultWpStyle,
  insertLink,
  mergeSavedBadges,
  moveUnpinned,
  unpinnedDrop,
  type WpItem,
  type WpList,
  type WpSavedBadge,
  type WpStyle,
} from "@/lib/smm/wp-list";

const field = "min-h-12 w-full rounded-xl bg-elevated px-3 text-[16px] text-fg outline-none";
const SWIPE_W = 88;

function BadgeFace({
  id,
  className,
  saved,
  face,
}: {
  id?: string;
  className?: string;
  saved?: WpSavedBadge[];
  face?: { bg: string; fg: string; img: string; path: string };
}) {
  const custom = !face && id ? saved?.find((row) => row.id === id) : undefined;
  const def = face
    ? { bg: face.bg, fg: face.fg, img: face.img, path: face.path, fill: true as const, text: "" }
    : custom
      ? { bg: custom.bg, fg: custom.fg, img: custom.img, path: custom.path, fill: true as const, text: "" }
      : id
        ? wpBadge(id)
        : null;
  if (!def) return null;
  if (def.img) {
    return (
      <span className={`wp-badge ${className ?? ""}`} style={{ background: def.bg, color: def.fg }} aria-hidden>
        <img src={def.img} alt="" className="relative z-[1] h-[72%] w-[86%] object-contain" />
      </span>
    );
  }
  if (def.text) {
    return (
      <span className={`wp-badge ${className ?? ""}`} style={{ background: def.bg, color: def.fg }} aria-hidden>
        <span className="relative z-[1] text-[0.72rem] leading-none font-extrabold tracking-tight">{def.text}</span>
      </span>
    );
  }
  return (
    <span className={`wp-badge ${className ?? ""}`} style={{ background: def.bg, color: def.fg }} aria-hidden>
      <svg viewBox="0 0 24 24" className="size-[78%]" fill={def.fill ? "currentColor" : "none"} stroke={def.fill ? "none" : "currentColor"} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
        <path d={def.path || ""} />
      </svg>
    </span>
  );
}

function stashBadge(list: WpList, hit: BrandHit): WpSavedBadge[] {
  const badges = list.badges ?? [];
  if (wpBadge(hit.id)) return badges;
  const prev = badges.find((row) => row.id === hit.id);
  if (prev?.listed) return badges;
  return mergeSavedBadges(badges, [
    { id: hit.id, label: hit.label, bg: hit.bg, fg: hit.fg, img: hit.img, path: hit.path, listed: true },
  ]);
}

function badgeHit(label: string, id: string, raw: string) {
  const q = raw.trim().toLowerCase();
  if (!q) return true;
  if (label.toLowerCase().includes(q) || id.includes(q)) return true;
  const needle = q.replace(/[^a-z0-9]+/g, "");
  if (!needle) return false;
  return `${label} ${id}`.toLowerCase().replace(/[^a-z0-9]+/g, "").includes(needle);
}

function readyList(next: WpList): WpList {
  return {
    ...next,
    style: next.style ?? defaultWpStyle(),
    badges: next.badges ?? [],
    items: (next.items ?? []).map((row) => ({ ...row, badge: row.badge ?? "", children: row.children ?? [] })),
  };
}

function blank(): WpItem {
  return {
    id: `i${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`,
    title: "",
    url: "",
    image: "",
    badge: "",
    published: true,
    children: [],
  };
}

function slide(index: number, from: number, to: number, h: number, pinned: readonly boolean[]) {
  if (pinned[index] || index === from) return 0;
  const free: number[] = [];
  for (let i = 0; i < pinned.length; i++) if (!pinned[i]) free.push(i);
  const fs = free.indexOf(from);
  const fd = free.indexOf(to);
  const k = free.indexOf(index);
  if (fs < 0 || fd < 0 || k < 0) return 0;
  if (fs < fd && k > fs && k <= fd) return (free[k - 1] - free[k]) * h;
  if (fd < fs && k < fs && k >= fd) return (free[k + 1] - free[k]) * h;
  return 0;
}

function LinkMark({ row, saved }: { row: WpItem; saved?: WpSavedBadge[] }) {
  if (row.image) return <img src={row.image} alt="" className="size-10 shrink-0 rounded-full object-cover" />;
  if (row.badge) return <BadgeFace id={row.badge} saved={saved} className="flex size-10 shrink-0 items-center justify-center rounded-full" />;
  return <span className="size-10 shrink-0 rounded-full bg-elevated" />;
}

function LinkBody({ row, saved }: { row: WpItem; saved?: WpSavedBadge[] }) {
  return (
    <>
      <LinkMark row={row} saved={saved} />
      <span className="min-w-0 flex-1">
        <span className="block truncate text-base font-bold">{row.title || "Untitled"}</span>
        <span className="block truncate text-xs text-muted">Tap to edit</span>
      </span>
    </>
  );
}

function Choice<T extends string>({
  label,
  value,
  options,
  onPick,
}: {
  label: string;
  value: T;
  options: { id: T; label: string }[];
  onPick: (id: T) => void;
}) {
  return (
    <div>
      <p className="text-xs text-muted">{label}</p>
      <div className="mt-1 flex flex-wrap gap-1.5">
        {options.map((row) => (
          <button key={row.id} type="button" className="wp-choice" aria-pressed={value === row.id} onClick={() => onPick(row.id)}>
            {row.label}
          </button>
        ))}
      </div>
    </div>
  );
}

export function WpListSheet() {
  const [list, setList] = useState<WpList | null>(null);
  const [busy, setBusy] = useState(false);
  const [draft, setDraft] = useState<WpItem | null>(null);
  const [draftNew, setDraftNew] = useState(false);
  const [badgeOpen, setBadgeOpen] = useState(false);
  const [badgeQuery, setBadgeQuery] = useState("");
  const badgePanel = useRef<HTMLDivElement>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const listState = useRef(list);
  listState.current = list;
  const dragRef = useRef<{ id: string; from: number; to: number; h: number; left: number; width: number; oy: number; y: number; anchor: number; count: number } | null>(null);
  const [dragView, setDragView] = useState<{ id: string; from: number; to: number; h: number; left: number; width: number; y: number } | null>(null);
  const [swipe, setSwipe] = useState<{ id: string; x: number; live: boolean } | null>(null);
  const [askDelete, setAskDelete] = useState<WpItem | null>(null);
  const [finding, setFinding] = useState(false);
  const [job, setJob] = useState<{ label: string; done: number; total: number } | null>(null);
  const [askClear, setAskClear] = useState(false);
  const [askMatch, setAskMatch] = useState(false);
  const [brandAsk, setBrandAsk] = useState<BrandHit | null>(null);
  const [saveBadge, setSaveBadge] = useState(true);
  const swipeRef = useRef<{
    id: string;
    x0: number;
    y0: number;
    base: number;
    x: number;
    lock: "x" | "y" | null;
    moved: boolean;
    lastX: number;
    lastT: number;
    vx: number;
  } | null>(null);
  const swipeMoved = useRef(false);
  const publishTimer = useRef(0);
  const commitOrder = useRef<(from: number, to: number) => void>(() => {});

  useEffect(() => {
    let alive = true;
    setDraft(null);
    setDraftNew(false);
    setBadgeOpen(false);
    void loadWpList()
      .then((next) => {
        if (!alive) return;
        setList(readyList(next));
      })
      .catch(() => {
        if (alive) toast.error("Could not load the list");
      });
    return () => {
      alive = false;
    };
  }, []);

  useEffect(() => {
    function away(e: Event) {
      if (swipeRef.current) return;
      const t = e.target;
      if (t instanceof Element && (t.closest(".wp-swipe.is-open") || t.closest(".order-verify"))) return;
      setSwipe((cur) => (cur ? null : cur));
    }
    function scrolled() {
      if (swipeRef.current?.lock === "x") return;
      setSwipe((cur) => (cur && !cur.live ? null : cur));
    }
    const scroller = listRef.current;
    window.addEventListener("pointerdown", away, true);
    scroller?.addEventListener("scroll", scrolled, { passive: true });
    return () => {
      window.removeEventListener("pointerdown", away, true);
      scroller?.removeEventListener("scroll", scrolled);
    };
  }, []);

  useEffect(() => {
    function move(e: globalThis.PointerEvent) {
      const s = swipeRef.current;
      if (s && !dragRef.current) {
        const dx = e.clientX - s.x0;
        const dy = e.clientY - s.y0;
        if (!s.lock) {
          if (Math.hypot(dx, dy) < 10) return;
          s.lock = Math.abs(dx) > Math.abs(dy) * 1.2 ? "x" : "y";
        }
        if (s.lock !== "x") return;
        e.preventDefault();
        const now = e.timeStamp;
        const dt = Math.max(8, now - s.lastT);
        s.vx = (e.clientX - s.lastX) / dt;
        s.lastX = e.clientX;
        s.lastT = now;
        s.moved = true;
        s.x = Math.max(-SWIPE_W, Math.min(0, s.base + dx));
        setSwipe({ id: s.id, x: s.x, live: true });
        return;
      }
      const d = dragRef.current;
      const scroller = listRef.current;
      if (!d || !scroller) return;
      e.preventDefault();
      const dy = e.clientY + scroller.scrollTop - d.anchor;
      const items = listState.current?.items ?? [];
      const to = unpinnedDrop(items, d.from, Math.max(0, Math.min(d.count - 1, d.from + Math.round(dy / d.h))));
      d.to = to;
      d.y = e.clientY - d.oy;
      const box = scroller.getBoundingClientRect();
      if (e.clientY < box.top + 64) scroller.scrollTop -= 16;
      else if (e.clientY > box.bottom - 80) scroller.scrollTop += 16;
      setDragView({ id: d.id, from: d.from, to, h: d.h, left: d.left, width: d.width, y: d.y });
    }
    function up() {
      const s = swipeRef.current;
      if (s) {
        swipeRef.current = null;
        if (s.lock === "x" && s.moved) swipeMoved.current = true;
        if (s.lock === "x") {
          const flickLeft = s.vx < -0.4;
          const flickRight = s.vx > 0.4;
          const open = flickLeft || (!flickRight && s.x < -SWIPE_W * 0.4);
          setSwipe(open ? { id: s.id, x: -SWIPE_W, live: false } : null);
        }
      }
      const d = dragRef.current;
      dragRef.current = null;
      document.body.style.touchAction = "";
      setDragView(null);
      if (d) commitOrder.current(d.from, d.to);
    }
    function block(e: TouchEvent) {
      if (dragRef.current || swipeRef.current?.lock === "x") e.preventDefault();
    }
    window.addEventListener("pointermove", move, { passive: false });
    window.addEventListener("pointerup", up);
    window.addEventListener("pointercancel", up);
    window.addEventListener("touchmove", block, { passive: false });
    return () => {
      window.clearTimeout(publishTimer.current);
      document.body.style.touchAction = "";
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      window.removeEventListener("pointercancel", up);
      window.removeEventListener("touchmove", block);
    };
  }, []);

  const editing = draft;

  useEffect(() => {
    if (!badgeOpen) return;
    badgePanel.current?.scrollIntoView({ block: "nearest" });
  }, [badgeOpen, editing?.id]);

  function patch(_id: string, next: Partial<WpItem>) {
    setDraft((cur) => (cur ? { ...cur, ...next } : cur));
  }

  function add() {
    setSwipe(null);
    setDraft(blank());
    setDraftNew(true);
    setBadgeOpen(false);
  }

  function openRow(row: WpItem) {
    setSwipe(null);
    setDraft({ ...row, children: (row.children ?? []).map((child) => ({ ...child })) });
    setDraftNew(false);
    setBadgeOpen(false);
  }

  function openBadge(row: WpItem) {
    openRow(row);
    setBadgeOpen(true);
    setBadgeQuery("");
  }

  function submitDraft() {
    const base = listState.current;
    if (!base) {
      toast.error("List is still loading");
      return;
    }
    if (!draft) return;
    if (!draft.title.trim() || !draft.url.trim()) {
      toast.error("Add a title and a link");
      return;
    }
    const url = draft.url.trim();
    const item = { ...draft, url: url && !/^https?:\/\//i.test(url) ? `https://${url}` : url, published: true };
    const rest = base.items.filter((row) => row.id !== draft.id);
    const updated = draftNew
      ? { ...base, items: insertLink(rest, item) }
      : { ...base, items: base.items.map((row) => (row.id === draft.id ? item : row)) };
    setList(updated);
    listState.current = updated;
    setDraft(null);
    setDraftNew(false);
    toast.success("Link saved");
    void send(updated, true);
  }

  function queue(next: WpList) {
    window.clearTimeout(publishTimer.current);
    publishTimer.current = window.setTimeout(() => {
      void send(next, false);
    }, 400);
  }

  commitOrder.current = (from, to) => {
    const cur = listState.current;
    if (!cur || from === to) return;
    const items = moveUnpinned(cur.items, from, to);
    if (!items) return;
    const updated = { ...cur, items };
    setList(updated);
    listState.current = updated;
    void send(updated, true);
  };

  function beginSwipe(e: PointerEvent<HTMLDivElement>, id: string) {
    if (e.button !== 0 || dragRef.current) return;
    if (swipe && swipe.id !== id) setSwipe(null);
    const open = swipe?.id === id ? swipe.x : 0;
    swipeRef.current = { id, x0: e.clientX, y0: e.clientY, base: open, x: open, lock: null, moved: false, lastX: e.clientX, lastT: e.timeStamp, vx: 0 };
  }

  function confirmDelete() {
    if (!askDelete || !list) return;
    const updated = { ...list, items: list.items.filter((item) => item.id !== askDelete.id) };
    setList(updated);
    setAskDelete(null);
    setSwipe(null);
    setDraft(null);
    setDraftNew(false);
    void send(updated, true);
  }

  function togglePin(id: string) {
    const cur = listState.current;
    if (!cur) return;
    const items = cur.items.map((row) => {
      if (row.id !== id) return row;
      return { ...row, pinned: row.pinned ? undefined : true };
    });
    const updated = { ...cur, items };
    setList(updated);
    listState.current = updated;
    void send(updated, false);
  }

  function beginDrag(e: PointerEvent<HTMLButtonElement>, index: number) {
    if (e.button !== 0 || listState.current?.items[index]?.pinned) return;
    const scroller = listRef.current;
    const el = e.currentTarget.closest("[data-link]");
    if (!scroller || !(el instanceof HTMLElement)) return;
    e.preventDefault();
    const rect = el.getBoundingClientRect();
    const id = el.dataset.link || "";
    const next = {
      id,
      from: index,
      to: index,
      h: rect.height + 12,
      left: rect.left,
      width: rect.width,
      oy: e.clientY - rect.top,
      y: rect.top,
      anchor: e.clientY + scroller.scrollTop,
      count: listState.current?.items.length ?? 0,
    };
    dragRef.current = next;
    document.body.style.touchAction = "none";
    setDragView(next);
  }

  async function send(next: WpList, tell: boolean) {
    setBusy(true);
    try {
      const res = await saveWpList({ data: { ...next, items: next.items.map((row) => ({ ...row, published: true })) } });
      setList(readyList(res.list));
      if (tell && res.hook.ok) toast.success("WordPress updated");
      else if (tell && !res.hook.ok) toast.error(res.hook.error || "Saved here. WordPress did not update");
      return res;
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not save");
      return null;
    } finally {
      setBusy(false);
    }
  }

  async function save() {
    if (!list || busy) return;
    setSwipe(null);
    await send(list, true);
  }

  async function matchAll() {
    const start = listState.current;
    if (!start || job || finding) return;
    const rows = start.items.filter((row) => linkReady(row.url));
    if (!rows.length) {
      toast.error("No links to match");
      return;
    }
    let current = start;
    let found = 0;
    let missed = 0;
    let kept = 0;
    setJob({ label: "Matching", done: 0, total: rows.length });
    try {
      for (let i = 0; i < rows.length; i++) {
        const row = rows[i]!;
        setJob({ label: "Matching", done: i, total: rows.length });
        if (row.badgeManual && row.badge) {
          kept += 1;
          continue;
        }
        try {
          const res = await findBrandBadge({ data: { url: row.url } });
          if (!res.ok) {
            missed += 1;
            continue;
          }
          const hit = res.hit;
          current = {
            ...current,
            items: current.items.map((item) => (item.id === row.id ? { ...item, badge: hit.id, image: "", badgeManual: false } : item)),
            badges: stashBadge(current, hit),
          };
          setList(current);
          listState.current = current;
          found += 1;
        } catch {
          missed += 1;
        }
      }
      setJob({ label: "Matching", done: rows.length, total: rows.length });
      const saved = await send(current, false);
      if (saved?.hook.ok) toast.success(kept ? `Matched ${found}. Kept ${kept} you chose` : missed ? `Matched ${found}. ${missed} had no brand. WordPress updated` : `Matched ${found}. WordPress updated`);
      else if (saved) toast.success(kept ? `Matched ${found}. Kept ${kept} you chose` : missed ? `Matched ${found}. ${missed} had no brand` : `Matched ${found}`);
    } finally {
      setJob(null);
    }
  }

  async function clearBadges() {
    const start = listState.current;
    setAskClear(false);
    if (!start || job) return;
    const library = start.badges ?? [];
    const updated = {
      ...start,
      badges: library,
      items: start.items.map((item) => ({
        ...item,
        badge: "",
        badgeManual: false,
        children: (item.children ?? []).map((child) => ({ ...child, badge: "" })),
      })),
    };
    setList(updated);
    listState.current = updated;
    setJob({ label: "Clearing", done: 0, total: 1 });
    try {
      const saved = await send(updated, false);
      if (saved?.list) {
        const next = readyList({ ...saved.list, badges: mergeSavedBadges(library, saved.list.badges ?? []) });
        setList(next);
        listState.current = next;
      }
      setJob({ label: "Clearing", done: 1, total: 1 });
      if (saved?.hook.ok) toast.success("Badges cleared from the links. Your badge list stays");
      else if (saved) toast.success("Badges cleared from the links");
    } finally {
      setJob(null);
    }
  }

  async function huntBrand() {
    if (!editing || finding) return;
    const url = linkReady(editing.url);
    if (!url) {
      toast.error("Enter a public link first");
      return;
    }
    setFinding(true);
    try {
      const res = await findBrandBadge({ data: { url } });
      if (!res.ok) {
        toast.error(res.error || "No brand found");
        return;
      }
      setSaveBadge(true);
      setBrandAsk(res.hit);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not search that link");
    } finally {
      setFinding(false);
    }
  }

  async function acceptBrand() {
    if (!brandAsk || !editing) return;
    const hit = brandAsk;
    const keep = saveBadge;
    patch(editing.id, { badge: hit.id, image: "", badgeManual: true });
    setBrandAsk(null);
    if (hit.existing || !list) return;
    const updated = {
      ...list,
      badges: mergeSavedBadges(list.badges ?? [], [
        { id: hit.id, label: hit.label, bg: hit.bg, fg: hit.fg, img: hit.img, path: hit.path, listed: keep },
      ]),
    };
    setList(updated);
    listState.current = updated;
    const res = await send(updated, false);
    if (res && !res.hook.ok) toast.error(res.hook.error || "Saved here. WordPress did not update");
  }

  return (
    <div className="flex h-full min-h-0 flex-col bg-bg">
        <div className="flex items-center gap-3 px-4 py-3">
          <h2 className="min-w-0 flex-1 text-lg font-bold">{editing ? (draftNew ? "New link" : "Edit link") : "Links"}</h2>
          {editing ? (
            <button
              type="button"
              className="shrink-0 rounded-full bg-[#e9d5ff] px-4 py-2 text-sm font-bold text-[#2a103a] shadow-[0_0_16px_rgba(216,180,254,0.85)]"
              onClick={() => setDraft(null)}
            >
              Back to List
            </button>
          ) : null}
        </div>

        <div ref={listRef} className="smm-scroll min-h-0 flex-1 space-y-3 overflow-y-auto px-4 pb-4">
          {editing ? (
            <div className="space-y-3">
              <input className={field} placeholder="Title" value={editing.title} onChange={(e) => patch(editing.id, { title: e.target.value })} />
              <input
                className={field}
                placeholder="Link, opens in a new tab"
                inputMode="url"
                autoCapitalize="none"
                autoCorrect="off"
                value={editing.url}
                onChange={(e) => patch(editing.id, { url: e.target.value })}
              />
              <button
                type="button"
                disabled={finding || !linkReady(editing.url)}
                className="min-h-12 w-full rounded-2xl bg-elevated text-sm font-semibold text-fg disabled:opacity-40"
                onClick={() => void huntBrand()}
              >
                {finding ? "Searching the brand…" : "Find brand from link"}
              </button>
              <button
                type="button"
                className="flex min-h-14 w-full items-center gap-3 rounded-2xl bg-elevated px-3 text-left"
                onClick={() => {
                  setBadgeOpen((on) => !on);
                  setBadgeQuery("");
                }}
              >
                {editing.badge ? (
                  <BadgeFace id={editing.badge} saved={list?.badges} className="wp-face flex size-10 shrink-0 items-center justify-center rounded-full" />
                ) : (
                  <span className="wp-face flex size-10 shrink-0 items-center justify-center rounded-full bg-bg text-[1.35rem]" aria-hidden>😊</span>
                )}
                <span className="text-base font-semibold">+ Badge</span>
              </button>
              {badgeOpen ? (
                <div ref={badgePanel} className="grid grid-cols-4 gap-2 rounded-2xl bg-surface p-3">
                  <input
                    className="col-span-4 min-h-9 w-full rounded-full bg-elevated px-3 text-[16px] text-fg outline-none placeholder:text-muted"
                    placeholder="Search badges"
                    value={badgeQuery}
                    autoCapitalize="none"
                    autoCorrect="off"
                    spellCheck={false}
                    onChange={(e) => setBadgeQuery(e.target.value)}
                  />
                  {badgeQuery.trim() ? null : (
                    <button type="button" className="flex flex-col items-center gap-1" onClick={() => { patch(editing.id, { badge: "", badgeManual: false }); setBadgeOpen(false); setBadgeQuery(""); }}>
                      <span className="size-12 rounded-full bg-elevated" />
                      <span className="text-[10px] text-muted">None</span>
                    </button>
                  )}
                  {(() => {
                    const savedHits = (list?.badges ?? []).filter((row) => row.listed && badgeHit(row.label, row.id, badgeQuery));
                    const builtHits = WP_BADGE_DEFS.filter((row) => badgeHit(row.label, row.id, badgeQuery));
                    const any = savedHits.length + builtHits.length > 0;
                    return (
                      <>
                        {savedHits.map((row) => (
                          <button
                            key={row.id}
                            type="button"
                            className="flex flex-col items-center gap-1"
                            onClick={() => {
                              patch(editing.id, { badge: row.id, image: "", badgeManual: true });
                              setBadgeOpen(false);
                              setBadgeQuery("");
                            }}
                          >
                            <BadgeFace id={row.id} saved={list?.badges} className="flex size-12 items-center justify-center rounded-full" />
                            <span className="text-[10px] text-muted">{row.label}</span>
                          </button>
                        ))}
                        {builtHits.map((row) => (
                          <button
                            key={row.id}
                            type="button"
                            className="flex flex-col items-center gap-1"
                            onClick={() => {
                              patch(editing.id, { badge: row.id, image: "", badgeManual: true });
                              setBadgeOpen(false);
                              setBadgeQuery("");
                            }}
                          >
                            <BadgeFace id={row.id} saved={list?.badges} className="flex size-12 items-center justify-center rounded-full" />
                            <span className="text-[10px] text-muted">{row.label}</span>
                          </button>
                        ))}
                        {any ? null : <p className="col-span-4 py-2 text-center text-xs text-muted">No badge</p>}
                      </>
                    );
                  })()}
                </div>
              ) : null}
            </div>
          ) : (
            <>
              <button
                type="button"
                aria-label="Add link"
                className="mx-auto flex size-14 items-center justify-center rounded-full bg-[#3dff6a] text-black shadow-[0_0_18px_rgba(61,255,106,0.45)]"
                onClick={add}
              >
                <Plus className="size-8" strokeWidth={2.6} />
              </button>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  disabled={!!job}
                  className="min-h-12 rounded-2xl bg-elevated text-sm font-semibold text-fg disabled:opacity-60"
                  onClick={() => setAskMatch(true)}
                >
                  {job?.label === "Matching" ? `Matching ${job.done} of ${job.total}` : "Match badges"}
                </button>
                <button
                  type="button"
                  disabled={!!job}
                  className="min-h-12 rounded-2xl bg-elevated text-sm font-semibold text-fg disabled:opacity-60"
                  onClick={() => setAskClear(true)}
                >
                  {job?.label === "Clearing" ? "Clearing…" : "Clear badges"}
                </button>
              </div>
              {job ? (
                <div className="space-y-1.5" role="progressbar" aria-valuemin={0} aria-valuemax={job.total} aria-valuenow={job.done} aria-label={job.label}>
                  <div className="h-2 overflow-hidden rounded-full bg-black/40">
                    <div
                      className={`h-full rounded-full bg-[#3dff6a] shadow-[0_0_12px_rgba(61,255,106,0.7)] transition-[width] duration-300 ease-out ${job.label === "Clearing" && job.done === 0 ? "animate-pulse" : ""}`}
                      style={{ width: `${job.label === "Clearing" && job.done === 0 ? 100 : job.total ? Math.round((job.done / job.total) * 100) : 0}%` }}
                    />
                  </div>
                  <p className="text-center text-xs font-semibold text-muted">
                    {job.label} {job.done} of {job.total}
                  </p>
                </div>
              ) : null}
              {(list?.items ?? []).map((row, i) => {
                const pins = (list?.items ?? []).map((item) => item.pinned === true);
                const shift = dragView ? slide(i, dragView.from, dragView.to, dragView.h, pins) : 0;
                return (
                  <div
                    key={row.id}
                    data-link={row.id}
                    className={`wp-row wp-swipe${swipe?.id === row.id ? " is-open" : ""}${swipe?.id === row.id && swipe.live ? " is-swiping" : ""} ${dragView?.id === row.id ? "is-src" : ""}`}
                    style={{
                      ...(shift ? { transform: `translate3d(0, ${shift}px, 0)` } : null),
                      ["--open" as string]: String(swipe?.id === row.id ? Math.min(1, Math.abs(swipe.x) / SWIPE_W) : 0),
                    }}
                  >
                    <button type="button" className="wp-swipe-del" onClick={() => setAskDelete(row)}>
                      Delete
                    </button>
                    <div
                      className="wp-swipe-face"
                      style={{ transform: `translate3d(${swipe?.id === row.id ? swipe.x : 0}px,0,0)` }}
                      onPointerDown={(e) => beginSwipe(e, row.id)}
                    >
                      <div className="flex min-h-14 min-w-0 flex-1 items-center gap-3 rounded-2xl bg-surface px-3">
                        <button
                          type="button"
                          aria-label={`Choose badge for ${row.title || "link"}`}
                          className="shrink-0 rounded-full"
                          onPointerDown={(e) => e.stopPropagation()}
                          onClick={() => {
                            if (swipeMoved.current) {
                              swipeMoved.current = false;
                              return;
                            }
                            if (swipe?.id === row.id && swipe.x < -20) {
                              setSwipe(null);
                              return;
                            }
                            openBadge(row);
                          }}
                        >
                          <LinkMark row={row} saved={list?.badges} />
                        </button>
                        <button
                          type="button"
                          className="flex min-h-14 min-w-0 flex-1 items-center text-left"
                          onClick={() => {
                            if (swipeMoved.current) {
                              swipeMoved.current = false;
                              return;
                            }
                            if (swipe?.id === row.id && swipe.x < -20) {
                              setSwipe(null);
                              return;
                            }
                            openRow(row);
                          }}
                        >
                          <span className="min-w-0 flex-1">
                            <span className="block truncate text-base font-bold">{row.title || "Untitled"}</span>
                            <span className="block truncate text-xs text-muted">Tap to edit</span>
                          </span>
                        </button>
                      </div>
                      {swipe ? null : (
                      <>
                      <button
                        type="button"
                        aria-label={row.pinned ? "Unpin link" : "Pin link"}
                        aria-pressed={row.pinned === true}
                        className={`flex w-12 shrink-0 items-center justify-center rounded-2xl ${row.pinned ? "bg-[#facc15] text-black" : "bg-elevated text-muted"}`}
                        onPointerDown={(e) => e.stopPropagation()}
                        onClick={() => togglePin(row.id)}
                      >
                        <Pin className="size-5" fill={row.pinned ? "currentColor" : "none"} />
                      </button>
                      <button
                        type="button"
                        aria-label={`Delete ${row.title}`}
                        className="wp-desk-del"
                        onPointerDown={(e) => e.stopPropagation()}
                        onClick={() => setAskDelete(row)}
                      >
                        <Trash2 className="size-4" strokeWidth={2.4} />
                      </button>
                      <button
                        type="button"
                        aria-label="Drag to reorder"
                        aria-disabled={row.pinned === true}
                        className={`flex w-12 shrink-0 touch-none items-center justify-center rounded-2xl bg-elevated text-muted ${row.pinned ? "opacity-30" : ""}`}
                        onPointerDown={(e) => {
                          e.stopPropagation();
                          beginDrag(e, i);
                        }}
                      >
                        <GripVertical className="size-5" />
                      </button>
                      </>
                      )}
                    </div>
                  </div>
                );
              })}
              {dragView ? (
                <div className="wp-drag-ghost gap-2" style={{ top: dragView.y, left: dragView.left, width: dragView.width }}>
                  <div className="flex min-h-14 min-w-0 flex-1 items-center gap-3 rounded-2xl bg-surface px-3">
                    <LinkBody row={(list?.items ?? []).find((row) => row.id === dragView.id) ?? { id: "", title: "", url: "", image: "", badge: "", published: true, children: [] }} saved={list?.badges} />
                  </div>
                  <div className="flex w-12 shrink-0 items-center justify-center rounded-2xl bg-elevated text-muted">
                    <GripVertical className="size-5" />
                  </div>
                </div>
              ) : null}
            </>
          )}
        </div>

        <div className="relative z-10 px-4 pt-2 pb-[max(0.75rem,env(safe-area-inset-bottom))]">
          <button
            type="button"
            disabled={!list || busy || (editing ? !editing.title.trim() || !editing.url.trim() : false)}
            className={`min-h-14 w-full rounded-2xl text-base font-bold text-black disabled:opacity-40 ${editing ? "bg-[#3dff6a]" : "bg-[var(--color-neon-blue)]"}`}
            onPointerDown={(e) => {
              if (e.button !== 0 || !list || busy) return;
              if (editing && (!editing.title.trim() || !editing.url.trim())) return;
              e.preventDefault();
              if (editing) submitDraft();
              else void save();
            }}
          >
            {editing ? "Submit" : busy ? "Pushing…" : "Push update"}
          </button>
        </div>
        {askMatch
          ? createPortal(
              <div className="order-verify" role="dialog" aria-modal="true" aria-labelledby="match-badges-title">
                <button type="button" className="order-verify-scrim" aria-label="Cancel" onClick={() => setAskMatch(false)} />
                <div className="order-verify-card">
                  <p id="match-badges-title" className="text-center text-base font-bold text-fg">
                    Find a badge for every link?
                  </p>
                  <div className="order-verify-acts">
                    <button
                      type="button"
                      className="order-verify-yes"
                      onClick={() => {
                        setAskMatch(false);
                        void matchAll();
                      }}
                    >
                      Yes
                    </button>
                    <button type="button" className="order-verify-no" onClick={() => setAskMatch(false)}>
                      No
                    </button>
                  </div>
                </div>
              </div>,
              document.body,
            )
          : null}
        {askClear
          ? createPortal(
              <div className="order-verify" role="dialog" aria-modal="true" aria-labelledby="clear-badges-title">
                <button type="button" className="order-verify-scrim" aria-label="Cancel" onClick={() => setAskClear(false)} />
                <div className="order-verify-card">
                  <p id="clear-badges-title" className="text-center text-base font-bold text-fg">
                    Remove the badge from every link?
                  </p>
                  <div className="order-verify-acts">
                    <button type="button" className="order-verify-yes" onClick={() => void clearBadges()}>
                      Yes
                    </button>
                    <button type="button" className="order-verify-no" onClick={() => setAskClear(false)}>
                      No
                    </button>
                  </div>
                </div>
              </div>,
              document.body,
            )
          : null}
        {askDelete
          ? createPortal(
              <div className="order-verify" role="dialog" aria-modal="true" aria-labelledby="del-link-title">
                <button type="button" className="order-verify-scrim" aria-label="Cancel" onClick={() => setAskDelete(null)} />
                <div className="order-verify-card">
                  <p id="del-link-title" className="text-center text-base font-bold text-fg">
                    Delete {askDelete.title}?
                  </p>
                  <div className="order-verify-acts">
                    <button type="button" className="order-verify-yes" onClick={confirmDelete}>
                      Yes
                    </button>
                    <button type="button" className="order-verify-no" onClick={() => setAskDelete(null)}>
                      No
                    </button>
                  </div>
                </div>
              </div>,
              document.body,
            )
          : null}
        {brandAsk
          ? createPortal(
              <div className="order-verify" role="dialog" aria-modal="true" aria-labelledby="brand-ask-title">
                <button type="button" className="order-verify-scrim" aria-label="Cancel" onClick={() => setBrandAsk(null)} />
                <div className="order-verify-card">
                  <p id="brand-ask-title" className="text-center text-base font-bold text-fg">
                    Use this badge on this link?
                  </p>
                  <div className="mt-4 flex items-center justify-center gap-3">
                    <BadgeFace face={brandAsk} className="flex size-14 items-center justify-center rounded-full" />
                    <span className="text-sm font-semibold text-fg">{brandAsk.label}</span>
                  </div>
                  {brandAsk.existing ? null : (
                    <label className="mt-4 flex items-center justify-center gap-2 text-sm text-fg">
                      <input type="checkbox" checked={saveBadge} onChange={(e) => setSaveBadge(e.target.checked)} />
                      Save to badge list
                    </label>
                  )}
                  <div className="order-verify-acts">
                    <button type="button" className="order-verify-yes" onClick={() => void acceptBrand()}>
                      Yes
                    </button>
                    <button type="button" className="order-verify-no" onClick={() => setBrandAsk(null)}>
                      No
                    </button>
                  </div>
                </div>
              </div>,
              document.body,
            )
          : null}
    </div>
  );
}

export function WpSiteSettings() {
  const [list, setList] = useState<WpList | null>(null);
  const [open, setOpen] = useState<"look" | "connect" | null>(null);
  const timer = useRef(0);

  useEffect(() => {
    let alive = true;
    void loadWpList()
      .then((next) => {
        if (!alive) return;
        setList(readyList(next));
      })
      .catch(() => undefined);
    return () => {
      alive = false;
      window.clearTimeout(timer.current);
    };
  }, []);

  function queue(next: WpList) {
    window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => {
      void saveWpList({ data: { ...next, items: next.items.map((row) => ({ ...row, published: true })) } }).catch(() =>
        toast.error("Could not save"),
      );
    }, 400);
  }

  function setStyle(next: Partial<WpStyle>) {
    setList((cur) => {
      if (!cur) return cur;
      const updated = { ...cur, style: { ...cur.style, ...next } };
      queue(updated);
      return updated;
    });
  }

  return (
    <div className="rounded-lg bg-elevated px-3 py-3">
      <p className="text-xs font-medium tracking-wide text-muted uppercase">WordPress links</p>
      <div className="mt-3 flex gap-2">
        <button type="button" className="wp-choice" aria-pressed={open === "look"} onClick={() => setOpen((p) => (p === "look" ? null : "look"))}>
          Look
        </button>
        <button type="button" className="wp-choice" aria-pressed={open === "connect"} onClick={() => setOpen((p) => (p === "connect" ? null : "connect"))}>
          Connection
        </button>
      </div>
      {open === "look" && list ? (
        <div className="mt-3 space-y-3">
          <div className="smm-desk" data-look={list.style.look} data-tone={list.style.tone} data-size={list.style.size} data-layout="stack" data-thumb={list.style.thumb} data-badge={list.style.badge}>
            <span className="smm-desk-btn">
              {list.style.thumb !== "off" ? <span className="smm-desk-thumb" /> : null}
              <span className="smm-desk-copy">
                <span className="smm-desk-title">Preview</span>
                {list.style.badge !== "off" ? <span className="smm-desk-badge">New</span> : null}
              </span>
            </span>
          </div>
          <Choice label="Style" value={list.style.look} options={WP_LOOKS} onPick={(look) => setStyle({ look })} />
          <Choice label="Color" value={list.style.tone} options={WP_TONES} onPick={(tone) => setStyle({ tone })} />
          <Choice label="Size" value={list.style.size} options={WP_SIZES} onPick={(size) => setStyle({ size })} />
          <Choice label="Arrange" value={list.style.layout} options={WP_LAYOUTS} onPick={(layout) => setStyle({ layout })} />
          <Choice label="Thumbnail" value={list.style.thumb} options={WP_THUMBS} onPick={(thumb) => setStyle({ thumb })} />
          <Choice label="Badge" value={list.style.badge} options={WP_BADGES} onPick={(badge) => setStyle({ badge })} />
        </div>
      ) : null}
      {open === "connect" ? (
        <div className="mt-3 space-y-3">
          <label className="block text-xs text-muted">
            App address, paste into the WordPress plugin
            <input className={`${field} mt-1`} readOnly value={typeof window === "undefined" ? "" : window.location.origin} />
          </label>
          <label className="block text-xs text-muted">
            WordPress REST address
            <input
              className={`${field} mt-1`}
              placeholder="http://claudiaivory.com/wp-json/smm-desk/v1/list"
              inputMode="url"
              autoCapitalize="none"
              autoCorrect="off"
              value={list?.hookUrl ?? ""}
              onChange={(e) =>
                setList((cur) => {
                  if (!cur) return cur;
                  const updated = { ...cur, hookUrl: e.target.value };
                  queue(updated);
                  return updated;
                })
              }
            />
          </label>
          <label className="block text-xs text-muted">
            Secret
            <input
              className={`${field} mt-1`}
              value={list?.secret ?? ""}
              autoComplete="off"
              onChange={(e) =>
                setList((cur) => {
                  if (!cur) return cur;
                  const updated = { ...cur, secret: e.target.value };
                  queue(updated);
                  return updated;
                })
              }
            />
          </label>
        </div>
      ) : null}
    </div>
  );
}
