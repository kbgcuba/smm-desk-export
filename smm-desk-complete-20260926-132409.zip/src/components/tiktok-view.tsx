import { SmmPanels } from "@/components/smm-panels";
import { useSmmDesks } from "@/lib/smm/desks";

export function TikTokView() {
  const desk = useSmmDesks((s) => s.desks.find((d) => d.id === "tiktok"));
  if (!desk) return null;
  return (
    <div className="h-full overflow-y-auto bg-bg">
      <SmmPanels desk={desk} />
    </div>
  );
}
