import { useEffect, useState } from "react";
import { toast } from "sonner";
import { runSmmRefills } from "@/lib/smm/fn";
import { watchedServiceKeys, useSmmDesks } from "@/lib/smm/desks";
import { canAutoRefill, useSmmOrders } from "@/lib/smm/orders";
import { useSmmRefills } from "@/lib/smm/refill-store";
import { useSmmPrefs } from "@/lib/smm/prefs";
import { refillStoresReady } from "@/lib/smm/refill-ready";

const POLL_MS = 5_000;
const MAX_TRIES = 3;
const PAUSE_MS = 30 * 60 * 1000;
const RETRY_KEY = "smm-refill-retries";

type Attempt = { n: number; until: number };

let autoBusy = false;

function bothHydrated() {
  return refillStoresReady({
    ordersHydrated: !useSmmOrders.persist || useSmmOrders.persist.hasHydrated(),
    desksHydrated: !useSmmDesks.persist || useSmmDesks.persist.hasHydrated(),
    desksSkipHydration: true,
  });
}

function loadAttempts(): Map<string, Attempt> {
  try {
    const raw = JSON.parse(localStorage.getItem(RETRY_KEY) ?? "{}") as Record<string, Attempt>;
    return new Map(Object.entries(raw));
  } catch {
    return new Map();
  }
}

const attempts = loadAttempts();

function saveAttempts() {
  try {
    localStorage.setItem(RETRY_KEY, JSON.stringify(Object.fromEntries(attempts)));
  } catch {
    /* quota */
  }
}

function idOf(panel: string, order: string) {
  return `${panel}:${order}`;
}

function retryOpen(panel: string, order: string, now = Date.now()): boolean {
  const hit = attempts.get(idOf(panel, order));
  if (!hit) return true;
  if (hit.n >= MAX_TRIES && now < hit.until) return false;
  if (hit.n >= MAX_TRIES && now >= hit.until) {
    attempts.delete(idOf(panel, order));
    saveAttempts();
    return true;
  }
  return true;
}

function noteOk(panel: string, order: string) {
  if (!attempts.has(idOf(panel, order))) return;
  attempts.delete(idOf(panel, order));
  saveAttempts();
}

function noteFail(panel: string, order: string) {
  const k = idOf(panel, order);
  const prev = attempts.get(k) ?? { n: 0, until: 0 };
  const n = prev.n + 1;
  attempts.set(k, { n, until: n >= MAX_TRIES ? Date.now() + PAUSE_MS : 0 });
  saveAttempts();
  return n;
}

async function autoRefill() {
  if (autoBusy) return;
  if (!useSmmPrefs.getState().autoRefill) return;
  const watch = watchedServiceKeys();
  const items = useSmmRefills.getState().items.filter((row) => {
    if (!row.ready) return false;
    if (watch.size === 0) return true;
    return watch.has(`${row.panel}:${row.service}`);
  });
  if (items.length === 0) return;
  const saved = useSmmOrders.getState().orders;
  const now = Date.now();
  const due = items.filter((row) => {
    const hit = saved.find((order) => order.panel === row.panel && order.order === row.order);
    return Boolean(hit && canAutoRefill(hit, now) && retryOpen(row.panel, row.order, now));
  });
  if (due.length === 0) return;

  autoBusy = true;
  try {
    const res = await runSmmRefills({
      data: {
        orders: due.map((row) => ({
          panel: row.panel,
          order: row.order,
          refill: true,
          service: row.service,
          name: row.name,
          link: row.link,
        })),
      },
    });
    const failed = new Set(res.fail.map((row) => row.order));
    const ok = due.filter((row) => !failed.has(row.order));
    for (const row of ok) noteOk(row.panel, row.order);
    if (ok.length) useSmmOrders.getState().markRefilled(ok);
    let paused = 0;
    for (const row of due) {
      if (!failed.has(row.order)) continue;
      if (noteFail(row.panel, row.order) >= MAX_TRIES) paused += 1;
    }
    if (res.ok && res.fail.length === 0) toast.success(`${res.ok} refill${res.ok === 1 ? "" : "s"} started`);
    else if (res.ok) toast.success(`${res.ok} started · ${res.fail.length} skipped`);
    if (paused) toast.warning(`Refill paused 30 min after ${MAX_TRIES} failed tries`);
  } catch {
    let paused = 0;
    for (const row of due) {
      if (noteFail(row.panel, row.order) >= MAX_TRIES) paused += 1;
    }
    if (paused) toast.warning(`Refill paused 30 min after ${MAX_TRIES} failed tries`);
  } finally {
    autoBusy = false;
  }
}

export function RefillSync() {
  const saved = useSmmOrders((s) => s.orders);
  const desks = useSmmDesks((s) => s.desks);
  const refresh = useSmmRefills((s) => s.refresh);
  const [hydrated, setHydrated] = useState(bothHydrated);

  useEffect(() => {
    const done = () => setHydrated(bothHydrated());
    const a = useSmmOrders.persist?.onFinishHydration(done);
    done();
    return () => {
      a?.();
    };
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    let alive = true;
    async function tick() {
      await refresh(saved);
      if (alive) await autoRefill();
    }
    void tick();
    const t = setInterval(() => {
      if (document.visibilityState !== "visible") return;
      void tick();
    }, POLL_MS);
    const onVis = () => {
      if (document.visibilityState === "visible") void tick();
    };
    document.addEventListener("visibilitychange", onVis);
    return () => {
      alive = false;
      clearInterval(t);
      document.removeEventListener("visibilitychange", onVis);
    };
  }, [hydrated, saved, desks, refresh]);

  return null;
}