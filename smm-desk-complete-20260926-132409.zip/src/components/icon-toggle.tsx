import type { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

export function IconToggle({
  on,
  OnIcon,
  OffIcon,
  onClass,
  offClass,
}: {
  on: boolean;
  OnIcon: LucideIcon;
  OffIcon: LucideIcon;
  onClass?: string;
  offClass?: string;
}) {
  return (
    <span className="relative inline-flex size-7 items-center justify-center">
      <span
        className={cn(
          "icon-swap absolute inset-0 flex items-center justify-center",
          on ? "scale-100 opacity-100 blur-none" : "scale-[0.25] opacity-0 blur-[4px]",
          onClass,
        )}
      >
        <OnIcon className="size-7" strokeWidth={2} fill="currentColor" />
      </span>
      <span
        className={cn(
          "icon-swap flex items-center justify-center",
          on ? "scale-[0.25] opacity-0 blur-[4px]" : "scale-100 opacity-100 blur-none",
          offClass,
        )}
      >
        <OffIcon className="size-7" strokeWidth={2} />
      </span>
    </span>
  );
}
