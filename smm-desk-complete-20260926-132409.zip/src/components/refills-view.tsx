import { useMemo, useState } from "react";
import { RefreshCw } from "lucide-react";
import { toast } from "sonner";
import { runSmmRefills, nameWithId, type RefillItem } from "@/lib/smm/fn";
import { formatRefillWait, refillStats, useSmmOrders } from "@/lib/smm/orders";
import { useSmmRefills } from "@/lib/smm/refill-store";

export function RefillsView() {
  const saved = useSmmOrders((s) => s.orders);
  const logs = useSmmOrders((s) => s.refills);
  const accounts = useSmmRefills((s) => s.accounts);
  const items = useSmmRefills((s) => s.items);
  const readyCount = useSmmRefills((s) => s.readyCount);
  const loading = useSmmRefills((s) => s.loading);
  const error = useSmmRefills((s) => s.error);
  const rememberRefill = useSmmOrders((s) => s.markRefilled);
  const refresh = useSmmRefills((s) => s.refresh);
  const [busy, setBusy] = useState(false);

  const ready = useMemo(() => items.filter((row) => row.ready), [items]);
  const waiting = useMemo(
    () => items.filter((row) => !row.ready && /complet|success|partial|done|finish/i.test(row.status)),
    [items],
  );
  const stats = useMemo(() => refillStats(logs), [logs]);

  async function refillAll() {
    if (busy || readyCount === 0) return;
    setBusy(true);
    try {
      const res = await runSmmRefills({
        data: {
          orders: ready.map((row) => ({
            panel: row.panel,
            order: row.order,
            refill: true,
            service: row.service,
            name: row.name,
            link: row.link,
          })),
        },
      });
      if (res.ok && res.fail.length === 0) toast.success(`${res.ok} refill${res.ok === 1 ? "" : "s"} started`);
      else if (res.ok) toast.success(`${res.ok} started · ${res.fail.length} skipped`);
      else toast.error(res.fail[0]?.error ?? "Could not refill");
      rememberRefill(ready);
      await refresh(saved);
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Could not refill");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="h-full overflow-y-auto bg-bg">
      <div className="mx-auto flex max-w-2xl flex-col gap-6 px-3 py-4 pb-10 lg:px-6">
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="text-xs font-medium tracking-wide text-muted uppercase">Ready to refill</p>
            <p className="money mt-2 text-[2.25rem] leading-none text-fg">{loading ? "…" : readyCount}</p>
            <p className="mt-2 text-sm text-muted">
              {loading
                ? "Checking SmmWiz, JustAnotherPanel, and SmmFanz…"
                : readyCount === 1
                  ? "1 refill is ready — it will send on its own"
                  : `${readyCount} refills are ready — they send on their own`}
              {!loading && waiting.length > 0 ? ` · ${waiting.length} waiting 24h` : ""}
              {!loading && saved.length > 0 && waiting.length === 0 ? ` · ${saved.length} tracked` : ""}
            </p>
          </div>
          <button
            type="button"
            onClick={() => void refresh(saved)}
            disabled={loading || busy}
            aria-label="Refresh refills"
            className="mt-1 flex size-11 shrink-0 items-center justify-center rounded-full bg-surface text-fg transition-transform duration-150 ease-out active:scale-[0.96] disabled:opacity-40"
          >
            <RefreshCw className={`size-4 ${loading ? "animate-spin" : ""}`} />
          </button>
        </div>

        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {(
            [
              ["Today", stats.today],
              ["This week", stats.thisWeek],
              ["This month", stats.thisMonth],
              ["This year", stats.thisYear],
            ] as const
          ).map(([label, n]) => (
            <div key={label} className="min-w-0 overflow-hidden rounded-xl bg-surface px-2.5 py-3 sm:px-3">
              <p className="text-[10px] leading-tight font-medium tracking-wide text-muted uppercase sm:text-xs">
                {label}
              </p>
              <p className="money mt-2 whitespace-nowrap text-[1.375rem] leading-none text-fg sm:text-[1.75rem]">{n}</p>
              <p className="mt-1 text-[10px] text-muted sm:text-xs">sent</p>
            </div>
          ))}
        </div>

        <div className="balance-pair" data-n={accounts.length}>
          {accounts.map((p) => (
            <div key={p.id} className="min-w-0 overflow-hidden rounded-xl bg-surface px-2.5 py-3 sm:px-3">
              <p className="text-[10px] leading-tight font-medium tracking-wide break-words text-muted uppercase sm:text-xs">
                {p.label}
              </p>
              <p className="money mt-2 whitespace-nowrap text-[1.375rem] leading-none text-fg sm:text-[1.75rem]">
                {loading ? "…" : p.ready}
              </p>
              <p className="mt-1 text-[10px] text-muted sm:text-xs">ready</p>
            </div>
          ))}
        </div>

        {error ? <p className="text-sm text-tt">{error}</p> : null}

        <button
          type="button"
          disabled={busy || loading || readyCount === 0}
          onClick={() => void refillAll()}
          className="flex min-h-11 w-full items-center justify-center gap-2 rounded-full bg-fg px-5 text-sm font-semibold text-accent-fg transition-transform duration-150 ease-out active:scale-[0.96] disabled:opacity-40"
        >
          <RefreshCw className={`size-4 ${busy ? "animate-spin" : ""}`} />
          {busy ? "Refilling…" : "Refill all"}
        </button>

        {ready.length || waiting.length ? (
          <ul className="flex flex-col gap-3">
            {ready.map((row) => (
              <OrderCard key={`${row.panel}:${row.order}`} row={row} wait={null} />
            ))}
            {waiting.map((row) => (
              <OrderCard
                key={`${row.panel}:${row.order}`}
                row={row}
                wait={formatRefillWait((row.dueAt ?? Date.now()) - Date.now())}
              />
            ))}
          </ul>
        ) : loading ? null : (
          <p className="text-sm text-muted">
            {saved.length
              ? "Tracked orders are still running. Refill opens 24 hours after an order completes."
              : "Place an order on TikTok or YouTube. Refill opens 24 hours after it completes."}
          </p>
        )}
      </div>
    </div>
  );
}

function OrderCard({ row, wait }: { row: RefillItem; wait: string | null }) {
  return (
    <li className="rounded-xl bg-surface px-4 py-4">
      <p className="text-xs font-medium tracking-wide text-muted uppercase">{row.label}</p>
      <p className="mt-1 text-sm leading-snug font-semibold text-fg">
        {row.name ? nameWithId({ id: row.service, name: row.name, panel: row.panel }) : `Order ${row.order}`}
      </p>
      <p className="mt-1 truncate text-xs text-muted">{row.link || `ID ${row.order}`}</p>
      <dl className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3">
        <div className="min-w-0">
          <dt className="text-xs font-medium tracking-wide text-muted uppercase">Status</dt>
          <dd className="mt-1 truncate text-sm font-semibold text-fg">{row.status}</dd>
        </div>
        <div className="min-w-0">
          <dt className="text-xs font-medium tracking-wide text-muted uppercase">Service</dt>
          <dd className="mt-1 truncate text-sm font-semibold text-fg tabular-nums">{row.service || "—"}</dd>
        </div>
        <div className="min-w-0">
          <dt className="text-xs font-medium tracking-wide text-muted uppercase">Refill</dt>
          <dd className="mt-1 truncate text-sm font-semibold text-fg">
            {wait ? `Opens in ${wait}` : "Ready"}
          </dd>
        </div>
      </dl>
    </li>
  );
}
