import { memo, startTransition, useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { useNavigate, useSearch } from "@tanstack/react-router";
import { ChevronLeft, ChevronRight, Star } from "lucide-react";
import { toast } from "sonner";
import {
  loadSmmLive,
  panelLabel,
  serviceKey,
  stripPanelPrefix,
  nameWithId,
  allowsDrip,
  allowsRefill,
  isCommentOrder,
  orderNeeds,
  type PanelBalance,
  type PanelId,
  type SmmCatalogPayload,
  type SmmService,
} from "@/lib/smm/fn";
import { loadAllCatalog, peekAllCatalog, subscribeAllCatalog } from "@/lib/smm/all-catalog";
import { ServiceForm, ServiceFav } from "@/components/smm-panels";
import { useSmmDesks, isPinned } from "@/lib/smm/desks";
import { toastFavorited, toastPinned } from "@/lib/smm/fav-toast";
import { formatCount, formatMoney } from "@/lib/format";
import { useSmmLive } from "@/lib/smm/live-store";
import { useSmmPrefs } from "@/lib/smm/prefs";
import { isCommentLikeName } from "@/lib/smm/add-match";
import { cn } from "@/lib/utils";

const LIST_CAP = 2000;
const ROW_H = 68;
const ROW_OVERSCAN = 8;

type Metric = { id: string; label: string; test: RegExp };

const MORE: Metric = { id: "more", label: "More", test: /.^/ };

export const POPULAR: { id: string; label: string; test: RegExp; tone: string; metrics: Metric[] }[] = [
  {
    id: "tiktok",
    label: "TikTok",
    test: /tiktok/i,
    tone: "tiktok",
    metrics: [
      { id: "views", label: "Views", test: /\bviews?\b|\bplays?\b/i },
      { id: "likes", label: "Likes", test: /\blikes?\b/i },
      { id: "followers", label: "Followers", test: /(?<!un)\bfollowers?\b/i },
      { id: "shares", label: "Shares", test: /\bshares?\b/i },
      { id: "comments", label: "Comments", test: /\bcomments?\b/i },
      { id: "saves", label: "Saves", test: /save|favorite|bookmark/i },
      { id: "live", label: "Live", test: /\blive\b/i },
      { id: "pk", label: "PK / other", test: /pk\s*battle|battle points|all-in-one/i },
      MORE,
    ],
  },
  {
    id: "youtube",
    label: "YouTube",
    test: /youtube|youtu\.be/i,
    tone: "youtube",
    metrics: [
      { id: "views", label: "Views", test: /\bviews?\b/i },
      { id: "likes", label: "Likes", test: /\blikes?\b/i },
      { id: "subs", label: "Subscribers", test: /\bsubscribers?\b|\bsubs\b/i },
      { id: "comments", label: "Comments", test: /\bcomments?\b/i },
      { id: "watch", label: "Watch hours", test: /watch\s*hours?|watch\s*time|\bretention\b/i },
      { id: "shares", label: "Shares", test: /\bshares?\b/i },
      MORE,
    ],
  },
  {
    id: "instagram",
    label: "Instagram",
    test: /instagram/i,
    tone: "instagram",
    metrics: [
      { id: "followers", label: "Followers", test: /(?<!un)\bfollowers?\b/i },
      { id: "likes", label: "Likes", test: /\blikes?\b/i },
      { id: "views", label: "Views", test: /\bviews?\b|\bplays?\b|\bigtv\b|\breels?\b(?![\s|/[\]()\-–—]*(?:likes?|followers?|comments?|saves?|shares?|reach|impressions?)\b)/i },
      { id: "comments", label: "Comments", test: /\bcomments?\b/i },
      { id: "saves", label: "Saves", test: /\bsaves?\b|\bsaved\b|\bbookmarks?\b/i },
      { id: "story", label: "Story", test: /stor(y|ies)/i },
      { id: "shares", label: "Shares", test: /\bshares?\b/i },
      { id: "reach", label: "Reach / impressions", test: /\breach\b|impression|profile visit/i },
      MORE,
    ],
  },
  {
    id: "facebook",
    label: "Facebook",
    test: /facebook|\bfb\b/i,
    tone: "facebook",
    metrics: [
      { id: "page", label: "Page likes", test: /page like|fan/i },
      { id: "followers", label: "Followers", test: /(?<!un)\bfollowers?\b/i },
      { id: "views", label: "Views", test: /\bviews?\b|\bwatch\b/i },
      { id: "post", label: "Post likes", test: /post\s*likes?/i },
      { id: "reactions", label: "Reactions", test: /react|\blove\b|\bhaha\b|\bangry\b|\bcare\b|\bwow\b/i },
      { id: "shares", label: "Shares", test: /\bshares?\b/i },
      { id: "events", label: "Events", test: /\bevents?\b|event join|\bgoing\b/i },
      MORE,
    ],
  },
  {
    id: "traffic",
    label: "Web traffic",
    test: /web\s*traffic|website\s*traffic|website\s*(?:visit|hit)|unique visitor/i,
    tone: "traffic",
    metrics: [
      { id: "unique", label: "Unique visitors", test: /unique/i },
      { id: "google", label: "From Google", test: /google|organic|seo/i },
      { id: "social", label: "From social", test: /social|from\s+(?:facebook|instagram|twitter|tiktok)/i },
      { id: "world", label: "Worldwide", test: /world|global|\bww\b|\bmix\b/i },
      { id: "hits", label: "Hits", test: /\bhits?\b|web\s*visit|site\s*visit/i },
      MORE,
    ],
  },
  {
    id: "twitter",
    label: "Twitter",
    test: /twitter|\btweets?\b/i,
    tone: "twitter",
    metrics: [
      { id: "followers", label: "Followers", test: /(?<!un)\bfollowers?\b/i },
      { id: "likes", label: "Likes", test: /\blikes?\b|\bfavorites?\b/i },
      { id: "retweets", label: "Retweets", test: /re[\s-]*tweets?|repost/i },
      { id: "views", label: "Views", test: /\bviews?\b|\bimpressions?\b/i },
      { id: "comments", label: "Comments", test: /\bcomments?\b|\brepl(?:y|ies)\b/i },
      { id: "bookmarks", label: "Bookmarks", test: /bookmark/i },
      MORE,
    ],
  },
  {
    id: "spotify",
    label: "Spotify",
    test: /spotify/i,
    tone: "spotify",
    metrics: [
      { id: "plays", label: "Plays", test: /play|stream/i },
      { id: "followers", label: "Followers", test: /(?<!un)\bfollowers?\b/i },
      { id: "monthly", label: "Monthly listeners", test: /monthly|listener/i },
      { id: "saves", label: "Saves", test: /save|playlist/i },
      { id: "likes", label: "Likes", test: /\blikes?\b/i },
      MORE,
    ],
  },
  {
    id: "telegram",
    label: "Telegram",
    test: /telegram/i,
    tone: "telegram",
    metrics: [
      { id: "members", label: "Members", test: /member|subscr/i },
      { id: "views", label: "Views", test: /\bviews?\b/i },
      { id: "reactions", label: "Reactions", test: /\breactions?\b|\blikes?\b/i },
      { id: "forwards", label: "Forwards", test: /\bforwards?\b|\bshares?\b/i },
      { id: "comments", label: "Comments", test: /\bcomments?\b/i },
      MORE,
    ],
  },
  {
    id: "other",
    label: "Other",
    test: /.^/,
    tone: "other",
    metrics: [
      { id: "snapchat", label: "Snapchat", test: /snapchat/i },
      { id: "twitch", label: "Twitch", test: /twitch/i },
      { id: "reddit", label: "Reddit", test: /reddit/i },
      { id: "linkedin", label: "LinkedIn", test: /linkedin/i },
      { id: "soundcloud", label: "SoundCloud", test: /soundcloud|audiomack/i },
      { id: "kick", label: "Kick", test: /\bkick\.com\b|\bkick\b/i },
      MORE,
    ],
  },
];

function platformHay(s: SmmService): string {
  return `${s.category} ${s.name} ${s.type ?? ""}`;
}

function metricHay(s: SmmService): string {
  return platformHay(s).replace(/\[[^\]]*\]/g, " ");
}

export function chipHits(chip: (typeof POPULAR)[number], s: SmmService): boolean {
  const hay = platformHay(s);
  if (chip.id === "other") {
    return !POPULAR.some((row) => row.id !== "other" && chipHits(row, s));
  }
  if (chip.id === "traffic") {
    return chip.test.test(hay) || /web traffic/i.test(s.type ?? "");
  }
  return chip.test.test(hay);
}

export function metricHits(chip: (typeof POPULAR)[number], metricId: string, s: SmmService): boolean {
  const hay = metricHay(s);
  const row = chip.metrics.find((m) => m.id === metricId);
  if (!row) return false;
  const liveChip = chip.metrics.some((m) => m.id === "live");
  const blocked = (id: string) => {
    if (id === "more") return false;
    if (isCommentLikeName(hay)) return true;
    if (liveChip && id !== "live" && /\blive\b/i.test(hay)) return true;
    return false;
  };
  if (row.id === "more") {
    return !chip.metrics.some((m) => m.id !== "more" && !blocked(m.id) && m.test.test(hay));
  }
  if (blocked(row.id)) return false;
  return row.test.test(hay);
}
const fieldClass =
  "min-h-11 w-full rounded-lg bg-elevated px-3 text-base text-fg outline-none placeholder:text-subtle disabled:opacity-40";

function formatRate(n: number): string {
  if (!Number.isFinite(n) || n <= 0) return "$0.00/1k";
  const cents = Math.round(n * 100) / 100;
  const money = Math.abs(n - cents) < 0.0005 ? formatMoney(n) : `$${n.toFixed(3)}`;
  return `${money}/1k`;
}

function mergePanels(prev: PanelBalance[], incoming: PanelBalance[]): PanelBalance[] {
  return incoming.map((p) => {
    if (p.balance === "—" || p.balance === "…") return prev.find((x) => x.id === p.id) ?? p;
    return p;
  });
}

function debitPanel(panels: PanelBalance[], id: PanelId, amount: number): PanelBalance[] {
  if (!Number.isFinite(amount) || amount <= 0) return panels;
  return panels.map((p) => {
    if (p.id !== id) return p;
    if (p.balance === "—" || p.balance === "…") return p;
    const n = Number(p.balance);
    if (!Number.isFinite(n)) return p;
    return { ...p, balance: Math.max(0, n - amount).toFixed(2) };
  });
}

export type SortId = "price-asc" | "price-desc" | "fastest" | "min" | "name";

export const SORTS: { id: SortId; label: string }[] = [
  { id: "fastest", label: "Average time: fastest to longest" },
  { id: "price-asc", label: "Price: low to high" },
  { id: "price-desc", label: "Price: high to low" },
  { id: "min", label: "Lowest minimum" },
  { id: "name", label: "Name A–Z" },
];

function timeScore(s: SmmService): number {
  const t = (s.averageTime ?? "").toLowerCase().trim();
  if (!t) return Number.POSITIVE_INFINITY;
  if (/instant|immediate/.test(t)) return 0;
  const range = t.match(/(\d+(?:\.\d+)?)\s*[–\-to]+\s*(\d+(?:\.\d+)?)/);
  const n = range ? parseFloat(range[2] ?? "") : parseFloat(t.replace(/,/g, ""));
  if (!Number.isFinite(n)) return Number.POSITIVE_INFINITY;
  if (/day|\bd\b/.test(t)) return n * 1_440;
  if (/hour|\bhr\b|\bh\b/.test(t)) return n * 60;
  if (/min/.test(t)) return n;
  if (/sec|\bs\b/.test(t)) return n / 60;
  return n;
}

export function brandOf(s: SmmService): string {
  const hit = POPULAR.find((row) => row.id !== "other" && chipHits(row, s));
  return hit?.tone ?? "other";
}

export function pillName(s: SmmService): string {
  const cleaned = stripPanelPrefix(s.name, s.panel)
    .replace(/\[[^\]]*\]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  const name = cleaned || s.name;
  if (new RegExp(`\\(\\s*${s.id}\\s*\\)\\s*$`).test(name)) return name;
  return `${name} (${s.id})`;
}

export function hasCustomComments(s: SmmService): boolean {
  if (isCommentOrder(s)) return true;
  return orderNeeds(s).lines?.param === "comments";
}

export function filterSplits(list: SmmService[], test: (s: SmmService) => boolean): boolean {
  if (list.length === 0) return false;
  let yes = 0;
  for (const row of list) {
    if (test(row)) yes += 1;
  }
  return yes > 0 && yes < list.length;
}

export function rowMeta(s: SmmService): string {
  const bits = [formatRate(Number(s.rate) || 0)];
  if (s.averageTime) bits.push(s.averageTime);
  if (s.min > 1) bits.push(`min ${formatCount(s.min)}`);
  if (allowsRefill(s)) bits.push("Refill");
  if (allowsDrip(s)) bits.push("Drip-feed");
  bits.push(`(${panelLabel(s.panel)})`);
  return bits.join(" · ");
}

type SvcRow = { key: string; service: SmmService; title: string; meta: string };

export function sortServices(list: SmmService[], sort: SortId): SmmService[] {
  if (list.length < 2) return list;
  const rows = list.map((s) => ({
    s,
    rate: Number(s.rate) || 0,
    time: sort === "fastest" ? timeScore(s) : 0,
    min: s.min,
    name: sort === "name" ? stripPanelPrefix(s.name, s.panel) : "",
  }));
  rows.sort((a, b) => {
    if (sort === "price-asc") return a.rate - b.rate;
    if (sort === "price-desc") return b.rate - a.rate;
    if (sort === "fastest") return a.time - b.time || a.rate - b.rate;
    if (sort === "min") return a.min - b.min || a.rate - b.rate;
    if (sort === "name") return a.name.localeCompare(b.name);
    return 0;
  });
  return rows.map((row) => row.s);
}

export function ChipSlider({ children, active }: { children: ReactNode; active?: string | null }) {
  const ref = useRef<HTMLDivElement>(null);
  const [canLeft, setCanLeft] = useState(false);
  const [canRight, setCanRight] = useState(false);

  function chipsOf(el: HTMLDivElement) {
    return [...el.children].filter((n) => n instanceof HTMLElement && !n.classList.contains("chip-pad")) as HTMLElement[];
  }

  function measure() {
    const el = ref.current;
    if (!el) {
      setCanLeft(false);
      setCanRight(false);
      return;
    }
    const max = Math.max(0, el.scrollWidth - el.clientWidth);
    const x = el.scrollLeft;
    const left = x > 8;
    const right = x < max - 8;
    setCanLeft((prev) => (prev === left ? prev : left));
    setCanRight((prev) => (prev === right ? prev : right));
  }

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    el.scrollLeft = 0;
    const kick = () => {
      measure();
      requestAnimationFrame(measure);
    };
    kick();
    const later = window.setTimeout(kick, 120);
    let frame = 0;
    function onScroll() {
      if (frame) return;
      frame = requestAnimationFrame(() => {
        frame = 0;
        measure();
      });
    }
    const ro = new ResizeObserver(kick);
    ro.observe(el);
    el.addEventListener("scroll", onScroll, { passive: true });
    el.addEventListener("scrollend", measure);

    return () => {
      ro.disconnect();
      el.removeEventListener("scroll", onScroll);
      el.removeEventListener("scrollend", measure);
      window.clearTimeout(later);
      if (frame) cancelAnimationFrame(frame);
    };
  }, []);

  useEffect(() => {
    const el = ref.current;
    if (!el || !active) return;
    const on = chipsOf(el).find((n) => n.getAttribute("aria-pressed") === "true");
    if (!on) return;
    const rail = el.getBoundingClientRect();
    const box = on.getBoundingClientRect();
    const pad = 10;
    if (box.left < rail.left + pad) el.scrollBy({ left: box.left - rail.left - pad, behavior: "smooth" });
    else if (box.right > rail.right - pad) el.scrollBy({ left: box.right - rail.right + pad, behavior: "smooth" });
  }, [active]);

  function slide(dir: -1 | 1) {
    const el = ref.current;
    if (!el) return;
    const step = Math.max(180, Math.round(el.clientWidth * 0.7));
    el.scrollBy({ left: dir * step, behavior: "smooth" });
  }

  return (
    <div className="chip-rail">
      <div className="chip-arrow-slot">
        {canLeft ? (
          <button type="button" aria-label="More chips left" className="chip-arrow is-left" onClick={() => slide(-1)}>
            <ChevronLeft className="size-5" strokeWidth={2.6} />
          </button>
        ) : null}
      </div>
      <div ref={ref} className="chip-slider">
        <span className="chip-pad" aria-hidden />
        {children}
        <span className="chip-pad" aria-hidden />
      </div>
      <div className="chip-arrow-slot">
        {canRight ? (
          <button type="button" aria-label="More chips right" className="chip-arrow is-right" onClick={() => slide(1)}>
            <ChevronRight className="size-5" strokeWidth={2.6} />
          </button>
        ) : null}
      </div>
    </div>
  );
}

const SvcRowItem = memo(function SvcRowItem({
  row,
  on,
  fav,
  top,
  onPick,
  onStar,
}: {
  row: SvcRow;
  on: boolean;
  fav: boolean;
  top: number;
  onPick: (key: string) => void;
  onStar: (row: SvcRow) => void;
}) {
  const pinned = isPinned(row.service.panel, row.service.id);
  return (
    <li className="svc-virt-row" style={{ top }}>
      {pinned ? (
        <span className="size-11 shrink-0 lg:size-9" aria-hidden />
      ) : (
      <button
        type="button"
        aria-label={fav ? "Remove from favorites" : "Add to favorites"}
        aria-pressed={fav}
        onClick={(e) => {
          e.stopPropagation();
          onStar(row);
        }}
        className="flex size-11 shrink-0 items-center justify-center rounded-lg touch-manipulation lg:size-9"
      >
        <Star
          className={`size-4 ${fav ? "text-fav-star" : "text-muted"}`}
          fill={fav ? "currentColor" : "none"}
          strokeWidth={fav ? 0 : 2}
        />
      </button>
      )}
      <button
        type="button"
        aria-pressed={on}
        onClick={() => onPick(row.key)}
        className={`flex min-h-11 min-w-0 flex-1 flex-col items-start justify-center rounded-lg px-2 py-1.5 text-left touch-manipulation lg:min-h-9 ${
          on ? "bg-elevated text-fg ring-1 ring-fg/40" : "text-muted"
        }`}
      >
        <span className="svc-row-title text-sm font-semibold text-fg">{row.title}</span>
        <span className="svc-row-meta mt-0.5 text-xs text-muted">{row.meta}</span>
      </button>
    </li>
  );
});

export function VirtualSvcList({
  rows,
  picked,
  favKeys,
  onPick,
  onStar,
  listRef,
  className,
}: {
  rows: SvcRow[];
  picked: string;
  favKeys: Set<string>;
  onPick: (key: string) => void;
  onStar: (row: SvcRow) => void;
  listRef: { current: HTMLUListElement | null };
  className?: string;
}) {
  const scroller = useRef<HTMLDivElement>(null);
  const [top, setTop] = useState(0);
  const [view, setView] = useState(320);

  useEffect(() => {
    const el = scroller.current;
    if (!el) return;
    el.scrollTop = 0;
    setTop(0);
    const next = el.clientHeight || 320;
    setView((v) => (v === next ? v : next));
  }, [rows.length, rows[0]?.key]);

  useEffect(() => {
    const el = scroller.current;
    if (!el) return;
    let frame = 0;
    function onScroll() {
      if (frame) return;
      frame = requestAnimationFrame(() => {
        frame = 0;
        setTop(el!.scrollTop);
      });
    }
    const ro = new ResizeObserver(() => setView(el.clientHeight || 320));
    ro.observe(el);
    el.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      ro.disconnect();
      el.removeEventListener("scroll", onScroll);
    };
  }, []);

  if (rows.length === 0) return null;

  const start = Math.max(0, Math.floor(top / ROW_H) - ROW_OVERSCAN);
  const end = Math.min(rows.length, Math.ceil((top + view) / ROW_H) + ROW_OVERSCAN);
  const slice = rows.slice(start, end);

  return (
    <div ref={scroller} className={cn("svc-list rounded-xl bg-surface", className)}>
      <ul
        ref={listRef}
        className="svc-virt"
        style={{ height: rows.length * ROW_H }}
      >
        {slice.map((row, i) => (
          <SvcRowItem
            key={row.key}
            row={row}
            on={row.key === picked}
            fav={favKeys.has(row.key)}
            top={(start + i) * ROW_H}
            onPick={onPick}
            onStar={onStar}
          />
        ))}
      </ul>
    </div>
  );
}

export function AllServicesView() {
  const search = useSearch({ from: "/" });
  const navigate = useNavigate({ from: "/" });
  const [data, setData] = useState<SmmCatalogPayload | null>(() => peekAllCatalog());
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(() => !peekAllCatalog());
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState<SortId>("fastest");
  const [popular, setPopular] = useState<string | null>(null);
  const [metric, setMetric] = useState<string | null>(null);
  const [picked, setPicked] = useState("");
  const [seedLink, setSeedLink] = useState("");
  const [wantComments, setWantComments] = useState(false);
  const [wantDrip, setWantDrip] = useState(false);
  const [wantRefill, setWantRefill] = useState(false);
  const [drop, setDrop] = useState<SmmService | null>(null);
  const seqRef = useRef(0);
  const livePanels = useSmmLive((s) => s.panels);
  const desks = useSmmDesks((s) => s.desks);
  const favKeys = useMemo(
    () => new Set(desks.flatMap((d) => d.services.map((row) => `${row.panel}:${row.id}`))),
    [desks],
  );

  function applyPanels(incoming: PanelBalance[], seq: number) {
    if (seq !== seqRef.current) return;
    useSmmLive.getState().apply(incoming);
    setData((prev) => (prev ? { ...prev, panels: mergePanels(prev.panels, incoming) } : prev));
  }

  useEffect(() => {
    return subscribeAllCatalog((next) => {
      setData(next);
      setLoading(false);
      useSmmDesks.getState().syncServiceNames(next.services);
    });
  }, []);

  useEffect(() => {
    let alive = true;
    if (!peekAllCatalog()) setLoading(true);
    setError(null);
    void loadAllCatalog()
      .then((next) => {
        if (!alive) return;
        setData(next);
        useSmmDesks.getState().syncServiceNames(next.services);
        const wanted = search.svc;
        if (wanted && next.services.some((s) => serviceKey(s) === wanted)) {
          setPicked(wanted);
          const svc = next.services.find((s) => serviceKey(s) === wanted);
          if (svc) {
            const chip = POPULAR.find((row) => row.id !== "other" && chipHits(row, svc));
            if (chip) {
              setPopular(chip.id);
              const hay = `${svc.category} ${svc.name} ${svc.type ?? ""}`.replace(/\[[^\]]*\]/g, " ");
              const hit = chip.metrics.find((m) => m.id !== "more" && m.test.test(hay));
              setMetric(hit?.id ?? chip.metrics[0]?.id ?? null);
            }
          }
        }
        if (search.link) setSeedLink(search.link);
      })
      .catch((err: unknown) => {
        if (!alive) return;
        if (!peekAllCatalog()) setError(err instanceof Error ? err.message : "Could not load services");
      })
      .finally(() => {
        if (alive) setLoading(false);
      });
    return () => {
      alive = false;
    };
  }, []);

  useEffect(() => {
    if (search.tab !== "all") return;
    if (!search.link && !search.svc) return;
    if (search.link) setSeedLink(search.link);
    if (search.svc) setPicked(search.svc);
    void navigate({ to: "/", search: { tab: "all" }, replace: true });
  }, [search.tab, search.link, search.svc, navigate]);

  const panelIds = useMemo(() => {
    const ids: string[] = [];
    for (const row of data?.panels ?? livePanels) {
      if (!ids.includes(row.id)) ids.push(row.id);
    }
    return ids;
  }, [data, livePanels]);

  const scoped = Boolean(popular && metric);
  const searchingAll = query.trim().length > 0 && !scoped;

  const chosenPool = useMemo(() => {
    const list = data?.services ?? [];
    const chip = POPULAR.find((row) => row.id === popular);
    if (chip && metric) return list.filter((s) => chipHits(chip, s) && metricHits(chip, metric, s));
    if (query.trim()) return list;
    return [];
  }, [data, popular, metric, query]);

  const showComments = useMemo(() => filterSplits(chosenPool, hasCustomComments), [chosenPool]);
  const showDrip = useMemo(() => filterSplits(chosenPool, allowsDrip), [chosenPool]);
  const showRefill = useMemo(() => filterSplits(chosenPool, allowsRefill), [chosenPool]);
  const showFilters = showComments || showDrip || showRefill;

  useEffect(() => {
    setWantComments(false);
    setWantDrip(false);
    setWantRefill(false);
  }, [popular, metric]);

  useEffect(() => {
    if (!showComments) setWantComments(false);
    if (!showDrip) setWantDrip(false);
    if (!showRefill) setWantRefill(false);
  }, [showComments, showDrip, showRefill]);

  const rows = useMemo(() => {
    const q = query.trim().toLowerCase();
    const matched = chosenPool.filter((s) => {
      if (wantComments && showComments && !hasCustomComments(s)) return false;
      if (wantDrip && showDrip && !allowsDrip(s)) return false;
      if (wantRefill && showRefill && !allowsRefill(s)) return false;
      if (!q) return true;
      return `${s.name} ${s.category} ${s.id} ${panelLabel(s.panel)}`.toLowerCase().includes(q);
    });
    return sortServices(matched, sort).slice(0, LIST_CAP).map((s) => ({
      key: serviceKey(s),
      service: s,
      title: nameWithId(s),
      meta: rowMeta(s),
    }));
  }, [chosenPool, query, sort, wantComments, wantDrip, wantRefill, showComments, showDrip, showRefill]);

  const selected = rows.find((row) => row.key === picked)?.service ?? null;
  const activePopular = POPULAR.find((row) => row.id === popular);
  const metricLabel = activePopular?.metrics.find((row) => row.id === metric)?.label;
  const searchLabel = scoped ? "Search" : "Search all";
  const searchPlaceholder = scoped ? `Search ${activePopular?.label ?? ""} ${metricLabel ?? ""}…`.replace(/\s+/g, " ").trim() : "Search every service…";
  const typing = query.trim().length > 0;
  const formRef = useRef<HTMLDivElement>(null);
  const listRef = useRef<HTMLUListElement>(null);

  useEffect(() => {
    if (!picked || rows.length === 0) return;
    if (!rows.some((row) => row.key === picked)) setPicked("");
  }, [rows, picked]);

  function pickService(key: string) {
    setPicked(key);
    useSmmPrefs.getState().setLastService("all", key);
    requestAnimationFrame(() => {
      formRef.current?.scrollIntoView({ behavior: "smooth", block: "nearest" });
    });
  }

  const onPick = useCallback((key: string) => {
    setPicked(key);
    useSmmPrefs.getState().setLastService("all", key);
    requestAnimationFrame(() => {
      formRef.current?.scrollIntoView({ behavior: "smooth", block: "nearest" });
    });
  }, []);

  const onStar = useCallback((row: SvcRow) => {
    const have = useSmmDesks.getState().desks.some((d) =>
      d.services.some((s) => s.panel === row.service.panel && s.id === row.service.id),
    );
    if (have) {
      if (isPinned(row.service.panel, row.service.id)) {
        toastPinned();
        return;
      }
      setDrop(row.service);
      return;
    }
    const chip = POPULAR.find((c) => c.id !== "other" && chipHits(c, row.service));
    const err = useSmmDesks.getState().toggleFavorite(
      { panel: row.service.panel, id: row.service.id, title: stripPanelPrefix(row.service.name, row.service.panel) },
      { id: chip?.id ?? "other", label: chip?.label ?? "Other" },
    );
    if (err === "pinned") toastPinned();
    else if (err) toast.warning(err);
    else {
      const hit = useSmmDesks
        .getState()
        .desks.find((d) => d.services.some((s) => s.panel === row.service.panel && s.id === row.service.id));
      toastFavorited(hit?.label ?? chip?.label ?? "Favorites", () => {
        void navigate({ to: "/", search: { tab: hit?.id ?? chip?.id ?? "tiktok" } });
      });
    }
  }, [navigate]);

  const panels: PanelBalance[] = panelIds.map((id) => {
    const live = livePanels.find((row) => row.id === id);
    const local = data?.panels.find((row) => row.id === id);
    return live ?? local ?? { id, label: panelLabel(id), balance: loading ? "…" : "—", currency: "USD" };
  });

  return (
    <div className="mx-auto flex max-w-2xl flex-col gap-6 px-3 py-4 pb-10 lg:px-6">
        <div>
          <label className="block">
            <span className="mb-2 block text-xs font-medium tracking-wide text-muted uppercase">{searchLabel}</span>
            <input
              value={query}
              onChange={(e) => {
                const v = e.target.value;
                setQuery(v);
                if (v.trim()) {
                  setPopular(null);
                  setMetric(null);
                }
              }}
              placeholder={searchPlaceholder}
              aria-label={searchLabel}
              className={fieldClass}
            />
          </label>
          <div className={typing ? "hidden" : ""} hidden={typing}>
          <div className="chip-bleed mt-4">
            <ChipSlider active={popular}>
              {POPULAR.map((row) => {
                const on = popular === row.id;
                return (
                  <button
                    key={row.id}
                    type="button"
                    aria-pressed={on}
                    onClick={() => {
                      startTransition(() => {
                        setPopular(on ? null : row.id);
                        setMetric(null);
                      });
                    }}
                    className={`brand-chip min-h-11 shrink-0 rounded-full px-3.5 text-sm font-semibold lg:min-h-9 lg:px-4 lg:text-xs ${on ? "is-on" : ""}`}
                    data-brand={row.tone}
                  >
                    {row.label}
                  </button>
                );
              })}
            </ChipSlider>
          </div>
          {activePopular?.metrics.length ? (
            <div className="chip-bleed mt-3">
              <ChipSlider key={activePopular.id} active={metric}>
                {activePopular.metrics.map((row) => {
                  const on = metric === row.id;
                  return (
                    <button
                      key={row.id}
                      type="button"
                      aria-pressed={on}
                      onClick={() => {
                        startTransition(() => {
                          setMetric(on ? null : row.id);
                        });
                      }}
                      className={`min-h-11 shrink-0 rounded-full px-3 text-sm font-semibold lg:min-h-9 lg:text-xs ${
                        on ? "bg-surface text-fg ring-1 ring-fg/30" : "bg-elevated text-muted"
                      }`}
                    >
                      {row.label}
                    </button>
                  );
                })}
              </ChipSlider>
            </div>
          ) : null}
          </div>
          <div className="mt-4 border-b border-border" />
        </div>

        {error ? <p className="text-sm text-neon-red">{error}</p> : null}

        {searchingAll || scoped ? (
        <div className="flex flex-col items-center gap-4">
          <label className="w-full max-w-md">
            <span className="mb-2 block text-center text-xs font-medium tracking-wide text-muted uppercase">Sort</span>
            <select
              value={sort}
              onChange={(e) => setSort(e.target.value as SortId)}
              aria-label="Sort services"
              className={`field-select ${fieldClass}`}
            >
              {SORTS.map((row) => (
                <option key={row.id} value={row.id}>
                  {row.label}
                </option>
              ))}
            </select>
          </label>
          {showFilters ? (
            <div className="flex w-full max-w-md flex-wrap items-center justify-center gap-x-5 gap-y-1 rounded-xl bg-surface px-4 py-2">
                {showComments ? (
                  <label className="flex min-h-11 items-center gap-2">
                    <input
                      type="checkbox"
                      checked={wantComments}
                      onChange={(e) => setWantComments(e.target.checked)}
                      className="size-4 shrink-0 accent-tt"
                    />
                    <span className="text-sm font-semibold leading-snug text-fg">Custom comments</span>
                  </label>
                ) : null}
                {showDrip ? (
                  <label className="flex min-h-11 items-center gap-2">
                    <input
                      type="checkbox"
                      checked={wantDrip}
                      onChange={(e) => setWantDrip(e.target.checked)}
                      className="size-4 shrink-0 accent-tt"
                    />
                    <span className="text-sm font-semibold leading-snug text-fg">Drip-feed</span>
                  </label>
                ) : null}
                {showRefill ? (
                  <label className="flex min-h-11 items-center gap-2">
                    <input
                      type="checkbox"
                      checked={wantRefill}
                      onChange={(e) => setWantRefill(e.target.checked)}
                      className="size-4 shrink-0 accent-tt"
                    />
                    <span className="text-sm font-semibold leading-snug text-fg">Refill</span>
                  </label>
                ) : null}
            </div>
          ) : null}
          <div className="w-full">
          <p className="text-xs font-medium tracking-wide text-muted uppercase">
            {loading && !data ? "Loading…" : `${rows.length}${chosenPool.length > LIST_CAP ? "+" : ""} services`}
          </p>
          {loading && !data ? null : rows.length === 0 ? (
            <p className="rounded-xl bg-surface px-3 py-6 text-sm text-muted">
              {loading ? "Loading…" : "Nothing matches. Try another search."}
            </p>
          ) : (
            <VirtualSvcList
              rows={rows}
              picked={picked}
              favKeys={favKeys}
              listRef={listRef}
              onPick={onPick}
              onStar={onStar}
            />
          )}
          {chosenPool.length > LIST_CAP ? (
            <p className="text-xs text-muted">Showing {LIST_CAP}. Type to narrow.</p>
          ) : null}
          <div ref={formRef}>
            {selected ? (
              <div className="svc-form-tile" data-brand={activePopular?.tone ?? brandOf(selected)}>
                <div className="mb-4 flex items-center gap-2">
                  <ServiceFav service={selected} deskId="all" />
                  <p
                    className="brand-chip svc-form-pill mb-0 min-w-0 flex-1"
                    data-brand={activePopular?.tone ?? brandOf(selected)}
                    title={nameWithId(selected)}
                  >
                    {pillName(selected)}
                  </p>
                </div>
                <ServiceForm
                  key={serviceKey(selected)}
                  service={selected}
                  deskId="all"
                  seedLink={seedLink}
                  panelBalance={panels.find((p) => p.id === selected.panel)}
                  onOrderStart={(id, amount) => {
                    const seq = ++seqRef.current;
                    setData((prev) => (prev ? { ...prev, panels: debitPanel(prev.panels, id, amount) } : prev));
                    return seq;
                  }}
                  onOrdered={(nextPanels, seq) => applyPanels(nextPanels, seq)}
                  onOrderFailed={(seq) => {
                    if (seq !== seqRef.current) return;
                    const next = ++seqRef.current;
                    void loadSmmLive()
                      .then((nextPanels) => applyPanels(nextPanels, next))
                      .catch(() => undefined);
                    toast.message("Balance restored");
                  }}
                  linkHint="https://…"
                  accentClass="accent-tt"
                  showFav={false}
                />
              </div>
            ) : null}
          </div>
          </div>
        </div>
        ) : null}

      {drop
        ? createPortal(
            <div className="order-verify" role="dialog" aria-modal="true" aria-labelledby="unfav-title">
              <button type="button" className="order-verify-scrim" aria-label="Cancel" onClick={() => setDrop(null)} />
              <div className="order-verify-card">
                <p id="unfav-title" className="text-base font-bold text-fg">
                  Remove from Favorites?
                </p>
                <p className="mt-2 text-sm text-muted">This service will leave the Favorites tab.</p>
                <div className="order-verify-acts">
                  <button
                    type="button"
                    className="order-verify-yes"
                    onClick={() => {
                      const s = drop;
                      setDrop(null);
                      if (!s) return;
                      const err = useSmmDesks.getState().toggleFavorite(
                        { panel: s.panel, id: s.id, title: stripPanelPrefix(s.name, s.panel) },
                        { id: activePopular?.id ?? "all", label: activePopular?.label ?? "Other" },
                      );
                      if (err) toast.warning(err);
                    }}
                  >
                    Yes
                  </button>
                  <button type="button" className="order-verify-no" onClick={() => setDrop(null)}>
                    No
                  </button>
                </div>
              </div>
            </div>,
            document.body,
          )
        : null}
    </div>
  );
}
