import { useEffect, useRef, useState, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { X } from "lucide-react";
import { cn } from "@/lib/utils";

const FADE_MS = 240;

export function BottomSheet({
  open,
  onClose,
  title,
  children,
  footer,
  tall,
  full,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
  footer?: ReactNode;
  tall?: boolean;
  full?: boolean;
}) {
  const [shown, setShown] = useState(open);
  const [on, setOn] = useState(false);
  const closeBtn = useRef<HTMLButtonElement>(null);
  const closeTimer = useRef(0);
  const onCloseRef = useRef(onClose);
  onCloseRef.current = onClose;

  useEffect(() => {
    if (open) {
      setShown(true);
      const id = window.requestAnimationFrame(() => {
        window.requestAnimationFrame(() => setOn(true));
      });
      return () => window.cancelAnimationFrame(id);
    }
    setOn(false);
    closeTimer.current = window.setTimeout(() => setShown(false), FADE_MS);
    return () => window.clearTimeout(closeTimer.current);
  }, [open]);

  function dismiss() {
    setOn(false);
    window.clearTimeout(closeTimer.current);
    closeTimer.current = window.setTimeout(() => onCloseRef.current(), FADE_MS);
  }

  useEffect(() => {
    if (!shown) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        if (document.querySelector(".order-verify")) return;
        e.preventDefault();
        setOn(false);
        window.clearTimeout(closeTimer.current);
        closeTimer.current = window.setTimeout(() => onCloseRef.current(), FADE_MS);
      }
    };
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    closeBtn.current?.focus();
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", onKey);
    };
  }, [shown]);

  if (!shown) return null;

  const node = (
    <div
      className="fixed inset-0 z-[80] flex items-center justify-center"
      role="presentation"
      style={{ zIndex: "var(--z-modal)" }}
    >
      <button
        type="button"
        aria-label="Close"
        onClick={dismiss}
        className={cn("modal-scrim absolute inset-0", on && "is-on")}
      />
      <div
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className={cn(
          "modal-panel flex flex-col bg-surface",
          full
            ? "modal-panel-full bg-bg"
            : cn("modal-panel-sheet absolute inset-x-0 bottom-0 rounded-t-xl", tall ? "max-h-[92dvh]" : "max-h-[78dvh]"),
          on && "is-on",
        )}
      >
        {full ? (
          <>
            <button
              ref={closeBtn}
              type="button"
              onClick={dismiss}
              className="modal-x"
              aria-label="Cancel"
            >
              <X className="size-5" strokeWidth={3} />
            </button>
            <div className="modal-full-bar">
              <h2 className="min-w-0 flex-1 text-base font-bold text-fg">{title}</h2>
            </div>
          </>
        ) : (
          <>
            <div className="flex items-center justify-between px-4 pt-3 pb-2">
              <span className="mx-auto h-1 w-10 rounded-full bg-elevated" aria-hidden />
            </div>
            <div className="flex items-center justify-between px-4 pb-3">
              <h2 className="text-sm font-semibold text-fg">{title}</h2>
              <button
                ref={closeBtn}
                type="button"
                onClick={dismiss}
                className="flex size-11 items-center justify-center rounded-full text-muted transition-colors hover:text-fg active:scale-[0.96]"
                aria-label="Close sheet"
              >
                <X className="size-5" strokeWidth={2} />
              </button>
            </div>
          </>
        )}
        <div className={cn("min-h-0 flex-1 overflow-y-auto px-4 pb-4", full && "pb-[max(1rem,env(safe-area-inset-bottom))]")}>
          {children}
        </div>
        {footer ? (
          <div className="border-t border-border px-4 py-3 pb-[max(0.75rem,env(safe-area-inset-bottom))]">{footer}</div>
        ) : null}
      </div>
    </div>
  );

  if (typeof document === "undefined") return node;
  return createPortal(node, document.body);
}
