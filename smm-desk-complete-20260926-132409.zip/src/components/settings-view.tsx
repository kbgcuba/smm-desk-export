import { useEffect, useState } from "react";
import { Lock, Unlock, ChevronUp, ChevronDown } from "lucide-react";
import { toast } from "sonner";
import { formatMoney } from "@/lib/format";
import {
  panelLabel,
  assignTitle,
  nameWithId,
  lookupSmmService,
  lookupSmmProfile,
  unlockSmmAdmin,
  loadSmmGate,
  saveSmmGate,
  revokeSmmDevice,
  loadSmmAccounts,
  addSmmAccount,
  updateSmmAccountKey,
  removeSmmAccount,
  loadSocialKeys,
  trySocialKey,
  saveSocialKey,
  removeSocialKey,
  type SmmService,
  type PanelPublic,
  type SocialPublic,
} from "@/lib/smm/fn";
import { useSmmDesks } from "@/lib/smm/desks";
import { useSmmLive } from "@/lib/smm/live-store";
import { useSmmOrders, formatRefillWait, refillDueAt } from "@/lib/smm/orders";
import { useSmmProfiles } from "@/lib/smm/profiles";
import { useSmmRefills } from "@/lib/smm/refill-store";
import { useSmmPrefs } from "@/lib/smm/prefs";
import { syncCloudNow, useCloudStamp } from "@/components/cloud-sync";
import { TabMark } from "@/components/platform-tabs";
import { WpSiteSettings } from "@/components/wp-list-sheet";
import { deviceId, deviceName } from "@/components/access-gate";
import type { LookedProfile } from "@/lib/smm/profile-types";
import type { PanelId } from "@/lib/smm/types";

const ADMIN_KEY = "smm-admin";
const fieldClass = "min-h-11 w-full rounded-lg bg-elevated px-3 text-base text-fg outline-none";

function balanceTone(balance: string): "ok" | "low" | "wait" {
  if (balance === "—" || balance === "…") return "wait";
  const n = Number(balance);
  return Number.isFinite(n) && n >= 1 ? "ok" : "low";
}

export function SettingsView() {
  const [unlocked, setUnlocked] = useState(false);
  const [password, setPassword] = useState("");
  const [adminPw, setAdminPw] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    try {
      setUnlocked(sessionStorage.getItem(ADMIN_KEY) === "1");
    } catch {
      setUnlocked(false);
    }
  }, []);

  async function unlock() {
    if (busy) return;
    setBusy(true);
    try {
      await unlockSmmAdmin({ data: { password } });
      sessionStorage.setItem(ADMIN_KEY, "1");
      setAdminPw(password.trim());
      setUnlocked(true);
      setPassword("");
      toast.success("Admin unlocked");
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Wrong password");
    } finally {
      setBusy(false);
    }
  }

  function lock() {
    sessionStorage.removeItem(ADMIN_KEY);
    setUnlocked(false);
    setPassword("");
    setAdminPw("");
  }

  return (
    <div className="h-full overflow-y-auto bg-bg">
      <div className="mx-auto flex max-w-2xl flex-col gap-6 px-3 py-4 pb-10 lg:px-6">
        <div>
          <p className="text-xs font-medium tracking-wide text-muted uppercase">Settings</p>
          <p className="mt-2 text-sm text-muted">Admin tools stay locked until the password is entered.</p>
        </div>

        <section className="rounded-xl bg-surface px-4 py-4">
          <div className="flex items-center justify-between gap-3">
            <div>
              <p className="text-xs font-medium tracking-wide text-muted uppercase">Admin</p>
              <p className="mt-1 text-sm text-fg">{unlocked ? "Unlocked" : "Locked"}</p>
            </div>
            {unlocked ? (
              <button
                type="button"
                onClick={lock}
                className="flex min-h-11 items-center gap-2 rounded-full bg-elevated px-4 text-sm font-semibold text-fg transition-transform duration-150 ease-out active:scale-[0.96] lg:min-h-9"
              >
                <Lock className="size-4" />
                Lock
              </button>
            ) : null}
          </div>

          {unlocked ? (
            <AdminBody adminPw={adminPw} />
          ) : (
            <form
              className="mt-4 flex flex-col gap-3"
              onSubmit={(e) => {
                e.preventDefault();
                void unlock();
              }}
            >
              <label className="block">
                <span className="mb-2 block text-xs font-medium tracking-wide text-muted uppercase">Password</span>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  autoComplete="current-password"
                  aria-label="Admin password"
                  className={fieldClass}
                />
              </label>
              <button
                type="submit"
                disabled={busy || !password.trim()}
                className="flex min-h-11 w-full items-center justify-center gap-2 rounded-full bg-fg px-5 text-sm font-semibold text-accent-fg transition-transform duration-150 ease-out active:scale-[0.96] disabled:opacity-40 lg:min-h-9"
              >
                <Unlock className="size-4" />
                {busy ? "Checking…" : "Unlock admin"}
              </button>
            </form>
          )}
        </section>
      </div>
    </div>
  );
}

function AdminBody({ adminPw }: { adminPw: string }) {
  const live = useSmmLive((s) => s.panels);
  const orders = useSmmOrders((s) => s.orders);
  const clear = useSmmOrders((s) => s.clear);
  const readyCount = useSmmRefills((s) => s.readyCount);
  const desks = useSmmDesks((s) => s.desks);
  const autoRefill = useSmmPrefs((s) => s.autoRefill);
  const setAutoRefill = useSmmPrefs((s) => s.setAutoRefill);
  const addService = useSmmDesks((s) => s.addService);
  const addDesk = useSmmDesks((s) => s.addDesk);
  const removeService = useSmmDesks((s) => s.removeService);
  const removeDesk = useSmmDesks((s) => s.removeDesk);
  const renameDesk = useSmmDesks((s) => s.renameDesk);
  const renameService = useSmmDesks((s) => s.renameService);
  const moveDesk = useSmmDesks((s) => s.moveDesk);
  const moveService = useSmmDesks((s) => s.moveService);
  const moveServiceTo = useSmmDesks((s) => s.moveServiceTo);

  const [panel, setPanel] = useState<PanelId>("smmwiz");
  const [idText, setIdText] = useState("");
  const [target, setTarget] = useState("tiktok");
  const [newLabel, setNewLabel] = useState("");
  const [found, setFound] = useState<SmmService | null>(null);
  const [looking, setLooking] = useState(false);
  const [accounts, setAccounts] = useState<PanelPublic[]>([]);

  useEffect(() => {
    void loadSmmAccounts()
      .then(setAccounts)
      .catch(() => undefined);
  }, []);

  async function lookup() {
    const id = Number(idText);
    if (!Number.isFinite(id) || id < 1) {
      toast.error("Enter a service number");
      return;
    }
    setLooking(true);
    setFound(null);
    try {
      const hit = await lookupSmmService({ data: { panel, id } });
      setFound(hit);
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Could not find service");
    } finally {
      setLooking(false);
    }
  }

  function assign() {
    if (!found) {
      toast.error("Look up a service first");
      return;
    }
    const service = { panel: found.panel, id: found.id, title: assignTitle(found) };
    const err =
      target === "__new__" ? addDesk(newLabel, service) : addService(target, service);
    if (err) {
      toast.error(err);
      return;
    }
    toast.success(
      target === "__new__"
        ? `${newLabel.trim()} added under Favorites · auto-refill will watch it`
        : `Added to ${desks.find((d) => d.id === target)?.label ?? "tab"} · auto-refill will watch it`,
    );
    setFound(null);
    setIdText("");
    setNewLabel("");
    void syncCloudNow();
  }

  const nextDue = orders
    .filter((row) => row.refill)
    .map((row) => refillDueAt(row) - Date.now())
    .filter((ms) => ms > 0)
    .sort((a, b) => a - b)[0];
  const lastRefill = useSmmOrders.getState().refills[0]?.at;
  const cloud = useCloudStamp();

  return (
    <div className="mt-5 flex flex-col gap-6">
      <AccessLock adminPw={adminPw} />
      <div className="rounded-lg bg-elevated px-3 py-3">
        <p className="text-xs font-medium tracking-wide text-muted uppercase">Device sync</p>
        <p className="mt-1 text-sm text-fg">
          {cloud.at
            ? `Last saved · ${new Date(cloud.at).toLocaleString(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}`
            : "Waiting for first save"}
          {cloud.live ? " · Live" : ""}
        </p>
        <p className="mt-1 text-xs text-muted">Orders, tabs, stats accounts, and settings stay the same on every device.</p>
      </div>
      <WpSiteSettings />
      <StatsAccounts />
      <LiveApis />
      <div className="rounded-lg bg-elevated px-3 py-3">
        <div className="flex items-center justify-between gap-3">
          <div>
            <p className="text-xs font-medium tracking-wide text-muted uppercase">Auto-refill</p>
            <p className="mt-1 text-sm text-fg">{autoRefill ? "On" : "Off"}</p>
            <p className="mt-1 text-xs text-muted">
              Sends as soon as the panel says refill is available. 3 tries, then waits 30 minutes before trying that
              order again.
              {nextDue != null ? ` Next in ${formatRefillWait(nextDue)}.` : " Nothing waiting."}
              {lastRefill
                ? ` Last ${new Date(lastRefill).toLocaleString(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}.`
                : ""}
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              setAutoRefill(!autoRefill);
              window.setTimeout(() => void syncCloudNow(), 0);
            }}
            className={
              autoRefill
                ? "min-h-11 rounded-full bg-fg px-4 text-sm font-semibold text-accent-fg lg:min-h-9"
                : "min-h-11 rounded-full bg-surface px-4 text-sm font-semibold text-muted lg:min-h-9"
            }
          >
            {autoRefill ? "On" : "Off"}
          </button>
        </div>
      </div>

      <ApisSection
        accounts={accounts}
        live={live}
        onChange={setAccounts}
      />

      <div>
        <p className="text-xs font-medium tracking-wide text-muted uppercase">Tabs & services</p>
        <p className="mt-1 text-xs text-muted">
          Rename, reorder, or move services between tabs. New tabs sit under Favorites. Auto-refill watches every
          service listed here.
        </p>
        <ul className="mt-3 flex flex-col gap-3">
          {desks.map((desk, deskIndex) => (
            <li key={desk.id} className="rounded-lg bg-elevated px-3 py-3">
              <div className="flex items-center gap-2">
                <div className="flex flex-col">
                  <button
                    type="button"
                    disabled={deskIndex === 0}
                    onClick={() => {
                      moveDesk(desk.id, -1);
                      void syncCloudNow();
                    }}
                    aria-label={`Move ${desk.label} up`}
                    className="flex size-8 items-center justify-center text-muted disabled:opacity-25"
                  >
                    <ChevronUp className="size-4" />
                  </button>
                  <button
                    type="button"
                    disabled={deskIndex === desks.length - 1}
                    onClick={() => {
                      moveDesk(desk.id, 1);
                      void syncCloudNow();
                    }}
                    aria-label={`Move ${desk.label} down`}
                    className="flex size-8 items-center justify-center text-muted disabled:opacity-25"
                  >
                    <ChevronDown className="size-4" />
                  </button>
                </div>
                <input
                  value={desk.label}
                  onChange={(e) => renameDesk(desk.id, e.target.value)}
                  onBlur={() => void syncCloudNow()}
                  aria-label="Tab name"
                  className="min-h-11 min-w-0 flex-1 rounded-lg bg-surface px-3 text-base font-semibold text-fg outline-none"
                />
                {desk.locked ? (
                  <p className="shrink-0 text-[10px] font-medium tracking-wide text-muted uppercase">Core</p>
                ) : (
                  <button
                    type="button"
                    onClick={() => {
                      removeDesk(desk.id);
                      void syncCloudNow();
                    }}
                    className="shrink-0 text-xs font-semibold text-muted"
                  >
                    Remove
                  </button>
                )}
              </div>
              <ul className="mt-3 flex flex-col gap-2">
                {desk.services.map((row, svcIndex) => (
                  <li key={`${row.panel}:${row.id}`} className="rounded-lg bg-surface px-2 py-2">
                    <div className="flex items-start gap-2">
                      <div className="flex flex-col">
                        <button
                          type="button"
                          disabled={svcIndex === 0}
                          onClick={() => {
                            moveService(desk.id, row.panel, row.id, -1);
                            void syncCloudNow();
                          }}
                          aria-label="Move service up"
                          className="flex size-8 items-center justify-center text-muted disabled:opacity-25"
                        >
                          <ChevronUp className="size-4" />
                        </button>
                        <button
                          type="button"
                          disabled={svcIndex === desk.services.length - 1}
                          onClick={() => {
                            moveService(desk.id, row.panel, row.id, 1);
                            void syncCloudNow();
                          }}
                          aria-label="Move service down"
                          className="flex size-8 items-center justify-center text-muted disabled:opacity-25"
                        >
                          <ChevronDown className="size-4" />
                        </button>
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <input
                            value={row.title}
                            onChange={(e) => renameService(desk.id, row.panel, row.id, e.target.value)}
                            onBlur={() => void syncCloudNow()}
                            aria-label="Service name"
                            className="min-h-11 min-w-0 flex-1 rounded-lg bg-elevated px-3 text-base text-fg outline-none"
                          />
                          <span className="shrink-0 text-sm font-semibold text-fg">({row.id})</span>
                        </div>
                        <p className="mt-1 text-[11px] text-muted">{panelLabel(row.panel)}</p>
                        {desks.length > 1 ? (
                          <label className="mt-2 block">
                            <span className="mb-1 block text-[10px] font-medium tracking-wide text-muted uppercase">
                              Move to
                            </span>
                            <select
                              value={desk.id}
                              onChange={(e) => {
                                const err = moveServiceTo(desk.id, row.panel, row.id, e.target.value);
                                if (err) toast.error(err);
                                else void syncCloudNow();
                              }}
                              aria-label="Move service to tab"
                              className={`field-select min-h-11 w-full rounded-lg bg-elevated px-3 text-sm text-fg`}
                            >
                              {desks.map((d) => (
                                <option key={d.id} value={d.id}>
                                  {d.label}
                                </option>
                              ))}
                            </select>
                          </label>
                        ) : null}
                      </div>
                      {desk.locked && desk.services.length === 1 ? null : (
                        <button
                          type="button"
                          onClick={() => {
                            removeService(desk.id, row.panel, row.id);
                            void syncCloudNow();
                          }}
                          className="shrink-0 pt-2 text-xs font-semibold text-muted"
                        >
                          Remove
                        </button>
                      )}
                    </div>
                  </li>
                ))}
              </ul>
            </li>
          ))}
        </ul>
      </div>

      <div>
        <p className="text-xs font-medium tracking-wide text-muted uppercase">Add service</p>
        <div className="mt-3 flex flex-col gap-3">
          <label className="block">
            <span className="mb-2 block text-xs font-medium tracking-wide text-muted uppercase">Panel</span>
            <select
              value={panel}
              onChange={(e) => {
                setPanel(e.target.value as PanelId);
                setFound(null);
              }}
              aria-label="Panel"
              className={`field-select ${fieldClass}`}
            >
              {accounts.map((row) => (
                <option key={row.id} value={row.id}>
                  {row.label}
                </option>
              ))}
            </select>
          </label>
          <label className="block">
            <span className="mb-2 block text-xs font-medium tracking-wide text-muted uppercase">Service number</span>
            <input
              type="number"
              min={1}
              value={idText}
              onChange={(e) => {
                setIdText(e.target.value);
                setFound(null);
              }}
              placeholder="19968"
              aria-label="Service number"
              className={fieldClass}
            />
          </label>
          <button
            type="button"
            disabled={looking || !idText.trim()}
            onClick={() => void lookup()}
            className="min-h-11 rounded-full bg-elevated px-5 text-sm font-semibold text-fg transition-transform duration-150 ease-out active:scale-[0.96] disabled:opacity-40 lg:min-h-9"
          >
            {looking ? "Looking…" : "Look up"}
          </button>
          {found ? (
            <div className="rounded-lg bg-elevated px-3 py-3">
              <p className="text-xs font-medium tracking-wide text-muted uppercase">{panelLabel(found.panel)}</p>
              <p className="mt-1 text-sm font-semibold text-fg">{nameWithId(found)}</p>
              <p className="mt-1 text-xs text-muted">
                ${Number(found.rate).toFixed(3)}/1k · {found.min}–{found.max}
              </p>
            </div>
          ) : null}
          <label className="block">
            <span className="mb-2 block text-xs font-medium tracking-wide text-muted uppercase">Add to</span>
            <select
              value={target}
              onChange={(e) => setTarget(e.target.value)}
              aria-label="Add to tab"
              className={`field-select ${fieldClass}`}
            >
              {desks.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.label}
                </option>
              ))}
              <option value="__new__">New tab</option>
            </select>
          </label>
          {target === "__new__" ? (
            <label className="block">
              <span className="mb-2 block text-xs font-medium tracking-wide text-muted uppercase">Tab name</span>
              <input
                value={newLabel}
                onChange={(e) => setNewLabel(e.target.value)}
                placeholder="Instagram"
                aria-label="New tab name"
                className={fieldClass}
              />
            </label>
          ) : null}
          <button
            type="button"
            disabled={!found || (target === "__new__" && !newLabel.trim())}
            onClick={assign}
            className="min-h-11 rounded-full bg-fg px-5 text-sm font-semibold text-accent-fg transition-transform duration-150 ease-out active:scale-[0.96] disabled:opacity-40 lg:min-h-9"
          >
            Add
          </button>
        </div>
      </div>

      <div>
        <p className="text-xs font-medium tracking-wide text-muted uppercase">Tracked orders</p>
        <p className="money mt-2 text-[1.75rem] leading-none text-fg">{orders.length}</p>
        <p className="mt-1 text-sm text-muted">
          {readyCount === 1 ? "1 refill ready" : `${readyCount} refills ready`}
        </p>
        <button
          type="button"
          disabled={orders.length === 0}
          onClick={() => {
            clear();
            toast.success("Tracked orders cleared");
          }}
          className="mt-3 min-h-11 w-full rounded-full bg-elevated px-5 text-sm font-semibold text-fg transition-transform duration-150 ease-out active:scale-[0.96] disabled:opacity-40 lg:min-h-9"
        >
          Clear tracked orders
        </button>
        <button
          type="button"
          onClick={() => {
            const blob = JSON.stringify({ desks, savedAt: Date.now() });
            void navigator.clipboard.writeText(blob).then(
              () => toast.success("Setup copied"),
              () => toast.error("Could not copy"),
            );
          }}
          className="mt-2 min-h-11 w-full rounded-full bg-elevated px-5 text-sm font-semibold text-fg transition-transform duration-150 ease-out active:scale-[0.96] lg:min-h-9"
        >
          Copy setup
        </button>
      </div>
    </div>
  );
}

function hostOf(url: string): string {
  try {
    return new URL(url).host;
  } catch {
    return url;
  }
}

function ApisSection({
  accounts,
  live,
  onChange,
}: {
  accounts: PanelPublic[];
  live: { id: string; balance: string; currency?: string }[];
  onChange: (rows: PanelPublic[]) => void;
}) {
  const [label, setLabel] = useState("");
  const [url, setUrl] = useState("");
  const [key, setKey] = useState("");
  const [busy, setBusy] = useState(false);
  const [editKey, setEditKey] = useState<Record<string, string>>({});

  async function add() {
    if (busy) return;
    setBusy(true);
    try {
      const row = await addSmmAccount({ data: { label, url, key } });
      onChange([...accounts.filter((item) => item.id !== row.id), row]);
      setLabel("");
      setUrl("");
      setKey("");
      toast.success(`${row.label} saved`);
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Could not save API");
    } finally {
      setBusy(false);
    }
  }

  async function saveKey(id: string) {
    const next = (editKey[id] ?? "").trim();
    if (!next) return;
    try {
      const row = await updateSmmAccountKey({ data: { id, key: next } });
      onChange(accounts.map((item) => (item.id === id ? row : item)));
      setEditKey((prev) => ({ ...prev, [id]: "" }));
      toast.success("Key updated");
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Could not update key");
    }
  }

  async function remove(id: string) {
    try {
      await removeSmmAccount({ data: { id } });
      onChange(accounts.filter((item) => item.id !== id));
      toast.success("API removed");
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Could not remove");
    }
  }

  return (
    <div>
      <p className="text-xs font-medium tracking-wide text-muted uppercase">APIs</p>
      <p className="mt-1 text-xs text-muted">
        PerfectPanel keys stay on this desk. Add any other panel with the same /api/v2 style.
      </p>
      <ul className="mt-3 flex flex-col gap-3">
        {accounts.map((row) => {
          const bal = live.find((p) => p.id === row.id)?.balance ?? "…";
          return (
            <li key={row.id} className="rounded-lg bg-elevated px-3 py-3">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-fg">{row.label}</p>
                  <p className="mt-0.5 truncate text-xs text-muted">{hostOf(row.url)}</p>
                  <p className="mt-0.5 text-xs text-muted">Key {row.hint}</p>
                </div>
                <div className="text-right">
                  <p className="balance-amt money text-lg leading-none text-fg" data-tone={balanceTone(bal)}>
                    {bal === "—" || bal === "…" ? bal : formatMoney(Number(bal) || 0)}
                  </p>
                  {row.locked ? (
                    <p className="mt-1 text-[10px] font-medium tracking-wide text-muted uppercase">Core</p>
                  ) : (
                    <button type="button" onClick={() => void remove(row.id)} className="mt-1 text-xs font-semibold text-muted">
                      Remove
                    </button>
                  )}
                </div>
              </div>
              <label className="mt-3 block">
                <span className="mb-2 block text-xs font-medium tracking-wide text-muted uppercase">Update key</span>
                <div className="flex gap-2">
                  <input
                    type="password"
                    value={editKey[row.id] ?? ""}
                    onChange={(e) => setEditKey((prev) => ({ ...prev, [row.id]: e.target.value }))}
                    placeholder="New API key"
                    autoComplete="off"
                    aria-label={`Update ${row.label} key`}
                    className={fieldClass}
                  />
                  <button
                    type="button"
                    disabled={!((editKey[row.id] ?? "").trim())}
                    onClick={() => void saveKey(row.id)}
                    className="min-h-11 shrink-0 rounded-full bg-surface px-4 text-xs font-semibold text-fg disabled:opacity-40 lg:min-h-9"
                  >
                    Save
                  </button>
                </div>
              </label>
            </li>
          );
        })}
      </ul>

      <div className="mt-4 rounded-lg bg-elevated px-3 py-3">
        <p className="text-xs font-medium tracking-wide text-muted uppercase">Add API</p>
        <div className="mt-3 flex flex-col gap-3">
          <label className="block">
            <span className="mb-2 block text-xs font-medium tracking-wide text-muted uppercase">Name</span>
            <input
              value={label}
              onChange={(e) => setLabel(e.target.value)}
              placeholder="SmmKing"
              aria-label="Panel name"
              className={fieldClass}
            />
          </label>
          <label className="block">
            <span className="mb-2 block text-xs font-medium tracking-wide text-muted uppercase">API URL</span>
            <input
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://example.com/api/v2"
              aria-label="API URL"
              autoCapitalize="off"
              autoCorrect="off"
              spellCheck={false}
              className={fieldClass}
            />
          </label>
          <label className="block">
            <span className="mb-2 block text-xs font-medium tracking-wide text-muted uppercase">API key</span>
            <input
              type="password"
              value={key}
              onChange={(e) => setKey(e.target.value)}
              placeholder="Key from the panel"
              aria-label="API key"
              autoComplete="off"
              className={fieldClass}
            />
          </label>
          <button
            type="button"
            disabled={busy || !label.trim() || !url.trim() || !key.trim()}
            onClick={() => void add()}
            className="min-h-11 rounded-full bg-fg px-5 text-sm font-semibold text-accent-fg transition-transform duration-150 ease-out active:scale-[0.96] disabled:opacity-40 lg:min-h-9"
          >
            {busy ? "Saving…" : "Save API"}
          </button>
        </div>
      </div>
    </div>
  );
}

function AccessLock({ adminPw }: { adminPw: string }) {
  const [on, setOn] = useState(false);
  const [next, setNext] = useState("");
  const [again, setAgain] = useState("");
  const [busy, setBusy] = useState(false);
  const [devices, setDevices] = useState<{ id: string; name: string; at: number }[]>([]);
  const mine = deviceId();

  useEffect(() => {
    void loadSmmGate({ data: { deviceId: mine } })
      .then((g) => {
        setOn(g.locked);
        setDevices(g.devices ?? []);
      })
      .catch(() => undefined);
  }, [mine]);

  async function save(value: string) {
    const admin = adminPw.trim();
    if (!admin) {
      toast.error("Unlock admin with the default password first");
      return;
    }
    setBusy(true);
    try {
      const gate = await saveSmmGate({
        data: { admin: adminPw, password: value, deviceId: mine, name: deviceName() },
      });
      setOn(gate.locked);
      setDevices(gate.devices ?? []);
      setNext("");
      setAgain("");
      try {
        if (gate.stamp) localStorage.setItem("smm-gate-stamp", gate.stamp);
        else localStorage.removeItem("smm-gate-stamp");
      } catch {
        /* private mode */
      }
      toast.success(
        gate.locked
          ? "Access password saved. This device stays in. Other devices need the password."
          : "App lock removed",
      );
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Could not save");
    } finally {
      setBusy(false);
    }
  }

  async function revoke(id: string) {
    if (!adminPw.trim()) {
      toast.error("Unlock admin with the default password first");
      return;
    }
    setBusy(true);
    try {
      const next = await revokeSmmDevice({ data: { admin: adminPw, deviceId: id } });
      setDevices(next.devices);
      toast.success(id === mine ? "This device will ask for a password next visit" : "Device removed");
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Could not remove");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="rounded-lg bg-elevated px-3 py-3">
      <p className="text-xs font-medium tracking-wide text-muted uppercase">App lock</p>
      <p className="mt-1 text-sm text-fg">{on ? "On — each new device needs a password" : "Off — anyone with the link can open the app"}</p>
      <p className="mt-1 text-xs text-muted">
        Your chosen password unlocks a device. The default password still always works and is not replaced. Unlocking
        remembers only this device.
      </p>
      <form
        className="mt-3 flex flex-col gap-3"
        onSubmit={(e) => {
          e.preventDefault();
          if (next !== again) {
            toast.error("Passwords do not match");
            return;
          }
          void save(next.trim());
        }}
      >
        <label className="block">
          <span className="mb-2 block text-xs font-medium tracking-wide text-muted uppercase">
            {on ? "New access password" : "Set access password"}
          </span>
          <input
            type="password"
            value={next}
            onChange={(e) => setNext(e.target.value)}
            autoComplete="new-password"
            aria-label="Access password"
            className={fieldClass}
          />
        </label>
        <label className="block">
          <span className="mb-2 block text-xs font-medium tracking-wide text-muted uppercase">Type it again</span>
          <input
            type="password"
            value={again}
            onChange={(e) => setAgain(e.target.value)}
            autoComplete="new-password"
            aria-label="Confirm access password"
            className={fieldClass}
          />
        </label>
        <div className="flex flex-wrap gap-2">
          <button
            type="submit"
            disabled={busy || !next.trim()}
            className="flex min-h-11 flex-1 items-center justify-center rounded-full bg-fg px-4 text-sm font-semibold text-accent-fg disabled:opacity-40 lg:min-h-9"
          >
            {busy ? "Saving…" : "Save password"}
          </button>
          {on ? (
            <button
              type="button"
              disabled={busy}
              onClick={() => void save("")}
              className="flex min-h-11 items-center justify-center rounded-full bg-surface px-4 text-sm font-semibold text-fg ring-1 ring-border lg:min-h-9"
            >
              Remove lock
            </button>
          ) : null}
        </div>
      </form>
      {on && devices.length ? (
        <div className="mt-4">
          <p className="text-xs font-medium tracking-wide text-muted uppercase">Unlocked devices</p>
          <ul className="mt-2 flex flex-col gap-2">
            {devices.map((row) => (
              <li key={row.id} className="flex items-center justify-between gap-3 rounded-lg bg-surface px-3 py-2">
                <div className="min-w-0">
                  <p className="truncate text-sm font-semibold text-fg">
                    {row.name}
                    {row.id === mine ? " · this device" : ""}
                  </p>
                  <p className="text-[11px] text-muted">
                    {row.at
                      ? new Date(row.at).toLocaleString(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })
                      : ""}
                  </p>
                </div>
                <button
                  type="button"
                  disabled={busy}
                  onClick={() => void revoke(row.id)}
                  className="shrink-0 rounded-full bg-elevated px-3 py-1.5 text-xs font-semibold text-fg"
                >
                  Lock
                </button>
              </li>
            ))}
          </ul>
        </div>
      ) : null}
    </div>
  );
}

function StatsAccounts() {
  const profiles = useSmmProfiles((s) => s.profiles);
  const save = useSmmProfiles((s) => s.save);
  const remove = useSmmProfiles((s) => s.remove);
  const [url, setUrl] = useState("");
  const [preview, setPreview] = useState<LookedProfile | null>(null);
  const [busy, setBusy] = useState<"try" | "save" | null>(null);

  async function tryLink() {
    const href = url.trim();
    if (!href) {
      toast.error("Paste a profile link");
      return;
    }
    setBusy("try");
    setPreview(null);
    try {
      const hit = await lookupSmmProfile({ data: { url: href } });
      setPreview(hit);
      if (!hit.stats.length && !hit.avatar) toast.warning("Found the account — some stats are hidden on that platform.");
      else toast.success(`Found @${hit.handle}`);
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Could not open that profile");
    } finally {
      setBusy(null);
    }
  }

  function saveLink() {
    if (!preview) {
      toast.error("Try the link first");
      return;
    }
    setBusy("save");
    save(preview);
    setUrl("");
    setPreview(null);
    setBusy(null);
    toast.success(`Saved @${preview.handle} to Stats`);
    void syncCloudNow();
  }

  return (
    <div className="rounded-lg bg-elevated px-3 py-3">
      <p className="text-xs font-medium tracking-wide text-muted uppercase">Stats accounts</p>
      <p className="mt-1 text-xs text-muted">
        Paste a profile link, Try it, then Save. TikTok, YouTube, Instagram, Facebook, X, Telegram work.
      </p>
      <label className="mt-3 block">
        <span className="mb-2 block text-xs font-medium tracking-wide text-muted uppercase">Profile link</span>
        <input
          value={url}
          onChange={(e) => {
            setUrl(e.target.value);
            setPreview(null);
          }}
          placeholder="https://www.tiktok.com/@clauivory"
          inputMode="url"
          className={fieldClass}
        />
      </label>
      {preview ? (
        <div className="mt-3 flex items-center gap-3 rounded-xl bg-surface px-3 py-2">
          {preview.avatar ? (
            <img src={preview.avatar} alt="" referrerPolicy="no-referrer" className="size-10 rounded-full object-cover" />
          ) : (
            <TabMark id={preview.platform} selected />
          )}
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-bold text-fg">{preview.title}</p>
            <p className="truncate text-xs text-muted">
              @{preview.handle} · {preview.platform}
            </p>
          </div>
        </div>
      ) : null}
      <div className="mt-3 grid grid-cols-2 gap-2">
        <button
          type="button"
          disabled={busy != null || !url.trim()}
          onClick={() => void tryLink()}
          className="min-h-11 rounded-full bg-surface px-4 text-sm font-semibold text-fg disabled:opacity-40 lg:min-h-9"
        >
          {busy === "try" ? "Trying…" : "Try"}
        </button>
        <button
          type="button"
          disabled={busy != null || !preview}
          onClick={saveLink}
          className="min-h-11 rounded-full bg-fg px-4 text-sm font-semibold text-accent-fg disabled:opacity-40 lg:min-h-9"
        >
          Save
        </button>
      </div>
      <div className="mt-4 flex flex-col gap-2">
        {profiles.map((row) => (
          <div key={row.id} className="flex items-center gap-2 rounded-xl bg-surface px-3 py-2">
            {row.avatar ? (
              <img src={row.avatar} alt="" referrerPolicy="no-referrer" className="size-8 rounded-full object-cover" />
            ) : (
              <TabMark id={row.platform} selected />
            )}
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-semibold text-fg">{row.title || row.handle}</p>
              <p className="truncate text-xs text-muted">@{row.handle}</p>
            </div>
            <button
              type="button"
              className="rounded-full px-3 py-1 text-xs font-bold text-red-400"
              onClick={() => {
                remove(row.id);
                void syncCloudNow();
              }}
            >
              Delete
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

const SOCIAL_GUIDE: Record<
  SocialPublic["id"],
  { blurb: string; extra: string; extraPh: string; steps: { text: string; href?: string }[] }
> = {
  youtube: {
    blurb: "Free Google API key. No credit card. Unlocks exact subscribers, channel views, likes, and comments.",
    extra: "",
    extraPh: "",
    steps: [
      { text: "Open Google Cloud Console and sign in with the Google account that owns @claudiaivory.", href: "https://console.cloud.google.com/" },
      { text: "New project → name it Smm Desk.", href: "https://console.cloud.google.com/projectcreate" },
      { text: "Enable YouTube Data API v3.", href: "https://console.cloud.google.com/apis/library/youtube.googleapis.com" },
      { text: "Credentials → Create credentials → API key. Copy the AIza… key.", href: "https://console.cloud.google.com/apis/credentials" },
      { text: "Paste it below → Try → Save. Restrict the key to YouTube Data API v3 after it works." },
    ],
  },
  instagram: {
    blurb: "Professional/Creator account token. Unlocks followers and per-post likes/comments. Public pages stay as backup.",
    extra: "Instagram user ID (optional)",
    extraPh: "Leave blank — Try finds it",
    steps: [
      { text: "On the phone, Instagram → Settings → Account type → Switch to Professional (Creator is fine)." },
      { text: "Open Meta for Developers → Create app → use case “Manage messaging & content on Instagram”.", href: "https://developers.facebook.com/apps/" },
      { text: "In the app: Instagram → API setup → Generate token for @clauivory. Copy the IGAA… token.", href: "https://developers.facebook.com/docs/instagram-platform/instagram-api-with-instagram-login/get-started/" },
      { text: "Paste it below → Try → Save. Leave User ID blank unless Try asks for it." },
    ],
  },
  facebook: {
    blurb: "Never-expiring Page token. Unlocks followers and every post’s reactions, comments, shares.",
    extra: "Page ID (optional)",
    extraPh: "105894818641566",
    steps: [
      { text: "Open Graph API Explorer and pick your Meta app.", href: "https://developers.facebook.com/tools/explorer/" },
      { text: "Generate Access Token → Get Page Access Token → choose Claudia Ivory." },
      { text: "Add permissions: pages_show_list, pages_read_engagement, pages_read_user_content, read_insights." },
      { text: "Copy the token. Page ID is 105894818641566 if you want to lock it. Paste → Try → Save." },
    ],
  },
  tiktok: {
    blurb: "Login Kit user token for @clauivory. Unlocks the full video list (not just the latest 10).",
    extra: "Open ID (optional)",
    extraPh: "From the token response",
    steps: [
      { text: "Open TikTok for Developers and create a Web app.", href: "https://developers.tiktok.com/apps/" },
      { text: "Add products: Login Kit + TikTok API. Scopes: user.info.basic, video.list." },
      { text: "Set a redirect URI, authorize with @clauivory, then exchange the code for an access token.", href: "https://developers.tiktok.com/doc/login-kit-web/" },
      { text: "Paste the access_token (starts with act.) below → Try → Save. Public embed stays as backup." },
    ],
  },
};

function LiveApis() {
  const [rows, setRows] = useState<SocialPublic[]>([]);
  const [draft, setDraft] = useState<Record<string, { token: string; extra: string }>>({});
  const [busy, setBusy] = useState<string | null>(null);

  useEffect(() => {
    void loadSocialKeys()
      .then(setRows)
      .catch(() => undefined);
  }, []);

  function field(id: string) {
    return draft[id] || { token: "", extra: "" };
  }

  async function tryRow(id: SocialPublic["id"]) {
    const f = field(id);
    if (!f.token.trim()) {
      toast.error("Paste the token first");
      return;
    }
    setBusy(`try:${id}`);
    try {
      const hit = await trySocialKey({ data: { id, token: f.token, extra: f.extra } });
      toast.success(`Connected · ${hit.title}`);
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Could not connect");
    } finally {
      setBusy(null);
    }
  }

  async function saveRow(id: SocialPublic["id"]) {
    const f = field(id);
    if (!f.token.trim()) {
      toast.error("Paste the token first");
      return;
    }
    setBusy(`save:${id}`);
    try {
      const next = await saveSocialKey({ data: { id, token: f.token, extra: f.extra } });
      setRows((list) => list.map((row) => (row.id === id ? next : row)));
      setDraft((d) => ({ ...d, [id]: { token: "", extra: f.extra } }));
      toast.success("Saved · Stats will use this API live");
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Could not save");
    } finally {
      setBusy(null);
    }
  }

  async function drop(id: SocialPublic["id"]) {
    setBusy(`del:${id}`);
    try {
      await removeSocialKey({ data: { id } });
      setRows((list) => list.map((row) => (row.id === id ? { ...row, hint: "", extra: "", ready: false, until: null, status: "off", note: "" } : row)));
      toast.success("Removed");
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Could not remove");
    } finally {
      setBusy(null);
    }
  }

  return (
    <div className="rounded-lg bg-elevated px-3 py-3">
      <p className="text-xs font-medium tracking-wide text-muted uppercase">Live stats APIs</p>
      <p className="mt-1 text-xs text-muted">
        Official tokens first. Public pages stay as backup if a token is missing or fails. Do YouTube first — it is the
        fastest.
      </p>
      <div className="mt-3 flex flex-col gap-3">
        {rows.map((row) => {
          const f = field(row.id);
          const guide = SOCIAL_GUIDE[row.id];
          return (
            <div key={row.id} className="rounded-xl bg-surface px-3 py-3">
              <div className="flex items-center gap-2">
                <TabMark id={row.id} selected />
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-semibold text-fg">{row.label}</p>
                  <p className="text-[11px] text-muted">{guide.blurb}</p>
                </div>
                <span
                  className={
                    row.status === "dead"
                      ? "text-[11px] font-bold text-neon-red"
                      : row.status === "soon"
                        ? "text-[11px] font-bold text-yellow-300"
                        : row.ready
                          ? "text-[11px] font-bold text-neon-green"
                          : "text-[11px] text-muted"
                  }
                >
                  {row.status === "dead"
                    ? "Reconnect"
                    : row.status === "soon"
                      ? "Soon"
                      : row.ready
                        ? `Live ${row.hint}`
                        : "Off"}
                </span>
              </div>
              {row.note ? <p className="mt-1 text-[11px] text-muted">{row.note}</p> : null}
              <ol className="mt-2 list-decimal space-y-1 pl-4 text-[11px] leading-snug text-muted">
                {guide.steps.map((step) => (
                  <li key={step.text}>
                    {step.href ? (
                      <a href={step.href} target="_blank" rel="noreferrer" className="text-fg underline-offset-2 hover:underline">
                        {step.text}
                      </a>
                    ) : (
                      step.text
                    )}
                  </li>
                ))}
              </ol>
              <label className="mt-2 block">
                <span className="mb-1 block text-[10px] font-medium tracking-wide text-muted uppercase">Token / key</span>
                <input
                  value={f.token}
                  onChange={(e) => setDraft((d) => ({ ...d, [row.id]: { ...f, token: e.target.value } }))}
                  placeholder={row.ready ? row.hint : "Paste key"}
                  className={fieldClass}
                  autoComplete="off"
                />
              </label>
              {guide.extra ? (
                <label className="mt-2 block">
                  <span className="mb-1 block text-[10px] font-medium tracking-wide text-muted uppercase">{guide.extra}</span>
                  <input
                    value={f.extra}
                    onChange={(e) => setDraft((d) => ({ ...d, [row.id]: { ...f, extra: e.target.value } }))}
                    placeholder={row.extra || guide.extraPh}
                    className={fieldClass}
                    autoComplete="off"
                  />
                </label>
              ) : null}
              <div className="mt-2 grid grid-cols-3 gap-2">
                <button
                  type="button"
                  disabled={busy != null || !f.token.trim()}
                  onClick={() => void tryRow(row.id)}
                  className="min-h-10 rounded-full bg-elevated px-3 text-xs font-semibold text-fg disabled:opacity-40"
                >
                  {busy === `try:${row.id}` ? "Trying…" : "Try"}
                </button>
                <button
                  type="button"
                  disabled={busy != null || !f.token.trim()}
                  onClick={() => void saveRow(row.id)}
                  className="min-h-10 rounded-full bg-fg px-3 text-xs font-semibold text-accent-fg disabled:opacity-40"
                >
                  {busy === `save:${row.id}` ? "Saving…" : "Save"}
                </button>
                <button
                  type="button"
                  disabled={busy != null || !row.ready}
                  onClick={() => void drop(row.id)}
                  className="min-h-10 rounded-full px-3 text-xs font-bold text-red-400 disabled:opacity-40"
                >
                  Delete
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
