import { SmmPanels } from "@/components/smm-panels";
import { useSmmDesks } from "@/lib/smm/desks";

export function YoutubeView() {
  const desk = useSmmDesks((s) => s.desks.find((d) => d.id === "youtube"));
  if (!desk) return null;
  return (
    <div className="h-full overflow-y-auto bg-bg">
      <SmmPanels desk={desk} />
    </div>
  );
}
