import { useEffect } from "react";
import { loadSmmLive, type PanelBalance } from "@/lib/smm/fn";
import { useSmmLive } from "@/lib/smm/live-store";

function applySnapshot(raw: string) {
  try {
    const data = JSON.parse(raw) as { panels?: { id: string; label: string; balance: string; currency: string }[] };
    if (!Array.isArray(data.panels)) return;
    const panels: PanelBalance[] = [];
    for (const row of data.panels) {
      if (!row?.id) continue;
      panels.push({ id: row.id, label: row.label, balance: row.balance, currency: row.currency });
    }
    if (panels.length) useSmmLive.getState().apply(panels);
  } catch {
    /* ignore a bad frame */
  }
}

export function SmmLive() {
  const setLive = useSmmLive((s) => s.setLive);

  useEffect(() => {
    let alive = true;
    let source: EventSource | null = null;
    let fallback: number | undefined;
    let retry: number | undefined;

    async function poll() {
      try {
        const panels = await loadSmmLive();
        if (alive) {
          useSmmLive.getState().apply(panels);
          setLive(true);
        }
      } catch {
        if (alive) setLive(false);
      }
      if (alive && document.visibilityState === "visible") {
        fallback = window.setTimeout(() => {
          void poll();
        }, 3_000);
      }
    }

    let fails = 0;

    function startFallback() {
      source?.close();
      source = null;
      void poll();
    }

    function connect() {
      if (!alive || document.visibilityState !== "visible") return;
      try {
        source = new EventSource("/api/smm-live");
      } catch {
        startFallback();
        return;
      }
      source.onopen = () => {
        fails = 0;
        if (alive) setLive(true);
      };
      source.onmessage = (event) => {
        fails = 0;
        applySnapshot(event.data);
        if (alive) setLive(true);
      };
      source.onerror = () => {
        source?.close();
        source = null;
        if (!alive) return;
        fails += 1;
        if (fails >= 2) {
          startFallback();
          return;
        }
        retry = window.setTimeout(connect, 1_200);
      };
    }

    function onVis() {
      window.clearTimeout(fallback);
      window.clearTimeout(retry);
      if (document.visibilityState !== "visible") {
        source?.close();
        source = null;
        return;
      }
      if (source) return;
      connect();
    }

    document.addEventListener("visibilitychange", onVis);
    connect();

    return () => {
      alive = false;
      document.removeEventListener("visibilitychange", onVis);
      source?.close();
      window.clearTimeout(fallback);
      window.clearTimeout(retry);
      setLive(false);
    };
  }, [setLive]);

  return null;
}
