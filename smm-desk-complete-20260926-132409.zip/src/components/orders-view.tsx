import { useEffect, useId, useMemo, useRef, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { RefreshCw, Recycle, Square, ChevronLeft, ChevronRight } from "lucide-react";
import { toast } from "sonner";
import { loadLinkPreview, loadOrderLive, loadSmmLive, cancelSmmOrder, runSmmRefills, nameWithId, loadSmmOrderIndex, loadSmmOrdersRange } from "@/lib/smm/fn";
import { useSmmDesks } from "@/lib/smm/desks";
import { useSmmOrders, type SavedOrder, orderFinished } from "@/lib/smm/orders";
import { isCommentOrder } from "@/lib/smm/types";
import { useSmmLive } from "@/lib/smm/live-store";
import { syncCloudNow, useCloudStamp } from "@/components/cloud-sync";
import { formatCount } from "@/lib/format";
import { cn } from "@/lib/utils";
import { brandPath } from "@/lib/smm/wp-badges";
import { APP_TZ, addDays, dayStart, daysInMonth, msUntilNextDay, wallInZone, weekday, zoneOffsetMinutes, zonedUtc } from "@/lib/tz";

function orderName(row: { name: string; service: number; panel?: string }): string {
  return nameWithId({ id: row.service, name: row.name, panel: row.panel });
}

const WEEKDAYS = ["S", "M", "T", "W", "T", "F", "S"];
const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

function zoneStamp(now = Date.now()): { today: number; zone: string; offset: number } {
  return {
    today: dayStart(now),
    zone: APP_TZ,
    offset: zoneOffsetMinutes(now),
  };
}

function shiftMonth(year: number, month: number, delta: number) {
  const p = wallInZone(zonedUtc(year, month + delta, 1));
  return { y: p.y, m: p.m };
}

function monthCells(year: number, month: number): (number | null)[] {
  const pad = weekday(zonedUtc(year, month, 1));
  const last = daysInMonth(year, month);
  const cells: (number | null)[] = Array.from({ length: pad < 0 ? 0 : pad }, () => null);
  for (let d = 1; d <= last; d += 1) cells.push(d);
  while (cells.length % 7) cells.push(null);
  return cells;
}

function countsByDay(rows: SavedOrder[]): Map<number, number> {
  const map = new Map<number, number>();
  for (const row of rows) {
    const k = dayStart(row.at);
    map.set(k, (map.get(k) ?? 0) + 1);
  }
  return map;
}

function countsByMonth(rows: SavedOrder[], year: number): number[] {
  const out = Array.from({ length: 12 }, () => 0);
  for (const row of rows) {
    const d = wallInZone(row.at);
    if (d.y === year) out[d.m] += 1;
  }
  return out;
}

function latestDayInMonth(rows: SavedOrder[], year: number, month: number): number | null {
  let best: number | null = null;
  for (const row of rows) {
    const d = wallInZone(row.at);
    if (d.y !== year || d.m !== month) continue;
    const k = dayStart(row.at);
    if (best == null || k > best) best = k;
  }
  return best;
}

function sectionLabel(day: number, now: number, timeZone: string): string {
  const today = dayStart(now);
  const yest = addDays(today, -1);
  if (day === today) return "Today";
  if (day === yest) return "Yesterday";
  const sameYear = wallInZone(day).y === wallInZone(now).y;
  return new Intl.DateTimeFormat(undefined, {
    timeZone,
    weekday: "short",
    month: "short",
    day: "numeric",
    year: sameYear ? undefined : "numeric",
  }).format(day);
}

function formatTime(at: number, timeZone: string): string {
  const date = new Intl.DateTimeFormat("en-US", {
    timeZone,
    month: "numeric",
    day: "numeric",
    year: "numeric",
  }).format(at);
  const time = new Intl.DateTimeFormat(undefined, {
    timeZone,
    hour: "numeric",
    minute: "2-digit",
  }).format(at);
  return `(${date}) ${time}`;
}

function matchesQuery(row: SavedOrder, q: string): boolean {
  if (!q) return true;
  const hay = `${row.mediaTitle ?? ""} ${row.name} ${row.link} ${row.service}`.toLowerCase();
  return hay.includes(q);
}

function orderBrand(row: SavedOrder): string {
  const hay = `${row.desk ?? ""} ${row.name} ${row.link}`;
  if (/tiktok/i.test(hay)) return "tiktok";
  if (/youtube|youtu\.be/i.test(hay)) return "youtube";
  if (/instagram/i.test(hay)) return "instagram";
  if (/facebook|\bfb\b/i.test(hay)) return "facebook";
  if (/spotify/i.test(hay)) return "spotify";
  if (/telegram/i.test(hay)) return "telegram";
  if (/twitter|\bx\.com\b|\btweets?\b/i.test(hay)) return "twitter";
  if (/web\s*traffic|website\s*traffic|\btraffic\b/i.test(hay)) return "traffic";
  return row.desk && row.desk !== "all" && row.desk !== "orders" ? row.desk : "";
}

function threadKey(row: SavedOrder): string {
  return `${row.panel}:${row.order}`;
}

function threadsOf(rows: SavedOrder[]) {
  const map = new Map<string, SavedOrder[]>();
  for (const row of rows) {
    const k = threadKey(row);
    const list = map.get(k);
    if (list) list.push(row);
    else map.set(k, [row]);
  }
  return [...map.values()]
    .map((sends) => {
      const sorted = [...sends].sort((a, b) => b.at - a.at);
      return {
        latest: sorted[0]!,
        sends: sorted,
        qty: sorted.reduce((n, s) => n + s.quantity, 0),
      };
    })
    .sort((a, b) => b.latest.at - a.latest.at);
}

function statusShort(raw: string, kind: ReturnType<typeof statusKind>, pct: number | null, row?: SavedOrder): string {
  if (kind === "done") return "Completed";
  if (/active|drip/.test(raw.toLowerCase())) {
    const doneRuns = row?.panelRuns;
    const total = row?.runs;
    if (doneRuns && total && total > 1) return `Drip ${doneRuns}/${total}`;
    return "Active";
  }
  if (kind === "run" && pct != null) return `${pct}%`;
  const s = raw.toLowerCase();
  if (/complet|success|done|finish/.test(s)) return "Completed";
  if (/partial/.test(s)) return "Partial";
  if (/cancel/.test(s)) return "Canceled";
  if (/refund/.test(s)) return "Refund";
  if (/fail|error|reject/.test(s)) return "Failed";
  if (/progress|process|sending/.test(s)) return "Sending";
  if (/pending|wait|queue/.test(s)) return "Wait";
  return prettyStatus(raw);
}

function prettyStatus(raw: string): string {
  const s = raw.replace(/\s+/g, " ").trim();
  if (!s) return "";
  return s.replace(/\b\w/g, (c) => c.toUpperCase());
}

function statusKind(row: SavedOrder): "run" | "done" | "part" | "low" | "wait" {
  const s = (row.panelStatus ?? "").toLowerCase();
  if (/cancel|refund|fail|error|reject/.test(s)) return "low";
  if (orderFinished(row)) return "done";
  if (/partial/.test(s)) return "part";
  if (/progress|pending|process|wait|queue|sending|active|drip/.test(s)) return "run";
  if (row.remains != null && row.remains > 0) return "run";
  return "wait";
}

function progressPct(row: SavedOrder, ordered: number): number | null {
  if (ordered <= 0) return null;
  if (orderFinished(row)) return 100;
  if (/active|drip/.test((row.panelStatus ?? "").toLowerCase()) && (row.remains == null || row.remains < 0)) {
    const doneRuns = row.panelRuns;
    const total = row.runs;
    if (doneRuns && total && total > 1) return Math.min(99, Math.round((doneRuns / total) * 100));
    return 0;
  }
  if (row.remains == null || row.remains < 0) return null;
  const pct = Math.round(((ordered - row.remains) / ordered) * 100);
  return Math.min(99, Math.max(0, pct));
}

function statusWord(row: SavedOrder): string {
  if (orderFinished(row)) return row.panelStatus || "Completed";
  if (row.panelStatus) return prettyStatus(row.panelStatus);
  if (row.remains != null && row.remains > 0) return "Sending";
  return "";
}

function withTime<T>(p: Promise<T>, ms: number): Promise<T> {
  return new Promise((resolve, reject) => {
    const t = window.setTimeout(() => reject(new Error("timeout")), ms);
    p.then(
      (v) => {
        window.clearTimeout(t);
        resolve(v);
      },
      (e) => {
        window.clearTimeout(t);
        reject(e);
      },
    );
  });
}

function deskFor(order: SavedOrder): string {
  const brand = orderBrand(order);
  if (brand) return brand;
  if (order.desk && order.desk !== "all" && order.desk !== "orders") return order.desk;
  const desks = useSmmDesks.getState().desks;
  const hit = desks.find((d) => d.services.some((s) => s.panel === order.panel && s.id === order.service));
  if (hit && hit.id !== "all" && hit.id !== "orders") return hit.id;
  return "";
}

export function OrdersView() {
  const orders = useSmmOrders((s) => s.orders);
  const patchMedia = useSmmOrders((s) => s.patchMedia);
  const patchLive = useSmmOrders((s) => s.patchLive);
  const markRefilled = useSmmOrders((s) => s.markRefilled);
  const hydrate = useSmmOrders((s) => s.hydrate);
  const desks = useSmmDesks((s) => s.desks);
  const navigate = useNavigate();
  const [now, setNow] = useState(() => Date.now());
  const [query, setQuery] = useState("");
  const [picked, setPicked] = useState(() => dayStart(Date.now()));
  const [view, setView] = useState(() => {
    const d = wallInZone(Date.now());
    return { y: d.y, m: d.m };
  });
  const [yearPick, setYearPick] = useState(false);
  const [desk, setDesk] = useState("all");
  const [today, setToday] = useState(() => dayStart(Date.now()));
  const zone = APP_TZ;
  const zoneRef = useRef(zoneStamp());
  const [remoteHits, setRemoteHits] = useState<{ at: number; desk: string }[]>([]);
  const [syncing, setSyncing] = useState(false);
  const [acting, setActing] = useState<string | null>(null);
  const cloud = useCloudStamp();
  const q = query.trim().toLowerCase();

  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), 30_000);
    return () => window.clearInterval(id);
  }, []);

  useEffect(() => {
    let timer: ReturnType<typeof setTimeout>;
    const apply = () => {
      const prev = zoneRef.current;
      const next = zoneStamp();
      const zoneChanged = next.zone !== prev.zone || next.offset !== prev.offset;
      zoneRef.current = next;
      setToday(next.today);
      if (zoneChanged) {
        setPicked((pickedNow) => {
          const nextPicked = pickedNow === prev.today ? next.today : dayStart(pickedNow);
          const d = wallInZone(nextPicked);
          setView({ y: d.y, m: d.m });
          return nextPicked;
        });
      }
    };
    const arm = () => {
      clearTimeout(timer);
      timer = setTimeout(() => {
        apply();
        arm();
      }, msUntilNextDay());
    };
    const onWake = () => {
      apply();
      arm();
    };
    arm();
    document.addEventListener("visibilitychange", onWake);
    window.addEventListener("focus", onWake);
    window.addEventListener("pageshow", onWake);
    window.addEventListener("online", onWake);
    return () => {
      clearTimeout(timer);
      document.removeEventListener("visibilitychange", onWake);
      window.removeEventListener("focus", onWake);
      window.removeEventListener("pageshow", onWake);
      window.removeEventListener("online", onWake);
    };
  }, []);

  useEffect(() => {
    let alive = true;
    const missing = orders.filter((row) => row.link && row.thumb == null).slice(0, 12);
    void Promise.all(
      missing.map(async (row) => {
        try {
          const preview = await loadLinkPreview({ data: { url: row.link } });
          if (!alive) return;
          patchMedia(row.order, row.panel, { thumb: preview.thumb, mediaTitle: preview.title });
        } catch {
          if (alive) patchMedia(row.order, row.panel, { thumb: "", mediaTitle: null });
        }
      }),
    );
    return () => {
      alive = false;
    };
  }, [orders, patchMedia]);

  const platforms = useMemo(() => {
    const ids = [
      ...new Set(orders.map((row) => deskFor(row)).filter((id) => id && id !== "all" && id !== "orders")),
    ];
    return ids.map((id) => ({
      id,
      label: desks.find((d) => d.id === id)?.label ?? id.charAt(0).toUpperCase() + id.slice(1),
    }));
  }, [orders, desks]);

  const scoped = useMemo(() => {
    return orders.filter((row) => {
      if (desk !== "all" && deskFor(row) !== desk) return false;
      return matchesQuery(row, q);
    });
  }, [orders, desk, q]);

  const dayCounts = useMemo(() => {
    const map = countsByDay(scoped);
    const remote = new Map<number, number>();
    for (const hit of remoteHits) {
      if (desk !== "all" && hit.desk && hit.desk !== desk) continue;
      const k = dayStart(hit.at);
      remote.set(k, (remote.get(k) ?? 0) + 1);
    }
    for (const [k, n] of remote) map.set(k, Math.max(map.get(k) ?? 0, n));
    return map;
  }, [scoped, remoteHits, desk]);
  const monthCounts = useMemo(() => {
    const out = countsByMonth(scoped, view.y);
    const extra = Array.from({ length: 12 }, () => 0);
    for (const hit of remoteHits) {
      const d = wallInZone(hit.at);
      if (d.y !== view.y) continue;
      if (desk !== "all" && hit.desk && hit.desk !== desk) continue;
      extra[d.m] += 1;
    }
    return out.map((n, i) => Math.max(n, extra[i] ?? 0));
  }, [scoped, view.y, remoteHits, desk]);
  const years = useMemo(() => {
    const set = new Set(orders.map((row) => wallInZone(row.at).y));
    for (const hit of remoteHits) set.add(wallInZone(hit.at).y);
    const nowY = wallInZone(Date.now()).y;
    set.add(nowY);
    return [...set].sort((a, b) => b - a);
  }, [orders, remoteHits]);

  useEffect(() => {
    let alive = true;
    const start = zonedUtc(view.y, view.m, 1);
    const end = yearPick ? zonedUtc(view.y + 1, 0, 1) : zonedUtc(view.y, view.m + 1, 1);
    const from = yearPick ? zonedUtc(view.y, 0, 1) : start;
    void loadSmmOrderIndex({ data: { start: from, end, desk: desk === "all" ? "" : desk } })
      .then((rows) => {
        if (alive) setRemoteHits(rows);
      })
      .catch(() => {
        if (alive) setRemoteHits([]);
      });
    return () => {
      alive = false;
    };
  }, [view.y, view.m, yearPick, desk]);

  useEffect(() => {
    let alive = true;
    const start = picked;
    const end = addDays(picked, 1);
    void loadSmmOrdersRange({ data: { start, end, desk: desk === "all" ? "" : desk } })
      .then((rows) => {
        if (!alive || !rows.length) return;
        hydrate(rows, useSmmOrders.getState().refills);
      })
      .catch(() => {
        /* keep local */
      });
    return () => {
      alive = false;
    };
  }, [picked, hydrate, desk]);

  const filtered = useMemo(() => scoped.filter((row) => dayStart(row.at) === picked), [scoped, picked]);

  const groups = useMemo(() => {
    const threads = threadsOf(filtered);
    const map = new Map<number, ReturnType<typeof threadsOf>>();
    for (const row of threads) {
      const key = dayStart(row.latest.at);
      const list = map.get(key);
      if (list) list.push(row);
      else map.set(key, [row]);
    }
    return [...map.entries()].sort((a, b) => b[0] - a[0]);
  }, [filtered]);

  const liveKeys = useMemo(
    () => filtered.slice(0, 20).map((row) => `${row.panel}:${row.order}`).join("|"),
    [filtered],
  );

  async function refreshLive() {
    if (!liveKeys) return;
    const want = new Set(liveKeys.split("|"));
    const slice = useSmmOrders.getState().orders.filter((row) => want.has(`${row.panel}:${row.order}`));
    if (slice.length === 0) return;
    const live = await loadOrderLive({
      data: {
        orders: slice.map((row) => ({
          panel: row.panel,
          order: row.order,
          link: row.link,
          name: row.name,
          quantity: row.quantity,
        })),
      },
    });
    patchLive(live);
  }

  useEffect(() => {
    let alive = true;
    const tick = async () => {
      if (!alive) return;
      try {
        await refreshLive();
      } catch {
        /* keep last */
      }
    };
    void tick();
    const id = window.setInterval(() => void tick(), 10_000);
    return () => {
      alive = false;
      window.clearInterval(id);
    };
  }, [liveKeys, patchLive]);

  async function syncNow() {
    if (syncing) return;
    setSyncing(true);
    try {
      const live = refreshLive();
      const money = loadSmmLive().then((panels) => {
        useSmmLive.getState().apply(panels);
      });
      const cloud = syncCloudNow();
      const results = await Promise.allSettled([
        withTime(live, 10_000),
        withTime(money, 10_000),
        withTime(cloud, 8_000),
      ]);
      if (results.every((row) => row.status === "rejected")) {
        toast.error("Could not update");
      } else {
        toast.success("Updated");
      }
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Could not update");
    } finally {
      setSyncing(false);
    }
  }

  async function act(row: SavedOrder, kind: "stop" | "refill") {
    const key = `${row.panel}:${row.order}`;
    if (acting) return;
    setActing(key);
    try {
      const payload = { data: { orders: [{ panel: row.panel, order: row.order }] } };
      const res = kind === "stop" ? await cancelSmmOrder(payload) : await runSmmRefills(payload);
      if (res.ok < 1) {
        const err = res.fail[0]?.error ?? (kind === "stop" ? "Could not stop" : "Could not refill");
        if (kind === "refill" && /disabled|isn.?t available/i.test(err)) {
          patchLive([{ ...row, actual: row.actual ?? null, metric: row.metric ?? "views", refill: false }]);
          return;
        }
        toast.error(err);
        return;
      }
      if (kind === "refill") markRefilled([{ panel: row.panel, order: row.order }]);
      toast.success(kind === "stop" ? "Stop requested" : "Refill sent");
      await refreshLive();
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Could not update order");
    } finally {
      setActing(null);
    }
  }

  function orderAgain(row: SavedOrder) {
    void navigate({
      to: "/",
      search: {
        tab: deskFor(row),
        link: row.link,
        svc: `${row.panel}:${row.service}`,
      },
    });
  }

  function goMonth(delta: number) {
    const next = shiftMonth(view.y, view.m, delta);
    setView(next);
    setYearPick(false);
    const dim = daysInMonth(next.y, next.m);
    const day = Math.min(Math.max(1, wallInZone(picked).d), dim);
    setPicked(zonedUtc(next.y, next.m, day));
  }

  function goYear(delta: number) {
    setView({ y: view.y + delta, m: view.m });
  }

  function goToday() {
    const next = zoneStamp();
    zoneRef.current = next;
    setToday(next.today);
    const d = wallInZone(next.today);
    setView({ y: d.y, m: d.m });
    setYearPick(false);
    setPicked(next.today);
  }

  function pickYear(y: number) {
    setView({ y, m: view.m });
    setYearPick(true);
  }

  function pickMonth(m: number) {
    setView({ y: view.y, m });
    setYearPick(false);
    const first = zonedUtc(view.y, m, 1);
    const last = zonedUtc(view.y, m, daysInMonth(view.y, m));
    if (today >= first && today <= last) {
      setPicked(today);
      return;
    }
    const hit = latestDayInMonth(scoped, view.y, m);
    setPicked(hit ?? first);
  }

  function pickDay(ts: number) {
    setPicked(ts);
    setYearPick(false);
  }

  const monthLabel = new Intl.DateTimeFormat(undefined, {
    timeZone: zone,
    month: "long",
    year: "numeric",
  }).format(zonedUtc(view.y, view.m, 1));
  const pickedWall = wallInZone(picked);
  const todayWall = wallInZone(today);
  const pickedLabel = new Intl.DateTimeFormat(undefined, {
    timeZone: zone,
    weekday: "long",
    month: "long",
    day: "numeric",
    year: pickedWall.y === todayWall.y ? undefined : "numeric",
  }).format(picked);

  return (
    <div className="smm-scroll h-full overflow-y-auto bg-bg">
      <div className="mx-auto flex max-w-2xl flex-col gap-4 px-3 py-4 pb-10 lg:px-6">
        {orders.length === 0 ? (
          <p className="text-sm text-muted">
            {cloud.ready
              ? "Place an order on a tab. It will land here with the post and a way to send it again."
              : "Loading orders from your other devices…"}
          </p>
        ) : (
          <>
            <div className="rounded-xl bg-surface px-2 py-3 sm:px-3">
              <div className="order-cal-head">
                <button
                  type="button"
                  onClick={() => void syncNow()}
                  disabled={syncing}
                  aria-label={syncing ? "Updating orders" : "Update orders"}
                  className="order-cal-refresh"
                >
                  <RefreshCw className={syncing ? "size-5 animate-spin" : "size-5"} />
                </button>
                <div className="order-cal-month">
                  <button
                    type="button"
                    onClick={() => (yearPick ? goYear(-1) : goMonth(-1))}
                    aria-label={yearPick ? "Previous year" : "Previous month"}
                    className="order-cal-arrow is-left"
                  >
                    <ChevronLeft className="size-5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setYearPick((v) => !v)}
                    aria-pressed={yearPick}
                    className="min-h-11 shrink-0 whitespace-nowrap px-1.5 text-sm font-semibold text-fg lg:min-h-9"
                  >
                    {yearPick ? String(view.y) : monthLabel}
                  </button>
                  <button
                    type="button"
                    onClick={() => (yearPick ? goYear(1) : goMonth(1))}
                    aria-label={yearPick ? "Next year" : "Next month"}
                    className="order-cal-arrow is-right"
                  >
                    <ChevronRight className="size-5" />
                  </button>
                </div>
                {picked === today ? (
                  <span />
                ) : (
                  <button
                    type="button"
                    onClick={goToday}
                    aria-label="Today's orders"
                    className="order-cal-today"
                  >
                    Today
                  </button>
                )}
              </div>

              {!yearPick && years.length > 1 ? (
                <div className="mt-2 flex flex-wrap gap-1.5 px-1">
                  {years.map((y) => (
                    <button
                      key={y}
                      type="button"
                      aria-pressed={view.y === y}
                      onClick={() => pickYear(y)}
                      className={cn(
                        "min-h-9 rounded-full px-3 text-xs font-semibold",
                        view.y === y ? "bg-fg text-accent-fg" : "bg-elevated text-muted",
                      )}
                    >
                      {y}
                    </button>
                  ))}
                </div>
              ) : null}

              {yearPick ? (
                <div className="order-cal-mo mt-3">
                  {MONTHS.map((label, m) => {
                    const n = monthCounts[m] ?? 0;
                    const on = view.m === m;
                    return (
                      <button
                        key={label}
                        type="button"
                        onClick={() => pickMonth(m)}
                        aria-pressed={on}
                        className={cn("order-cal-mo-btn", on && "is-on", n === 0 && !on && "is-empty")}
                      >
                        <span className="text-sm font-semibold">{label}</span>
                        {n > 0 ? <span className="order-cal-count">{n > 99 ? "99+" : n}</span> : null}
                      </button>
                    );
                  })}
                </div>
              ) : (
                <div className="order-cal mt-3">
                  {WEEKDAYS.map((d, i) => (
                    <span key={`${d}-${i}`} className="order-cal-wd">
                      {d}
                    </span>
                  ))}
                  {monthCells(view.y, view.m).map((day, i) => {
                    if (day == null) return <span key={`e-${i}`} />;
                    const ts = zonedUtc(view.y, view.m, day);
                    const n = dayCounts.get(ts) ?? 0;
                    const on = ts === picked;
                    return (
                      <button
                        key={ts}
                        type="button"
                        onClick={() => pickDay(ts)}
                        aria-pressed={on}
                        aria-label={`${new Intl.DateTimeFormat(undefined, { timeZone: zone, month: "long", day: "numeric" }).format(ts)}${n ? `, ${n} orders` : ""}`}
                        className={cn(
                          "order-cal-day",
                          on && "is-on",
                          ts === today && "is-today",
                          n === 0 && "is-mute",
                        )}
                      >
                        <span className="order-cal-n">{day}</span>
                        {n > 0 ? <span className="order-cal-count">{n > 99 ? "99+" : n}</span> : null}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            <label className="block">
              <span className="sr-only">Search orders</span>
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search posts, links, services"
                aria-label="Search orders"
                className="min-h-11 w-full rounded-lg bg-elevated px-3 text-base text-fg outline-none placeholder:text-subtle"
              />
            </label>

            {platforms.length > 1 ? (
              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  aria-pressed={desk === "all"}
                  onClick={() => setDesk("all")}
                  className={cn(
                    "min-h-11 rounded-full px-4 text-sm font-semibold transition-transform duration-150 ease-out active:scale-[0.96] lg:min-h-9 lg:px-3 lg:text-xs",
                    desk === "all" ? "bg-fg text-accent-fg" : "bg-surface text-muted",
                  )}
                >
                  All tabs
                </button>
                {platforms.map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    aria-pressed={desk === p.id}
                    onClick={() => setDesk(p.id)}
                    className={cn(
                      "min-h-11 rounded-full px-4 text-sm font-semibold transition-transform duration-150 ease-out active:scale-[0.96] lg:min-h-9 lg:px-3 lg:text-xs",
                      desk === p.id ? "bg-fg text-accent-fg" : "bg-surface text-muted",
                    )}
                  >
                    {p.label}
                  </button>
                ))}
              </div>
            ) : null}

            {groups.length === 0 ? (
              <p className="text-sm text-muted">Nothing on {pickedLabel}.</p>
            ) : (
              <div className="flex flex-col gap-6">
                {groups.map(([day, rows]) => (
                  <section key={day}>
                    <h2 className="sticky top-0 z-10 bg-bg py-2 text-xs font-medium tracking-wide text-muted uppercase">
                      {sectionLabel(day, today, zone)}
                    </h2>
                    <ul className="flex flex-col gap-3">
                      {rows.map((thread) => {
                        const row = thread.latest;
                        const status = statusWord(row);
                        const kind = statusKind(row);
                        const pct = progressPct(row, row.quantity);
                        const busyKey = `${row.panel}:${row.order}`;
                        const busy = acting === busyKey;
                        return (
                          <li
                            key={threadKey(row)}
                            data-brand={orderBrand(row) || undefined}
                            className="order-tile rounded-xl bg-surface px-3 py-3 sm:px-4"
                          >
                            <div className="flex gap-3">
                              <div className="flex w-16 shrink-0 flex-col items-center gap-1.5">
                                {row.link ? (
                                  <a href={row.link} target="_blank" rel="noreferrer" aria-label="Open post">
                                    <Thumb
                                      src={row.thumb}
                                      title={row.mediaTitle || orderName(row)}
                                      link={row.link}
                                      brand={orderBrand(row)}
                                    />
                                  </a>
                                ) : (
                                  <Thumb
                                    src={row.thumb}
                                    title={row.mediaTitle || row.name}
                                    link={row.link}
                                    brand={orderBrand(row)}
                                  />
                                )}
                                {status ? (
                                  <div className="order-status">
                                    <div
                                      className={`order-status-bar is-${kind}`}
                                      role="status"
                                      title={status}
                                    >
                                      {kind === "run" || kind === "part" ? (
                                        <span className="order-status-fill" style={{ width: `${pct ?? 0}%` }} />
                                      ) : null}
                                      <span className="order-status-label">
                                        {statusShort(status, kind, pct, row)}
                                      </span>
                                    </div>
                                    {kind === "run" ? (
                                      <button
                                        type="button"
                                        className="order-status-act is-stop"
                                        disabled={busy}
                                        aria-label="Stop order"
                                        onClick={() => void act(row, "stop")}
                                      >
                                        <Square className="size-2.5 fill-current" />
                                      </button>
                                    ) : null}
                                    {row.panelRefill === true ? (
                                      <button
                                        type="button"
                                        className="order-status-act is-refill"
                                        disabled={busy}
                                        aria-label="Refill order"
                                        onClick={() => void act(row, "refill")}
                                      >
                                        <Recycle className="size-2.5" />
                                      </button>
                                    ) : null}
                                  </div>
                                ) : (
                                  <div className="order-status">
                                    <div className="order-status-bar is-wait" role="status">
                                      <span className="order-status-label">
                                        <PendingMark />
                                      </span>
                                    </div>
                                  </div>
                                )}
                              </div>
                              <div className="min-w-0 flex-1">
                                <p className="truncate text-sm font-semibold text-fg">{row.mediaTitle || orderName(row)}</p>
                                <p className="mt-0.5 text-xs text-muted">{formatTime(row.at, zone)}</p>
                                <QtyLine row={row} ordered={row.quantity} now={now} />
                                {row.mediaTitle && row.mediaTitle !== row.name ? (
                                  <p className="mt-1 truncate text-xs text-muted">{orderName(row)}</p>
                                ) : null}
                                {row.link ? (
                                  <a
                                    href={row.link}
                                    target="_blank"
                                    rel="noreferrer"
                                    className="mt-1 block truncate text-xs font-medium text-fg underline-offset-2 hover:underline"
                                  >
                                    {row.link}
                                  </a>
                                ) : null}
                              </div>
                            </div>
                            <button
                              type="button"
                              onClick={() => orderAgain(row)}
                              className="mt-3 min-h-11 w-full rounded-full bg-fg px-5 text-sm font-bold text-accent-fg transition-transform duration-150 ease-out active:scale-[0.96] lg:min-h-9 lg:text-xs"
                            >
                              Order again
                            </button>
                          </li>
                        );
                      })}
                    </ul>
                  </section>
                ))}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

function PendingMark() {
  return (
    <span className="pending-word" aria-label="Pending">
      Pending
    </span>
  );
}

function startCount(row: SavedOrder): number | null {
  if (row.startOnPost != null) return row.startOnPost;
  if (row.start != null) return row.start;
  return null;
}

function gainedOf(row: SavedOrder): number | null {
  if (!orderFinished(row)) return null;
  const start = startCount(row);
  if (start == null) return null;
  const end = row.doneOnPost ?? (row.source === "post" ? row.actual : null);
  if (end == null) return null;
  return Math.max(0, end - start);
}

function waitSpan(ms: number): string {
  const min = Math.max(0, Math.round(ms / 60_000));
  if (min < 1) return "under a minute";
  if (min < 60) return `${min} min`;
  const h = Math.floor(min / 60);
  const m = min % 60;
  if (h < 48) return m ? `${h}h ${m}m` : `${h}h`;
  const d = Math.floor(h / 24);
  const rh = h % 24;
  return rh ? `${d}d ${rh}h` : `${d}d`;
}

function viewDelay(row: SavedOrder, now: number): string | null {
  const metric = row.metric ?? (/like/i.test(row.name) ? "likes" : "views");
  if (metric !== "views") return null;
  if (startCount(row) == null) return null;
  if (row.viewsAt && row.viewsAt >= row.at) return `Views showed in ${waitSpan(row.viewsAt - row.at)}`;
  if (row.viewsClosedAt && row.viewsClosedAt >= row.at) return `Views never showed · ${waitSpan(row.viewsClosedAt - row.at)}`;
  return `Views delayed ${waitSpan(now - row.at)}`;
}

function QtyLine({ row, ordered, now }: { row: SavedOrder; ordered: number; now: number }) {
  if (isCommentOrder(row)) {
    const landed = row.remains != null ? Math.max(0, ordered - row.remains) : null;
    return (
      <div className="mt-1 text-xs text-fg">
        <p>
          <span className="text-muted">Placed </span>
          <span className="money tabular-nums">{formatCount(ordered)}</span>
          <span className="text-muted"> comments</span>
        </p>
        <p className="mt-0.5">
          {landed != null ? (
            <>
              <span className="text-muted">Landed </span>
              <span className="money tabular-nums">{formatCount(landed)}</span>
              <span className="text-muted"> of {formatCount(ordered)}</span>
            </>
          ) : (
            <>
              <span className="text-muted">Landed </span>
              <PendingMark />
            </>
          )}
        </p>
      </div>
    );
  }
  const metric = row.metric ?? (/like/i.test(row.name) ? "likes" : "views");
  const fresh = Boolean(row.actualAt && Date.now() - row.actualAt < 20_000 && row.source === "post");
  const gained = gainedOf(row);
  const done = orderFinished(row);
  const waitGain = !done || gained == null;
  const live = row.source === "post" && row.actual != null;
  const delay = viewDelay(row, now);
  return (
    <div className="mt-1 text-xs text-fg">
      <p>
        <span className="text-muted">Placed </span>
        <span className="money tabular-nums">{formatCount(ordered)}</span>
        {waitGain || gained != null ? (
          <>
            <span className="text-muted"> · Gained </span>
            {gained != null ? (
              <span key={gained} className="money tabular-nums count-pop">
                +{formatCount(gained)}
              </span>
            ) : (
              <PendingMark />
            )}
          </>
        ) : null}
      </p>
      <p className="mt-0.5">
        <span className="text-muted">On post right now </span>
        {live ? (
          <span key={row.actual} className="count-pop">
            <span className="money tabular-nums">{formatCount(row.actual!)}</span>
            <span className="text-muted"> {metric}</span>
            {fresh ? <span className="live-dot ml-1 inline-block align-middle" aria-hidden /> : null}
          </span>
        ) : (
          <PendingMark />
        )}
      </p>
      {delay ? <p className="mt-0.5 text-muted">{delay}</p> : null}
    </div>
  );
}

function Thumb({
  src,
  title,
  link,
  brand,
}: {
  src?: string | null;
  title: string;
  link: string;
  brand: string;
}) {
  const ready = Boolean(src);
  const kind = /tiktok\.com/i.test(link) ? "tt" : /youtu(\.be|be\.com)/i.test(link) ? "yt" : /instagram\.com/i.test(link) ? "ig" : "x";
  return (
    <div className="relative size-16 shrink-0">
      <div
        className={
          kind === "tt"
            ? "size-16 overflow-hidden rounded-lg bg-tt"
            : kind === "yt"
              ? "size-16 overflow-hidden rounded-lg bg-yt"
              : kind === "ig"
                ? "size-16 overflow-hidden rounded-lg bg-ig"
                : "size-16 overflow-hidden rounded-lg bg-elevated"
        }
      >
        {ready ? (
          <img src={src ?? ""} alt={title} referrerPolicy="no-referrer" className="size-full object-cover" />
        ) : (
          <span className="flex size-full items-center justify-center text-xs font-bold text-fg">
            {kind === "tt" ? "TT" : kind === "yt" ? "YT" : kind === "ig" ? "IG" : (title[0] ?? "?").toUpperCase()}
          </span>
        )}
      </div>
      <BrandMark brand={brand} />
    </div>
  );
}

function BrandMark({ brand }: { brand: string }) {
  const uid = useId();
  const d = brandPath(brand);
  if (brand === "tiktok" && d) {
    return (
      <span className="thumb-brand" aria-hidden>
        <svg viewBox="0 0 24 24" className="size-3.5">
          <path d={d} fill="#25F4EE" transform="translate(-0.7 0.4)" />
          <path d={d} fill="#FE2C55" transform="translate(0.7 -0.35)" />
          <path d={d} fill="#fff" />
        </svg>
      </span>
    );
  }
  if (brand === "instagram" && d) {
    const ig = `ig-${uid.replace(/:/g, "")}`;
    return (
      <span className="thumb-brand" aria-hidden>
        <svg viewBox="0 0 24 24" className="size-3.5">
          <defs>
            <linearGradient id={ig} x1="4" y1="20" x2="20" y2="4">
              <stop stopColor="#f58529" />
              <stop offset=".5" stopColor="#dd2a7b" />
              <stop offset="1" stopColor="#515bd4" />
            </linearGradient>
          </defs>
          <path d={d} fill={`url(#${ig})`} />
        </svg>
      </span>
    );
  }
  if (brand === "telegram") {
    return (
      <span className="thumb-brand" aria-hidden>
        <svg viewBox="0 0 24 24" className="size-3.5">
          <circle cx="12" cy="12" r="10" fill="#2AABEE" />
          <path fill="#fff" d="M7.2 11.8 16.8 8.2c.5-.2 1 .2.8.9l-1.6 7.6c-.1.6-.7.7-1.1.4l-2.4-1.8-1.3 1.3c-.2.2-.5.1-.5-.2l.1-2.6 4.5-4.1-5.6 3.5z" />
        </svg>
      </span>
    );
  }
  if (brand === "traffic") {
    return (
      <span className="thumb-brand" aria-hidden>
        <svg viewBox="0 0 24 24" className="size-3.5">
          <circle cx="12" cy="12" r="10" fill="#22D3EE" />
          <path fill="none" stroke="#0c0c0e" strokeWidth="1.4" d="M4.5 12h15M12 4.5c2.8 2.4 4.2 5 4.2 7.5S14.8 17.1 12 19.5C9.2 17.1 7.8 14.5 7.8 12S9.2 6.9 12 4.5z" />
        </svg>
      </span>
    );
  }
  const fill = brand === "youtube" ? "#FF0033" : brand === "facebook" ? "#1877F2" : brand === "twitter" ? "#fff" : brand === "spotify" ? "#1ED760" : "";
  if (!d || !fill) return null;
  return (
    <span className="thumb-brand" aria-hidden>
      <svg viewBox="0 0 24 24" className="size-3.5">
        {brand === "youtube" ? <path d="M9.4 8.3h5.4v7.4H9.4z" fill="#fff" /> : null}
        <path d={d} fill={fill} />
      </svg>
    </span>
  );
}
