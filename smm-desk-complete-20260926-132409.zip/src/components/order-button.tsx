import { useEffect, useState } from "react";
import { createPortal } from "react-dom";
import { Check } from "lucide-react";
import { cn } from "@/lib/utils";

const DUST = Array.from({ length: 28 }, (_, i) => i);

export function OrderButton({
  ready,
  busy,
  onPress,
}: {
  ready: boolean;
  busy: boolean;
  onPress: () => void;
}) {
  return (
    <span
      className={cn(
        "order-btn-wrap relative isolate inline-flex p-4 -m-4",
        ready && !busy ? "is-ready" : "",
        busy ? "is-placing" : "",
      )}
    >
      {busy ? (
        <>
          <span className="order-btn-ring" aria-hidden />
          <span className="order-btn-ring order-btn-ring-2" aria-hidden />
          <span className="order-btn-ring order-btn-ring-3" aria-hidden />
        </>
      ) : null}
      <button
        type="button"
        disabled={busy || !ready}
        onClick={onPress}
        aria-label={busy ? "Placing order" : "Place order"}
        className={cn(
          "order-btn relative isolate min-h-14 shrink-0 overflow-hidden rounded-full px-10",
          "text-lg font-bold tracking-tight text-accent-fg lg:min-h-16 lg:px-12",
          "disabled:opacity-40",
        )}
      >
        <span className="order-btn-sheen" aria-hidden />
        <span className="order-btn-sheen order-btn-sheen-2" aria-hidden />
        <span className="order-btn-dust" aria-hidden>
          {DUST.map((i) => (
            <span key={i} style={{ ["--i" as string]: i }} />
          ))}
        </span>
        <span className="order-btn-label relative z-10">{busy ? "Placing…" : "Place order"}</span>
      </button>
    </span>
  );
}

export function OrderConfirm({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [mounted, setMounted] = useState(false);

  useEffect(() => setMounted(true), []);

  useEffect(() => {
    if (!open) return;
    const t = window.setTimeout(onClose, 2800);
    return () => window.clearTimeout(t);
  }, [open, onClose]);

  if (!mounted) return null;

  return createPortal(
    <div className={cn("order-confirm", open ? "is-open" : "")} aria-hidden={!open} role="status">
      <button type="button" className="order-confirm-card" onClick={onClose} aria-label="Order confirmed">
        <span className="order-confirm-mark">
          <Check className="size-5" strokeWidth={2.6} />
        </span>
        <span className="min-w-0 text-left">
          <span className="block text-base font-bold text-fg">Order confirmed</span>
          <span className="mt-0.5 block text-sm text-muted">Ready for the next one</span>
        </span>
      </button>
    </div>,
    document.body,
  );
}

export type OrderVerifyInfo = {
  name: string;
  link: string;
  quantity: number;
  charge: string;
  panel: string;
  dripFeed?: boolean;
  drip?: string | null;
  memo?: string | null;
  thumb?: string | null;
};

export function OrderVerify({
  open,
  info,
  onYes,
  onNo,
}: {
  open: boolean;
  info: OrderVerifyInfo | null;
  onYes: () => void;
  onNo: () => void;
}) {
  const [mounted, setMounted] = useState(false);

  useEffect(() => setMounted(true), []);

  useEffect(() => {
    if (!open) return;
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") onNo();
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onNo]);

  if (!mounted || !open || !info) return null;

  return createPortal(
    <div className="order-verify" role="dialog" aria-modal="true" aria-labelledby="order-verify-title">
      <button type="button" className="order-verify-scrim" aria-label="Cancel" onClick={onNo} />
      <div className="order-verify-card">
        <p id="order-verify-title" className="text-base font-bold text-fg">
          Verify order
        </p>
        <p className="mt-1 text-sm text-muted">Check this before it goes through.</p>
        {info.thumb ? (
          <img src={info.thumb} alt="" referrerPolicy="no-referrer" className="mt-4 h-16 w-16 rounded-lg object-cover" />
        ) : null}
        <dl className="order-verify-list">
          <div>
            <dt>Service</dt>
            <dd>{info.name}</dd>
          </div>
          <div>
            <dt>Quantity</dt>
            <dd>
              {info.quantity.toLocaleString()}
              {info.dripFeed && info.drip ? (
                <span className="mt-0.5 block text-sm font-normal text-muted">{info.drip}</span>
              ) : null}
            </dd>
          </div>
          <div>
            <dt>Link</dt>
            <dd className="break-all">{info.link}</dd>
          </div>
          {info.memo ? (
            <div>
              <dt>Messages</dt>
              <dd>{info.memo}</dd>
            </div>
          ) : null}
          <div>
            <dt>Charge</dt>
            <dd className="money text-matte-green">{info.charge}</dd>
          </div>
        </dl>
        {info.dripFeed ? (
          <p className="mt-4 text-sm font-extrabold text-neon-red">
            Drip-Feed orders may cause huge delays ⚠️
          </p>
        ) : null}
        <div className="order-verify-acts">
          <button type="button" className="order-verify-yes" onClick={onYes}>
            Yes
          </button>
          <button type="button" className="order-verify-no" onClick={onNo}>
            No
          </button>
        </div>
      </div>
    </div>,
    document.body,
  );
}
