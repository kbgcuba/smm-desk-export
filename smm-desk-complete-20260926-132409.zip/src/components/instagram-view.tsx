import { useEffect, useRef, useState } from "react";
import {
  Bookmark,
  BookmarkCheck,
  Compass,
  Heart,
  Home,
  MessageCircle,
  MoreHorizontal,
  Play,
  Search,
  Send,
  User,
  X,
} from "lucide-react";
import {
  INSTAGRAM,
  STORIES,
  creator,
  postsByCreator,
  type IgPost,
  type IgStory,
} from "@/data/catalog";
import { formatCount } from "@/lib/format";
import { useSocial, withLike } from "@/lib/store";
import { cn } from "@/lib/utils";
import { BottomSheet } from "@/components/bottom-sheet";
import { CommentComposer, CommentThread } from "@/components/comment-thread";
import { IconToggle } from "@/components/icon-toggle";
import { toast } from "sonner";

type IgTab = "home" | "explore" | "reels" | "profile";

export function InstagramView() {
  const [tab, setTab] = useState<IgTab>("home");
  const [storyIndex, setStoryIndex] = useState<number | null>(null);
  const [profileId, setProfileId] = useState<string | "you">("you");
  const [commentsFor, setCommentsFor] = useState<string | null>(null);
  const [query, setQuery] = useState("");
  const commentPost = INSTAGRAM.find((p) => p.id === commentsFor);

  return (
    <div className="flex h-full justify-center bg-bg">
      <div className="flex h-full w-full max-w-lg flex-col lg:border-x lg:border-border">
        <div className="min-h-0 flex-1 overflow-hidden">
          {tab === "home" ? (
            <HomeFeed
              onStory={(i) => setStoryIndex(i)}
              onProfile={(id) => {
                setProfileId(id);
                setTab("profile");
              }}
              onComments={setCommentsFor}
            />
          ) : null}
          {tab === "explore" ? (
            <ExploreGrid
              query={query}
              onQuery={setQuery}
              onOpen={(id) => {
                setProfileId(INSTAGRAM.find((p) => p.id === id)?.creatorId ?? "you");
                setTab("profile");
              }}
            />
          ) : null}
          {tab === "reels" ? <ReelsFeed onComments={setCommentsFor} /> : null}
          {tab === "profile" ? <Profile id={profileId} onOpenComments={setCommentsFor} /> : null}
        </div>

        <nav className="z-10 flex shrink-0 items-center justify-around border-t border-border bg-bg pb-[max(0.5rem,env(safe-area-inset-bottom))]">
          {(
            [
              ["home", Home, "Home"],
              ["explore", Compass, "Explore"],
              ["reels", Play, "Reels"],
              ["profile", User, "Profile"],
            ] as const
          ).map(([id, Icon, label]) => (
            <button
              key={id}
              type="button"
              aria-label={label}
              aria-current={tab === id ? "page" : undefined}
              onClick={() => {
                if (id === "profile") setProfileId("you");
                setTab(id);
              }}
              className={cn(
                "flex min-h-12 min-w-12 items-center justify-center transition-transform duration-150 ease-out active:scale-[0.96]",
                tab === id ? "text-fg" : "text-muted",
              )}
            >
              <Icon className="size-6" strokeWidth={tab === id ? 2.4 : 2} />
            </button>
          ))}
        </nav>
      </div>

      {storyIndex !== null ? (
        <StoryViewer
          index={storyIndex}
          onClose={() => setStoryIndex(null)}
          onIndex={setStoryIndex}
        />
      ) : null}

      <BottomSheet
        open={Boolean(commentsFor)}
        onClose={() => setCommentsFor(null)}
        title="Comments"
        footer={commentsFor ? <CommentComposer postId={commentsFor} /> : null}
      >
        {commentPost ? <CommentThread postId={commentPost.id} seed={commentPost.thread} /> : null}
      </BottomSheet>
    </div>
  );
}

function HomeFeed({
  onStory,
  onProfile,
  onComments,
}: {
  onStory: (i: number) => void;
  onProfile: (id: string) => void;
  onComments: (id: string) => void;
}) {
  const viewed = useSocial((s) => s.viewedStories);

  return (
    <div className="h-full overflow-y-auto">
      <div className="flex items-center justify-between px-4 py-2">
        <h1 className="font-display text-xl font-extrabold tracking-tight text-fg">Instagram</h1>
        <button
          type="button"
          className="flex size-11 items-center justify-center text-fg transition-transform duration-150 ease-out active:scale-[0.96]"
          aria-label="Messages"
          onClick={() => toast("No new messages")}
        >
          <Send className="size-5" />
        </button>
      </div>

      <div className="flex gap-4 overflow-x-auto px-4 py-3">
        {STORIES.map((story, i) => {
          const person = creator(story.creatorId);
          const seen = Boolean(viewed[story.id]);
          return (
            <button
              key={story.id}
              type="button"
              onClick={() => onStory(i)}
              className="flex w-16 shrink-0 flex-col items-center gap-1.5 transition-transform duration-150 ease-out active:scale-[0.96]"
            >
              <span
                className={cn(
                  "flex size-16 items-center justify-center rounded-full p-0.5",
                  seen ? "ig-ring-viewed" : "ig-ring",
                )}
              >
                <img
                  src={person.avatar}
                  alt=""
                  className="size-full rounded-full border-2 border-bg object-cover"
                />
              </span>
              <span className="w-full truncate text-2xs text-fg">{person.handle}</span>
            </button>
          );
        })}
      </div>

      <div className="flex flex-col">
        {INSTAGRAM.map((post) => (
          <IgCard
            key={post.id}
            post={post}
            onProfile={() => onProfile(post.creatorId)}
            onComments={() => onComments(post.id)}
          />
        ))}
      </div>
    </div>
  );
}

function IgCard({
  post,
  onProfile,
  onComments,
}: {
  post: IgPost;
  onProfile: () => void;
  onComments: () => void;
}) {
  const person = creator(post.creatorId);
  const liked = useSocial((s) => Boolean(s.liked[post.id]));
  const saved = useSocial((s) => Boolean(s.saved[post.id]));
  const likedMap = useSocial((s) => s.liked);
  const extra = useSocial((s) => s.extraComments[post.id]);
  const toggleLike = useSocial((s) => s.toggleLike);
  const toggleSave = useSocial((s) => s.toggleSave);
  const [burst, setBurst] = useState(false);
  const lastTap = useRef(0);

  function like() {
    if (!useSocial.getState().liked[post.id]) toggleLike(post.id);
    setBurst(true);
    window.setTimeout(() => setBurst(false), 650);
  }

  return (
    <article className="border-t border-border">
      <header className="flex items-center gap-3 px-3 py-2">
        <button
          type="button"
          onClick={onProfile}
          className="flex min-w-0 flex-1 items-center gap-3 text-left"
        >
          <img src={person.avatar} alt="" className="size-9 rounded-full object-cover" />
          <span className="min-w-0">
            <span className="block truncate text-sm font-semibold text-fg">{person.handle}</span>
            {post.location ? (
              <span className="block truncate text-xs text-muted">{post.location}</span>
            ) : null}
          </span>
        </button>
        <button
          type="button"
          className="flex size-11 items-center justify-center text-fg transition-transform duration-150 ease-out active:scale-[0.96]"
          aria-label="More"
          onClick={() => toast("Not available")}
        >
          <MoreHorizontal className="size-5" />
        </button>
      </header>

      <div className="relative">
        <button
          type="button"
          className="block w-full"
          aria-label="Like post"
          onClick={() => {
            const now = Date.now();
            if (now - lastTap.current < 280) {
              lastTap.current = 0;
              like();
            } else {
              lastTap.current = now;
            }
          }}
        >
          <img src={post.image} alt="" className="aspect-[4/5] w-full object-cover" />
        </button>
        {burst ? (
          <Heart
            className="heart-burst pointer-events-none absolute top-1/2 left-1/2 size-24 -translate-x-1/2 -translate-y-1/2 text-fg"
            fill="currentColor"
          />
        ) : null}
      </div>

      <div className="flex items-center px-1">
        <button
          type="button"
          aria-label="Like"
          onClick={() => (liked ? toggleLike(post.id) : like())}
          className="flex size-11 items-center justify-center transition-transform duration-150 ease-out active:scale-[0.96]"
        >
          <IconToggle
            on={liked}
            OnIcon={Heart}
            OffIcon={Heart}
            onClass="text-heart"
            offClass="text-fg"
          />
        </button>
        <button
          type="button"
          aria-label="Comment"
          onClick={onComments}
          className="flex size-11 items-center justify-center text-fg transition-transform duration-150 ease-out active:scale-[0.96]"
        >
          <MessageCircle className="size-7" />
        </button>
        <button
          type="button"
          aria-label="Share"
          onClick={() => {
            void navigator.clipboard?.writeText(`${window.location.origin}/?tab=instagram`);
            toast("Link copied");
          }}
          className="flex size-11 items-center justify-center text-fg transition-transform duration-150 ease-out active:scale-[0.96]"
        >
          <Send className="size-6" />
        </button>
        <button
          type="button"
          aria-label="Save"
          onClick={() => toggleSave(post.id)}
          className="ml-auto flex size-11 items-center justify-center text-fg transition-transform duration-150 ease-out active:scale-[0.96]"
        >
          <IconToggle
            on={saved}
            OnIcon={BookmarkCheck}
            OffIcon={Bookmark}
            onClass="text-fg"
            offClass="text-fg"
          />
        </button>
      </div>

      <div className="px-3 pb-4">
        <p className="text-sm font-semibold text-fg tabular-nums">
          {formatCount(withLike(post.likes, post.id, likedMap))} likes
        </p>
        <p className="mt-1 text-sm text-fg">
          <button type="button" onClick={onProfile} className="font-semibold">
            {person.handle}
          </button>{" "}
          {post.caption}
        </p>
        <button type="button" onClick={onComments} className="mt-1 text-sm text-muted">
          View all comments
          {extra?.length ? ` (${post.thread.length + extra.length})` : ""}
        </button>
        <p className="mt-1 text-2xs tracking-wide text-subtle uppercase">{post.posted}</p>
      </div>
    </article>
  );
}

function ExploreGrid({
  query,
  onQuery,
  onOpen,
}: {
  query: string;
  onQuery: (v: string) => void;
  onOpen: (id: string) => void;
}) {
  const q = query.trim().toLowerCase();
  const posts = INSTAGRAM.filter((p) => {
    if (!q) return true;
    const c = creator(p.creatorId);
    return (
      p.caption.toLowerCase().includes(q) ||
      c.handle.includes(q) ||
      (p.location ?? "").toLowerCase().includes(q)
    );
  });

  return (
    <div className="h-full overflow-y-auto">
      <label className="relative mx-3 mt-3 block">
        <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted" />
        <input
          value={query}
          onChange={(e) => onQuery(e.target.value)}
          placeholder="Search"
          aria-label="Search Instagram"
          className="min-h-11 w-full rounded-lg bg-elevated pr-4 pl-10 text-sm text-fg outline-none placeholder:text-subtle"
        />
      </label>
      <div className="mt-3 grid grid-cols-3 gap-px bg-border">
        {posts.map((p) => (
          <button
            key={p.id}
            type="button"
            onClick={() => onOpen(p.id)}
            className="aspect-square overflow-hidden bg-surface active:opacity-80"
            aria-label={p.caption}
          >
            <img src={p.image} alt="" className="h-full w-full object-cover" />
          </button>
        ))}
      </div>
      {posts.length === 0 ? (
        <p className="px-4 py-10 text-center text-sm text-muted">Nothing matches that search.</p>
      ) : null}
    </div>
  );
}

function ReelsFeed({ onComments }: { onComments: (id: string) => void }) {
  return (
    <div className="h-full snap-y snap-mandatory overflow-y-auto">
      {INSTAGRAM.map((post) => (
        <ReelSlide key={post.id} post={post} onComments={() => onComments(post.id)} />
      ))}
    </div>
  );
}

function ReelSlide({ post, onComments }: { post: IgPost; onComments: () => void }) {
  const person = creator(post.creatorId);
  const liked = useSocial((s) => Boolean(s.liked[post.id]));
  const likedMap = useSocial((s) => s.liked);
  const toggleLike = useSocial((s) => s.toggleLike);
  const toggleFollow = useSocial((s) => s.toggleFollow);
  const followed = useSocial((s) => Boolean(s.followed[person.id]));

  return (
    <section className="relative h-full snap-start overflow-hidden bg-bg">
      <img src={post.image} alt="" className="kenburns absolute inset-0 h-full w-full object-cover" />
      <div className="absolute inset-0 bg-gradient-to-t from-bg via-transparent to-transparent" />
      <div className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-3 px-4 pb-6">
        <div className="min-w-0 pb-2">
          <button
            type="button"
            className="flex items-center gap-2"
            onClick={() => toggleFollow(person.id)}
          >
            <img src={person.avatar} alt="" className="size-8 rounded-full object-cover" />
            <span className="text-sm font-semibold text-fg">{person.handle}</span>
            <span className="rounded-md border border-fg/40 px-2 py-0.5 text-xs font-semibold text-fg">
              {followed ? "Following" : "Follow"}
            </span>
          </button>
          <p className="mt-2 text-sm text-fg">{post.caption}</p>
        </div>
        <div className="flex flex-col items-center gap-4">
          <button
            type="button"
            onClick={() => toggleLike(post.id)}
            className="flex flex-col items-center gap-1 text-fg transition-transform duration-150 ease-out active:scale-[0.96]"
          >
            <Heart className={cn("size-7", liked && "text-heart")} fill={liked ? "currentColor" : "none"} />
            <span className="text-2xs tabular-nums">
              {formatCount(withLike(post.likes, post.id, likedMap))}
            </span>
          </button>
          <button
            type="button"
            onClick={onComments}
            className="flex flex-col items-center gap-1 text-fg transition-transform duration-150 ease-out active:scale-[0.96]"
          >
            <MessageCircle className="size-7" />
            <span className="text-2xs tabular-nums">{formatCount(post.thread.length)}</span>
          </button>
          <button
            type="button"
            onClick={() => {
              void navigator.clipboard?.writeText(`${window.location.origin}/?tab=instagram`);
              toast("Link copied");
            }}
            className="text-fg transition-transform duration-150 ease-out active:scale-[0.96]"
            aria-label="Share"
          >
            <Send className="size-6" />
          </button>
        </div>
      </div>
    </section>
  );
}

function Profile({
  id,
  onOpenComments,
}: {
  id: string | "you";
  onOpenComments: (postId: string) => void;
}) {
  const followed = useSocial((s) => s.followed);
  const liked = useSocial((s) => s.liked);
  const toggleFollow = useSocial((s) => s.toggleFollow);
  const followingCount = Object.values(followed).filter(Boolean).length;

  if (id === "you") {
    const likedPosts = INSTAGRAM.filter((p) => liked[p.id]);
    return (
      <div className="h-full overflow-y-auto">
        <div className="px-4 py-6">
          <div className="flex items-center gap-6">
            <span className="flex size-20 items-center justify-center rounded-full bg-elevated font-display text-2xl font-extrabold text-fg">
              Y
            </span>
            <div className="flex flex-1 justify-around text-center">
              <Stat n={likedPosts.length} label="Posts" />
              <Stat n={0} label="Followers" />
              <Stat n={followingCount} label="Following" />
            </div>
          </div>
          <p className="mt-4 text-sm font-semibold text-fg">You</p>
          <p className="text-sm text-muted">Likes and follows live on this device.</p>
          {likedPosts.length === 0 ? (
            <p className="mt-10 text-center text-sm text-muted">Posts you like will collect here.</p>
          ) : (
            <div className="mt-6 grid grid-cols-3 gap-px bg-border">
              {likedPosts.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => onOpenComments(p.id)}
                  className="aspect-square overflow-hidden bg-surface"
                >
                  <img src={p.image} alt="" className="h-full w-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  }

  const person = creator(id);
  const posts = postsByCreator(id);
  const isFollowed = Boolean(followed[id]);

  return (
    <div className="h-full overflow-y-auto">
      <div className="px-4 py-6">
        <div className="flex items-center gap-6">
          <img src={person.avatar} alt="" className="size-20 rounded-full object-cover" />
          <div className="flex flex-1 justify-around text-center">
            <Stat n={posts.length} label="Posts" />
            <Stat n={person.followers} label="Followers" compact />
            <Stat n={person.following} label="Following" />
          </div>
        </div>
        <p className="mt-4 text-sm font-semibold text-fg">{person.name}</p>
        <p className="text-sm text-muted">{person.bio}</p>
        <button
          type="button"
          onClick={() => toggleFollow(id)}
          className={cn(
            "mt-4 min-h-11 w-full rounded-lg text-sm font-semibold transition-transform duration-150 ease-out active:scale-[0.96]",
            isFollowed ? "bg-elevated text-fg" : "bg-fg text-accent-fg",
          )}
        >
          {isFollowed ? "Following" : "Follow"}
        </button>
        <div className="mt-6 grid grid-cols-3 gap-px bg-border">
          {posts.map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => onOpenComments(p.id)}
              className="aspect-square overflow-hidden bg-surface"
            >
              <img src={p.image} alt="" className="h-full w-full object-cover" />
            </button>
          ))}
        </div>
        {posts.length === 0 ? (
          <p className="mt-10 text-center text-sm text-muted">No posts yet.</p>
        ) : null}
      </div>
    </div>
  );
}

function Stat({ n, label, compact }: { n: number; label: string; compact?: boolean }) {
  return (
    <div>
      <p className="text-base font-semibold text-fg tabular-nums">{compact ? formatCount(n) : n}</p>
      <p className="text-xs text-muted">{label}</p>
    </div>
  );
}

function StoryViewer({
  index,
  onClose,
  onIndex,
}: {
  index: number;
  onClose: () => void;
  onIndex: (i: number) => void;
}) {
  const story: IgStory = STORIES[index];
  const person = creator(story.creatorId);
  const markStory = useSocial((s) => s.markStory);

  useEffect(() => {
    markStory(story.id);
  }, [story.id, markStory]);

  useEffect(() => {
    const t = window.setTimeout(() => {
      if (index >= STORIES.length - 1) onClose();
      else onIndex(index + 1);
    }, 5000);
    return () => window.clearTimeout(t);
  }, [index, onClose, onIndex]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowRight") {
        if (index >= STORIES.length - 1) onClose();
        else onIndex(index + 1);
      }
      if (e.key === "ArrowLeft") {
        if (index === 0) onClose();
        else onIndex(index - 1);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [index, onClose, onIndex]);

  return (
    <div className="fixed inset-0 z-50 bg-bg">
      <img src={story.image} alt="" className="h-full w-full object-cover" />
      <div className="absolute inset-0 bg-gradient-to-b from-bg/60 via-transparent to-bg/40" />

      <div className="absolute inset-x-0 top-0 flex gap-1 px-3 pt-[max(0.75rem,env(safe-area-inset-top))]">
        {STORIES.map((s, i) => (
          <span key={s.id} className="h-0.5 flex-1 overflow-hidden rounded-full bg-fg/30">
            <span
              key={`${s.id}-${index}`}
              className={cn(
                "block h-full bg-fg",
                i < index ? "w-full" : i === index ? "progress-run" : "w-0",
              )}
              style={i === index ? { animationDuration: "5s" } : undefined}
            />
          </span>
        ))}
      </div>

      <div className="absolute inset-x-0 top-6 flex items-center gap-3 px-3 pt-[env(safe-area-inset-top)]">
        <img src={person.avatar} alt="" className="size-8 rounded-full object-cover" />
        <p className="text-sm font-semibold text-fg">{person.handle}</p>
        <button
          type="button"
          onClick={onClose}
          className="ml-auto flex size-11 items-center justify-center text-fg transition-transform duration-150 ease-out active:scale-[0.96]"
          aria-label="Close story"
        >
          <X className="size-6" />
        </button>
      </div>

      <button
        type="button"
        className="absolute top-16 bottom-0 left-0 w-1/3"
        aria-label="Previous story"
        onClick={() => {
          if (index === 0) onClose();
          else onIndex(index - 1);
        }}
      />
      <button
        type="button"
        className="absolute top-16 right-0 bottom-0 w-2/3"
        aria-label="Next story"
        onClick={() => {
          if (index >= STORIES.length - 1) onClose();
          else onIndex(index + 1);
        }}
      />
    </div>
  );
}
