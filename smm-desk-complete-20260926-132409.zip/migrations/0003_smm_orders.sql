-- Orders as rows so a year-by-year calendar can look up a day without
-- parsing the whole desk dump. Times are unix ms, matching the app clock.
create table if not exists smm_orders (
  panel text not null,
  order_id text not null,
  placed_at bigint not null,
  desk text not null default '',
  service integer not null default 0,
  name text not null default '',
  link text not null default '',
  quantity integer not null default 0,
  refill boolean not null default false,
  body jsonb not null default '{}'::jsonb,
  primary key (panel, order_id)
);

create index if not exists smm_orders_placed_at_idx on smm_orders (placed_at desc);
create index if not exists smm_orders_desk_placed_idx on smm_orders (desk, placed_at desc);
create index if not exists smm_orders_link_idx on smm_orders (link);
