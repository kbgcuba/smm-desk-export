create table if not exists smm_cloud (
  id text primary key,
  dump text not null,
  version integer not null default 0
);

insert into smm_cloud (id, dump, version)
values (
  'desk',
  '{"orders":[],"refills":[],"desks":[],"prefs":{"lastService":{},"lastQty":{},"recentLinks":[],"autoRefill":true},"panels":[],"savedAt":0}',
  0
)
on conflict (id) do nothing;
