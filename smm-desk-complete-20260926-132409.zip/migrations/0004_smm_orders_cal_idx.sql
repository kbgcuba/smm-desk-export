-- Calendar lookups only need date + tab + id. Cover those so a month
-- scan never touches the heavy jsonb body. Drop the unused link btree
-- (search is client-side; writes were paying for an index nobody queried).
drop index if exists smm_orders_placed_at_idx;
drop index if exists smm_orders_desk_placed_idx;
drop index if exists smm_orders_link_idx;

create index if not exists smm_orders_placed_cal_idx
  on smm_orders (placed_at desc)
  include (desk, panel, order_id);

create index if not exists smm_orders_desk_cal_idx
  on smm_orders (desk, placed_at desc)
  include (panel, order_id);
