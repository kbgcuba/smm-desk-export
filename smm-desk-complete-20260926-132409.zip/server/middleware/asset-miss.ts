/**
 * A missing /assets file must not be stored for a year.
 * The host otherwise caches that "not found" page, and phones keep
 * failing to open the app even after the real file is uploaded.
 */
interface AssetEvent {
  url: URL;
}

export default async function assetMiss(
  event: AssetEvent,
  next: () => unknown | Promise<unknown>,
): Promise<unknown> {
  if (!event.url.pathname.startsWith("/assets/")) return next();
  const result = await next();
  if (!(result instanceof Response)) return result;
  const type = result.headers.get("content-type") ?? "";
  if (result.status < 400 && !type.includes("text/html")) return result;
  const headers = new Headers(result.headers);
  headers.set("cache-control", "no-store");
  headers.set("cdn-cache-control", "no-store");
  return new Response(result.body, {
    status: result.status,
    statusText: result.statusText,
    headers,
  });
}
