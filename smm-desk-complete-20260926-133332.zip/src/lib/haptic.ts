function isIos(): boolean {
  if (typeof navigator === "undefined") return false;
  return /iPad|iPhone|iPod/.test(navigator.userAgent) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
}

export function buzz(ms = 12) {
  try {
    navigator.vibrate?.(ms);
  } catch {
    /* this browser has no vibration */
  }
}

/** iPhone has no vibrate API. A hidden switch under the finger buzzes on a real tap. */
export function armHaptic(el: HTMLElement | null) {
  if (!el || !isIos() || el.querySelector("[data-haptic]")) return;
  const input = document.createElement("input");
  input.type = "checkbox";
  input.setAttribute("switch", "");
  input.setAttribute("data-haptic", "");
  input.setAttribute("aria-hidden", "true");
  input.tabIndex = -1;
  Object.assign(input.style, {
    position: "absolute",
    inset: "0",
    width: "100%",
    height: "100%",
    margin: "0",
    opacity: "0",
    touchAction: "pan-x pan-y",
  });
  input.style.setProperty("-webkit-tap-highlight-color", "transparent");
  if (getComputedStyle(el).position === "static") el.style.position = "relative";
  let y = 0;
  let moved = false;
  input.addEventListener("pointerdown", (e) => {
    y = e.clientY;
    moved = false;
  }, { passive: true });
  input.addEventListener("pointermove", (e) => {
    if (Math.abs(e.clientY - y) > 10) {
      moved = true;
      input.checked = false;
    }
  }, { passive: true });
  input.addEventListener("pointerup", () => {
    if (moved) input.checked = false;
    moved = false;
  }, { passive: true });
  input.addEventListener("pointercancel", () => {
    moved = false;
    input.checked = false;
  }, { passive: true });
  el.appendChild(input);
}
